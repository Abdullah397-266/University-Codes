# MovieInsightML – Revenue Forecasting & Genre Classification

## Group Members
- **Abdullah Qadri** (23i-0089)  
- **Hanzala Hassan** (23i-0085)

---

## Project Description

MovieInsightML is a machine learning project that combines **numerical features** and **textual data** from movie datasets to solve two predictive tasks:

1. **Revenue Prediction (Regression)** – Forecasting a movie’s revenue using features such as budget, popularity, runtime, vote average, and vote count.
2. **Genre Classification (Classification)** – Predicting the main movie genre using a combination of numeric features and **TF-IDF** textual features extracted from movie overviews and keywords.

This project demonstrates end-to-end ML workflow including data preprocessing, feature engineering, model training, evaluation, visualization, and TinyML deployment readiness using TensorFlow Lite.

---

## Required Libraries / Dependencies

Ensure the following Python libraries are installed:

```bash
numpy
pandas
matplotlib
seaborn
tensorflow