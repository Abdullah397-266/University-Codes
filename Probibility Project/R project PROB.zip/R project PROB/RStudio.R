# Load Libraries
library(tidyverse)
library(DescTools)
library(magrittr)
library(ggplot2)
library(readxl)
library(GGally)
# Load the Excel file
data <- read_excel("Data.xlsx")
# Compute Summary Statistics
summary_stats <- data %>%
    reframe(
        CGPA_Mean = mean(CGPA, na.rm = TRUE),
        CGPA_Median = median(CGPA, na.rm = TRUE),
        CGPA_Mode = Mode(CGPA, na.rm = TRUE),
        CGPA_Quartiles = paste(quantile(CGPA, probs = c(0.25, 0.75), na.rm = TRUE), collapse = " - "),
        
        StudyHours_Mean = mean(studyHrs, na.rm = TRUE),
        StudyHours_Median = median(studyHrs, na.rm = TRUE),
        StudyHours_Mode = Mode(studyHrs, na.rm = TRUE),
        StudyHours_Quartiles = paste(quantile(studyHrs, probs = c(0.25, 0.75), na.rm = TRUE), collapse = " - "),
        
        SleepingHours_Mean = mean(sleepHrs, na.rm = TRUE),
        SleepingHours_Median = median(sleepHrs, na.rm = TRUE),
        SleepingHours_Mode = Mode(sleepHrs, na.rm = TRUE),
        SleepingHours_Quartiles = paste(quantile(sleepHrs, probs = c(0.25, 0.75), na.rm = TRUE), collapse = " - "),
        
        SocialMedia_Mean = mean(socialMedia, na.rm = TRUE),
        SocialMedia_Median = median(socialMedia, na.rm = TRUE),
        SocialMedia_Mode = Mode(socialMedia, na.rm = TRUE),
        SocialMedia_Quartiles = paste(quantile(socialMedia, probs = c(0.25, 0.75), na.rm = TRUE), collapse = " - "),
        
        Attendance_Mean = mean(Attendance, na.rm = TRUE),
        Attendance_Median = median(Attendance, na.rm = TRUE),
        Attendance_Mode = Mode(Attendance, na.rm = TRUE),
        Attendance_Quartiles = paste(quantile(Attendance, probs = c(0.25, 0.75), na.rm = TRUE), collapse = " - ")
    )
# print(summary_stats)
# Fit a linear regression model
# Example: Predict CGPA based on other variables
model <- lm(CGPA ~ studyHrs + sleepHrs + socialMedia + Attendance, data = data)
# Summary of the model
summary_model <- summary(model)
# Extract R-squared
r_squared <- summary_model$r.squared
# Extract Adjusted R-squared
adj_r_squared <- summary_model$adj.r.squared
# Print R-squared values
cat("R-squared:", r_squared, "\n")
cat("Adjusted R-squared:", adj_r_squared, "\n")
# Task 2: Create a Box Plot
# Exclude non-numeric columns (like `Name`) in pivot_longer
data_long <- data %>%
    select(where(is.numeric)) %>%  # Select only numeric columns
    pivot_longer(cols = everything(), names_to = "Variable", values_to = "Value")
# Create Box Plot
ggplot(data_long, aes(x = Variable, y = Value, fill = Variable)) +
    geom_boxplot(outlier.color = "red", outlier.shape = 16) +
    labs(title = "Box and Whisker Plot", x = "Variable", y = "Value") +
    theme_minimal()
# Task 3: Create a Scatter Plot
ggplot(data, aes(x = studyHrs, y = CGPA)) +
    geom_point(aes(color = socialMedia), size = 3) +
    labs(title = "Scatter Plot of Study Hours vs CGPA", x = "Study Hours", y = "CGPA") +
    theme_minimal()
ggplot(data, aes(x = sleepHrs, y = CGPA)) +
    geom_point(aes(color = socialMedia), size = 3) +
    labs(title = "Scatter Plot of Sleeping Hours vs CGPA", x = "Sleeping Hours", y = "CGPA") +
    theme_minimal()
ggplot(data, aes(x = socialMedia, y = CGPA)) +
    geom_point(aes(color = socialMedia), size = 3) +
    labs(title = "Scatter Plot of Social Media Usage vs CGPA", x = "Social Media Usage", y = "CGPA") +
    theme_minimal()