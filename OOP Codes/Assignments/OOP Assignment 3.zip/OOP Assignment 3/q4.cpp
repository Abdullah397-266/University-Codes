// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

#include <iostream>
#include <cstring>

using namespace std;

class Product
{
    int id;
    char *name;
    float price;
    int quantity;

public:
    Product()
    {
        name = new char[30];
        id = 0;
        price = 0;
        quantity = 0;
    }

    Product(int id, const char *name, float price, int quantity)
    {
        this->id = id;
        this->name = new char[strlen(name) + 1];
        strcpy(this->name, name);
        this->price = price;
        this->quantity = quantity;
    }

    // Copy constructor
    Product(const Product &p)
    {
        this->id = p.id;
        this->name = new char[strlen(p.name) + 1];
        strcpy(this->name, p.name);
        this->price = p.price;
        this->quantity = p.quantity;
    }

    void DisplayProduct()
    {
        cout << "ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Price: " << price << endl;
        cout << "Quantity: " << quantity << endl;
    }

    void setId(int id)
    {
        this->id = id;
    }

    void setName(char *name)
    {
        this->name = name;
    }

    void setPrice(float price)
    {
        this->price = price;
    }

    void setQuantity(int quantity)
    {
        this->quantity = quantity;
    }

    int getId() const
    {
        return id;
    }

    char *getName() const
    {
        return name;
    }

    float getPrice() const
    {
        return price;
    }

    int getQuantity() const
    {
        return quantity;
    }

    // ~Product()
    // {
    //     delete[] name;
    // }
};

class Inventory
{
    Product *products;
    // No. of product in the Inventory
    int count;
    // Max no. of products the Inventory can hold
    int maxSize;

public:
    Inventory(int MaxSize)
    {
        // cout << "Inventory Created" << endl;
        maxSize = MaxSize;
        products = new Product[maxSize];
        count = 0;
    }

    // a function to add a new product to the inventory with the specified ID, name, price, and quantity.
    void add_product(int id, const char *name, float price, int quantity)
    {
        cout << "Adding Product with ID: " << id << endl;
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                cout << "Product with ID: " << id << " already exists. Product Addition Failed!" << endl;
                exit(0);
            }
        }
        if (count >= maxSize)
        {
            cout << "Inventory is full, Cannot Add more" << endl;
            exit(0);
        }
        else if (quantity < 0)
        {
            cout << "Invalid Quantity, Quantity must be >= 0" << endl;
            exit(0);
        }
        else if (price <= 0)
        {
            cout << "Invalid Price, Price must be >= 0" << endl;
            exit(0);
        }

        // cout << "Value of count: " << count << endl;
        Product p1;
        products[count] = Product(id, name, price, quantity);
        count++;
        // cout << "Value of count after: " << count << endl;
        return;
    }

    // a function to add a new product to the inventory by sending a whole product.
    void add_product(Product *product)
    {
        for (int i = 0; i < count; i++)
        {
            int ID = products[i].getId();
            if (ID == product->getId())
            {
                cout << "Product with ID: " << product->getId() << " already exists. Product Addition Failed!" << endl;
                exit(0);
            }
        }
        if (count >= maxSize)
        {
            cout << "Inventory is full, Cannot Add more" << endl;
            exit(0);
        }
        else if (product->getQuantity() < 0)
        {
            cout << "Invalid Quantity, Quantity must be >= 0" << endl;
            exit(0);
        }
        else if (product->getPrice() <= 0)
        {
            cout << "Invalid Price, Price must be >= 0" << endl;
            exit(0);
        }

        products[count] = *product;
        count++;
        return;
    }

    // a function to remove a product from the inventory based on its unique identifier.
    void remove_product(int id)
    {
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                // Assigning the last product to the product after it until the last product
                for (int j = i; j < count - 1; j++)
                {
                    products[j] = products[j + 1];
                }
                cout << "Product with ID: " << id << " removed successfully" << endl;
                count--;
                return;
            }
        }
        cout << "Product with ID: " << id << " not found" << endl;
        return;
    }

    // a function to remove a/some product(s) from the inventory based on its name.
    void remove_product(const char *name)
    {
        int removed = 0;
        bool flag = false;
        for (int i = 0; i < count; i++)
        {
            if (strcmp(products[i].getName(), name) == 0) // Compare complete names
            {
                flag = true;
                // Assigning the last product to the product after it until the last product
                for (int j = i; j < count - 1; j++)
                {
                    products[j] = products[j + 1];
                }
                removed++;
                count--;
            }
        }

        if (flag)
        {
            cout << removed << " Product(s) with Name: " << name << " removed successfully" << endl;
            return;
        }
        else
        {
            cout << "Product with Name: " << name << " not found" << endl;

            return;
        }
    }

    // a function to remove a specified quantity of products based on their ID from the inventory
    void remove_product(int id, int toRemove)
    {
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                int prevQuantity = products[i].getQuantity();

                if (prevQuantity < toRemove)
                {
                    cout << "Cannot remove " << toRemove << " products, only " << prevQuantity << " products available" << endl;
                    return;
                }
                else
                {
                    products[i].setQuantity(prevQuantity - toRemove);
                }

                cout << toRemove << " Product(s) with ID: " << id << " removed successfully. New Quantity is: " << products[i].getQuantity() << endl;
                return;
            }
        }
        cout << "Product with ID: " << id << " not found" << endl;
        return;
    }

    // a function to update the quantity of a product in the inventory based on its ID. Quantity_change can be positive or negative to add or subtract from the existing quantity.
    void update_quantity(int id, int quantity_change)
    {
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                int prevQuantity = products[i].getQuantity();

                if (prevQuantity + quantity_change < 0)
                {
                    cout << "Invalid Quantity, Quantity must be >= 0" << endl;
                    return;
                }
                else
                {
                    products[i].setQuantity(prevQuantity + quantity_change);
                }

                cout << "Quantity of Product with ID: " << id << " updated successfully. New Quantity is: " << products[i].getQuantity() << endl;
                return;
            }
        }
        cout << "Product with ID: " << id << " not found" << endl;
        return;
    }

    //  a function to retrieve product information (ID, name, price, quantity) based on the specified ID.
    Product &get_product(int id)
    {
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                return products[i];
            }
        }
        cout << "Product with ID: " << id << " not found" << endl;
    }

    // a function to calculate the total value of the inventory by summing up the prices of all products.
    float calculate_inventory_value()
    {
        float totalValue = 0;
        for (int i = 0; i < count; i++)
        {
            float price = products[i].getPrice();
            int quantity = products[i].getQuantity();
            totalValue += (price * quantity);
        }
        return totalValue;
    }

    // – a function to display the entire product catalogue, including ID, name, price, and quantity
    void display_catalogue()
    {
        cout << "ID\tName\t\tPrice\tQuantity" << endl;
        for (int i = 0; i < count; i++)
        {
            cout << products[i].getId() << "\t" << products[i].getName() << "\t" << products[i].getPrice() << "\t" << products[i].getQuantity() << endl;
        }
        return;
    }

    // Destructor
    ~Inventory()
    {
        delete[] products;
        delete[] products->getName();
    }
};

int main()
{
    Inventory inv(10);

    cout << endl;
    cout << "Adding Products to Inventory by arguments" << endl;
    inv.add_product(1, "Product1", 100, 10);
    inv.add_product(2, "Product2", 200, 20);
    inv.add_product(3, "Product3", 300, 30);
    inv.add_product(4, "Product4", 400, 40);
    inv.add_product(5, "Product5", 500, 50);
    inv.add_product(6, "Product6", 600, 60);
    inv.add_product(7, "Product7", 700, 70);
    inv.add_product(8, "Product8", 800, 80);
    inv.add_product(9, "Product9", 900, 90);
    inv.add_product(10, "Product10", 1000, 100);
    cout << endl;

    inv.display_catalogue();
    cout << endl;

    cout << "Removing Products from Inventory by ID" << endl;
    inv.remove_product(1);
    inv.remove_product(2);
    inv.remove_product(3);
    inv.remove_product(4);
    inv.remove_product(5);
    cout << endl;

    cout << "Removing Products from Inventory by Name" << endl;
    inv.remove_product("Product6");
    inv.remove_product("Product7");
    inv.remove_product("Product8");
    inv.remove_product("Product9");
    inv.remove_product("Product10");
    cout << endl;

    inv.display_catalogue();
    cout << endl;

    cout << "Adding Products to Inventory" << endl;
    inv.add_product(1, "Product1", 100, 10);
    inv.add_product(2, "Product2", 200, 20);
    inv.add_product(3, "Product3", 300, 30);
    inv.add_product(4, "Product4", 400, 40);
    inv.add_product(5, "Product5", 500, 50);
    cout << endl;

    inv.display_catalogue();
    cout << endl;

    cout << "Removing Products from Inventory by Quantity" << endl;
    inv.remove_product(1, 5);
    inv.remove_product(2, 10);
    inv.remove_product(3, 15);
    inv.remove_product(4, 20);
    inv.remove_product(5, 25);
    cout << endl;

    inv.display_catalogue();
    cout << endl;

    cout << "updating the Quantity of Products" << endl;
    inv.update_quantity(1, 5);
    inv.update_quantity(2, 10);
    inv.update_quantity(3, 15);
    inv.update_quantity(4, 20);
    inv.update_quantity(5, 25);
    cout << endl;

    cout << "Getting the Product and Displaying its Info" << endl;
    Product p1 = inv.get_product(1);
    p1.DisplayProduct();
    cout << endl;

    cout << "Calculating Inventory Value" << endl;
    cout << "Total Inventory Value: " << inv.calculate_inventory_value() << endl;
    cout << endl;
}