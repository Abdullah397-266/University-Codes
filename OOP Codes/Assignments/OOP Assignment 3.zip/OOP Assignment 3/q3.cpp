// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
using namespace std;

class HotelBooking
{
    string bookingID;
    string customerName;
    string hotelName;
    string roomType;
    string checkInDate;
    string checkOutDate;
    int stayDuration;
    double roomRate;

public:
    HotelBooking(string bookingID, string customerName, string hotelName, string roomType, string checkIn, string checkOut)
    {
        this->bookingID = bookingID;
        this->customerName = customerName;
        this->hotelName = hotelName;
        this->roomType = roomType;
        this->checkInDate = checkIn;
        this->checkOutDate = checkOut;
    }

    bool validateBookingID() const
    {
        string ID = bookingID;
        if (ID.length() == 14)
        {
            // checking characters
            for (int i = 0; i < 8; i++)
            {
                if (isalpha(ID[i]))
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }

            // Checking special characters
            for (int i = 8; i < 10; i++)
            {
                if (((int)ID[i] >= 32 && (int)ID[i] <= 47) || ((int)ID[i] >= 58 && (int)ID[i] <= 64) || ((int)ID[i] >= 91 && (int)ID[i] <= 96) || ((int)ID[i] >= 123 && (int)ID[i] <= 126))
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }

            // Checking digits
            int sum = 0;
            for (int i = 10; i < 14; i++)
            {
                if (isdigit(ID[i]))
                {
                    sum += ((int)ID[i] - 48);
                    if (sum >= 18)
                    {
                        return false;
                    }
                    continue;
                }
                else
                {
                    return false;
                }
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    void calculateRoomRate()
    {
        if (roomType == "Single")
        {
            roomRate = 1000;
        }
        else if (roomType == "Double")
        {
            roomRate = 2000;
        }
        else if (roomType == "Suite")
        {
            roomRate = 3000;
        }
    }

    void calcStayDuration()
    {
        stayDuration = stoi(checkOutDate) - stoi(checkInDate);
    }

    void calculateTotalCost()
    {
        cout << "Total Cost: " << (stayDuration * roomRate) << endl;
    }

    void getBookingDetails()
    {
        if (!(validateBookingID()))
        {
            cout << "Invalid Booking ID" << endl;
            exit(0);
        }
        cout << "Booking ID: " << bookingID << endl;
        cout << "Customer Name: " << customerName << endl;
        cout << "Hotel Name: " << hotelName << endl;
        cout << "Room Type: " << roomType << endl;
        cout << "Check In Date: " << checkInDate << endl;
        cout << "Check Out Date: " << checkOutDate << endl;
        calcStayDuration();
        cout << "Stay Duration: " << stayDuration << endl;
        calculateRoomRate();
        cout << "Room Rate: " << roomRate << endl;
        calculateTotalCost();
    }

    void updateBookingInfo()
    {
        int update = 0;
        cout << "Choose to update:" << endl
             << "1. BookingID" << endl
             << "2. Name" << endl
             << "3. Hotel Name"
             << "4. Room" << endl
             << "5. Check-In Date" << endl
             << "6. Check-Out date" << endl
             << "Enter (1-6) : ";
        if (cin >> update)
        {
            if (update < 1 || update > 6)
            {
                cout << "Invalid Input! Choose between 1 and 6 only" << endl;
                exit(0);
            }
        }
        else
        {
            cout << "Invalid Input!" << endl;
            exit(0);
        }

        if(update == 1)
        {
            cout << "Enter new Booking ID: ";
            cin >> bookingID;
        }
        else if(update == 2)
        {
            cout << "Enter new Name: ";
            cin >> customerName;
        }
        else if(update == 3)
        {
            cout << "Enter new Hotel Name: ";
            cin >> hotelName;
        }
        else if(update == 4)
        {
            int choice = 0;
            cout << "Choose your room type:" << endl
                 << "1. Room with Single Bed ($1000)" << endl
                 << "2. Room with Double bed ($2000)" << endl
                 << "3. Suite ($3000)" << endl
                 << "Enter (1-3) : ";
            if (cin >> choice)
            {
                if (choice > 3 || choice < 1)
                {
                    cout << "Invalid Input! Choose between 1 and 3 only" << endl;
                    return;
                }
            }
            else
            {
                cout << "Invalid Input!" << endl;
                return;
            }

            if (choice == 1)
            {
                roomType = "Single";
            }
            else if (choice == 2)
            {
                roomType = "Double";
            }
            else
            {
                roomType = "Suite";
            }
        }
        else if(update == 5)
        {
            cout << "Enter new Check-In date: ";
            cin >> checkInDate;
        }
        else
        {
            cout << "Enter new Check-Out date: ";
            cin >> checkOutDate;
        
        }

        if(stoi(checkInDate) > stoi(checkOutDate))
        {
            cout << "Check-Out date should be greater than Check-In" << endl;
            exit(0);
        }

        cout << "Do you want to update more? (Y/N): ";
        char ch;
        cin >> ch;
        if (ch == 'Y' || ch == 'y')
        {
            updateBookingInfo();
        }
        else
        {
            getBookingDetails();
        }
    }
};

int main()
{
    string ID, name, hotel, room, checkIn, checkOut;

    cout << "Enter booking ID (8 char, 2 special char, 4 numbers): ";
    cin >> ID;
    cout << endl;

    cout << "Enter Name: ";
    cin >> name;
    cout << endl;

    cout << "Enter Hotel Name: ";
    cin >> hotel;
    cout << endl;

    int choice = 0;
    cout << "Choose your room type:" << endl
         << "1. Room with Single Bed ($1000)" << endl
         << "2. Room with Double bed ($2000)" << endl
         << "3. Suite ($3000)" << endl
         << "Enter (1-3) : ";
    if (cin >> choice)
    {
        if (choice > 3 || choice < 1)
        {
            cout << "Invalid Input! Choose between 1 and 3 only" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input!" << endl;
        return 0;
    }

    if (choice == 1)
    {
        room = "Single";
    }
    else if (choice == 2)
    {
        room = "Double";
    }
    else
    {
        room = "Suite";
    }
    cout << endl;

    cout << "Enter check-In date: ";
    cin >> checkIn;
    cout << endl;

    cout << "Enter check-Out date: ";
    cin >> checkOut;
    cout << endl;

    if (stoi(checkIn) > stoi(checkOut))
    {
        cout << "Check-Out date should be greater than Check-In" << endl;
        return 0;
    }

    HotelBooking h1(ID, name, hotel, room, checkIn, checkOut);
    h1.getBookingDetails();

    cout << endl;
    h1.updateBookingInfo();
}