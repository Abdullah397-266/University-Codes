// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

#include <iostream>
#include <cstring>

using namespace std;

class String
{
private:
    char *str;
    int length;

public:
    String() : str(nullptr), length(0)
    {
    }

    String(int size)
    {
        if (size <= 0)
        {
            cout << "Invalid size, must be > 0" << endl;
            return;
        }
        str = new char[size];
        length = size;
    }

    String(const char *str)
    {
        this->str = new char[strlen(str) + 1];
        strcpy(this->str, str);
        length = strlen(str);
    }

    ~String()
    {
        if (str != nullptr)
        {
            delete[] str;
            str = nullptr;
        }
    }

    int strLength() const
    {
        return length;
    }

    // should clear the data in your string class (data and length)
    void clear()
    {
        if (length == 0)
        {
            cout << "String is already empty" << endl;
            return;
        }

        str = nullptr;
        length = 0;
    }

    // this method should check to see if data within the String class is empty or not
    bool empty()
    {
        if (length == 0)
        {
            return true;
        }
        return false;
    }

    // this method returns the index at which this character first occurs in the string
    int charAt(char c)
    {
        for (int i = 0; i < length; i++)
        {
            if (str[i] == c)
            {
                return i;
            }
        }
        cout << "Character not found" << endl;
    }

    // a getter to get the actual string
    char *getdata()
    {
        return str;
    }

    // this method compares if the data in the calling string object is equal to str
    bool equals(char *str)
    {
        if (length == strlen(str))
        {
            for (int i = 0; i < length; i++)
            {
                if (str[i] != this->str[i])
                {
                    return false;
                }
            }
            return true;
        }
        else
        {
            cout << "Strings are not equal" << endl;
            return false;
        }
    }

    bool equalsIgnoreCase(char *str)
    {
        if (length == strlen(str))
        {
            for (int i = 0; i < length; i++)
            {
                // str[i] != this->str[i] && str[i] != this->str[i] + 32 && str[i] != this->str[i] - 32
                if (this->str[i] == str[i] || this->str[i] == str[i] + 32 || this->str[i] == str[i] - 32)
                {
                    continue;
                }
                else
                {
                    cout << "Strings are not equal" << endl;
                    return false;
                }
            }
            return true;
        }
        else
        {
            cout << "Strings are not equal" << endl;
            return false;
        }
    }

    // this method should search for substr in data within the calling String object starting from the startIndex. The method should search for the substring from the startIndex and return the substring from the position found till the end. For example, if you had the string “awesome” and you wanted to find the substring ‘es’ starting from the beginning of the string (startIndex = 0). Your function should return “esome”. Returns NULL if the substring is not found.
    char *substring(char *substr, int startIndex)
    {
        if (startIndex < 0 || startIndex > length)
        {
            cout << "Invalid start index" << endl;
            return NULL;
        }

        char *sub = new char[strlen(str) - strlen(substr)];
        int index = -1; // Invalid value for debugging
        bool check = false;

        for (int i = startIndex; str[i] != '\0'; i++)
        {
            if (this->str[i] == substr[startIndex])
            {
                index = i;
                for (int j = 1; substr[j] != '\0'; j++)
                {
                    if (substr[j] == this->str[j + i])
                    {
                        check = true;
                    }
                    else
                    {
                        check = false;
                        break;
                    }
                }
                if (check)
                {
                    break;
                }
            }
        }

        if (check)
        {
            cout << "Substring found at index: " << index << endl;
            for (int k = index; str[k] != '\0'; k++)
            {
                sub[k - index] = str[k];
                if (this->str[k + 1] == '\0')
                {
                    sub[k - index + 1] = '\0';
                    break;
                }
            }
            return sub;
        }
        else
        {
            cout << "Substring not found" << endl;
            delete[] sub;
            return NULL;
        }
    }

    // this method should search for substr in data within the calling String object between the startIndex and endIndex. For example, if you had the string “awesome” and you wanted to find the substring ‘es’ starting from startIndex=2 and endIndex=5. Your function should return “esom”. Returns NULL if substring is not found.
    char *substring(char *substr, int startIndex, int endIndex)
    {
        if (startIndex < 0 || startIndex > length || endIndex < 0 || endIndex > length)
        {
            cout << "Invalid start or end index" << endl;
            return NULL;
        }
        if (startIndex > endIndex)
        {
            cout << "Start index cannot be greater than end index" << endl;
            return NULL;
        }

        char *sub = new char[endIndex - startIndex + 1];
        int index = -1; // Invalid value for debugging
        bool check = false;

        for (int i = startIndex; i <= endIndex; i++)
        {
            if (this->str[i] == substr[startIndex])
            {
                index = i;
                for (int j = 1; substr[j] != '\0'; j++)
                {
                    if (substr[j] == this->str[j + i])
                    {
                        check = true;
                    }
                    else
                    {
                        check = false;
                        break;
                    }
                }
                if (check)
                {
                    break;
                }
            }
        }

        if (check)
        {
            cout << "Substring found at index: " << index << endl;
            for (int k = index; k <= endIndex; k++)
            {
                sub[k - index] = str[k];
                if (k == endIndex)
                {
                    sub[k - index + 1] = '\0';
                    break;
                }
            }
            return sub;
        }
        else
        {
            cout << "Substring not found" << endl;
            delete[] sub;
            return NULL;
        }
    }

    void toUpperCase()
    {
        // cout << str << endl;
        for (int i = 0; i < length; i++)
        {
            if (str[i] >= 'a' && str[i] <= 'z')
            {
                str[i] -= 32;
            }
        }
    }

    void toLowerCase()
    {
        for (int i = 0; i < length; i++)
        {
            if (str[i] >= 'A' && str[i] <= 'Z')
            {
                str[i] = str[i] + 32;
            }
        }
    }

    bool startsWith(char *substr) const
    {
        for (int i = 0; substr[i] != '\0'; i++)
        {
            if (str[i] != substr[i])
            {
                return false;
            }
        }
        return true;
    }

    bool endsWith(char *substr) const
    {
        int j = 0;
        for (int i = (length - strlen(substr)); i < length; i++)
        {
            if (str[i] != substr[j])
            {
                return false;
            }
            j++;
        }
        return true;
    }

    void concatenate(char *str)
    {
        char *temp = new char[length + strlen(str) + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->str[i];
        }
        for (int i = 0; str[i] != '\0'; i++)
        {
            temp[length + i] = str[i];
            if (str[i + 1] == '\0')
            {
                temp[length + i + 1] = '\0';
                break;
            }
        }

        delete[] this->str;
        this->str = temp;
        //delete[] temp;
        //temp = nullptr;
        length = length + strlen(str);
    }

    // this method should print the string to the console
    void print()
    {
        if (length == 0)
        {
            cout << "NULL" << endl;
            return;
        }
        for (int i = 0; i < length; i++)
        {
            cout << str[i];
        }
        cout << endl;
    }

    void insert(int index, char *str)
    {
        if (index < 0 || index > length)
        {
            cout << "Invalid index" << endl;
            return;
        }

        char *temp = new char[length + strlen(str) + 1];
        for (int i = 0; i < length + strlen(str); i++)
        {
            if (i < index)
            {
                temp[i] = this->str[i];
            }
            else if (i >= index && i < index + strlen(str))
            {
                temp[i] = str[i - index];
            }
            else
            {
                temp[i] = this->str[i - strlen(str)];
            }
            if (i == length + strlen(str) - 1)
            {
                temp[i + 1] = '\0';
                break;
            }
        }

        delete[] this->str;
        this->str = temp;
        //delete[] temp;
        //temp = nullptr;
        length = length + strlen(str);
    }

    // this method removes all occurrences of the specified substring from the current string. If the substring is found, it is removed; otherwise, the string remains unchanged.
    void remove(char *substr)
    {
        bool check = false;
        bool majorCheck = false;
        int count = 0;
        int tempLength = length;

        for (int i = 0; i < length; i++)
        {
            check = false;
            count = 0;
            if (str[i] == substr[0])
            {
                count = 1; // becz we already found the first character
                for (int j = 1; substr[j] != '\0'; j++)
                {
                    if (str[i + j] == substr[j])
                    {
                        check = true;
                        count++;
                    }
                    else
                    {
                        check = false;
                        break;
                    }
                }
                if (check)
                {
                    majorCheck = true;
                    for (int k = i; k <= (count + i); k++)
                    {
                        str[k] = str[k + count];
                        tempLength -= 1;
                    }
                }
            }
        }

        if (!majorCheck)
        {
            cout << "Substring not found" << endl;
            return;
        }
        else
        {
            length = tempLength + 1;
        }
    }

    // Removes any leading and trailing whitespace characters from the current string
    void trim()
    {
        for (int i = 0; i < length; i++)
        {
            if (str[i] == ' ')
            {
                for (int j = i; j < length; j++)
                {
                    str[j] = str[j + 1];
                }
                length -= 1;
            }
        }
    }
};

int main()
{
    // making a string
    cout << "String s1: ";
    String s1((char*)"Hello World");
    s1.print();
    cout << endl;

    // clearing the string
    cout << "Clearing the string: ";
    s1.clear();
    if (s1.empty())
    {
        cout << "String is empty" << endl;
    }
    cout << endl;

    // Testing charAt function
    cout << "Testing charAt function: " << endl;
    cout << "String s2: ";
    String s2((char*)"Hello World");
    s2.print();
    cout << "Index of \"W\": " << s2.charAt('W') << endl;
    cout << endl;

    // Testing equals function
    cout << "Testing equals function:" << endl;
    cout << "String s3: ";
    String s3((char*)"Hello World");
    s3.print();
    cout << "Comparing s3 with \"Helo Wod\": ";
    if (s3.equals((char*)"Helo Wod"))
    {
        cout << "Strings are equal" << endl;
    }
    else
    {
        cout << "Strings are not equal" << endl;
    }
    cout << "Comparing s3 with \"Hello World\": ";
    if (s3.equals((char*)"Hello World"))
    {
        cout << "Strings are equal" << endl;
    }
    else
    {
        cout << "Strings are not equal" << endl;
    }
    cout << endl;

    // Testing equalsIgnoreCase function
    cout << "Testing equalsIgnoreCase function: " << endl;
    cout << "String s4: ";
    String s4((char*)"Hello World");
    s4.print();
    cout << "Comparing s4 with \"hElLo wOrLd\": ";
    if (s4.equalsIgnoreCase((char*)"hElLo wOrLd"))
    {
        cout << "Strings are equal" << endl;
    }
    else
    {
        cout << "Strings are not equal" << endl;
    }
    cout << endl;

    // Testing toUpperCase function
    cout << "Testing toUpperCase function: " << endl;
    cout << "String s5: ";
    String s5((char*)"Hello World");
    s5.print();
    cout << "Converting to uppercase: ";
    s5.toUpperCase();
    s5.print();
    cout << endl;

    // Testing toLowerCase function
    cout << "Testing toLowerCase function: " << endl;
    cout << "String s6: ";
    String s6((char*)"HeLlO WoRLd");
    s6.print();
    cout << "Converting to lowercase: ";
    s6.toLowerCase();
    s6.print();
    cout << endl;

    // Testing substring function
    cout << "Testing substring function: " << endl;
    String s7((char*)"Hello World");
    char *ptr = s7.substring((char*)"ell", 0);
    if (ptr != NULL)
    {
        for (int i = 0; ptr[i] != '\0'; i++)
        {
            cout << ptr[i];
        }
        cout << endl;
    }
    else
    {
        cout << "Null pointer returned" << endl;
    }
    delete[] ptr;
    cout << endl;

    // Testing substring function with end Index
    cout << "Testing substring function with end Index: " << endl;
    String s8((char*)"Hello World");
    char *ptr1 = s8.substring((char*)"ell", 0, 8);
    if (ptr1 != NULL)
    {
        for (int i = 0; ptr1[i] != '\0'; i++)
        {
            cout << ptr1[i];
        }
        cout << endl;
    }
    else
    {
        cout << "Null pointer returned" << endl;
    }
    cout << endl;
    delete[] ptr1;

    // Testing startsWith function
    cout << "Testing startsWith function: " << endl;
    cout << "String s9: ";
    String s9((char*)"Hello World");
    s9.print();
    cout << "Checking if s9 starts with \"Hello\": ";
    if (s9.startsWith((char*)"Hello"))
    {
        cout << "String starts with \"Hello\"" << endl;
    }
    else
    {
        cout << "String does not start with \"Hello\"" << endl;
    }
    cout << endl;

    // Testing endsWith function
    cout << "Testing endsWith function: " << endl;
    cout << "String s10: ";
    String s10((char*)"Hello World");
    s10.print();
    cout << "Checking if s10 ends with \"rld\": ";
    if (s10.endsWith((char*)"rld"))
    {
        cout << "String ends with \"rld\"" << endl;
    }
    else
    {
        cout << "String does not end with \"rld\"" << endl;
    }
    cout << endl;

    // Testing concatenate function
    cout << "Testing concatenate function: " << endl;
    cout << "String s11: ";
    String s11((char*)"Hello");
    s11.print();
    cout << "Concatenating \" World\": ";
    s11.concatenate((char*)" World");
    s11.print();
    cout << endl;

    // Testing insert function
    cout << "Testing insert function: " << endl;
    cout << "String s12: ";
    String s12((char*)"Hello");
    s12.print();
    cout << "Inserting \" WORLD \" at index 3: ";
    s12.insert(3, (char*)"WORLD");
    s12.print();
    cout << endl;

    // Testing remove function
    cout << "Testing remove function: " << endl;
    cout << "String s13: ";
    String s13((char*)"Hlolololo");
    s13.print();
    cout << "Removing \"lo\": ";
    s13.remove((char*)"lo");
    s13.print();
    cout << endl;

    // Testing trim function
    cout << "Testing trim function: " << endl;
    cout << "String s14: ";
    String s14((char*)"H e l l o W o r l d");
    s14.print();
    cout << "Trimming the string: ";
    s14.trim();
    s14.print();
    cout << endl;

    return 0;
}