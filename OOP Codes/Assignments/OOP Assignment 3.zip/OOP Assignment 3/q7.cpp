// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

// 72 for H (Hidden)
// 70 for F (Flag)
// 77 for M (Mine)
// 48-57 for 0-9 (Number of mines around)
// 82 for R (Revealed)

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
void Input(int &size, int &mines);

class Minesweeper
{
    int  size;
    int mines;
    int **Grid;
    int **minesArr;
    bool win;

public:
    Minesweeper(int size, int mines) : size(size), mines(mines), Grid(nullptr), minesArr(nullptr), win(false)
    {
        prepareGrid();
    }

    ~Minesweeper()
    {
        for (int i = 0; i < size; i++)
        {
            delete[] Grid[i];
        }
        delete[] Grid;

        for (int i = 0; i < mines; i++)
        {
            delete[] minesArr[i];
        }
        delete[] minesArr;
    }

    void prepareGrid()
    {
        Grid = new int *[size];
        for (int i = 0; i < size; i++)
        {
            Grid[i] = new int[size];
            for (int j = 0; j < size; j++)
            {
                Grid[i][j] = 72; // 72 for H (Hidden)
            }
        }

        minesArr = new int *[mines];
        for (int i = 0; i < mines; i++)
        {
            minesArr[i] = new int[2];
        }

        // Placing mines
        int x, y;

        for (int i = 0; i < mines; i++)
        {
            x = rand() % size;
            y = rand() % size;

            if (Grid[x][y] == 77) // 77 for M (Mine)
            {
                i--;
            }
            else
            {
                minesArr[i][0] = x;
                minesArr[i][1] = y;
                Grid[x][y] = 77; // 77 for M (Mine)
            }
        }

        // // Temporarily revealing mines for testing
        // {
        //     for (int i = 0; i < size; i++)
        //     {
        //         for (int j = 0; j < size; j++)
        //         {
        //             if (Grid[i][j] != 77)
        //             {
        //                 Grid[i][j] = 0;
        //             }
        //         }
        //     }
        // }
    }

    void dispalyGrid()
    {
        cout << "  ";
        for (int i = 0; i < size; i++)
        {
            cout << i << " ";
        }
        cout << endl;

        for (int i = 0; i < size; i++)
        {
            cout << i << " ";
            for (int j = 0; j < size; j++)
            {
                if (Grid[i][j] == 72) // 72 for H (Hidden)
                    cout << "H ";
                else if (Grid[i][j] == 70) // 70 for F (Flag)
                    cout << "F ";
                else if (Grid[i][j] == 77) // 77 for M (Mine)
                    cout << "H ";
                else if (Grid[i][j] == 82 || Grid[i][j] == 0) // 82 for R (Revealed)
                    cout << "  ";
                else
                    cout << Grid[i][j] << " ";
            }
            cout << endl;
        }
    }

    void reset()
    {
        system("cls");
        cout << "Game Reset Successfully" << endl;
        prepareGrid();
        return;
    }

    void revealAll() const
    {
        system("cls");
        cout << "Game Over" << endl;

        cout << "  ";
        for (int i = 0; i < size; i++)
        {
            cout << i << " ";
        }
        cout << endl;

        for (int i = 0; i < size; i++)
        {
            cout << i << " ";
            for (int j = 0; j < size; j++)
            {
                if (Grid[i][j] == 77) // 77 for M (Mine)
                    cout << "* ";
                else
                    cout << "  ";
            }
            cout << endl;
        }
        cout << "Result: ";
        if (win)
            cout << "You Win" << endl;
        else
            cout << "You Lose" << endl;
        exit(0);
    }

    void revealCell()
    {
        cout << "Enter the cell to reveal (x y): ";
        int x, y;
        if (cin >> y >> x) // x and y are swapped because of the display
        {
            if (x < 0 || x >= size || y < 0 || y >= size)
            {
                cout << "Invalid cell" << endl;
                revealCell();
            }
        }
        else
        {
            cout << "Invalid cell" << endl;
            revealCell();
        }

        if (Grid[x][y] == 82 || Grid[x][y] == 0 || Grid[x][y] == 1 || Grid[x][y] == 2 || Grid[x][y] == 3 || Grid[x][y] == 4 || Grid[x][y] == 5 || Grid[x][y] == 6 || Grid[x][y] == 7 || Grid[x][y] == 8) // 82 for R (Revealed)
        {
            cout << "Cell already revealed, Enter new one" << endl;
            revealCell();
        }

        if (Grid[x][y] == 77) // 77 for M (Mine)
        {
            revealAll();
        }
        else if (Grid[x][y] == 72) // 72 for H (Hidden
        {
            countMines(x, y);
        }
    }

    void flagCell()
    {
        int x, y;
        cout << "Enter the cell to flag (x y): ";
        if (cin >> y >> x) // x and y are swapped because of the display
        {
            if (x < 0 || x >= size || y < 0 || y >= size)
            {
                cout << "Invalid cell" << endl;
                flagCell();
            }
        }
        else
        {
            cout << "Invalid cell" << endl;
            flagCell();
        }

        if (Grid[x][y] == 72) // 72 for H (Hidden)
        {
            Grid[x][y] = 70; // 70 for F (Flag)
        }
        else if (Grid[x][y] == 70) // 70 for F (Flag)
        {
            Grid[x][y] = 72; // 72 for H (Hidden)
        }
    }

    bool checkWin()
    {
        int count = 0;
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (Grid[i][j] == 82 || Grid[i][j] == 0 || Grid[i][j] == 1 || Grid[i][j] == 2 || Grid[i][j] == 3 || Grid[i][j] == 4 || Grid[i][j] == 5 || Grid[i][j] == 6 || Grid[i][j] == 7 || Grid[i][j] == 8) // 82 for R (Revealed)
                {
                    count++;
                }
            }
        }
        for (int k = 0; k < mines; k++)
        {
            if (Grid[minesArr[k][0]][minesArr[k][1]] == 70)
            {
                count++;
            }
        }

        if (count == (size * size - mines))
        {
            win = true;
            system("cls");
            revealAll();
        }
        return false;
    }

    void countMines(int x, int y)
    {
        int count = 0;
        for (int i = x - 1; i <= x + 1; i++)
        {
            for (int j = y - 1; j <= y + 1; j++)
            {
                if (i >= 0 && i < size && j >= 0 && j < size)
                {
                    if (Grid[i][j] == 77) // 77 for M (Mine)
                    {
                        count++;
                    }
                }
            }
        }
        Grid[x][y] = count;
    }
};

int main()
{
    srand(time(0));

    int size = 0, mines = 0;
    Input(size, mines);

    system("cls");
    Minesweeper game(size, mines);
    game.dispalyGrid();

    while (!game.checkWin())
    {
        cout << "Enter 'x' to reset the game" << endl;
        cout << "Enter 'q' to quit the game" << endl;
        cout << "Enter 'r' to reveal the cell" << endl;
        cout << "Enter 'f' to flag the cell" << endl;
        cout << "Otherwise, press any key to continue: ";
        char ch;
        cin >> ch;
        if (ch == 'x' || ch == 'X')
        {
            game.reset();
        }
        else if (ch == 'q' || ch == 'Q')
        {
            exit(0);
        }
        else if (ch == 'r' || ch == 'R')
        {
            game.revealCell();
        }
        else if (ch == 'f' || ch == 'F')
        {
            game.flagCell();
        }
        system("cls");
        game.dispalyGrid();
    }

    return 0;
}

void Input(int &size, int &mines)
{
    cout << "Eter the size of the grid: ";
InputSize:
    if (cin >> size)
    {
        if (size < 7)
        {
            cout << "Size should be >= 7" << endl;
            cout << "Enter size again: ";
            goto InputSize;
        }
    }
    else
    {
        cout << "Invalid size" << endl;
        cout << "Enter size again: ";
        goto InputSize;
    }

    cout << "Enter the number of mines: ";
InputMines:
    if (cin >> mines)
    {
        if (mines < 1 || mines >= (size * size))
        {
            cout << "Number of mines should > 0 and < " << (size * size) << endl;
            cout << "Enter number of mines again: ";
            goto InputMines;
        }
    }
    else
    {
        cout << "Invalid number of mines" << endl;
        cout << "Enter number of mines again: ";
        goto InputMines;
    }
}