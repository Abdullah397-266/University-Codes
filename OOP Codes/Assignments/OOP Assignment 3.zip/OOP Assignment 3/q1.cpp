// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

#include <iostream>
#include <cstring>
using namespace std;

struct IceCream
{
private:
    char *flavor;
    char *topping;
    char *servingType;
    bool isReady;
    double price;

public:
    // Default Constructor
    IceCream() : flavor(nullptr), topping(nullptr), servingType(nullptr), isReady(false), price(0.0)
    {
    }

    // parameterized constructors
    IceCream(char *flavor, char *topping, char *servingType, double price) : isReady(true)
    {
        this->flavor = new char[30];
        this->topping = new char[30];
        this->servingType = new char[30];
        setFlavor(flavor);
        setTopping(topping);
        setServingType(servingType);
        price = getPrice();
        this->price = price;
    }

    IceCream(char *topping, double price) : flavor(nullptr), servingType(nullptr), isReady(true)
    {
        this->flavor = new char[30];
        this->topping = new char[30];
        this->servingType = new char[30];
        cout << "Enter the flavor (1-3): ";
        if (cin >> flavor)
        {
            if (!(*flavor == '1' || *flavor == '2' || *flavor == '3'))
            {
                cout << "Invalid input!" << endl;
                exit(0);
            }
            setFlavor(flavor);
        }
        else
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }
        setTopping(topping);
        cout << "Enter the servingType (1-3): ";
        if (cin >> servingType)
        {
            if (!(*servingType == '1' || *servingType == '2' || *servingType == '3'))
            {
                cout << "Invalid input!" << endl;
                exit(0);
            }
            setServingType(servingType);
        }
        else
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }
        price = getPrice();
        this->price = price;
    }

    // a copy constructor
    IceCream(const IceCream &obj)
    {
        flavor = new char[strlen(obj.flavor) + 1];
        this->flavor = obj.flavor;

        topping = new char[strlen(obj.topping) + 1];
        this->topping = obj.topping;

        servingType = new char[strlen(obj.servingType) + 1];
        this->servingType = obj.servingType;

        isReady = obj.isReady;

        this->price = obj.price;
    }

    // a destructor
    ~IceCream()
    {
        // cout << "Object is being deleted!" << endl;
        delete[] flavor;
        delete[] topping;
        delete[] servingType;
    }

    // a function to set the flavor
    void setFlavor(char *flavor)
    {
        delete[] this->flavor;
        this->flavor = new char[strlen(flavor) + 1]; 

        if (*flavor == '1')
        {
            this->flavor = (char*)"Vanilla";
            // price += 100;
        }
        else if (*flavor == '2')
        {
            this->flavor = (char*)"Chocolate";
            // price += 150;
        }
        else if (*flavor == '3')
        {
            this->flavor = (char*)"Strawberry";
            // price += 200;
        }
        else
        {
            cout << "Invalid argument of Flavor" << endl;
            exit(0);
        }
    }

    // a function to set the topping
    void setTopping(char *topping)
    {
        delete[] this->topping;
        this->topping = new char[strlen(topping) + 1];

        if (*topping == '1')
        {
            this->topping = (char*)"Chocochips";
            // price += 50;
        }
        else if (*topping == '2')
        {
            this->topping = (char*)"Sprinkles";
            // price += 100;
        }
        else if (*topping == '3')
        {
            this->topping = (char*)"Nuts";
            // price += 150;
        }
        else
        {
            cout << "Invalid argument of topping" << endl;
            exit(0);
        }
    }

    // a function to set the serving type
    void setServingType(char *servingType)
    {
        delete[] this->servingType;
        this->servingType = new char[strlen(servingType) + 1];

        if (*servingType == '1')
        {
            this->servingType = (char*)"Stick";
            // price += 50;
        }
        else if (*servingType == '2')
        {
            this->servingType = (char*)"Cone";
            // price += 100;
        }
        else if (*servingType == '3')
        {
            this->servingType = (char*)"Bucket";
            // price += 200;
        }
        else
        {
            cout << "Invalid argument of serving type" << endl;
            exit(0);
        }
    }

    // a function to set the price
    void setPrice(double price)
    {
        this->price = price;
    }

    // a function to get the flavor
    char *getFlavor() const
    {
        return flavor;
    }

    // a function to get the topping
    char *getTopping() const
    {
        return topping;
    }

    // a function to get the serving type
    char *getServingType() const
    {
        return servingType;
    }

    // a function to get the price
    double getPrice()
    {
        price = 0;
        if (flavor != nullptr && topping != nullptr && servingType != nullptr)
        {
            // For Flavor
            if (*flavor == 'V')
            {
                price += 100;
            }
            else if (*flavor == 'C')
            {
                price += 150;
            }
            else if (*flavor == 'S')
            {
                price += 200;
            }

            // For Topping
            if (*topping == 'C')
            {
                price += 50;
            }
            else if (*topping == 'S')
            {
                price += 100;
            }
            else if (*topping == 'N')
            {
                price += 150;
            }

            // For Serving Type
            if (*servingType == 'S')
            {
                price += 50;
            }
            else if (*servingType == 'C')
            {
                price += 100;
            }
            else if (*servingType == 'B')
            {
                price += 200;
            }
        }
        else
        {
            cout << "IceCream isn't ready yet!" << endl;
        }

        return price;
    }

    // a function to make ice cream (check if topping is not NULL then set the value of isReady to true).
    void makeIceCream()
    {
        if (topping != nullptr)
        {
            isReady = true;
        }
        else
        {
            isReady = false;
        }
    }

    // a function to check if the ice cream is ready or not.
    bool checkStatus()
    {
        makeIceCream();
        if (isReady)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};

void InputServingType(char &, IceCream &);
void InputFlavor(char &, IceCream &);
void InputTopping(char &, IceCream &);
void PrintOrder(IceCream &);

int main()
{
    IceCream i1;

    cout << "Flavors:" << endl
         << "1) Vanilla: 100" << endl
         << "2) Chocolate: 150" << endl
         << "3) Strawberry: 200" << endl;
    cout << endl;

    cout << "Toppings:" << endl
         << "1) Chocochips: 50" << endl
         << "2) Sprinkles: 100" << endl
         << "3) Nuts: 150" << endl;
    cout << endl;

    cout << "Serving Types:" << endl
         << "1) Stick: 50" << endl
         << "2) Cone: 100" << endl
         << "3) Bucket: 200" << endl;
    cout << endl;

    char flavor, topping, servingType;

    InputFlavor(flavor, i1);
    cout << "Would you like to add a topping? (y/n): ";
    char choice;
    if (cin >> choice)
    {
        if (choice == 'y' || choice == 'Y')
        {
            InputTopping(topping, i1);
        }
        else if (choice == 'n' || choice == 'N')
        {
        }
        else
        {
            cout << "Invalid input!" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid input!" << endl;
        return 0;
    }
    InputServingType(servingType, i1);

    // check if the ice cream is ready or not
    cout << "IceCream Status: ";
    if (i1.checkStatus())
    {
        cout << "Ice Cream is ready!" << endl;
        PrintOrder(i1);
    }
    else
    {
        cout << "Ice Cream isn't ready yet!" << endl;

        cout << "You need to choose a topping to make the ice cream!" << endl;
        InputTopping(topping, i1);
        cout << "Printing 1st Object" << endl;
        PrintOrder(i1);
    }

    // Use of copy constructor
    cout << endl;
    IceCream i2(i1);
    cout << "Copy Construvtor Result, Printing 2nd Object" << endl;
    PrintOrder(i2);

    // Parameterized Constructor
    cout << endl;
    cout << "Parameterized Constructor with 1 argunment, Printing 3rd Object" << endl;
    IceCream i3((char*)"2", 0);
    PrintOrder(i3);

    // Parameterized Constructor
    cout << endl;
    cout << "Parameterized Constructor with all argunments, Printing 3rd Object" << endl;
    IceCream i4((char*)"2",(char*)"1",(char*)"3", 0);
    PrintOrder(i4);

    return 0;
}

// =============================================================================================================== //

void InputFlavor(char &flavor, IceCream &i1)
{
    cout << "Enter the flavor (1-3): ";
    if (cin >> flavor)
    {
        if (!(flavor == '1' || flavor == '2' || flavor == '3'))
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }
        i1.setFlavor(&flavor);
    }
    else
    {
        cout << "Invalid input!" << endl;
        exit(0);
    }
}

void InputTopping(char &topping, IceCream &i1)
{
    cout << "Enter the topping (1-3): ";
    if (cin >> topping)
    {
        if (!(topping == '1' || topping == '2' || topping == '3'))
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }
        i1.setTopping(&topping);
    }
    else
    {
        cout << "Invalid input!" << endl;
        exit(0);
    }
}

void InputServingType(char &servingType, IceCream &i1)
{
    cout << "Enter the serving type (1-3): ";
    if (cin >> servingType)
    {
        if (!(servingType == '1' || servingType == '2' || servingType == '3'))
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }
        i1.setServingType(&servingType);
    }
    else
    {
        cout << "Invalid input!" << endl;
        exit(0);
    }
}

void PrintOrder(IceCream &i)
{
    cout << "Flavor: " << i.getFlavor() << endl;
    cout << "Topping: " << i.getTopping() << endl;
    cout << "Serving Type: " << i.getServingType() << endl;
    cout << "Price: " << i.getPrice() << endl;
}