// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

#include <iostream>
using namespace std;

class Student
{

private:
    static int stdID;
    string name;
    int numOfCourses;
    string *courseCodes;
    int *courseGrades;
    float gpa;

public:
    Student() : name(""), numOfCourses(0), gpa(0.0)
    {
        stdID++;
        cout << "Student ID: " << stdID << endl;

        cout << "Enter student name: ";
        {
            cin >> name;
        }

        cout << "Enter no of courses: ";
        if (cin >> numOfCourses)
        {
            if (numOfCourses <= 0)
            {
                cout << "Invalid input! courses must be > 0" << endl;
                exit(0);
            }
        }
        else
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }

        courseCodes = new string[numOfCourses];
        for (int i = 0; i < numOfCourses; i++)
        {
            cout << "Enter code for course " << i + 1 << ": ";
            cin >> courseCodes[i];
        }

        courseGrades = new int[numOfCourses];
        for (int i = 0; i < numOfCourses; i++)
        {
            cout << "Enter grade for course " << i + 1 << ": ";
            if (cin >> courseGrades[i])
            {
                if (courseGrades[i] < 0 || courseGrades[i] > 100)
                {
                    cout << "Invalid input! Grade must be between 0 and 100" << endl;
                    exit(0);
                }
            }
            else
            {
                cout << "Invalid input!" << endl;
                exit(0);
            }
        }

        calcGPA();

        cout << endl;
    }

    ~Student()
    {
        delete[] courseCodes;
        delete[] courseGrades;
    }

    int getStdID() const
    {
        return stdID;
    }

    string getName() const
    {
        return name;
    }

    int getNumOfCourses() const
    {
        return numOfCourses;
    }

    string getCourseCode(int index) const
    {
        return courseCodes[index];
    }

    int getCourseGrades(int index) const
    {
        return courseGrades[index];
    }

    float getGPA() const
    {
        return gpa;
    }

    void setStdID(int ID)
    {
        stdID = ID;
    }

    void setName(string Name)
    {
        name = Name;
    }

    void setNumOfCourses(int num)
    {
        numOfCourses = num;
    }

    void setCourseGrades(int index, int grade)
    {
        courseGrades[index] = grade;
    }

    void addCourse(string courseCode, int grade)
    {
        string *tempCourseCodes = new string[numOfCourses + 1];
        int *tempCourseGrades = new int[numOfCourses + 1];

        for (int i = 0; i < numOfCourses; i++)
        {
            tempCourseCodes[i] = courseCodes[i];
            tempCourseGrades[i] = courseGrades[i];
        }

        tempCourseCodes[numOfCourses] = courseCode;
        tempCourseGrades[numOfCourses] = grade;

        delete[] courseCodes;
        delete[] courseGrades;

        courseCodes = tempCourseCodes;
        courseGrades = tempCourseGrades;

        numOfCourses++;
    }

    void calcGPA()
    {
        float totalGrade = 0;
        for (int i = 0; i < numOfCourses; i++)
        {
            totalGrade += courseGrades[i];
        }
        gpa = totalGrade / (numOfCourses * 3);
    }
};

int Student::stdID = 0;

Student getStudentAt(Student[], int);
float calcClassGPA(Student[], int);
float getMaxGPA(Student[], int);
float getMinGPA(Student[], int);
void printStudentRecord(Student);
void printAllStudentRecords(Student[], int);
void askToContinue();

int main()
{
    const int count = 3;
    Student students[count];

    input:
    cout << "chose from following:" << endl
         << "1. Print a specific student record" << endl
         << "2. Calculate the whole class GPA" << endl
         << "3. Get max GPA in the entire class" << endl
         << "4. get min GPA in the entire class" << endl
         << "5. Add an additional course" << endl
         << "6. Print the record of All students" << endl;
    cout << endl;

    int choice;
    cout << "enter the number (1-6) according to your choice: ";
    if (cin >> choice)
    {
        if (choice < 1 || choice > 6)
        {
            cout << "Invalid Input! number must be between 1-6" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input! number must be between 1-6" << endl;
        return 0;
    }

    if (choice == 1)
    {
        int index;
        cout << "There are total of " << count << " students" << endl
             << "Which student's record you want, Enter(1-" << count << ") : ";
        if (cin >> index)
        {
            if (index < 1 || index > count)
            {
                cout << "Invalid Input! Number must be between 1 and " << count << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input!" << endl;
            return 0;
        }

        printStudentRecord(getStudentAt(students, index - 1));

        askToContinue();
        goto input;
    }
    else if (choice == 2)
    {
        float totalGPA;
        totalGPA = calcClassGPA(students, count);
        cout << "The total GPA of the class is: " << totalGPA << endl;

        askToContinue();
        goto input;
    }
    else if (choice == 3)
    {
        float maxGPA;
        maxGPA = getMaxGPA(students, count);
        cout << "Max GPA in the entire class is: " << maxGPA << endl;

        askToContinue();
        goto input;
    }
    else if (choice == 4)
    {
        float minGPA;
        minGPA = getMinGPA(students, count);
        cout << "Min GPA in the entire class is: " << minGPA << endl;

        askToContinue();
        goto input;
    }
    else if (choice == 5)
    {
        int index;
        cout << "There are total of " << count << " students" << endl
             << "Which student's record you want to add the course to, Enter(1-" << count << ") : ";
        if (cin >> index)
        {
            if (index < 1 || index > count)
            {
                cout << "Invalid Input! Number must be between 1 and " << count << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input!" << endl;
            return 0;
        }

        string courseCode;
        int grade;
        cout << "Enter course code: ";
        cin >> courseCode;
        cout << "Enter grade: ";
        if (cin >> grade)
        {
            if (grade < 0 || grade > 100)
            {
                cout << "Invalid input! Grade must be between 0 and 100" << endl;
                exit(0);
            }
        }
        else
        {
            cout << "Invalid input!" << endl;
            exit(0);
        }

        students[index - 1].addCourse(courseCode, grade);
        students[index - 1].calcGPA();

        askToContinue();
        goto input;
    }
    else if (choice == 6)
    {
        printAllStudentRecords(students, count);

        askToContinue();
        goto input;
    }

    return 0;
}

Student getStudentAt(Student students[], int index)
{
    return students[index];
}

float calcClassGPA(Student students[], int numStudents)
{
    float totalGPA = 0;
    for (int i = 0; i < numStudents; i++)
    {
        totalGPA += students[i].getGPA();
    }
    return totalGPA / numStudents;
}

float getMaxGPA(Student students[], int numStudents)
{
    float maxGPA = students[0].getGPA();
    for (int i = 1; i < numStudents; i++)
    {
        if (students[i].getGPA() > maxGPA)
        {
            maxGPA = students[i].getGPA();
        }
    }
    return maxGPA;
}

float getMinGPA(Student students[], int numStudents)
{
    float minGPA = students[0].getGPA();
    for (int i = 1; i < numStudents; i++)
    {
        if (students[i].getGPA() < minGPA)
        {
            minGPA = students[i].getGPA();
        }
    }
    return minGPA;
}

void printStudentRecord(Student student)
{
    cout << "Student ID: " << student.getStdID() << endl;
    cout << "Student Name: " << student.getName() << endl;
    cout << "Number of Courses: " << student.getNumOfCourses() << endl;

    cout << "Course Codes: ";
    for (int i = 0; i < student.getNumOfCourses(); i++)
    {
        cout << student.getCourseCode(i) << " ";
    }
    cout << endl;

    cout << "Course Grades: ";
    for (int i = 0; i < student.getNumOfCourses(); i++)
    {
        cout << student.getCourseGrades(i) << " ";
    }
    cout << endl;

    cout << "GPA: " << student.getGPA() << endl;
}

void printAllStudentRecords(Student students[], int numStudents)
{
    for (int i = 0; i < numStudents; i++)
    {
        printStudentRecord(students[i]);
        cout << endl;
    }
}

void askToContinue()
{
    char choice;
    cout << "Do you want to continue? (y/n): ";
    cin >> choice;
    if (choice == 'n' || choice == 'N')
    {
        exit(0);
    }
}