// Assignment # 3
// Name : Abdullah qadri
// Roll No : 23i-0089

#include <iostream>
#include <cstring>
using namespace std;

class Library
{
    char *bookTitle;
    char *author;
    int bookID;
    int quantity;
    float price;
    static int totalBooks;

public:
    bool searchByTittle(Library books[], char *titlename);
    Library getBook_at(Library books[], int index);
    void addBook(Library books[], Library newBook);
    void removeBook(Library books[], int bookID);
    Library mostExpensiveBook(Library books[]);
    void SortByAuthor(Library books[]);
    void SortByTitle(Library books[]);
    void SortByPrice(Library books[]);

    Library() : bookTitle(nullptr), author(nullptr)
    {
        bookID = 0;
        quantity = 0;
        price = 0.0;
    }

    Library(char *title, char *author, int id, int qty, float price)
    {
        bookTitle = new char[strlen(title) - 1];
        this->bookTitle = title;

        this->author = new char[strlen(author) - 1];
        this->author = author;

        if (id <= 0 || qty <= 0 || price <= 0.0)
        {
            cout << "Invalid Input! ID, Quantity, and Price must be > 0" << endl;
            exit(0);
        }

        for (int i = 0; i < totalBooks; i++)
        {
            if (id == bookID)
            {
                cout << "Invalid Input! Book with ID: " << id << " Already Exists!" << endl;
                exit(0);
            }
        }

        bookID = id;
        quantity = qty;
        this->price = price;
        totalBooks++;
    }

    void display()
    {
        cout << "Book Title: " << bookTitle << endl;
        cout << "Author: " << author << endl;
        cout << "Book ID: " << bookID << endl;
        cout << "Quantity: " << quantity << endl;
        cout << "Price: " << price << endl;
        cout << "Total Books: " << totalBooks << endl;
    }

    // Setters
    void setTitle(char *newTitle)
    {
        delete[] bookTitle;
        bookTitle = new char[strlen(newTitle) + 1];
        this->bookTitle = newTitle;
    }

    void setAuthor(char *newAuthor)
    {
        delete[] author;
        author = new char[strlen(newAuthor) + 1];
        this->author = newAuthor;
    }

    void setBookID(int newID)
    {
        for (int i = 0; i < totalBooks; i++)
        {
            if (newID == bookID)
            {
                cout << "Invalid Input! Book with ID: " << newID << " Already Exists!" << endl;
                exit(0);
            }
        }
        if (newID <= 0)
        {
            cout << "Invalid Input! ID must be > 0" << endl;
            exit(0);
        }
        bookID = newID;
    }

    void setPrice(float newPrice)
    {
        if (newPrice <= 0.0)
        {
            cout << "Invalid Input! Price must be > 0" << endl;
            exit(0);
        }
        price = newPrice;
    }

    void setQuantity(int newQuantity)
    {
        if (newQuantity <= 0)
        {
            cout << "Invalid Input! Quantity must be > 0" << endl;
            exit(0);
        }
        quantity = newQuantity;
    }

    static void setTotalBooks(int newTotalBooks)
    {
        totalBooks = newTotalBooks;
    }

    // Getters
    char *getBookTitle() const
    {
        return bookTitle;
    }

    char *getAuthor() const
    {
        return author;
    }

    int getBookID() const
    {
        return bookID;
    }

    float getPrice() const
    {
        return price;
    }

    int getQuantity() const
    {
        return quantity;
    }

    static int getTotalBooks()
    {
        return totalBooks;
    }

    // Functions
    void clacTotalPrice()
    {
        cout << "Total Price: " << (price * quantity) << endl;
    }

    void displayBook()
    {
        cout << bookTitle << "\t\t" << author << "\t" << bookID << "\t\t" << quantity << "\t\t" << price << endl;
    }

    // ~Library()
    // {
    //     delete[] bookTitle;
    //     delete[] author;
    // }
};

// returns the Library object at the given array index
Library Library::getBook_at(Library books[], int index)
{
    return books[index];
}

// adds a new book to the library array
void Library::addBook(Library books[], Library newBook)
{
    for (int i = 0; i < Library::totalBooks; i++)
    {
        if (books[i].getBookID() == newBook.getBookID())
        {
            cout << "Can't Add, Book With ID: " << newBook.getBookID() << " Already Exists!" << endl;
            return;
        }
    }

    books[Library::totalBooks - 1] = newBook;
    //Library::totalBooks++;
    cout << "Book Added Successfully!" << endl;
}

// removes a book from the library array
void Library::removeBook(Library books[], int bookID)
{
    for (int i = 0; i < Library::totalBooks; i++)
    {
        if (books[i].getBookID() == bookID)
        {
            for (int j = i; j < ((Library::totalBooks)-1); j++)
            {
                books[j] = books[j + 1];
            }
            Library::totalBooks--;
            cout << "Book With ID: " << bookID << " Removed Successfully!" << endl;
            return;
        }
    }
    cout << "Book With ID: " << bookID << " NOT Found!" << endl;
}

void Library::SortByTitle(Library books[])
{
    for (int i = 0; i < Library::totalBooks; i++)
    {
        for (int j = 0; j < Library::totalBooks - i - 1; j++)
        {
            char *title1 = books[j].getBookTitle();
            char *title2 = books[j + 1].getBookTitle();
            int len1 = strlen(title1);
            int len2 = strlen(title2);

            if (len1 >= len2)
            {
                for (int i = 0; i < len2; i++)
                {
                    if (title1[i] > title2[i])
                    {
                        Library temp = books[j];
                        books[j] = books[j + 1];
                        books[j + 1] = temp;
                        break;
                    }
                }
            }
            else
            {
                for (int i = 0; i < len1; i++)
                {
                    if (title1[i] > title2[i])
                    {
                        Library temp = books[j];
                        books[j] = books[j + 1];
                        books[j + 1] = temp;
                        break;
                    }
                }
            }
        }
    }
}

// sorts the books in ascending order based on author name
void Library::SortByAuthor(Library books[])
{
    for (int i = 0; i < Library::totalBooks; i++)
    {
        for (int j = 0; j < Library::totalBooks - i - 1; j++)
        {
            char *author1 = books[j].getAuthor();
            char *author2 = books[j + 1].getAuthor();
            int len1 = strlen(author1);
            int len2 = strlen(author2);

            if (len1 >= len2)
            {
                for (int i = 0; i < len2; i++)
                {
                    if (author1[i] > author2[i])
                    {
                        Library temp = books[j];
                        books[j] = books[j + 1];
                        books[j + 1] = temp;
                        break;
                    }
                }
            }
            else
            {
                for (int i = 0; i < len1; i++)
                {
                    if (author1[i] > author2[i])
                    {
                        Library temp = books[j];
                        books[j] = books[j + 1];
                        books[j + 1] = temp;
                        break;
                    }
                }
            }
        }
    }
}

// sorts the books in ascending order based on price
void Library::SortByPrice(Library books[])
{
    for (int i = 0; i < Library::totalBooks; i++)
    {
        for (int j = 0; j < Library::totalBooks - i - 1; j++)
        {
            if (books[j].getPrice() > books[j + 1].getPrice())
            {
                Library temp = books[j];
                books[j] = books[j + 1];
                books[j + 1] = temp;
            }
        }
    }
}

// returns true if the book with the titlename is found in the list
bool Library::searchByTittle(Library books[], char *titlename)
{
    for (int i = 0; i < Library::totalBooks; i++)
    {
        if (*(books[i].getBookTitle()) == *titlename)
        {
            return true;
        }
    }
    return false;
}

// returns the book with the most expensive price from the list
Library Library::mostExpensiveBook(Library books[])
{
    int maxPrice = books[0].getPrice();
    int index = 0;

    for (int i = 1; i < Library::totalBooks; i++)
    {
        if (books[i].getPrice() > maxPrice)
        {
            maxPrice = books[i].getPrice();
            index = i;
        }
    }
    return books[index];
}

int Library::totalBooks = 0;

int main()
{
    const int SIZE = 5;

    Library books[SIZE];

    books[0] = Library((char*)"Book 2", (char*)"Author 2", 1, 10, 1010.0);
    books[1] = Library((char*)"Book 5", (char*)"Author 5", 2, 20, 400.9);
    books[2] = Library((char*)"Book 3", (char*)"Author 3", 3, 30, 300.6);
    books[3] = Library((char*)"Book 1", (char*)"Author 4", 4, 40, 200.3);
    books[4] = Library((char*)"Book 4", (char*)"Author 1", 5, 50, 500.1);

    cout << "Books Before Sorting: " << endl;
    cout << "Title\t\tAuthor\t\tID\t\tQuantity\tPrice" << endl;
    for (int i = 0; i < Library::getTotalBooks(); i++)
    {
        books[i].displayBook();
    }
    cout << endl;

    cout << "Removing books by ID: 1, 3" << endl;
    books[0].removeBook(books, 1);
    books[0].removeBook(books, 3);
    cout << endl;
    cout << "Displaying Books After Removing: " << endl;
    cout << "Title\t\tAuthor\t\tID\t\tQuantity\tPrice" << endl;
    for (int i = 0; i < Library::getTotalBooks(); i++)
    {
        books[i].displayBook();
    }
    cout << endl;

    //cout << "Value of totalBooks: " << Library::getTotalBooks() << endl; // 3

    cout << "Adding New Books: 1, 3" << endl;
    Library newBook1((char*)"Book 1", (char*)"Author 4", 6, 110, 1100.7);
    books[0].addBook(books, newBook1);
    Library newBook3((char*)"Book 3", (char*)"Author 3", 7, 130, 1300.7);
    books[0].addBook(books, newBook3);
    //Library::setTotalBooks(3);
    cout << endl;

    cout << "Displaying Books After Adding: " << endl;
    cout << "Title\t\tAuthor\t\tID\t\tQuantity\tPrice" << endl;
    for (int i = 0; i < Library::getTotalBooks(); i++)
    {
        books[i].displayBook();
    }
    cout << endl;

    cout << "Value of totalBooks: " << Library::getTotalBooks() << endl; // 5

    cout << "Books After Sorting By Title: " << endl;
    books[0].SortByTitle(books);
    cout << "Title\t\tAuthor\t\tID\t\tQuantity\tPrice" << endl;
    for (int i = 0; i < Library::getTotalBooks(); i++)
    {
        books[i].displayBook();
    }
    cout << endl;

    cout << "Books After Sorting By Author: " << endl;
    books[0].SortByAuthor(books);
    cout << "Title\t\tAuthor\t\tID\t\tQuantity\tPrice" << endl;
    for (int i = 0; i < Library::getTotalBooks(); i++)
    {
        books[i].displayBook();
    }
    cout << endl;

    cout << "Books After Sorting By Price: " << endl;
    books[0].SortByPrice(books);
    cout << "Title\t\tAuthor\t\tID\t\tQuantity\tPrice" << endl;
    for (int i = 0; i < Library::getTotalBooks(); i++)
    {
        books[i].displayBook();
    }
    cout << endl;

    cout << "Searching for Book with Title: Book 3" << endl;
    if (books[0].searchByTittle(books, (char*)"Book 3"))
    {
        cout << "Book Found!" << endl;
    }
    else
    {
        cout << "Book NOT Found!" << endl;
    }
    cout << endl;

    cout << "Most Expensive Book details: " << endl;
    Library mostExpensive = books[0].mostExpensiveBook(books);
    mostExpensive.display();
    cout << endl;

    cout << "Total price of all copies of Book 1: ";
    books[0].clacTotalPrice();

    return 0;
}