// Name:    Abdullah Qadri
// Roll No: 23I-0089
// Section: AI-B

#include <iostream>
using namespace std;

class Set
{
private:
    // You will need an array to store the elements of the set.
    // You will also need a variable to keep track of the size of the array.
    int *elements;
    int size;

public:
    Set()
    {
        elements = nullptr;
        size = 0;
    }

    Set(const int *elements, int size = 0)
    {
        // Removing duplicates
        int *tempArr = new int[size];
        int tempSize = 0;
        tempArr[0] = elements[0];
        tempSize++;
        for (int i = 1; i < size; i++)
        {
            bool isDuplicate = false;
            for (int j = 0; j < tempSize; j++)
            {
                if (elements[i] == tempArr[j])
                {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate)
            {
                tempArr[tempSize] = elements[i];
                tempSize++;
            }
        }

        // cout << "Size: " << tempSize << endl;
        this->size = tempSize;
        this->elements = new int[tempSize];
        for (int i = 0; i < tempSize; i++)
        {
            this->elements[i] = tempArr[i];
            // cout << elements[i] << ", ";
        }

        delete[] tempArr;
        tempArr = nullptr;
    }

    Set(const Set &copy) // copy constructor
    {
        size = copy.size;
        elements = new int[size];
        for (int i = 0; i < size; i++)
        {
            elements[i] = copy.elements[i];
        }
    }
    // Binary Operators
    // Set Operators
    Set operator=(const Set &val)
    {
        size = val.size;
        delete[] elements;
        elements = nullptr;
        elements = new int[size];
        for (int i = 0; i < size; i++)
        {
            elements[i] = val.elements[i];
        }
        return *this;
    }

    Set operator+(const Set &val) const // Union
    {
        Set result;
        int secondSize = 0;
        for (int i = 0; i < val.size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (val.elements[i] == elements[j])
                {
                    break;
                }
                if (j == size - 1)
                {
                    secondSize++;
                }
            }
        }
        result.size = size + secondSize;
        result.elements = new int[result.size];
        int i = 0;
        for (i = 0; i < size; i++)
        {
            result.elements[i] = elements[i];
        }
        for (int j = 0; j < val.size; j++)
        {
            for (int k = 0; k < size; k++)
            {
                if (val.elements[j] == elements[k])
                {
                    break;
                }
                if (k == size - 1)
                {
                    result.elements[i] = val.elements[j];
                    i++;
                }
            }
        }

        return result;
    }

    Set operator*(const Set &val) const // Intersection
    {
        Set result;
        int tempSize = 0;
        for (int i = 0; i < val.size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (val.elements[i] == elements[j])
                {
                    tempSize++;
                    break;
                }
            }
        }
        result.size = tempSize;
        result.elements = new int[result.size];
        int control = 0;
        for (int j = 0; j < val.size; j++)
        {
            for (int k = 0; k < size; k++)
            {
                if (val.elements[j] == elements[k])
                {
                    result.elements[control] = val.elements[j];
                    control++;
                    break;
                }
            }
        }

        return result;
    }

    Set operator-(const Set &val) const // Difference
    {
        Set result;
        int tempSize = 0;
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < val.size; j++)
            {
                if (elements[i] == val.elements[j])
                {
                    break;
                }
                if (j == val.size - 1)
                {
                    tempSize++;
                }
            }
        }

        result.size = tempSize;
        result.elements = new int[result.size];
        int i = 0;
        for (int j = 0; j < size; j++)
        {
            for (int k = 0; k < val.size; k++)
            {
                if (elements[j] == val.elements[k])
                {
                    break;
                }
                if (k == val.size - 1)
                {
                    result.elements[i] = elements[j];
                    i++;
                }
            }
        }

        return result;
    }

    // Compound Assignment Operators
    Set &operator+=(const Set &rhs) // Union Assignment
    {
        Set result;
        result = *this + rhs;
        *this = result;
        return *this;
    }

    Set &operator*=(const Set &rhs) // Intersection Assignment
    {
        Set result;
        result = *this * rhs;
        *this = result;
        return *this;
    }

    Set &operator-=(const Set &rhs) // Difference Assignment
    {
        Set result;
        result = *this - rhs;
        *this = result;
        return *this;
    }

    // // Logical Operators
    bool operator==(const Set &val) const
    {
        if (size != val.size)
        {
            return false;
        }
        for (int i = 0; i < size; i++)
        {
            if (elements[i] != val.elements[i])
            {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const Set &val) const
    {
        if (size != val.size)
        {
            return true;
        }
        for (int i = 0; i < size; i++)
        {
            if (elements[i] != val.elements[i])
            {
                return true;
            }
        }
        return false;
    }

    // //  Functional Operators
    Set &operator>(Set &) // Sort the elements in the set
    {
        for (int i = 0; i < size; i++)
        {
            for (int j = i + 1; j < size; j++)
            {
                if (elements[i] > elements[j])
                {
                    int temp = elements[i];
                    elements[i] = elements[j];
                    elements[j] = temp;
                }
            }
        }
        return *this;
    }

    int &operator[](int element) // Access element at index
    {
        return elements[element];
    }

    bool operator()(int element) const // Check if element is in the set
    {
        for (int i = 0; i < size; i++)
        {
            if (elements[i] == element)
            {
                return true;
            }
        }
        return false;
    }

    bool operator()(int element, int dumy) // Add element to the set if it is not already in set, The dumy element to differenciate from the other operator
    {
        for (int i = 0; i < size; i++)
        {
            if (elements[i] == element)
            {
                cout << "Failed! Element already exists in the set" << endl;
                return false;
            }
        }
        int *tempArr = new int[size + 1];
        for (int i = 0; i < size; i++)
        {
            tempArr[i] = elements[i];
        }
        tempArr[size] = element;
        size++;
        delete[] elements;
        elements = nullptr;
        elements = new int[size];
        for (int i = 0; i < size; i++)
        {
            elements[i] = tempArr[i];
        }
        delete[] tempArr;
        tempArr = nullptr;
        cout << "Success! Element added to the set" << endl;
        return true;
    }

    // Add element to the set if it is not already in set and element is lcm between any to numbers of the set,
    // Two dumy elements to differenciate from the other operator.
    bool operator()(int element, int dumy, int dumy2)
    {
        for (int i = 0; i < size; i++)
        {
            if (elements[i] == element)
            {
                cout << "Failed! Element already exists in the set" << endl;
                return false;
            }
        }
        for (int i = 0; i < size; i++)
        {
            for (int j = i + 1; j < size; j++)
            {
                if (element % elements[i] == 0 && element % elements[j] == 0)
                {
                    int *tempArr = new int[size + 1];
                    for (int i = 0; i < size; i++)
                    {
                        tempArr[i] = elements[i];
                    }
                    tempArr[size] = element;
                    size++;
                    delete[] elements;
                    elements = nullptr;
                    elements = new int[size];
                    for (int i = 0; i < size; i++)
                    {
                        elements[i] = tempArr[i];
                    }
                    delete[] tempArr;
                    tempArr = nullptr;
                    cout << "Success! Element added to the set" << endl;
                    return true;
                }
            }
        }
        cout << "Failed! Element is not LCM between any two numbers of the set" << endl;
        return false;
    }

    // Additional Functions for functional operators
    // Find element in the set
    int find(int element) const
    {
        for (int i = 0; i < size; i++)
        {
            if (elements[i] == element)
            {
                return i;
            }
        }
        return -1;
    }

    void display()
    {
        cout << "Size: " << size << endl;
        cout << "Elements: ";
        for (int i = 0; i < size; i++)
        {
            if (i == size - 1)
            {
                cout << elements[i];
                break;
            }
            cout << elements[i] << ", ";
        }
        cout << endl;
    }

    ~Set() // destructor
    {
        delete[] elements;
        elements = nullptr;
    }

    friend std::ostream &operator<<(std::ostream &output, const Set &val) // outputs the Set
    {
        output << "Size: " << val.size << endl;
        output << "Elements: ";
        for (int i = 0; i < val.size; i++)
        {
            if (i == val.size - 1)
            {
                output << val.elements[i];
                break;
            }
            output << val.elements[i] << ", ";
        }
        output << endl;
        return output;
    }

    friend std::istream &operator>>(std::istream &input, Set &val) // inputs the Set
    {
        cout << "Enter size of the set: ";
        input >> val.size;
        delete[] val.elements;
        val.elements = nullptr;
        val.elements = new int[val.size];
        cout << "Enter elements of the set: ";
        for (int i = 0; i < val.size; i++)
        {
            input >> val.elements[i];
        }
        return input;
    }
};

int main()
{
    system("cls");
    int arr1[] = {1, 2, 3, 4, 5, 1, 1, 1};
    int arr2[] = {1, 2, 8, 9, 10};
    int arr3[] = {6, 2, 8, 4, 6, 9, 5, 2, 7, 0, 1, 3};

    cout << "***************** Testing Removing Duplicates in Constructor *****************\n";
    Set set1(arr1, 8);
    set1.display();
    cout << endl;

    cout << "***************** Testing Union Operator *****************\n";
    cout << "Set 1: " << endl;
    set1.display();
    cout << endl;
    Set set2(arr2, 5);
    cout << "Set 2: " << endl;
    set2.display();
    cout << endl;
    cout << "Union of Set 1 and Set 2: " << endl;
    Set set3 = set1 + set2;
    set3.display();
    cout << endl;

    cout << "***************** Testing Intersection Operator *****************\n";
    cout << "Set 1: " << endl;
    set1.display();
    cout << endl;
    cout << "Set 2: " << endl;
    set2.display();
    cout << endl;
    cout << "Intersection of Set 1 and Set 2: " << endl;
    Set set4 = set1 * set2;
    set4.display();
    cout << endl;

    cout << "***************** Testing Difference Operator *****************\n";
    cout << "Set 1: " << endl;
    set1.display();
    cout << endl;
    cout << "Set 2: " << endl;
    set2.display();
    cout << endl;
    cout << "Difference of Set 1 and Set 2: " << endl;
    Set set5 = set1 - set2;
    set5.display();
    cout << endl;

    cout << "***************** Testing Union Assignment Operator *****************\n";
    cout << "Set 1: " << endl;
    Set set6(arr1, 8);
    set6.display();
    cout << endl;
    cout << "Set 2: " << endl;
    Set set7(arr2, 5);
    set7.display();
    cout << endl;
    cout << "Union of Set 1 and Set 2 stored in Set 1: " << endl;
    set6 += set7;
    set6.display();
    cout << endl;

    cout << "***************** Testing Intersection Assignment Operator *****************\n";
    cout << "Set 1: " << endl;
    Set set8(arr1, 8);
    set8.display();
    cout << endl;
    cout << "Set 2: " << endl;
    Set set9(arr2, 5);
    set9.display();
    cout << endl;
    cout << "Intersection of Set 1 and Set 2 stored in Set 1: " << endl;
    set8 *= set9;
    set8.display();
    cout << endl;

    cout << "***************** Testing Difference Assignment Operator *****************\n";
    cout << "Set 1: " << endl;
    Set set10(arr1, 8);
    set10.display();
    cout << endl;
    cout << "Set 2: " << endl;
    Set set11(arr2, 5);
    set11.display();
    cout << endl;
    cout << "Difference of Set 1 and Set 2 stored in Set 1: " << endl;
    set10 -= set11;
    set10.display();
    cout << endl;

    cout << "***************** Testing Equality Operator *****************\n";
    cout << "Set 1: " << endl;
    Set set12(arr1, 8);
    set12.display();
    cout << endl;
    cout << "Set 2: " << endl;
    Set set13(set12);
    set13.display();
    cout << endl;
    if (set12 == set13)
    {
        cout << "Set 1 and Set 2 are equal" << endl;
    }
    else
    {
        cout << "Set 1 and Set 2 are not equal" << endl;
    }
    cout << endl;

    cout << "***************** Testing Inequality Operator *****************\n";
    cout << "Set 1: " << endl;
    Set set14(arr1, 8);
    set14.display();
    cout << endl;
    cout << "Set 2: " << endl;
    Set set15(arr2, 5);
    set15.display();
    cout << endl;
    if (set14 != set15)
    {
        cout << "Set 1 and Set 2 are not equal" << endl;
    }
    else
    {
        cout << "Set 1 and Set 2 are equal" << endl;
    }
    cout << endl;

    cout << "***************** Testing Sort Operator(>) *****************\n";
    cout << "Set 1 before sorting: " << endl;
    Set set16(arr3, 12);
    set16.display();
    cout << endl;
    cout << "Set 1 after sorting: " << endl;
    set16 > set16;
    set16.display();
    cout << endl;

    cout << "***************** Testing Access Operator([]) *****************\n";
    cout << "Set 1: " << endl;
    Set set17(arr3, 12);
    set17.display();
    cout << endl;
    cout << "Element at index 3: " << set17[3] << endl;
    cout << endl;

    cout << "***************** Testing Check Operator() *****************\n";
    cout << "Set 1: " << endl;
    Set set18(arr3, 12);
    set18.display();
    cout << endl;
    cout << "Checking if element 5 exists in the set: " << endl;
    if (set18(5))
    {
        cout << "Element exists in the set" << endl;
    }
    else
    {
        cout << "Element does not exist in the set" << endl;
    }
    cout << endl;

    cout << "***************** Testing Add Operator() *****************\n";
    cout << "Set 1: " << endl;
    Set set19(arr3, 12);
    set19.display();
    cout << endl;
    cout << "Adding element 5 to the set: " << endl;
    set19(5, 0);
    set19.display();
    cout << endl;

    cout << "***************** Testing Add Operator() with LCM *****************\n";
    cout << "Set 1: " << endl;
    Set set20(arr3, 12);
    set20.display();
    cout << endl;
    cout << "Adding element 10 to the set: " << endl;
    set20(10, 0, 0);
    set20.display();
    cout << endl;

    cout << "***************** Testing Find Function *****************\n";
    cout << "Set 1: " << endl;
    Set set21(arr3, 12);
    set21.display();
    cout << endl;
    cout << "Finding element 1 in the set: " << endl;
    if (set21.find(1) != -1)
    {
        cout << "Element found at index " << set21.find(1) << endl;
    }
    else
    {
        cout << "Element not found in the set" << endl;
    }
    cout << endl;

    cout << "***************** Testing Input Operator(>>) *****************\n";
    Set set22;
    cin >> set22;
    cout << endl;

    cout << "***************** Testing Output Operator(<<) *****************\n";
    cout << set22 << endl;

    return 0;
}