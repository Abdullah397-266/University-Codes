// Name: Abdullah Qadri
// Roll No: 23I-0089
// Section: AI-B

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

class Car
{
private:
    string name;
    int year;
    double sellingPrice;
    int kmDriven;
    string fuel;
    string sellerType;
    string transmission;
    int owner;
    double mileage;
    double engine;
    double maxPower;
    double torque;
    int seats;

public:
    // Constructor
    Car()
    {
        name = "";
        year = 0;
        sellingPrice = 0;
        kmDriven = 0;
        fuel = "";
        sellerType = "";
        transmission = "";
        owner = 0;
        mileage = 0.0;
        engine = 0;
        maxPower = 0;
        torque = 0;
        seats = 0;
    }

    Car(string n, int y, double sp, int km, string f, string st, string tr, int own, double ml, double eng, double mp, double tq, int s)
        : name(n), year(y), sellingPrice(sp), kmDriven(km), fuel(f), sellerType(st), transmission(tr), owner(own), mileage(ml), engine(eng), maxPower(mp), torque(tq), seats(s)
    {
    }

    // Overloading + operator to combine details of 2 cars i.e. Add their SellingPrice, Mileage, Engine, MaxPower, Torque, Assign name with your name Take the rest for 1st Car
    Car operator+(const Car &other) const
    {
        Car temp;
        temp.name = "Abdullah Qadri";
        temp.year = year;
        temp.sellingPrice = sellingPrice + other.sellingPrice;
        temp.kmDriven = kmDriven;
        temp.fuel = fuel;
        temp.sellerType = sellerType;
        temp.transmission = transmission;
        temp.owner = owner;
        temp.mileage = mileage + other.mileage;
        temp.engine = engine + other.engine;
        temp.maxPower = maxPower + other.maxPower;
        temp.torque = torque + other.torque;
        temp.seats = seats;
        return temp;
    }

    // Overloading += operator to combine details of 2 cars i.e. Add their SellingPrice, Mileage, Engine, MaxPower, Torque
    Car &operator+=(const Car &other)
    {
        sellingPrice += other.sellingPrice;
        mileage += other.mileage;
        engine += other.engine;
        maxPower += other.maxPower;
        torque += other.torque;
        return *this;
    }

    // Overloading - operator to subtract selling prices of two cars
    double operator-(const Car &other) const
    {
        return sellingPrice - other.sellingPrice;
    }

    // Overloading -= operator to subtract details of 2 cars i.e. subtract their SellingPrice, Mileage, Engine, MaxPower, Torque
    Car &operator-=(const Car &other)
    {
        sellingPrice -= other.sellingPrice;
        mileage -= other.mileage;
        engine -= other.engine;
        maxPower -= other.maxPower;
        torque -= other.torque;
        return *this;
    }

    // Overloading == operator to compare details of two cars
    bool operator==(const Car &other) const
    {
        if (name == other.name && year == other.year && sellingPrice == other.sellingPrice && kmDriven == other.kmDriven && fuel == other.fuel && sellerType == other.sellerType && transmission == other.transmission && owner == other.owner && mileage == other.mileage && engine == other.engine && maxPower == other.maxPower && torque == other.torque && seats == other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading > operator to compare details of (int, float and Double Datatype)
    bool operator>(const Car &other) const
    {
        if (year > other.year && sellingPrice > other.sellingPrice && kmDriven > other.kmDriven && owner > other.owner && mileage > other.mileage && engine > other.engine && maxPower > other.maxPower && torque > other.torque && seats > other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading < operator to compare details of (int, float and Double Datatype)
    bool operator<(const Car &other) const
    {
        if (year < other.year && sellingPrice < other.sellingPrice && kmDriven < other.kmDriven && owner < other.owner && mileage < other.mileage && engine < other.engine && maxPower < other.maxPower && torque < other.torque && seats < other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading >= operator to compare details of (int, float and Double Datatype)
    bool operator>=(const Car &other) const
    {
        if (year >= other.year && sellingPrice >= other.sellingPrice && kmDriven >= other.kmDriven && owner >= other.owner && mileage >= other.mileage && engine >= other.engine && maxPower >= other.maxPower && torque >= other.torque && seats >= other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading <= operator to compare details of (int, float and Double Datatype)
    bool operator<=(const Car &other) const
    {
        if (year <= other.year && sellingPrice <= other.sellingPrice && kmDriven <= other.kmDriven && owner <= other.owner && mileage <= other.mileage && engine <= other.engine && maxPower <= other.maxPower && torque <= other.torque && seats <= other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading != operator to compare details of (int, float and Double Datatype)
    bool operator!=(const Car &other) const
    {
        if (year != other.year && sellingPrice != other.sellingPrice && kmDriven != other.kmDriven && owner != other.owner && mileage != other.mileage && engine != other.engine && maxPower != other.maxPower && torque != other.torque && seats != other.seats)
        {
            return true;
        }
        return false;
    }

    // Display car details
    friend ostream &operator<<(ostream &output, const Car &car)
    {
        output << "Name: " << car.name << endl;
        output << "Year: " << car.year << endl;
        output << "Selling Price: " << car.sellingPrice << endl;
        output << "KM Driven: " << car.kmDriven << endl;
        output << "Fuel: " << car.fuel << endl;
        output << "Seller Type: " << car.sellerType << endl;
        output << "Transmission: " << car.transmission << endl;
        if (car.owner == 1)
        {
            output << "Owner: First Owner" << endl;
        }
        else if (car.owner == 2)
        {
            output << "Owner: Second Owner" << endl;
        }
        else if (car.owner == 3)
        {
            output << "Owner: Third Owner" << endl;
        }
        else
        {
            output << "Owner: Fourth & Above Owner" << endl;
        }
        output << "Mileage: " << car.mileage << endl;
        output << "Engine: " << car.engine << endl;
        output << "Max Power: " << car.maxPower << endl;
        output << "Torque: " << car.torque << endl;
        output << "Seats: " << car.seats << endl;
        return output;
    }

    // Input Car Details
    friend istream &operator>>(istream &input, Car &car)
    {
        cout << "Enter Car Name: ";
        input >> car.name;

        cout << "Enter Car Year: ";
        if (input >> car.year)
        {
            while (car.year < 0)
            {
                cout << "Year cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.year;
            }
        }
        else
        {
            while (!(input >> car.year))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.year;
            }
            while (car.year < 0)
            {
                cout << "Year cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.year;
            }
        }

        cout << "Enter Car Selling Price: ";
        if (input >> car.sellingPrice)
        {
            while (car.sellingPrice < 0)
            {
                cout << "Selling Price cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.sellingPrice;
            }
        }
        else
        {
            while (!(input >> car.sellingPrice))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.sellingPrice;
            }
            while (car.sellingPrice < 0)
            {
                cout << "Selling Price cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.sellingPrice;
            }
        }

        cout << "Enter Car KM Driven: ";
        if (input >> car.kmDriven)
        {
            while (car.kmDriven < 0)
            {
                cout << "KM Driven cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.kmDriven;
            }
        }
        else
        {
            while (!(input >> car.kmDriven))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.kmDriven;
            }
            while (car.kmDriven < 0)
            {
                cout << "KM Driven cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.kmDriven;
            }
        }

        cout << "Choose Car Fuel (Petrol/Diesel/LPG/CNG): ";
        {
            cout << "Enter (1-4): ";
            int choice = 0;
            while (!(input >> choice))
            {
                cout << "Invalid Input, Enter a number only!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> choice;
            }
            while (choice < 1 || choice > 4)
            {
                cout << "Invalid Choice, Enter btw 1-4!" << endl;
                cout << "Re-Enter: ";
                input >> choice;
            }
            if (choice == 1)
            {
                car.fuel = "Petrol";
            }
            else if (choice == 2)
            {
                car.fuel = "Diesel";
            }
            else if (choice == 3)
            {
                car.fuel = "LPG";
            }
            else if (choice == 4)
            {
                car.fuel = "CNG";
            }
        }

        cout << "Enter Car Seller Type (Individual/Dealer/TrustworkMaster): ";
        {
            cout << "Enter (1-3): ";
            int choice = 0;
            while (!(input >> choice))
            {
                cout << "Invalid Input, Enter a number only!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> choice;
            }
            while (choice < 1 || choice > 3)
            {
                cout << "Invalid Choice, Enter btw 1-3!" << endl;
                cout << "Re-Enter: ";
                input >> choice;
            }
            if (choice == 1)
            {
                car.sellerType = "Individual";
            }
            else if (choice == 2)
            {
                car.sellerType = "Dealer";
            }
            else if (choice == 3)
            {
                car.sellerType = "TrustworkMaster";
            }
        }

        cout << "Enter Car Transmission (Manual/Auto): ";
        {
            cout << "Enter (1-2): ";
            int choice = 0;
            while (!(input >> choice))
            {
                cout << "Invalid Input, Enter a number only!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> choice;
            }
            while (choice < 1 || choice > 2)
            {
                cout << "Invalid Choice, Enter btw 1-2!" << endl;
                cout << "Re-Enter: ";
                input >> choice;
            }
            if (choice == 1)
            {
                car.transmission = "Manual";
            }
            else if (choice == 2)
            {
                car.transmission = "Auto";
            }
        }

        cout << "Enter Car Owner: ";
        if (input >> car.owner)
        {
            while (car.owner <= 0)
            {
                cout << "Owner cannot be negative or 0" << endl;
                cout << "Re-Enter: ";
                input >> car.owner;
            }
        }

        cout << "Enter Car Mileage: ";
        if (input >> car.mileage)
        {
            while (car.mileage < 0)
            {
                cout << "Mileage cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.mileage;
            }
        }

        cout << "Enter Car Engine CC: ";
        if (input >> car.engine)
        {
            while (car.engine < 0)
            {
                cout << "Engine CC cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.engine;
            }
        }
        else
        {
            while (!(input >> car.engine))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.engine;
            }
            while (car.engine < 0)
            {
                cout << "Engine CC cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.engine;
            }
        }

        cout << "Enter Car Max Power: ";
        if (input >> car.maxPower)
        {
            while (car.maxPower < 0)
            {
                cout << "Max Power cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.maxPower;
            }
        }
        else
        {
            while (!(input >> car.maxPower))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.maxPower;
            }
            while (car.maxPower < 0)
            {
                cout << "Max Power cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.maxPower;
            }
        }

        cout << "Enter Car Torque: ";
        if (input >> car.torque)
        {
            while (car.torque < 0)
            {
                cout << "Torque cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.torque;
            }
        }
        else
        {
            while (!(input >> car.torque))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.torque;
            }
            while (car.torque < 0)
            {
                cout << "Torque cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.torque;
            }
        }

        cout << "Enter Car Seats: ";
        if (input >> car.seats)
        {
            while (car.seats < 0)
            {
                cout << "Seats cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.seats;
            }
        }
        else
        {
            while (!(input >> car.seats))
            {
                cout << "Invalid Input!" << endl;
                cout << "Re-Enter: ";
                input.clear();
                input.ignore();
                input >> car.seats;
            }
            while (car.seats < 0)
            {
                cout << "Seats cannot be negative!" << endl;
                cout << "Re-Enter: ";
                input >> car.seats;
            }
        }
        cout << endl;
        return input;
    }

    // Setters
    void setName(string n) { name = n; }
    void setYear(int y) { year = y; }
    void setSellingPrice(double sp) { sellingPrice = sp; }
    void setKmDriven(int km) { kmDriven = km; }
    void setFuel(string f) { fuel = f; }
    void setSellerType(string st) { sellerType = st; }
    void setTransmission(string tr) { transmission = tr; }
    void setOwner(int own) { owner = own; }
    void setMileage(double ml) { mileage = ml; }
    void setEngine(double eng) { engine = eng; }
    void setMaxPower(double mp) { maxPower = mp; }
    void setTorque(double tq) { torque = tq; }
    void setSeats(int s) { seats = s; }

    // Getters
    string getName() const { return name; }
    int getYear() const { return year; }
    double getSellingPrice() const { return sellingPrice; }
    int getKmDriven() const { return kmDriven; }
    string getFuel() const { return fuel; }
    string getSellerType() const { return sellerType; }
    string getTransmission() const { return transmission; }
    int getOwner() const { return owner; }
    double getMileage() const { return mileage; }
    double getEngine() const { return engine; }
    double getMaxPower() const { return maxPower; }
    double getTorque() const { return torque; }
    int getSeats() const { return seats; }
};

class Garage
{
private:
    Car *cars;
    int numOfCars;

public:
    // Constructor to make cars null
    Garage()
    {
        cars = nullptr;
        numOfCars = 0;
    }

    Garage(int n)
    {
        numOfCars = n;
        cars = new Car[numOfCars];
    }

    // Overloading + operator to Add car using user input use the operator overloading as done in Car Class
    Garage operator+(const Car &other) const
    {
        Garage temp(numOfCars + 1);
        for (int i = 0; i < numOfCars; i++)
        {
            temp.cars[i] = cars[i];
        }
        temp.cars[numOfCars] = other;
        return temp;
    }

    // Overloading += operator to Add car of another garage
    Garage &operator+=(const Car &other)
    {
        Garage temp(numOfCars + 1);
        for (int i = 0; i < numOfCars; i++)
        {
            temp.cars[i] = cars[i];
        }
        temp.cars[numOfCars] = other;
        delete[] cars;
        this->cars = temp.cars;
        numOfCars++;
        *this = temp;
        return *this;
    }

    // Overloading - operator to remove car using index
    Garage operator-(int index) const
    {
        if (numOfCars <= 0)
        {
            cout << "Garage is Empty!" << endl;
            return *this;
        }
        if (index < 0 || index >= numOfCars)
        {
            cout << "Invalid Index! Previous Garage returned" << endl;
            return *this;
        }

        Garage temp(numOfCars - 1);
        bool check = false;
        for (int i = 0; i < numOfCars; i++)
        {
            if (i == index)
            {
                check = true;
                continue;
            }
            if (check)
            {
                temp.cars[i - 1] = cars[i];
            }
            else
            {
                temp.cars[i] = cars[i];
            }
        }

        if (check)
        {
            return temp;
        }
        else
        {
            cout << "Index not found!, Previous obj Returned" << endl;
        }
        return *this;
    }

    // Overloading -= operator to remove car using name
    Garage &operator-=(const Car &other)
    {
        if (numOfCars <= 0)
        {
            cout << "Garage is Empty!" << endl;
            return *this;
        }
        Garage temp(numOfCars - 1);
        bool check = false;
        for (int i = 0; i < numOfCars; i++)
        {
            if (cars[i].getName() == other.getName())
            {
                check = true;
                continue;
            }
            if (check)
            {
                temp.cars[i - 1] = cars[i];
            }
            else
            {
                temp.cars[i] = cars[i];
            }
        }

        if (check)
        {
            delete[] cars;
            this->cars = temp.cars;
            numOfCars--;
        }
        else
        {
            cout << "Name not found!, Previous obj Returned" << endl;
        }
        return *this;
    }

    // Overloading = operator
    Garage &operator=(const Garage &other)
    {
        if (other.numOfCars <= 0)
        {
            cout << "Garage to be assigned is Empty!" << endl;
            return *this;
        }
        if (this != &other)
        {
            numOfCars = other.numOfCars;

            delete[] cars;
            cars = new Car[numOfCars];
            for (int i = 0; i < numOfCars; i++)
            {
                cars[i] = other.cars[i];
            }
        }
        return *this;
    }

    // Overloading == operator to compare details of two Garage for each car
    bool operator==(const Garage &other) const
    {
        if (numOfCars != other.numOfCars)
        {
            cout << "Number of Cars are not equal!" << endl;
            return false;
        }

        for (int i = 0; i < numOfCars; i++)
        {
            if (cars[i] != other.cars[i])
            {
                cout << "Car Details are not equal!" << endl;
                return false;
            }
        }
        return true;
    }

    // Overloading > operator to compare Avg price of 2 garage
    bool operator>(const Garage &other) const
    {
        double avgPrice1 = 0;
        double avgPrice2 = 0;

        for (int i = 0; i < numOfCars; i++)
        {
            avgPrice1 += cars[i].getSellingPrice();
        }
        avgPrice1 = avgPrice1 / numOfCars;

        for (int i = 0; i < other.numOfCars; i++)
        {
            avgPrice2 += other.cars[i].getSellingPrice();
        }
        avgPrice2 = avgPrice2 / other.numOfCars;

        if (avgPrice1 > avgPrice2)
        {
            return true;
        }
        return false;
    }

    // Overloading < operator to average maxPower of cars of 2 garage
    bool operator<(const Garage &other) const
    {
        double avgMaxPower1 = 0;
        double avgMaxPower2 = 0;

        for (int i = 0; i < numOfCars; i++)
        {
            avgMaxPower1 += cars[i].getMaxPower();
        }
        avgMaxPower1 = avgMaxPower1 / numOfCars;

        for (int i = 0; i < other.numOfCars; i++)
        {
            avgMaxPower2 += other.cars[i].getMaxPower();
        }
        avgMaxPower2 = avgMaxPower2 / other.numOfCars;

        if (avgMaxPower1 < avgMaxPower2)
        {
            return true;
        }
        return false;
    }

    // Overloading >= operator to compare Average Mileage of 2 Garage
    bool operator>=(const Garage &other) const
    {
        double avgMileage1 = 0;
        double avgMileage2 = 0;

        for (int i = 0; i < numOfCars; i++)
        {
            avgMileage1 += cars[i].getMileage();
        }
        avgMileage1 = avgMileage1 / numOfCars;

        for (int i = 0; i < other.numOfCars; i++)
        {
            avgMileage2 += other.cars[i].getMileage();
        }
        avgMileage2 = avgMileage2 / other.numOfCars;

        if (avgMileage1 >= avgMileage2)
        {
            return true;
        }
        return false;
    }

    // Overloading <= operator to compare Average torque of 2 garage
    bool operator<=(const Garage &other) const
    {
        double avgTorque1 = 0;
        double avgTorque2 = 0;

        for (int i = 0; i < numOfCars; i++)
        {
            avgTorque1 += cars[i].getTorque();
        }
        avgTorque1 = avgTorque1 / numOfCars;

        for (int i = 0; i < other.numOfCars; i++)
        {
            avgTorque2 += other.cars[i].getTorque();
        }
        avgTorque2 = avgTorque2 / other.numOfCars;

        if (avgTorque1 <= avgTorque2)
        {
            return true;
        }
        return false;
    }

    // Overloading != operator to compare No of Cars of 2 garage
    bool operator!=(const Garage &other) const
    {
        if (numOfCars != other.numOfCars)
        {
            return true;
        }
        return false;
    }

    friend ostream &operator<<(ostream &output, const Garage &garage)
    {
        if (garage.numOfCars <= 0)
        {
            output << "Garage is Empty!" << endl;
            return output;
        }

        // Display details of all cars in the garage
        for (int i = 0; i < garage.numOfCars; i++)
        {
            output << "Car " << i + 1 << endl;
            output << garage.cars[i] << endl;
        }
        cout << "Number of Cars in Garage: " << garage.numOfCars << endl;
        return output;
    }

    ~Garage()
    {
        delete[] cars;
    }

    void setCarAtindex(int index, Car car)
    {
        cars[index] = car;
    }

    Car getCarAtIndex(int index)
    {
        return cars[index];
    }
};

// Prototypes
int length(string cell);
void fillGarage(Garage &g, int n);

// ==============================================================================================================
// ==============================================================================================================

int main()
{
    system("cls");
    int numOfCars = 2;
    Garage garage1(numOfCars);
    fillGarage(garage1, numOfCars);
    Garage garage2(numOfCars);
    fillGarage(garage2, numOfCars);

    // Testing all the Garage functions

    // Outputing the Garage
    cout << "************************* Output Garage1 *************************" << endl;
    cout << "Garage 1:" << endl;
    cout << garage1;

    // Adding a Car to the Garage
    cout << "************************* Adding a Car to Garage1 (+) *************************" << endl;
    Car car1;
    cin >> car1;
    Garage garage3(numOfCars + 1);
    garage3 = garage1 + car1;
    cout << "Car Added!" << endl;
    cout << garage3;
    cout << endl;

    // Adding a Car to the Garage
    cout << "************************* Adding a Car to Garage2 (+=) *************************" << endl;
    Car temp;
    temp = garage2.getCarAtIndex(0);
    garage1 += temp;
    cout << "Car Added!" << endl;
    cout << garage1;
    cout << endl;

    // Removing a Car from the Garage
    cout << "************************* Removing a Car from Garage1 (-) *************************" << endl;
    Garage garage4(numOfCars - 1);
    garage4 = garage1 - 0; // Removing the first car at index 0
    cout << "Car Removed!" << endl;
    cout << garage4;
    cout << endl;

    // Removing a Car from the Garage
    cout << "************************* Removing a Car from Garage2 (-=) *************************" << endl;
    garage2 -= garage2.getCarAtIndex(0); // Removing the first car at index 0
    cout << "Car Removed!" << endl;
    cout << garage2;
    cout << endl;

    // Comparing 2 Garages
    cout << "************************* Comparing 2 Garages (==) *************************" << endl;
    cout << "Result: ";
    if (garage1 == garage2)
    {
        cout << "TRUE, Garages are Equal!" << endl;
    }
    else
    {
        cout << "FALSE, Garages are not Equal!" << endl;
    }
    cout << endl;

    // Comparing 2 Garages
    cout << "************************* Comparing 2 Garages (>) *************************" << endl;
    cout << "Result: ";
    if (garage1 > garage2)
    {
        cout << "TRUE, Garage1 has more Avg Price than Garage2!" << endl;
    }
    else
    {
        cout << "FASLE, Garage1 has less Avg Price than Garage2!" << endl;
    }
    cout << endl;

    // Comparing 2 Garages
    cout << "************************* Comparing 2 Garages (<) *************************" << endl;
    cout << "Result: ";
    if (garage1 < garage2)
    {
        cout << "TRUE, Garage1 has less Avg Max Power than Garage2!" << endl;
    }
    else
    {
        cout << "FALSE, Garage1 has more Avg Max Power than Garage2!" << endl;
    }
    cout << endl;

    // Comparing 2 Garages
    cout << "************************* Comparing 2 Garages (>=) *************************" << endl;
    cout << "Result: ";
    if (garage1 >= garage2)
    {
        cout << "TRUE, Garage1 has more Avg Mileage than Garage2!" << endl;
    }
    else
    {
        cout << "FALSE, Garage1 has less Avg Mileage than Garage2!" << endl;
    }
    cout << endl;

    // Comparing 2 Garages
    cout << "************************* Comparing 2 Garages (<=) *************************" << endl;
    cout << "Result: ";
    if (garage1 <= garage2)
    {
        cout << "TRUE, Garage1 has less Avg Torque than Garage2!" << endl;
    }
    else
    {
        cout << "FALSE, Garage1 has more Avg Torque than Garage2!" << endl;
    }
    cout << endl;

    // Comparing 2 Garages
    cout << "************************* Comparing 2 Garages (!=) *************************" << endl;
    cout << "Result: ";
    if (garage1 != garage2)
    {
        cout << "TRUE, Garages are not Equal!" << endl;
    }
    else
    {
        cout << "FALSE, Garages are Equal!" << endl;
    }
    cout << endl;

    return 0;
}

// ==============================================================================================================
// ==============================================================================================================

int length(string cell)
{
    int len = 0;
    for (int i = 0; cell[i] != '\0'; i++)
    {
        len++;
    }
    return len;
}

void fillGarage(Garage &g, int n)
{
    // cout << "Storing in Garage" << endl;
    //  Reading the Details of Cars from the CSV file
    ifstream inputFile;
    inputFile.open("Car details v3.csv");

    if (!inputFile.is_open())
    {
        cout << "Failed to open file!" << endl;
        exit(0);
    }

    string line;
    // Max Rows
    const int ROWS = n;
    int row = 0;

    // Temp object to store car details
    Car car;
    while (getline(inputFile, line))
    {
        // Skip the first row becz it contains the column names
        if (row == 0)
        {
            row++;
            continue;
        }

        if (row > ROWS)
        {
            break;
        }

        stringstream lineStream(line);
        string cell;
        int col = 0;
        while (getline(lineStream, cell, ','))
        {
            if (col == 0) // Name
            {
                // cout << "Name: " << cell << endl;
                car.setName(cell);
            }
            else if (col == 1) // Year
            {
                int year = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == '0' || cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9')
                    {
                        if (cell[i] == ' ')
                        {
                            break;
                        }

                        year = year * 10 + (cell[i] - '0');
                    }
                }
                // cout << "Year: " << year << endl;
                car.setYear(year);
            }
            else if (col == 2) // Selling Price
            {
                int sellingPrice = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                    {
                        sellingPrice = sellingPrice * 10 + (cell[i] - '0');
                    }
                }
                // cout << "Selling Price: " << sellingPrice << endl;
                car.setSellingPrice(sellingPrice);
            }
            else if (col == 3) // KM Driven
            {
                int kmDriven = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                    {
                        kmDriven = kmDriven * 10 + (cell[i] - '0');
                    }
                }
                // cout << "KM Driven: " << kmDriven << endl;
                car.setKmDriven(kmDriven);
            }
            else if (col == 4) // Fuel
            {
                // cout << "Fuel: " << cell << endl;
                car.setFuel(cell);
            }
            else if (col == 5) // Seller Type
            {
                // cout << "Seller Type: " << cell << endl;
                car.setSellerType(cell);
            }
            else if (col == 6) // Transmission
            {
                // cout << "Transmission: " << cell << endl;
                car.setTransmission(cell);
            }
            else if (col == 7) // Owner
            {
                int malik = 0;
                if (cell[0] == 'F') // First Owner
                {
                    malik = 1;
                }
                else if (cell[0] == 'S') // Second Owner
                {
                    malik = 2;
                }
                else if (cell[0] == 'T') // Third Owner
                {
                    malik = 3;
                }
                else if (cell[0] == 'F')
                {
                    malik = 4;
                }
                else
                {
                    cout << "Invalid Owner!" << endl;
                }
                // cout << "Owner: " << malik << endl;
                car.setOwner(malik);
            }
            else if (col == 8) // Mileage
            {
                int len = length(cell);
                double mile = 0.0;
                int divisor = 10;
                bool point = false;
                for (int i = 0; i < len; i++)
                {
                    if (cell[i] == '.')
                    {
                        point = true;
                        continue;
                    }

                    if (!point)
                    {
                        if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                        {
                            mile = mile * 10 + (cell[i] - '0');
                        }
                    }
                    else if (point)
                    {
                        if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                        {
                            double num = cell[i] - '0';
                            double toAdd = (num / divisor);
                            mile = mile + toAdd;
                            divisor *= 10;
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
                // cout << "Mileage: " << mile << endl;
                car.setMileage(mile);
            }
            else if (col == 9) // Engine
            {
                int CC = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                    {
                        CC = CC * 10 + (cell[i] - '0');
                    }
                }
                // cout << "Engine: " << CC << endl;
                car.setEngine(CC);
            }
            else if (col == 10) // Max Power
            {
                int maxPower = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                    {
                        maxPower = maxPower * 10 + (cell[i] - '0');
                    }
                }
                // cout << "Max Power: " << maxPower << endl;
                car.setMaxPower(maxPower);
            }
            else if (col == 11) // Torque
            {
                int torque = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == 'k' || cell[i] == 'N' || cell[i] == '@')
                    {
                        break;
                    }
                    if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                    {
                        torque = torque * 10 + (cell[i] - '0');
                    }
                }
                // cout << "Torque: " << torque << endl;
                car.setTorque(torque);
            }
            else if (col == 12) // Seats
            {
                int seat = 0;
                for (int i = 0; i < length(cell); i++)
                {
                    if (cell[i] == '1' || cell[i] == '2' || cell[i] == '3' || cell[i] == '4' || cell[i] == '5' || cell[i] == '6' || cell[i] == '7' || cell[i] == '8' || cell[i] == '9' || cell[i] == '0')
                    {
                        seat = cell[i] - '0';
                    }
                }
                // cout << "Seats: " << seat << endl;
                car.setSeats(seat);
            }
            col++;
        }
        // cout << endl;
        g.setCarAtindex(row - 1, car);
        row++;
    }
    inputFile.close();

    // cout << "Garage Filled!" << endl;
    return;
}
