// Name:    Abdullah Qadri
// Roll No: 23I-0089
// Section: AI-B

#include <iostream>
#include <cmath>
#include <string>

using namespace std;

class BigFloat
{
    // think about the private data members
    double a;
    string integerPart, fractionalPart;
    int precision;
    bool sign;

public:
    BigFloat(double val = 0.0, int precision = 2)
    {
        if (precision < 0)
        {
            cout << "Precision can't be negative. Setting precision to 2." << endl;
            precision = 2;
        }
        else if(precision > 14)
        {
            cout << "Precision can't be greater than 14. Setting precision to 14." << endl;
            precision = 14;
        }
        a = val;
        this->precision = precision;
        integerPart = "";
        fractionalPart = "";
        // Initialize the sign of the number.
        if (a < 0)
        {
            sign = false;
            // made the number positive for further calculations
            a = -a;
        }
        else
        {
            sign = true;
        }

        // Initialize the integer and fractional parts of the number.
        int integer = a;
        while (integer)
        {
            char ch = (integer % 10) + '0';
            integerPart = ch + integerPart;
            integer /= 10;
        }
        // cout << "Integer Part: " << integerPart << endl;

        double fraction = a - (int)a;
        int tempPrecision = this->precision;
        while (tempPrecision--)
        {
            fraction *= 10;
            char ch = (int)fraction + '0';
            fractionalPart += ch;
            fraction -= (int)fraction;
        }
        // cout << "Fractional Part: " << fractionalPart << endl;

        a = 0;
        for (int i = 0; integerPart[i] != '\0'; i++)
        {
            a = a * 10 + (integerPart[i] - '0');
        }

        double divisor = 10;
        for (int i = 0; fractionalPart[i] != '\0'; i++)
        {
            a = a + (fractionalPart[i] - '0') / divisor;
            divisor *= 10;
        }
        // cout << "Value of a: " << a << endl;
    }
    BigFloat(const string &text, int precision = 2)
    {
        if (precision < 0)
        {
            cout << "Precision can't be negative. Setting precision to 2." << endl;
            precision = 2;
        }
        else if(precision > 14)
        {
            cout << "Precision can't be greater than 14. Setting precision to 14." << endl;
            precision = 14;
        }
        a = 0.0;
        this->precision = precision;
        integerPart = "";
        fractionalPart = "";
        // Initialize the sign of the number.
        if (text[0] == '-')
        {
            sign = false;
        }
        else
        {
            sign = true;
        }

        // Initialize the integer and fractional parts of the number.
        int i = 0;
        while (text[i] != '.' && text[i] != '\0')
        {
            integerPart += text[i];
            i++;
        }
        // cout << "Integer Part: " << integerPart << endl;

        i++;
        int tempPrecision = this->precision;
        while (tempPrecision--)
        {
            fractionalPart += text[i];
            i++;
        }
        // cout << "Fractional Part: " << fractionalPart << endl;

        for (int i = 0; integerPart[i] != '\0'; i++)
        {
            a = a * 10 + (integerPart[i] - '0');
        }

        double divisor = 10;
        for (int i = 0; fractionalPart[i] != '\0'; i++)
        {
            a = a + (fractionalPart[i] - '0') / divisor;
            divisor *= 10;
        }
        // cout << "Value of a: " << a << endl;
    }

    BigFloat(const BigFloat &copy)
    {
        a = copy.a;
        integerPart = copy.integerPart;
        fractionalPart = copy.fractionalPart;
        precision = copy.precision;
        sign = copy.sign;
    }

    // Binary Operators
    // Arithmetic Operators
    BigFloat operator+(const BigFloat &val) const
    {
        int tempPrecision = 0;
        if (precision < val.precision)
        {
            tempPrecision = precision;
        }
        else
        {
            tempPrecision = val.precision;
        }

        if (sign && val.sign)
        {
            BigFloat result(a + val.a, tempPrecision);
            return result;
        }
        else if (sign && !val.sign)
        {
            BigFloat result(a - val.a, tempPrecision);
            return result;
        }
        else if (!sign && val.sign)
        {
            BigFloat result(val.a - a, tempPrecision);
            return result;
        }
        else if (!sign && !val.sign)
        {
            BigFloat result(-(a + val.a), tempPrecision);
            return result;
        }
        return BigFloat(0.0, 1);
    }

    BigFloat operator-(const BigFloat &val) const
    {
        int tempPrecision = 0;
        if (precision < val.precision)
        {
            tempPrecision = precision;
        }
        else
        {
            tempPrecision = val.precision;
        }

        if (sign && val.sign)
        {
            BigFloat result(a - val.a, tempPrecision);
            return result;
        }
        else if (sign && !val.sign)
        {
            BigFloat result(a + val.a, tempPrecision);
            return result;
        }
        else if (!sign && val.sign)
        {
            BigFloat result(-(a + val.a), tempPrecision);
            return result;
        }
        else if (!sign && !val.sign)
        {
            BigFloat result(val.a - a, tempPrecision);
            return result;
        }
        return BigFloat(0.0, 1);
    }

    BigFloat operator*(const BigFloat &val) const
    {
        int tempPrecision = 0;
        if (precision < val.precision)
        {
            tempPrecision = precision;
        }
        else
        {
            tempPrecision = val.precision;
        }

        if (sign && val.sign)
        {
            BigFloat result(a * val.a, tempPrecision);
            return result;
        }
        else if (sign && !val.sign)
        {
            BigFloat result(-(a * val.a), tempPrecision);
            return result;
        }
        else if (!sign && val.sign)
        {
            BigFloat result(-(a * val.a), tempPrecision);
            return result;
        }
        else if (!sign && !val.sign)
        {
            BigFloat result(a * val.a, tempPrecision);
            return result;
        }
        return BigFloat(0.0, 1);
    }

    BigFloat operator/(const BigFloat &val) const
    {
        if (val.a == 0)
        {
            cout << "<--- Division by zero is not allowed. --->" << endl;
            return BigFloat(0.0, 1);
        }
        int tempPrecision = 0;
        if (precision < val.precision)
        {
            tempPrecision = precision;
        }
        else
        {
            tempPrecision = val.precision;
        }

        if (sign && val.sign)
        {
            BigFloat result(a / val.a, tempPrecision);
            return result;
        }
        else if (sign && !val.sign)
        {
            BigFloat result(-(a / val.a), tempPrecision);
            return result;
        }
        else if (!sign && val.sign)
        {
            BigFloat result(-(a / val.a), tempPrecision);
            return result;
        }
        else if (!sign && !val.sign)
        {
            BigFloat result(a / val.a, tempPrecision);
            return result;
        }
        return BigFloat(0.0, 1);
    }

    BigFloat operator%(const BigFloat &val) const
    {
        if (val.a == 0)
        {
            cout << "<--- Division by zero is not allowed. --->" << endl;
            return BigFloat(0.0, 1);
        }
        int tempPrecision = 0;
        if (precision < val.precision)
        {
            tempPrecision = precision;
        }
        else
        {
            tempPrecision = val.precision;
        }

        double fmodResult = a - (int)(a / val.a) * val.a;
        cout << "Modulus Result: " << fmodResult << endl;
        BigFloat result(fmodResult, tempPrecision);
        return result;
    }

    // Compound Assignment Operators
    BigFloat operator+=(const BigFloat &rhs)
    {
        *this = *this + rhs;
        return *this;
    }

    BigFloat operator-=(const BigFloat &rhs)
    {
        *this = *this - rhs;
        return *this;
    }

    BigFloat operator*=(const BigFloat &rhs)
    {
        *this = *this * rhs;
        return *this;
    }

    BigFloat operator/=(const BigFloat &rhs)
    {
        *this = *this / rhs;
        return *this;
    }

    BigFloat operator%=(const BigFloat &rhs)
    {
        *this = *this % rhs;
        return *this;
    }

    // Logical Operators
    bool operator==(const BigFloat &val) const
    {
        if (a == val.a && sign == val.sign)
        {
            return true;
        }
        return false;
    }

    bool operator!=(const BigFloat &val) const
    {
        if (a != val.a || sign != val.sign)
        {
            return true;
        }
        return false;
    }

    bool operator<(const BigFloat &val) const
    {
        if (sign && val.sign)
        {
            if (a < val.a)
            {
                return true;
            }
            return false;
        }
        else if (sign && !val.sign)
        {
            return false;
        }
        else if (!sign && val.sign)
        {
            return true;
        }
        else if (!sign && !val.sign)
        {
            if (a > val.a)
            {
                return true;
            }
            return false;
        }
        return false;
    }

    bool operator<=(const BigFloat &val) const
    {
        if (sign && val.sign)
        {
            if (a <= val.a)
            {
                return true;
            }
            return false;
        }
        else if (sign && !val.sign)
        {
            return false;
        }
        else if (!sign && val.sign)
        {
            return true;
        }
        else if (!sign && !val.sign)
        {
            if (a >= val.a)
            {
                return true;
            }
            return false;
        }
        return false;
    }

    bool operator>(const BigFloat &val) const
    {
        if (sign && val.sign)
        {
            if (a > val.a)
            {
                return true;
            }
            return false;
        }
        else if (sign && !val.sign)
        {
            return true;
        }
        else if (!sign && val.sign)
        {
            return false;
        }
        else if (!sign && !val.sign)
        {
            if (a < val.a)
            {
                return true;
            }
            return false;
        }
        return false;
    }

    bool operator>=(const BigFloat &val) const
    {
        if (sign && val.sign)
        {
            if (a >= val.a)
            {
                return true;
            }
            return false;
        }
        else if (sign && !val.sign)
        {
            return true;
        }
        else if (!sign && val.sign)
        {
            return false;
        }
        else if (!sign && !val.sign)
        {
            if (a <= val.a)
            {
                return true;
            }
            return false;
        }
        return false;
    }

    // Unary Operators
    // Unary Plus Operator
    BigFloat operator+() const
    {
        return *this;
    }

    // Unary Minus Operator
    BigFloat operator-()
    {
        if (sign)
        {
            sign = false;
        }
        else
        {
            sign = true;
        }
        return *this;
    } 

    // Conversion Operator
    // return value of the BigFloat as string
    operator std::string() const
    {
        string result = "";
        if (!sign)
        {
            result += '-';
        }
        result += integerPart + '.' + fractionalPart;
        return result;
    }

    ~BigFloat() {}

    // Inputs the BigFloat
    friend std::istream &operator>>(std::istream &input, BigFloat &val)
    {
        cout << "want to input in string or double? (s/d): ";
        char choice;
        if (input >> choice)
        {
            if (choice == 's' || choice == 'S')
            {
                cout << "Enter the value in string: ";
                string text;
                input >> text;

                cout << "Enter the precision: ";
                int precision;
                input >> precision;
                if (precision < 0)
                {
                    cout << "Precision can't be negative. Setting precision to 2." << endl;
                    precision = 2;
                }

                val = BigFloat(text, precision);
            }
            else if (choice == 'd' || choice == 'D')
            {
                cout << "Enter the floating-point value: ";
                double value;
                input >> value;

                cout << "Enter the precision: ";
                int precision;
                input >> precision;
                if (precision < 0)
                {
                    cout << "Precision can't be negative. Setting precision to 2." << endl;
                    precision = 2;
                }

                val = BigFloat(value, precision);
            }
        }
        return input;
    }

    // outputs the BigFloat
    friend std::ostream &operator<<(std::ostream &output, const BigFloat &val)
    {
        output << "Value: ";
        if (!val.sign)
        {
            output << '-';
        }
        output << val.integerPart << '.' << val.fractionalPart << endl;

        output << "Precision: " << val.precision << endl;
        output << "Integer Part: " << val.integerPart << endl;
        output << "Fractional Part: " << val.fractionalPart << endl;

        return output;
    }
};

int main()
{
    system("cls");
    cout << "*** Tesing by sending floating value ***" << endl;
    BigFloat b1(123.456, 5);
    cout << b1;
    cout << endl;

    cout << "*** Tesing by sending string value ***" << endl;
    BigFloat b2("123.456", 2);
    cout << b2;
    cout << endl;

    cout << "*** Testing Copy Constructor ***" << endl;
    BigFloat b3(b1);
    cout << b3;
    cout << endl;

    cout << "*** Testing Output Operator ***" << endl;
    cout << b3;
    cout << endl;

    cout << "*** Testing + Operator ***" << endl;
    BigFloat b5(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b5 << endl;
    BigFloat b6(20.5485, 4);
    cout << "Object 2: " << endl;
    cout << b6 << endl;
    cout << "Result: " << endl;
    BigFloat b7 = b5 + b6;
    cout << b7;
    cout << endl;

    cout << "*** Testing - Operator ***" << endl;
    BigFloat b8(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b8 << endl;
    BigFloat b9(-20.5485, 4);
    cout << "Object 2: " << endl;
    cout << b9 << endl;
    cout << "Result: " << endl;
    BigFloat b10 = b8 - b9;
    cout << b10;
    cout << endl;

    cout << "*** Testing * Operator ***" << endl;
    BigFloat b11(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b11 << endl;
    BigFloat b12(-20.5485, 4);
    cout << "Object 2: " << endl;
    cout << b12 << endl;
    cout << "Result: " << endl;
    BigFloat b13 = b11 * b12;
    cout << b13;
    cout << endl;

    cout << "*** Testing / Operator ***" << endl;
    BigFloat b14(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b14 << endl;
    BigFloat b15(2.5485, 4);
    cout << "Object 2: " << endl;
    cout << b15 << endl;
    cout << "Result: " << endl;
    BigFloat b16 = b14 / b15;
    cout << b16;
    cout << endl;

    cout << "*** Testing / Operator with division by zero ***" << endl;
    BigFloat b17(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b17 << endl;
    BigFloat b18(0.0, 4);
    cout << "Object 2: " << endl;
    cout << b18 << endl;
    cout << "Result: " << endl;
    BigFloat b19 = b17 / b18;
    cout << b19;
    cout << endl;

    cout << "*** Testing % Operator ***" << endl;
    BigFloat b20(21.5, 1);
    cout << "Object 1: " << endl;
    cout << b20 << endl;
    BigFloat b21(2.2485, 4);
    cout << "Object 2: " << endl;
    cout << b21 << endl;
    cout << "Result: " << endl;
    BigFloat b22 = b20 % b21;
    cout << b22;
    cout << endl;

    cout << "*** Testing % Operator with division by zero ***" << endl;
    BigFloat b23(21.5, 1);
    cout << "Object 1: " << endl;
    cout << b23 << endl;
    BigFloat b24(0.0, 4);
    cout << "Object 2: " << endl;
    cout << b24 << endl;
    cout << "Result: " << endl;
    BigFloat b25 = b23 % b24;
    cout << b25;
    cout << endl;

    cout << "*** Testing += Operator ***" << endl;
    BigFloat b26(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b26 << endl;
    BigFloat b27(20.5485, 4);
    cout << "Object 2: " << endl;
    cout << b27 << endl;
    cout << "Result: First Object Modified" << endl;
    b26 += b27;
    cout << b26;
    cout << endl;

    cout << "*** Testing -= Operator ***" << endl;
    BigFloat b28(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b28 << endl;
    BigFloat b29(-20.5485, 4);
    cout << "Object 2: " << endl;
    cout << b29 << endl;
    cout << "Result: First Object Modified" << endl;
    b28 -= b29;
    cout << b28;
    cout << endl;

    cout << "*** Testing *= Operator ***" << endl;
    BigFloat b30(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b30 << endl;
    BigFloat b31(-20.5485, 4);
    cout << "Object 2: " << endl;
    cout << b31 << endl;
    cout << "Result: First Object Modified" << endl;
    b30 *= b31;
    cout << b30;
    cout << endl;

    cout << "*** Testing /= Operator ***" << endl;
    BigFloat b32(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b32 << endl;
    BigFloat b33(2.5485, 4);
    cout << "Object 2: " << endl;
    cout << b33 << endl;
    cout << "Result: First Object Modified" << endl;
    b32 /= b33;
    cout << b32 << endl;

    cout << "*** Testing /= Operator with division by zero ***" << endl;
    BigFloat b34(10.5, 2);
    cout << "Object 1: " << endl;
    cout << b34 << endl;
    BigFloat b35(0.0, 4);
    cout << "Object 2: " << endl;
    cout << b35 << endl;
    cout << "Result: First Object Modified" << endl;
    b34 /= b35;
    cout << b34 << endl;

    cout << "*** Testing %= Operator ***" << endl;
    BigFloat b36(21.5, 1);
    cout << "Object 1: " << endl;
    cout << b36 << endl;
    BigFloat b37(2.2485, 4);
    cout << "Object 2: " << endl;
    cout << b37 << endl;
    cout << "Result: First Object Modified" << endl;
    b36 %= b37;
    cout << b36 << endl;

    cout << "*** Testing %= Operator with division by zero ***" << endl;
    BigFloat b38(21.5, 1);
    cout << "Object 1: " << endl;
    cout << b38 << endl;
    BigFloat b39(0.0, 4);
    cout << "Object 2: " << endl;
    cout << b39 << endl;
    cout << "Result: First Object Modified" << endl;
    b38 %= b39;
    cout << b38 << endl;

    cout << "*** Testing == Operator ***" << endl;
    BigFloat b40(21.545, 1);
    cout << "Object 1: " << endl;
    cout << b40 << endl;
    BigFloat b41(21.5, 1);
    cout << "Object 2: " << endl;
    cout << b41 << endl;
    cout << "Result: " << endl;
    if (b40 == b41)
    {
        cout << "Both objects are equal." << endl;
    }
    else
    {
        cout << "Both objects are not equal." << endl;
    }
    cout << endl;

    cout << "*** Testing != Operator ***" << endl;
    BigFloat b42(21.545, 1);
    cout << "Object 1: " << endl;
    cout << b42 << endl;
    BigFloat b43(21.5, 1);
    cout << "Object 2: " << endl;
    cout << b43 << endl;
    cout << "Result: " << endl;
    if (b42 != b43)
    {
        cout << "Both objects are not equal." << endl;
    }
    else
    {
        cout << "Both objects are equal." << endl;
    }
    cout << endl;

    cout << "*** Testing < Operator ***" << endl;
    BigFloat b44(21.545, 0);
    cout << "Object 1: " << endl;
    cout << b44 << endl;
    BigFloat b45(21.5, 1);
    cout << "Object 2: " << endl;
    cout << b45 << endl;
    cout << "Result: " << endl;
    if (b44 < b45)
    {
        cout << "Object 1 is less than Object 2." << endl;
    }
    else
    {
        cout << "Object 1 is not less than Object 2." << endl;
    }
    cout << endl;

    cout << "*** Testing <= Operator ***" << endl;
    BigFloat b46(21.545, 1);
    cout << "Object 1: " << endl;
    cout << b46 << endl;
    BigFloat b47(21.5555, 3);
    cout << "Object 2: " << endl;
    cout << b47 << endl;
    cout << "Result: " << endl;
    if (b46 <= b47)
    {
        cout << "Object 1 is less than or equal to Object 2." << endl;
    }
    else
    {
        cout << "Object 1 is not less than or equal to Object 2." << endl;
    }
    cout << endl;

    cout << "*** Testing > Operator ***" << endl;
    BigFloat b48(21.545, 3);
    cout << "Object 1: " << endl;
    cout << b48 << endl;
    BigFloat b49(21.5, 1);
    cout << "Object 2: " << endl;
    cout << b49 << endl;
    cout << "Result: " << endl;
    if (b48 > b49)
    {
        cout << "Object 1 is greater than Object 2." << endl;
    }
    else
    {
        cout << "Object 1 is not greater than Object 2." << endl;
    }
    cout << endl;

    cout << "*** Testing >= Operator ***" << endl;
    BigFloat b50(21.545, 1);
    cout << "Object 1: " << endl;
    cout << b50 << endl;
    BigFloat b51(21.5, 1);
    cout << "Object 2: " << endl;
    cout << b51 << endl;
    cout << "Result: " << endl;
    if (b50 >= b51)
    {
        cout << "Object 1 is greater than or equal to Object 2." << endl;
    }
    else
    {
        cout << "Object 1 is not greater than or equal to Object 2." << endl;
    }
    cout << endl;

    cout << "*** Testing Unary + Operator ***" << endl;
    BigFloat b52(21.545, 1);
    cout << "Object 1: " << endl;
    cout << b52 << endl;
    cout << "Result: " << endl;
    cout << +b52 << endl;
    
    cout << "*** Testing Unary - Operator ***" << endl;
    BigFloat b53(21.545, 1);
    cout << "Object 1: " << endl;
    cout << b53 << endl;
    cout << "Result: " << endl;
    cout << -b53 << endl;

    cout << "*** Testing String Conversion Operator ***" << endl;
    BigFloat b54(323.142857362415273892, 14);
    cout << "Object 1: " << endl;
    cout << b54 << endl;
    cout << "Result: " << endl;
    cout << (string)b54 << endl;
    
    cout << "*** Testing Input Operator ***" << endl;
    BigFloat b4;
    cin >> b4;
    cout << b4;
    cout << endl;

    return 0;
}