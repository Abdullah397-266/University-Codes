// Name:    Abdullah Qadri
// Roll No: 23I-0089
// Section: AI-B

#include <iostream>
#include <ctime>
using namespace std;

class Time
{
private:
    // You will need three integer data members to store the hours, minutes, and seconds.
    int hours;
    int minutes;
    int seconds;

public:
    Time(int hours = 0, int minutes = 0, int seconds = 0)
    {
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59 || seconds < 0 || seconds > 59)
        {
            cout << "Error: Invalid Time" << endl;
            exit(0);
        }
        this->hours = hours;
        this->minutes = minutes;
        this->seconds = seconds;
    }

    // copy constructor
    Time(const Time &copy)
    {
        this->hours = copy.hours;
        this->minutes = copy.minutes;
        this->seconds = copy.seconds;
    }

    // Binary Operators
    // Arithmetic Operators
    Time operator+(const Time &val) const
    {
        Time result;
        result.hours = this->hours + val.hours;
        result.minutes = this->minutes + val.minutes;
        result.seconds = this->seconds + val.seconds;
        result.makeTimeRight();
        return result;
    }

    Time operator-(const Time &val) const
    {
        int Time1_Sec = this->hours * 3600 + this->minutes * 60 + this->seconds;
        int Time2_Sec = val.hours * 3600 + val.minutes * 60 + val.seconds;
        if (Time1_Sec < Time2_Sec)
        {
            cout << "Error: Time1 is less than Time2" << endl;
            return Time();
        }

        int total_seconds = Time1_Sec - Time2_Sec;

        Time result;
        result.hours = total_seconds / 3600;
        total_seconds %= 3600;
        result.minutes = total_seconds / 60;
        total_seconds %= 60;
        result.seconds = total_seconds;
        result.makeTimeRight();
        return result;
    }

    // Compound Assignment Operators
    Time &operator+=(const Time &rhs)
    {
        this->hours += rhs.hours;
        this->minutes += rhs.minutes;
        this->seconds += rhs.seconds;
        this->makeTimeRight();
        return *this;
    }

    Time &operator-=(const Time &rhs)
    {
        int Time1_Sec = this->hours * 3600 + this->minutes * 60 + this->seconds;
        int Time2_Sec = rhs.hours * 3600 + rhs.minutes * 60 + rhs.seconds;
        if (Time1_Sec < Time2_Sec)
        {
            cout << "Error: Time1 is less than Time2" << endl;
            return *this;
        }

        int total_seconds = Time1_Sec - Time2_Sec;

        this->hours = total_seconds / 3600;
        total_seconds %= 3600;
        this->minutes = total_seconds / 60;
        total_seconds %= 60;
        this->seconds = total_seconds;
        this->makeTimeRight();
        return *this;
    }

    // Logical Operators
    bool operator==(const Time &val) const
    {
        if (this->hours == val.hours && this->minutes == val.minutes && this->seconds == val.seconds)
        {
            return true;
        }
        return false;
    }

    bool operator!=(const Time &val) const
    {
        if (this->hours != val.hours || this->minutes != val.minutes || this->seconds != val.seconds)
        {
            return true;
        }
        return false;
    }

    bool operator<(const Time &val) const
    {
        if (this->hours < val.hours)
        {
            return true;
        }
        else if (this->hours == val.hours)
        {
            if (this->minutes < val.minutes)
            {
                return true;
            }
            else if (this->minutes == val.minutes)
            {
                if (this->seconds < val.seconds)
                {
                    return true;
                }
            }
        }
        return false;
    }

    bool operator<=(const Time &val) const
    {
        if (this->hours < val.hours)
        {
            return true;
        }
        else if (this->hours == val.hours)
        {
            if (this->minutes < val.minutes)
            {
                return true;
            }
            else if (this->minutes == val.minutes)
            {
                if (this->seconds <= val.seconds)
                {
                    return true;
                }
            }
        }
        return false;
    }

    bool operator>(const Time &val) const
    {
        if (this->hours > val.hours)
        {
            return true;
        }
        else if (this->hours == val.hours)
        {
            if (this->minutes > val.minutes)
            {
                return true;
            }
            else if (this->minutes == val.minutes)
            {
                if (this->seconds > val.seconds)
                {
                    return true;
                }
            }
        }
        return false;
    }

    bool operator>=(const Time &val) const
    {
        if (this->hours > val.hours)
        {
            return true;
        }
        else if (this->hours == val.hours)
        {
            if (this->minutes > val.minutes)
            {
                return true;
            }
            else if (this->minutes == val.minutes)
            {
                if (this->seconds >= val.seconds)
                {
                    return true;
                }
            }
        }
        return false;
    }

    
// Calculate elapsed time
    Time elapsedTime() const
    {
        Time result;

        // Convert the given time to a time_t object
        time_t givenTime_t = convertToTimeT();

        // Get the current time
        time_t currentTime;
        time(&currentTime);

        // Calculate the elapsed time
        double elapsedTimeSeconds = difftime(currentTime, givenTime_t);
        if (elapsedTimeSeconds < 0) 
        {
            cout << "Error: Elapsed Time is negative" << endl;
            exit(0);
        }

        // Convert the elapsed time to hours, minutes, and seconds
        result.hours = elapsedTimeSeconds / 3600;
        elapsedTimeSeconds -= result.hours * 3600;
        result.minutes = elapsedTimeSeconds / 60;
        elapsedTimeSeconds -= result.minutes * 60;
        result.seconds = elapsedTimeSeconds;

        return result;
    }

    // Convert Time object to time_t
    time_t convertToTimeT() const {
        time_t rawTime;
        time(&rawTime);

        struct tm* timeInfo = localtime(&rawTime);
        timeInfo->tm_hour = hours;
        timeInfo->tm_min = minutes;
        timeInfo->tm_sec = seconds;

        return mktime(timeInfo);
    }

    // // Additional Functions
    // Time elapsedTime() const // Calculate elapsed time
    // {
    //     Time result; 

    //     struct tm givenTime;
    //     givenTime.tm_hour = hours;
    //     givenTime.tm_min = minutes;
    //     givenTime.tm_sec = seconds;

    //     // Convert the given time to a time_t object
    //     time_t givenTime_t = mktime(&givenTime);

    //     // Get the current time
    //     time_t currentTime;
    //     time(&currentTime);

    //     // Calculate the elapsed time
    //     double elapsedTime = difftime(currentTime, givenTime_t);
    //     if(elapsedTime < 0)
    //     {
    //         cout << "Error: Elapsed Time is negative" << endl;
    //         exit(0);
    //     }

    //     // Convert the elapsed time to a Time object
    //     result.hours = static_cast<int>(elapsedTime / 3600);
    //     elapsedTime -= result.hours * 3600;
    //     result.minutes = static_cast<int>(elapsedTime / 60);
    //     elapsedTime -= result.minutes * 60;
    //     result.seconds = static_cast<int>(elapsedTime);

    //     return result;

    //     // Time start;
    //     // cin >> start;

    //     // if(start > *this)
    //     // {
    //     //     cout << "Error: Start Time is greater than End Time" << endl;
    //     //     exit(0);
    //     // }
    //     // cout << endl;

    //     // cout << "Start Time: " << endl;
    //     // cout << start << endl;

    //     // cout << "End Time: " << endl;
    //     // cout << *this << endl;

    //     // Time result;
    //     // result = *this - start;
    //     // return result;
    // }

    ~Time() {} // destructor

    friend std::ostream &operator<<(std::ostream &output, const Time &val) // outputs the Time
    {
        output << "Time: " << val.hours << ":" << val.minutes << ":" << val.seconds;
        output << endl;
        return output;
    }

    friend std::istream &operator>>(std::istream &input, Time &val) // inputs the Time
    {
        cout << "Enter Hours: ";
        input >> val.hours;
        cout << "Enter Minutes: ";
        input >> val.minutes;
        cout << "Enter Seconds: ";
        input >> val.seconds;
        if (val.hours < 0 || val.hours > 23 || val.minutes < 0 || val.minutes > 59 || val.seconds < 0 || val.seconds > 59)
        {
            cout << "Error: Invalid Time" << endl;
            exit(0);
        }
        return input;
    }

    Time makeTimeRight()
    {
        while (this->seconds >= 60)
        {
            this->seconds -= 60;
            this->minutes++;
        }
        while (this->minutes >= 60)
        {
            this->minutes -= 60;
            this->hours++;
        }
        while (this->hours >= 24)
        {
            this->hours -= 24;
        }
        return *this;
    }
};

int main()
{
    system("CLS");
    cout << "<--- TIme will be in 24 hours format --->" << endl;

    cout << "***************** Testing Constructors *****************" << endl;
    Time t1(12, 30, 45);
    cout << "Time 1: " << endl;
    cout << t1 << endl;

    cout << "***************** Testing Copy Constructor *****************" << endl;
    Time t2(t1);
    cout << "Time 1 Cpoied in Time 2: " << endl;
    cout << t2 << endl;

    cout << "***************** Testing + Operator *****************" << endl;
    Time t3(1, 30, 45);
    cout << "Time 3:" << endl;
    cout << t3 << endl;
    Time t4(2, 30, 45);
    cout << "Time 4:" << endl;
    cout << t4 << endl;
    Time t5 = t3 + t4;
    cout << "Time 3 + Time 4: " << endl;
    cout << t5 << endl;

    cout << "***************** Testing - Operator *****************" << endl;
    Time t6(2, 30, 45);
    cout << "Time 6:" << endl;
    cout << t6 << endl;
    Time t7(1, 30, 45);
    cout << "Time 7:" << endl;
    cout << t7 << endl;
    Time t8 = t6 - t7;
    cout << "Time 6 - Time 7: " << endl;
    cout << t8 << endl;

    cout << "***************** Testing += Operator *****************" << endl;
    Time t9(1, 30, 45);
    cout << "Time 9:" << endl;
    cout << t9 << endl;
    Time t10(2, 30, 45);
    cout << "Time 10:" << endl;
    cout << t10 << endl;
    t9 += t10;
    cout << "Time 9 += Time 10: " << endl;
    cout << t9 << endl;

    cout << "***************** Testing -= Operator *****************" << endl;
    Time t11(2, 30, 45);
    cout << "Time 11:" << endl;
    cout << t11 << endl;
    Time t12(1, 30, 45);
    cout << "Time 12:" << endl;
    cout << t12 << endl;
    t11 -= t12;
    cout << "Time 11 -= Time 12: " << endl;
    cout << t11 << endl;

    cout << "***************** Testing == Operator *****************" << endl;
    Time t13(2, 30, 45);
    cout << "Time 13:" << endl;
    cout << t13 << endl;
    Time t14(2, 30, 45);
    cout << "Time 14:" << endl;
    cout << t14 << endl;
    if (t13 == t14)
    {
        cout << "TRUE, Time 13 is equal to Time 14" << endl;
    }
    else
    {
        cout << "FALSE, Time 13 is not equal to Time 14" << endl;
    }
    cout << endl;

    cout << "***************** Testing != Operator *****************" << endl;
    Time t15(2, 30, 45);
    cout << "Time 15:" << endl;
    cout << t15 << endl;
    Time t16(2, 30, 30);
    cout << "Time 16:" << endl;
    cout << t16 << endl;
    if (t15 != t16)
    {
        cout << "TRUE, Time 15 is not equal to Time 16" << endl;
    }
    else
    {
        cout << "FALSE, Time 15 is equal to Time 16" << endl;
    }
    cout << endl;

    cout << "***************** Testing < Operator *****************" << endl;
    Time t17(2, 30, 45);
    cout << "Time 17:" << endl;
    cout << t17 << endl;
    Time t18(2, 30, 30);
    cout << "Time 18:" << endl;
    cout << t18 << endl;
    if (t17 < t18)
    {
        cout << "TRUE, Time 17 is less than Time 18" << endl;
    }
    else
    {
        cout << "FALSE, Time 17 is not less than Time 18" << endl;
    }
    cout << endl;

    cout << "***************** Testing <= Operator *****************" << endl;
    Time t19(2, 30, 45);
    cout << "Time 19:" << endl;
    cout << t19 << endl;
    Time t20(2, 30, 45);
    cout << "Time 20:" << endl;
    cout << t20 << endl;
    if (t19 <= t20)
    {
        cout << "TRUE, Time 19 is less than or equal to Time 20" << endl;
    }
    else
    {
        cout << "FALSE, Time 19 is not less than or equal to Time 20" << endl;
    }
    cout << endl;

    cout << "***************** Testing > Operator *****************" << endl;
    Time t21(2, 30, 45);
    cout << "Time 21:" << endl;
    cout << t21 << endl;
    Time t22(2, 30, 30);
    cout << "Time 22:" << endl;
    cout << t22 << endl;
    if (t21 > t22)
    {
        cout << "TRUE, Time 21 is greater than Time 22" << endl;
    }
    else
    {
        cout << "FALSE, Time 21 is not greater than Time 22" << endl;
    }
    cout << endl;

    cout << "***************** Testing >= Operator *****************" << endl;
    Time t23(2, 30, 45);
    cout << "Time 23:" << endl;
    cout << t23 << endl;
    Time t24(2, 30, 45);
    cout << "Time 24:" << endl;
    cout << t24 << endl;
    if (t23 >= t24)
    {
        cout << "TRUE, Time 23 is greater than or equal to Time 24" << endl;
    }
    else
    {
        cout << "FALSE, Time 23 is not greater than or equal to Time 24" << endl;
    }
    cout << endl;

    cout << "***************** Testing elapsedTime() Function *****************" << endl;
    Time t25(2, 30, 45);
    cout << "Time 25:" << endl;
    cout << t25 << endl;
    Time t26 = t25.elapsedTime();
    cout << "Elapsed Time is: " << endl;
    cout << t26 << endl;

    cout << "***************** Testing Input Operator *****************" << endl;
    Time t27;
    cin >> t27;

    cout << "***************** Testing Output Operator *****************" << endl;
    cout << t27;

    return 0;
}