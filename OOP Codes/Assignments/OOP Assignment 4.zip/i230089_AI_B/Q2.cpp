// Name:    Abdullah Qadri
// Roll No: 23I-0089
// Section: AI-B

#include <iostream>
#include <string>

using namespace std;

class Binary
{
private:
    string binaryString;
    int base;

public:
    // Constructor (If base is greater than 2 first convert into base 10 using that base and then convert back into binary and change the base to 2)
    Binary(string binaryStr = "", int base = 2) : binaryString(binaryStr), base(base)
    {
        int decimal = 0;
        int power = 0;
        // cout << "Constructor Called" << endl;

        if (base < 2)
        {
            cout << "Base cannot be less than 2" << endl;
            exit(1);
        }
        else if (base > 2)
        {
            // Convert to base 10
            cout << "Base is greater than 2 so Converting it to base 10" << endl;
            for (int i = (binaryStr.length() - 1); i >= 0; i--)
            {
                if (binaryStr[i] == '1')
                {
                    int temp = 1;
                    for (int j = 1; j <= power; j++)
                    {
                        temp = temp * 2;
                    }
                    decimal += temp;
                }
                power++;
            }
            cout << "Decimal: " << decimal << endl;

            // Changing to base 2
            cout << "Now changing back to base 2" << endl;
            this->base = 2;
            cout << "Changing DONE" << endl;
        }
    }

    // Overloading + operator for addition
    Binary operator+(const Binary &other) const
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Adding both the decimal values
        int sum = decimal + decimalOther;
        cout << "Sum: " << sum << endl;

        // Now converting the sum to binary
        Binary b;
        // b = new Binary();
        while (sum > 0)
        {
            int mod = sum % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            sum = sum / 2;
        }
        // this->binaryString = binarySumString;
        // cout << "Binary String: " << b.binaryString << endl;
        return b;

        // // Now converting the sum to binary
        // string binarySumString = "";
        // while (sum > 0)
        // {
        //     int mod = sum % 2;
        //     char ch = mod + 48;
        //     binarySumString = ch + binarySumString;
        //     sum = sum / 2;
        // }
        // // this->binaryString = binarySumString;
        // cout << "Binary String: " << binarySumString << endl;
        // return *this;
    }

    // Overloading - operator for subtraction
    Binary operator-(const Binary &other) const
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Subtracting both the decimal values
        int diff = decimal - decimalOther;
        cout << "diff: " << diff << endl;

        // Now converting the diff to binary
        Binary b;
        // b = new Binary();
        if (diff == 0)
        {
            b.binaryString = "0";
        }
        else if (diff > 0)
        {
            while (diff > 0)
            {
                int mod = diff % 2;
                char ch = mod + 48;
                b.binaryString = ch + b.binaryString;
                diff = diff / 2;
            }
        }
        else if (diff < 0)
        {
            cout << "Negative" << endl;
            diff = diff * -1;
            while (diff > 0)
            {
                int mod = diff % 2;
                char ch = mod + 48;
                b.binaryString = ch + b.binaryString;
                diff = diff / 2;
            }
            b = !b;
        }
        return b;

        // // Now converting the diff to binary
        // string binaryDiffString = "";
        // if (diff == 0)
        // {
        //     binaryDiffString = binaryString;
        // }
        // else if (diff > 0)
        // {
        //     while (diff > 0)
        //     {
        //         int mod = diff % 2;
        //         char ch = mod + 48;
        //         binaryDiffString = ch + binaryDiffString;
        //         diff = diff / 2;
        //     }
        // }
        // // this->binaryString = binaryDiffString;
        // cout << "Binary String: " << binaryDiffString << endl;
        // return *this;
    }

    // Overloading += operator for addition
    Binary &operator+=(const Binary &other)
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Adding both the decimal values
        int sum = decimal + decimalOther;
        cout << "Sum: " << sum << endl;

        // Now converting the sum to binary
        Binary b;
        // b = new Binary();
        while (sum > 0)
        {
            int mod = sum % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            sum = sum / 2;
        }
        // this->binaryString = binarySumString;
        // cout << "Binary String: " << b.binaryString << endl;
        *this = b;
        return *this;
    }

    // Overloading -= operator for subtraction
    Binary &operator-=(const Binary &other)
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Subtracting both the decimal values
        int diff = decimal - decimalOther;
        cout << "diff: " << diff << endl;

        // Now converting the diff to binary
        Binary b;
        // b = new Binary();
        if (diff == 0)
        {
            b.binaryString = "0";
        }
        else if (diff > 0)
        {
            while (diff > 0)
            {
                int mod = diff % 2;
                char ch = mod + 48;
                b.binaryString = ch + b.binaryString;
                diff = diff / 2;
            }
        }
        else if (diff < 0)
        {
            cout << "Negative" << endl;
            diff = diff * -1;
            while (diff > 0)
            {
                int mod = diff % 2;
                char ch = mod + 48;
                b.binaryString = ch + b.binaryString;
                diff = diff / 2;
            }
            b = !b;
        }
        *this = b;
        return *this;
    }

    // Overloading * operator for multiplication (Convert to base 10 multiply and convert back into base 2)
    Binary operator*(const Binary &other) const
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Multiplying both the decimal values
        int product = decimal * decimalOther;
        cout << "Product: " << product << endl;

        // Now converting the product to binary
        Binary b;
        while (product > 0)
        {
            int mod = product % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            product = product / 2;
        }
        // this->binaryString = binaryProductString;
        // cout << "Binary String: " << b.binaryString << endl;
        return b;
    }

    // Overloading / operator for division  (Convert to base 10 divide and convert back into base 2)
    Binary operator/(const Binary &other) const
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Dividing both the decimal values
        if (decimalOther == 0)
        {
            cout << "Cannot divide by 0" << endl;
            exit(1);
        }
        int quotient = decimal / decimalOther;
        cout << "Quotient: " << quotient << endl;

        // Now converting the quotient to binary
        Binary b;
        while (quotient > 0)
        {
            int mod = quotient % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            quotient = quotient / 2;
        }
        // this->binaryString = binaryQuotientString;
        // cout << "Binary String: " << b.binaryString << endl;
        return b;
    }

    // Overloading % operator for modulus  (Convert to base 10 modulus and convert back into base 2)
    Binary operator%(const Binary &other) const
    {
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // Changing the other string to base 10
        int decimalOther = 0;
        int powerOther = 0;
        for (int i = (other.binaryString.length() - 1); i >= 0; i--)
        {
            if (other.binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= powerOther; j++)
                {
                    temp = temp * 2;
                }
                decimalOther += temp;
            }
            powerOther++;
        }

        // Modulus both the decimal values
        if (decimalOther == 0)
        {
            cout << "Cannot divide by 0" << endl;
            exit(1);
        }
        int modulus = decimal % decimalOther;
        cout << "Modulus: " << modulus << endl;

        // Now converting the modulus to binary
        Binary b;
        while (modulus > 0)
        {
            int mod = modulus % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            modulus = modulus / 2;
        }
        // this->binaryString = binaryModulusString;
        // cout << "Binary String: " << b.binaryString << endl;
        return b;
    }

    // Overloading | operator for or
    Binary operator|(const Binary &other) const
    {
        Binary b;
        int bigLen, smallLen;
        if (this->binaryString.length() < other.binaryString.length())
        {
            smallLen = this->binaryString.length();
            bigLen = other.binaryString.length();
            for (int i = bigLen - 1; i >= smallLen; i--)
            {
                if (this->binaryString[i] == '1' || other.binaryString[i] == '1')
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }

            for (int i = bigLen - smallLen - 1; i >= 0; i--)
            {
                b.binaryString = '0' + b.binaryString;
            }
        }
        else
        {
            smallLen = other.binaryString.length();
            bigLen = this->binaryString.length();
            for (int i = bigLen - 1; i >= smallLen; i--)
            {
                if (this->binaryString[i] == '1' || other.binaryString[i] == '1')
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }

            for (int i = bigLen - smallLen - 1; i >= 0; i--)
            {
                b.binaryString = '0' + b.binaryString;
            }
        }
        return b;
    }

    // Overloading & operator for and
    Binary operator&(const Binary &other) const
    {
        Binary b;
        int bigLen, smallLen;
        if (this->binaryString.length() < other.binaryString.length())
        {
            smallLen = this->binaryString.length();
            bigLen = other.binaryString.length();
            for (int i = bigLen - 1; i >= smallLen; i--)
            {
                if (this->binaryString[i] == '1' && other.binaryString[i] == '1')
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }

            for (int i = bigLen - smallLen - 1; i >= 0; i--)
            {
                b.binaryString = '0' + b.binaryString;
            }
        }
        else
        {
            smallLen = other.binaryString.length();
            bigLen = this->binaryString.length();
            for (int i = bigLen - 1; i >= smallLen; i--)
            {
                if (this->binaryString[i] == '1' && other.binaryString[i] == '1')
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }

            for (int i = bigLen - smallLen - 1; i >= 0; i--)
            {
                b.binaryString = '0' + b.binaryString;
            }
        }
        return b;
    }

    // Overloading ^ operator for xor
    Binary operator^(const Binary &other) const
    {
        Binary b;
        int bigLen, smallLen;
        if (this->binaryString.length() < other.binaryString.length())
        {
            smallLen = this->binaryString.length();
            bigLen = other.binaryString.length();
            for (int i = bigLen; i >= smallLen; i--)
            {
                if ((this->binaryString[i] == '1' && other.binaryString[i] == '0') || (this->binaryString[i] == '0' && other.binaryString[i] == '1'))
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }

            for (int i = bigLen - smallLen; i >= 0; i--)
            {
                if (other.binaryString[i] == '1')
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }
        }
        else
        {
            smallLen = other.binaryString.length();
            bigLen = this->binaryString.length();
            for (int i = bigLen; i >= smallLen; i--)
            {
                if ((this->binaryString[i] == '1' && other.binaryString[i] == '0') || (this->binaryString[i] == '0' && other.binaryString[i] == '1'))
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }

            for (int i = bigLen - smallLen; i >= 0; i--)
            {
                if (other.binaryString[i] == '1')
                {
                    b.binaryString = '1' + b.binaryString;
                }
                else
                {
                    b.binaryString = '0' + b.binaryString;
                }
            }
        }
        return b;
    }

    // Overloading ! operator for 2's Compliment
    Binary operator!()
    {
        for (int i = 32 - ((this->binaryString.length()) + 1); i >= 0; i--)
        {
            this->binaryString = '0' + this->binaryString;
        }
        cout << "Binary String: " << this->binaryString << endl;

        ~(*this);
        cout << "Binary String before 2's: " << this->binaryString << endl;

        int control = 1;
        for (int i = 31; i >= 0; i--)
        {
            char ch = this->binaryString[i];
            if (ch == '1' && control == 1)
            {
                this->binaryString[i] = '0';
                control = 1;
            }
            else if (ch == '1' && control == 0)
            {
                this->binaryString[i] = '1';
                control = 0;
            }
            else if (ch == '0' && control == 1)
            {
                this->binaryString[i] = '1';
                control = 0;
            }
            else if (ch == '0' && control == 0)
            {
                this->binaryString[i] = '0';
                control = 0;
            }
        }

        // cout << *this;
        return *this;
    }

    // Overloading ~ operator for 1's Compliment
    Binary operator~()
    {
        // cout << "Length is: " << binaryString.length() << endl;
        for (int i = 0; i < binaryString.length(); i++)
        {
            if (binaryString[i] == '0')
            {
                binaryString[i] = '1';
            }
            else
            {
                binaryString[i] = '0';
            }
        }

        return *this;
    }

    // Overloading left shift operator (Multiplies)
    Binary operator<<(int shiftAmount) const
    {
        if (shiftAmount < 0)
        {
            // If -ve, then call opposite operator
            this->operator>>(shiftAmount * -1);
        }
        else if (shiftAmount == 0)
        {
            return *this;
        }
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // taking power of 2
        int toShift=1;
        for (int i = 1; i <= shiftAmount; i++)
        {
            toShift *= 2;
        }

        // Multiplying both the decimal values
        int product = decimal * toShift;
        cout << "Product: " << product << endl;

        // Now converting the product to binary
        Binary b;
        while (product > 0)
        {
            int mod = product % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            product = product / 2;
        }
        // this->binaryString = binaryProductString;
        // cout << "Binary String: " << b.binaryString << endl;
        return b;
    }

    // Overloading right shift operator (Divides)
    Binary operator>>(int shiftAmount) const
    {
        if (shiftAmount < 0)
        {
            // If -ve, then call opposite operator
            this->operator<<(shiftAmount * -1);
        }
        else if (shiftAmount == 0)
        {
            return *this;
        }
        // Changing the main string to base 10
        int decimal = 0;
        int power = 0;
        for (int i = (binaryString.length() - 1); i >= 0; i--)
        {
            if (binaryString[i] == '1')
            {
                int temp = 1;
                for (int j = 1; j <= power; j++)
                {
                    temp = temp * 2;
                }
                decimal += temp;
            }
            power++;
        }

        // taking power of 2
        int toShift=1;
        for (int i = 1; i <= shiftAmount; i++)
        {
            toShift *= 2;
        }

        // Multiplying both the decimal values
        int divide = decimal / toShift;
        cout << "divide: " << divide << endl;

        // Now converting the divide to binary
        Binary b;
        while (divide > 0)
        {
            int mod = divide % 2;
            char ch = mod + 48;
            b.binaryString = ch + b.binaryString;
            divide = divide / 2;
        }
        // this->binaryString = binarydivideString;
        // cout << "Binary String: " << b.binaryString << endl;
        return b;
    }

    // Overloading input operator
    friend istream &operator>>(istream &input, Binary &other)
    {
        cout << "Enter Binary String: ";
        getline(input, other.binaryString);
        cout << "Enter Base: ";
        input >> other.base;
        return input;
    }

    // Overloading output operator (Display Both Binary as well as Integer value)
    friend ostream &operator<<(ostream &output, const Binary &other)
    {
        output << "Binary String: " << other.binaryString << endl;
        output << "Base: " << other.base << endl;
        return output;
    }
};

int main()
{
    system("cls");
    cout << "*** Adding 2 Binary Objects by + ***" << endl;
    Binary b1("1010", 2); // 10
    cout << "First Binary Object: " << endl
         << b1 << endl;
    Binary b2("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b2 << endl;
    Binary b3 = b1 + b2;
    cout << "Result of Addition: " << endl;
    cout << b3 << endl;

    cout << "*** Subtracting 2 Binary Objects by - ***" << endl;
    Binary b4("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b4 << endl;
    Binary b5("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b5 << endl;
    Binary b6 = b4 - b5;
    cout << "Result of Subtraction:" << endl;
    cout << b6 << endl;

    cout << "*** Adding 2 Binary Objects by += ***" << endl;
    Binary b8("1010", 2); // 10
    cout << "First Binary Object: " << endl
         << b8 << endl;
    Binary b9("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b9 << endl;
    b8 += b9;
    cout << "First Binary Object Changes: " << endl
         << b8 << endl;

    cout << "*** Subtracting 2 Binary Objects by -= ***" << endl;
    Binary b11("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b11 << endl;
    Binary b12("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b12 << endl;
    b12 -= b11;
    cout << "Second Binary Object Changes: " << endl
         << b12 << endl;

    cout << "*** Multiplying 2 Binary Objects by * ***" << endl;
    Binary b13("1010", 2); // 10
    cout << "First Binary Object: " << endl
         << b13 << endl;
    Binary b14("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b14 << endl;
    Binary b15 = b13 * b14;
    cout << "Result of Multiplication:" << endl;
    cout << b15 << endl;

    cout << "*** Dividing 2 Binary Objects by / ***" << endl;
    Binary b16("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b16 << endl;
    Binary b17("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b17 << endl;
    Binary b18 = b16 / b17;
    cout << "Result of Division:" << endl;
    cout << b18 << endl;

    cout << "*** Modulus 2 Binary Objects by % ***" << endl;
    Binary b19("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b19 << endl;
    Binary b20("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b20 << endl;
    Binary b21 = b19 % b20;
    cout << "Result of Modulus:" << endl;
    cout << b21 << endl;

    cout << "*** 2's Compliment of Binary Object by ! ***" << endl;
    Binary b22("1010", 2); // 10
    cout << "First Binary Object: " << endl
         << b22 << endl;
    Binary b23 = !b22;
    cout << "2's Compliment: " << b23 << endl;

    cout << "*** 1's Compliment of Binary Object by ~ ***" << endl;
    Binary b24("1010", 2); // 10
    cout << "First Binary Object: " << endl
         << b24 << endl;
    Binary b25 = ~b24;
    cout << "1's Compliment: " << b25 << endl;

    cout << "*** OR of 2 Binary Objects by | ***" << endl;
    Binary b26("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b26 << endl;
    Binary b27("10", 2); // 2
    cout << "Second Binary Object: " << endl
         << b27 << endl;
    Binary b28 = b26 | b27;
    cout << "Result of OR:" << endl;
    cout << b28 << endl;

    cout << "*** AND of 2 Binary Objects by & ***" << endl;
    Binary b29("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b29 << endl;
    Binary b30("10", 2); // 2
    cout << "Second Binary Object: " << endl
         << b30 << endl;
    Binary b31 = b29 & b30;
    cout << "Result of AND:" << endl;
    cout << b31 << endl;

    cout << "*** XOR of 2 Binary Objects by ^ ***" << endl;
    Binary b32("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b32 << endl;
    Binary b33("1010", 2); // 10
    cout << "Second Binary Object: " << endl
         << b33 << endl;
    Binary b34 = b32 ^ b33;
    cout << "Result of XOR:" << endl;
    cout << b34 << endl;

    cout << "*** Left Shift of Binary Object by << ***" << endl;
    Binary b35("10", 2); // 2
    cout << "First Binary Object: " << endl
         << b35 << endl;
    Binary b36 = b35 << 3;
    cout << "2 Left Shift of 3: " << endl; 
    cout << b36 << endl;

    cout << "*** Right Shift of Binary Object by >> ***" << endl;
    Binary b37("10100", 2); // 20
    cout << "First Binary Object: " << endl
         << b37 << endl;
    Binary b38 = b37 >> 2;
    cout << "20 Right Shift of 2: " << endl;
    cout << b38 << endl;

    cout << "*** Input and Output using Operators ***" << endl;
    Binary b7;
    cin >> b7;
    cout << b7;
    cout << endl;
}
