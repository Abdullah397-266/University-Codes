// Abdulllah Qadri
// 23i-0089
// AI-B

#include <iostream>
#include <ctime>

using namespace std;

void AddScalar(int ***&p, int row, int col, int layer);
void Subtract(int ***&p, int row, int col, int layer);
void Multiply(int ***&p, int row, int col, int layer);
void Divide(int ***&p, int row, int col, int layer);
void Transpose(int ***&p, int row, int col, int layer);
void Normal_Deallocate(int ***p, int row, int layer);
void Trans_Deallocate(int ***p, int col, int layer);
int Choice(int choice);

int main()
{
    srand(time(NULL));
    int row, col, layer;

    cout << "Enter Rows Columns and Layers respectively: ";
    if (cin >> row >> col >> layer)
    {
        if (row > 0 && col > 0 && layer > 0)
        {
        }
        else
        {
            cout << "Invalid Input: All must be > 0" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input: Input must be a number" << endl;
        return 0;
    }
    cout << endl;

    //* Making the matrix dynamically
    cout << "Here is your Generated Matrix: " << endl;
    int ***p = new int **[layer];
    for (int i = 0; i < layer; i++)
    {
        p[i] = new int *[row];
        for (int j = 0; j < row; j++)
        {
            p[i][j] = new int[col];
            for (int k = 0; k < col; k++)
            {
                p[i][j][k] = (rand() % 89) + 10;
                cout << p[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }

    // Asking for Operation
    int choice = 0;
    choice = Choice(choice);

    if (choice == 1)
    {
        AddScalar(p, row, col, layer);
        Normal_Deallocate(p, row, layer);
    }
    else if (choice == 2)
    {
        Subtract(p, row, col, layer);
        Normal_Deallocate(p, row, layer);
    }
    else if (choice == 3)
    {
        Multiply(p, row, col, layer);
        Normal_Deallocate(p, row, layer);
    }
    else if (choice == 4)
    {
        Divide(p, row, col, layer);
        Normal_Deallocate(p, row, layer);
    }
    else if (choice == 5)
    {
        Transpose(p, row, col, layer);
        Trans_Deallocate(p, col, layer);
    }

    return 0;
}

//* Functions Begin

int Choice(int choice)
{
    cout << "For Addition, press 1" << endl
         << "For Subtraction, press 2" << endl
         << "For Multiplication, press 3" << endl
         << "For Division, press 4" << endl
         << "To take transpose, press 5" << endl
         << "Enter: ";
    if (cin >> choice)
    {
        if (choice > 0 && choice < 6)
        {
        }
        else
        {
            cout << "Invalid Number" << endl;
            exit(0);
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        exit(0);
    }

    return choice;
}

void AddScalar(int ***&p, int row, int col, int layer)
{
    int num;

    cout << "Enter the number you want to add: ";
    if (cin >> num)
    {
        if (num > -1)
        {
        }
        else
        {
            cout << "Invalid Input: number must be >= 0" << endl;
            exit(0);
        }
    }
    else
    {
        cout << "Invalid Input: Input must be a number" << endl;
        exit(0);
    }

    for (int i = 0; i < layer; i++)
    {
        for (int j = 0; j < row; j++)
        {
            for (int k = 0; k < col; k++)
            {
                p[i][j][k] += num;
                cout << p[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
}

void Subtract(int ***&p, int row, int col, int layer)
{
    int num;

    cout << "Enter the number you want to add: ";
    if (cin >> num)
    {
        if (num > -1)
        {
        }
        else
        {
            cout << "Invalid Input: number must be >= 0" << endl;
            exit(0);
        }
    }
    else
    {
        cout << "Invalid Input: Input must be a number" << endl;
        exit(0);
    }

    for (int i = 0; i < layer; i++)
    {
        for (int j = 0; j < row; j++)
        {
            for (int k = 0; k < col; k++)
            {
                p[i][j][k] -= num;
                cout << p[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
}

void Multiply(int ***&p, int row, int col, int layer)
{
    int num;

    cout << "Enter the number you want to add: ";
    if (cin >> num)
    {
    }
    else
    {
        cout << "Invalid Input: Input must be a number" << endl;
        exit(0);
    }

    for (int i = 0; i < layer; i++)
    {
        for (int j = 0; j < row; j++)
        {
            for (int k = 0; k < col; k++)
            {
                p[i][j][k] *= num;
                cout << p[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
}

void Divide(int ***&p, int row, int col, int layer)
{
    int num;

    cout << "Enter the number you want to add: ";
    if (cin >> num)
    {
        if (num != 0)
        {
        }
        else
        {
            cout << "Invalid Input: number must not be 0" << endl;
            exit(0);
        }
    }
    else
    {
        cout << "Invalid Input: Input must be a number" << endl;
        exit(0);
    }

    for (int i = 0; i < layer; i++)
    {
        for (int j = 0; j < row; j++)
        {
            for (int k = 0; k < col; k++)
            {
                p[i][j][k] /= num;
                cout << p[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
}

void Transpose(int ***&p, int row, int col, int layer)
{
    cout << endl
         << "Transpose is: " << endl;
    int ***trans = new int **[layer];
    for (int i = 0; i < layer; i++)
    {
        trans[i] = new int *[col];
        for (int j = 0; j < col; j++)
        {
            trans[i][j] = new int[row];
            for (int k = 0; k < row; k++)
            {
                trans[i][j][k] = p[j][i][k];
                cout << trans[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }

    // De-allocating previous Memory
    Normal_Deallocate(p, row, layer);

    // Assigning New memory
    p = trans;
}

void Normal_Deallocate(int ***p, int row, int layer)
{
    for (int i = 0; i < layer; i++)
    {
        for (int j = 0; j < row; j++)
        {
            delete[] p[i][j];
        }
        delete[] p[i];
    }
    delete[] p;
}

void Trans_Deallocate(int ***p, int col, int layer)
{
    for (int i = 0; i < layer; i++)
    {
        for (int j = 0; j < col; j++)
        {
            delete[] p[i][j];
        }
        delete[] p[i];
    }
    delete[] p;
}