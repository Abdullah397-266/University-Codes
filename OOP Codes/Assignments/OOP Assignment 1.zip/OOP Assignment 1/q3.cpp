// Abdulllah Qadri
// 23i-0089
// AI-B

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int num, range;

    cout << "Enter the Starting number: ";
    if (cin >> num)
    {
        if (num > 0)
        {
        }
        else
        {
            cout << "Invalid Input \n Number must be greater than 0" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input \n Enter a number only" << endl;
        return 0;
    }

    cout << "Enter the range of numbers: ";
    if (cin >> range)
    {
        if (num > 0)
        {
        }
        else
        {
            cout << "Invalid Input \n Number must be greater than 0" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input \n Enter a number only" << endl;
        return 0;
    }

    const int Range = range;
    int *arr = new int[Range];
    int *newArr = new int[Range]; 
    // short int arr[Range]; 
    int temp = num, count = 0;
    while (temp)
    {
        temp /= 10;
        count++;
    }
    // cout << count;
    temp = num;
    for (int i = count - 1; i >= 0; i--)
    {
        arr[i] = temp % 10;
        temp /= 10;
        // cout << arr[i];
    }

    int firstVal, sameNumCount = 1, arrLength = count, j = 0, combLength = 0;
    long long int combinedNum = num;
    int preJ = 0;
    temp = 0;

    cout << num << endl;
    while ((combinedNum < (pow(2, 63) - 1) && combinedNum > 0) && combLength < range)
    {
        // cout << "arrLength: "<< arrLength << endl;
        // cout << "!";
        // cout << "1st val: " << firstVal << endl;
        firstVal = arr[0];
        sameNumCount = 1;
        combLength = 0;
        for (int i = 0; i < arrLength; i++)
        {
            // cout << "@";
            while (arr[i + 1] == firstVal)
            {
                // cout << endl << "Inside IF";
                sameNumCount++;
                ++i;
            }
            {
                for (; j < (preJ + 2); j++)
                {
                    // cout << "#";
                    if (j == 0 || j % 2 == 0)
                    {
                        newArr[j] = sameNumCount;
                        combLength++;
                        if (combLength > range)
                        {
                            cout << "Overflow Occured!!!" << endl;
                            delete[] arr;
                            delete[] newArr;
                            return 0;
                        }
                    }
                    else
                    {
                        newArr[j] = firstVal;
                        combLength++;
                        if (combLength > range)
                        {
                            cout << "Overflow Occured!!!" << endl;
                            delete[] arr;
                            delete[] newArr;
                            return 0;
                        }
                    }
                    // cout << sameNumCount << firstVal;
                    // cout << newArr[j];
                }
                preJ = j;
                firstVal = arr[i + 1];
                sameNumCount = 1;
                // cout << endl << "After 1stVal: " << firstVal << endl;
            }
        }
        // cout << endl;
        j = 0;
        preJ = 0;

        combinedNum = newArr[0];
        for (int i = 1; i < combLength; i++)
        {
            // cout << "$";
            combinedNum = (combinedNum * 10) + newArr[i];
            if ((combinedNum < (pow(2, 63) - 1) && combinedNum > 0))
            {
            }
            else
            {
                cout << "Overflow Occured!!!" << endl;
                delete[] arr;
                delete[] newArr;
                return 0;
            }
        }
        cout << combinedNum << endl;

        for (int i = 0; i < range; i++)
        {
            arr[i] = newArr[i];
            newArr[i] = 0;
        }

        // temp = combinedNum;
        // count = 0;
        // while (temp)
        // {
        //     // cout << "%";
        //     temp /= 10;
        //     count++;
        // }
        // cout << "Count is: " << count << endl;

        // cout << "arrLength: " << arrLength << endl;
        arrLength = combLength; // count
        count = 0;
        combLength = 0;
    }

    delete[] arr;
    delete[] newArr;

    return 0;
}