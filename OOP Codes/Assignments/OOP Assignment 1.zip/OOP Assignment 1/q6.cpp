// Abdulllah Qadri
// 23i-0089
// AI-B

#include <iostream>
#include <fstream>

using namespace std;

void Draw(char **);
void Encrypt(char **);
void Decrypt(char **);
void UpdateGrid(char **);

int main()
{
    char symbol;
    cout << "Enter a symbol to draw pattern with: ";
    cin >> symbol;

    char **p = new char *[5];
    for (int i = 0; i < 5; i++)
    {
        p[i] = new char[5];
        for (int j = 0; j < 5; j++)
        {
            if (i == 0 || i == 2 || i == 4 || j == 0)
            {
                p[i][j] = symbol;
            }
            else
            {
                p[i][j] = ' ';
            }
        }
    }
    cout << endl;

    // Drawing the pattern
    cout << "Drawing the pattern: " << endl;
    Draw(p);
    cout << endl;

    // Encrypting The pattern
    cout << "Encrypting The pattern:" << endl;
    Encrypt(p);
    cout << endl;

    // Decrypting The pattern
    cout << "Decrypting The pattern:" << endl;
    Decrypt(p);
    cout << endl;

    // Updating Grid
    UpdateGrid(p);
    cout << endl; 

    // Releaseing the memory
    for (int i = 0; i < 5; i++)
    {
        delete[] p[i];
    }
    delete[] p;
}

void Draw(char **p)
{
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cout << p[i][j] << " ";
        }
        cout << endl;
    }
}

void Encrypt(char **p)
{
    char temp;
    char **p1 = new char *[5];
    for (int i = 0; i < 5; i++)
    {
        p1[i] = new char[5];
        for (int j = 0; j < 5; j++)
        {
            p1[i][j] = p[j][i];
        }
    }

    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (i == 0)
            {
                temp = p1[0][j];
                p1[0][j] = p1[4][j];
            }
            if (i == 4)
            {
                p1[4][j] = temp;
            }
            cout << p1[i][j] << " ";
        }
        cout << endl;
    }

    p = p1;
}

void Decrypt(char **p)
{
    char **p1 = new char *[5];
    for (int i = 0; i < 5; i++)
    {
        p1[i] = new char[5];
        for (int j = 0; j < 5; j++)
        {
            p1[i][j] = p[i][j];
            cout << p1[i][j] << " ";
        }
        cout << endl;
    }

    p = p1;
}

void UpdateGrid(char **p)
{
    char symbol;
    int row, col;
    cout << "Enter the symbol to change: ";
    if (cin >> symbol)
    {
    }
    else
    {
        cout << "Invalid Input";
        exit(0);
    }

    cout << "Enter the row index and col index: ";
    if (cin >> row >> col)
    {
        if ((row > -1 && row < 6) && (col > -1 && col < 6))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            exit(0);
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        exit(0);
    }

    cout << "Grid after updation: " << endl;

    if (p[row][col] != ' ')
    {
        p[row][col] = symbol;
    }
    else
    {
        cout << "Updation NOT Possible" << endl;
    }
    cout << endl;

    Draw(p);
}