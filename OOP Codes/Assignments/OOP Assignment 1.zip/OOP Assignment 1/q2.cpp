// Abdulllah Qadri
// 23i-0089
// AI-B

#include <iostream>

using namespace std;

void resize(int **&arr, int info[])
{
    int col, row;
    int colChange, rowChange;

    cout << "Enter the change in rows and columns respectively: ";
    if (cin >> colChange >> rowChange)
    {
        if (colChange >= 0 && rowChange >= 0)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            exit(0);
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        exit(0);
    }

    // Changing the size
    col = info[0] + colChange;
    row = info[1] + rowChange;
    int size = col * row;

    // Creating new resized arrat
    int **p2 = new int *[col];
    for (int i = 0; i < col; i++)
    {
        p2[i] = new int[row];
    }

    // filling Previous elements
    for (int i = 0; i < (row - rowChange); i++)
    {
        for (int j = 0; j < (col - colChange); j++)
        {
            p2[i][j] = arr[i][j];
        }
    }

    // Removing link from previous array
    for (int i = 0; i < (col - colChange); i++)
    {
        delete arr[i];
    }
    delete arr;

    // pointing the ariginal array to newly created array
    arr = p2;

    // returning these updated values
    info[0] = col;
    info[1] = row;
    info[2] = size;
    // // removing link from the p2 (temporary 2d pointer)
    // for (int i = 0; i < col; i++)
    // {
    //     delete p2[i];
    // }
    // delete p2;

    
}

int main()
{
    int col = 3, row = 3;
    int count = 0;
    int size = col * row;
    int info[3];
    info[0] = col;
    info[1] = row;
    info[2] = size;

    // cout << col << " " << row << " " << size << endl;

    cout << "Previous dynamic 2D array:" << endl;

    int **p = new int *[col];
    for (int i = 0; i < col; i++)
    {
        p[i] = new int[row];
        for (int j = 0; j < row; j++)
        {
            p[i][j] = count;
            cout << p[i][j] << " ";
            count++;
        }
        cout << endl;
    }

    resize(p, info);

    col = info[0];
    row = info[1];
    size = info[2];

    // cout << col << " " << row << " " << size << endl;

    cout << endl
         << "After dynamic 2D array:" << endl;

    for (int i = 0; i < col; i++)
    {
        for (int j = 0; j < row; j++)
        {
            cout << p[i][j] << " ";
        }
        cout << endl;
    }

    // Removing link from previous array
    for (int i = 0; i < (col / 2); i++)
    {
        delete p[i];
    }
    delete p;

    return 0;
}