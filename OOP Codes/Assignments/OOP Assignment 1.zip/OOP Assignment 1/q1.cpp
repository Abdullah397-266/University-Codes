// Abdulllah Qadri
// 23i-0089
// AI-B

#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream file;
    file.open("Boggle.txt", ios::out | ios::in | ios::app);
    if (!file)
    {
        cout << "File NOT created" << endl;
    }
    else
    {
        cout << "File created successfully" << endl;
    }
    char boggleArr[10][10] = {'R', 'E', 'T', 'A', 'W', 'S', 'T', 'L', 'Y', 'B',
                              'P', 'O', 'I', 'U', 'C', 'M', 'P', 'T', 'A', 'E',
                              'S', 'E', 'H', 'D', 'R', 'I', 'E', 'V', 'O', 'F',
                              'R', 'S', 'N', 'A', 'I', 'O', 'L', 'E', 'T', 'C',
                              'A', 'E', 'E', 'E', 'C', 'A', 'R', 'S', 'S', 'T',
                              'G', 'L', 'O', 'P', 'T', 'E', 'E', 'O', 'H', 'Y',
                              'L', 'U', 'S', 'E', 'R', 'S', 'A', 'P', 'R', 'O',
                              'T', 'R', 'E', 'N', 'C', 'H', 'O', 'O', 'U', 'R',
                              'A', 'F', 'R', 'I', 'C', 'A', 'N', 'Z', 'U', 'U',
                              'S', 'E', 'A', 'O', 'H', 'O', 'R', 'I', 'A', 'N'};

    //* Coping Boggle array to the file
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            file << boggleArr[i][j];
        }
    }

    //* taking input from the user
    string word;
    int length = 0;
    cout << "Enter the word to find (In capital letters): ";
    if (cin >> word)
    {
        length = word.length();
        // cout << "Length of word is: " << length << endl;
        for (int i = 0; i < length; i++)
        {
            if (word[i] >= 'A' && word[i] <= 'Z')
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                cout << "Enter all Alphabets in Capital: ";
            }
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        cout << "Enter all Alphabets in Capital: ";
    }

    // Finding The entered word in the Array
    bool flag = false;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (boggleArr[i][j] == word[0])
            {
                // checking on x-axis
                for (int k = 1; (k < length); k++)
                {
                    flag = false;
                    if ((j+k)>=10)
                    {
                        break;
                    }
                    if (boggleArr[i][j + k] == word[k])
                    {
                        flag = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (flag == true)
                {
                    cout << "Word Found on x-axis" << endl;
                    cout << "Starting Index: (" << i << ", " << j << ")" << endl;
                    cout << "Ending Index: (" << i << ", " << (j + length - 1) << ")" << endl;
                    file.close();
                    return 0;
                }

                // checking on negative x-axis
                for (int k = 1; (k < length); k++)
                {
                    flag = false;
                    if(j-k<0 || j-k>9)
                    {
                        break;
                    }
                    if (boggleArr[i][j - k] == word[k])
                    {
                        flag = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (flag == true)
                {
                    cout << "Word Found on -ve x-axis" << endl;
                    cout << "Starting Index: (" << i << ", " << j << ")" << endl;
                    cout << "Ending Index: (" << i << ", " << (j - length + 1) << ")" << endl;
                    file.close();
                    return 0;
                }

                // checking on y-axis
                for (int k = 1; (k < length); k++)
                {
                    flag = false;
                    if((i+k)>=10)
                    {
                        break;
                    }
                    if (boggleArr[i + k][j] == word[k])
                    {
                        flag = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (flag == true)
                {
                    cout << "Word Found on y-axis" << endl;
                    cout << "Starting Index: (" << i << ", " << j << ")" << endl;
                    cout << "Ending Index: (" << (i + length - 1) << ", " << j << ")" << endl;
                    file.close();
                    return 0;
                }

                // checking on negative y-axis
                for (int k = 1; (k < length); k++)
                {
                    flag = false;
                    if (i-k<0 || i-k > 9)
                    {
                        break;
                    }
                    if (boggleArr[i - k][j] == word[k])
                    {
                        flag = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (flag == true)
                {
                    cout << "Word Found on -ve y-axis" << endl;
                    cout << "Starting Index: (" << i << ", " << j << ")" << endl;
                    cout << "Ending Index: (" << (i - length + 1) << ", " << j << ")" << endl;
                    file.close();
                    return 0;
                }

                // checking on Diagonal
                for (int k = 1; (k < length); k++)
                {
                    flag = false;
                    if ((i+k>=10 || j+k>=10))
                    {
                        break;
                    }
                    if (boggleArr[i + k][j + k] == word[k])
                    {
                        flag = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (flag == true)
                {
                    cout << "Word Found on Diagonal" << endl;
                    cout << "Starting Index: (" << i << ", " << j << ")" << endl;
                    cout << "Ending Index:   (" << (i + length - 1) << ", " << (j + length - 1) << ")" << endl;
                    file.close();
                    return 0;
                }

                // checking on reverse Diagonal
                for (int k = 1; (k < length); k++)
                {
                    flag = false;
                    if(i-k<0 || j-k<0)
                    {
                        break;
                    }
                    if (boggleArr[i - k][j - k] == word[k])
                    {
                        flag = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (flag == true)
                {
                    cout << "Word Found on -ve Diagonal" << endl;
                    cout << "Starting Index: (" << i << ", " << j << ")" << endl;
                    cout << "Ending Index:   (" << (i - length + 1) << ", " << (j - length + 1) << ")" << endl;
                    file.close();
                    return 0;
                }
            }
        }
    }
    if (flag == false)
    {
        cout << "Word NOT found" << endl;
        file.close();
        return 0;
    }

    file.close();
    return 0;
}