// Abdulllah Qadri
// 23i-0089
// AI-B

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int Length(const char *str);
void ConvertToCharArr(const string &str);
void Concatenate(char *, char *);
void Compare(const char *, const char *);

int main()
{
    int choice = 0;
    cout << "Enter 1 for Length calculation" << endl
         << "Enter 2 for conversion from string to Char array" << endl
         << "Enter 3 for concatenation of char Arrays" << endl
         << "Enter 4 for Comparison of strings" << endl
         << "Enter (1-4): ";
    if (cin >> choice)
    {
        if (!(choice > 0 && choice < 5))
        {
            cout << "Invalid Input, Plz enter a valid number" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    cout << endl;

    if (choice == 1)
    {
        string str;
        cout << "Enter a string: ";
        getline(cin, str);
        getline(cin, str);
        cout << "Length of String is: " << Length(&str[0]) << endl;
    }
    else if (choice == 2)
    {
        string str;
        cout << "Enter a string: ";
        getline(cin, str);
        getline(cin, str);
        ConvertToCharArr(str);
    }
    else if (choice == 3)
    {
        string str1, str2;
        cout << "Enter 1st String: ";
        getline(cin, str1);
        getline(cin, str1);
        cout << "Enter 2nd String: ";
        getline(cin, str2);

        Concatenate(&str1[0], &str2[0]);
    }
    else
    {
        string str1, str2;
        cout << "Enter String: ";
        getline(cin, str1);
        getline(cin, str1);
        cout << "Enter Pattern: ";
        getline(cin, str2);

        Compare(&str1[0], &str2[0]);
    }
    //  int len=0;
    //  cout << str << endl;

    // cout << "Length of string is: " << len << endl;

    // ConvertToCharArr(str);
    // Concatenate();

    return 0;
}

int Length(const char *str)
{
    int i = 0, count = 0;
    while (str[i] != '\0')
    {
        count++;
        i++;
    }

    return count;
}

void ConvertToCharArr(const string &str)
{
    int length = 0, i = 0;
    length = Length(&str[0]);
    char *p = new char[length];
    cout << "Array is: ";
    while (str[i] != '\0')
    {
        p[i] = str[i];
        cout << p[i] << " ";
        i++;
    }
    cout << endl;
}

void Concatenate(char *p1, char *p2)
{
    int len1, len2, combLen, i = 0;

    // Finding Lengths of strings
    len1 = Length(p1);
    len2 = Length(p2);
    combLen = len1 + len2;

    char *arr1 = new char[len1];
    char *arr2 = new char[len2];
    char *combArr = new char[combLen];

    // Converting Strings to array
    while (p1[i] != '\0')
    {
        arr1[i] = p1[i];
        i++;
    }

    i = 0;
    while (p2[i] != '\0')
    {
        arr2[i] = p2[i];
        i++;
    }

    // Concatenating arrays
    cout << "Combined Array is: ";
    for (int j = 0; j < combLen; j++)
    {
        if (j < len1)
        {
            combArr[j] = arr1[j];
        }
        else
        {
            combArr[j] = arr2[j - len1];
        }
        cout << combArr[j] << " ";
    }
    cout << endl;
}

void Compare(const char *p1, const char *p2)
{
    const int len = Length(p1);
    const int len_p2 = Length(p2);

    char *arr = new char[len];
    int p1i=0;
    
    for (int i = 0; i < len_p2; i++)
    {
        if (p1[p1i] == p2[i])
        {
            arr[p1i] = p1[p1i];
            ++p1i;
        }
        else if (p2[i] == '#')
        {
            arr[p1i] = p1[p1i];
            ++p1i;
        }
        else if (p2[i] == '*')
        {
            char toRepeat;
            toRepeat = p1[p1i];

            while (p1[p1i] == toRepeat)
            {
                arr[p1i] = p1[p1i];
                ++p1i;
            }
        }
    }

    bool flag = true;
    cout << "Matched Array is: ";
    for (int i = 0; i < len; i++)
    {
        if (arr[i] != p1[i])
        {
            flag = false;
        }
        cout << arr[i] << " ";
    }
    cout << endl;

    if (flag)
    {
        cout << "Array is Matched" << endl;
    }
    else
    {
        cout << "Array is Not Matched" << endl;
    }

    delete[] arr;
}