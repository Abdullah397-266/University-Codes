// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

int countPathes(int m, int n);

int main()
{
    int m, n, totalPathes = 0;
    cout << "Enter street and avenue no: ";
    if (cin >> m >> n)
    {
        if (m > 0 && n > 0)
        {
        }
        else
        {
            cout << "Invaild Input (Numbers must be > 0)" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invaild Input" << endl;
        return 0;
    }

    totalPathes = countPathes(m, n);
    cout << "Total pathes are: " << totalPathes << endl;
    return 0;
}

int countPathes(int m, int n)
{
    if(n==1 && m==1) // Already at origin
    {
        cout << "Already at origin" << endl;
        return 0;
    }
    else if (m == 1 || n == 1)  
    {
        return 1;
    }
    else
    {
        return countPathes(m, n - 1) + countPathes(m - 1, n);
    }
}