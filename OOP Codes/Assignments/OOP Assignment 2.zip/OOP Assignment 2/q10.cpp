// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

void allocateMemory(int **, int, int, int);
void Input(int **, int, int, int, int);
void HourGlass(int **, int, int, int, int &);
void FindSum(int **, int &, int, int, int);

int main()
{
    int rows, cols, maxSum = 0;
    cout << "Enter no of Rows and Cols respectively: ";
    if (cin >> rows >> cols)
    {
        if (!(rows > 2 && cols > 2))
        {
            cout << "Invalid Input: Both must be >= 3" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Allocating memory
    int **ptr = new int *[rows];
    allocateMemory(ptr, rows - 1, cols - 1, 0);

    HourGlass(ptr, rows, cols, 0, maxSum);

    cout << "Maximum Sum is: " << maxSum << endl;

    return 0;
}

void allocateMemory(int **ptr, int rows, int cols, int i)
{
    ptr[i] = new int[cols];
    cout << "Enter " << cols + 1 << " values for Row " << i + 1 << ": " << endl;
    Input(ptr, rows, cols, i, 0);

    if (i < rows)
    {
        allocateMemory(ptr, rows, cols, i + 1);
    }
}

void Input(int **ptr, int rows, int cols, int i, int j)
{
    if (j < cols + 1)
    {
        cin >> ptr[i][j];
        Input(ptr, rows, cols, i, j + 1);
    }
    else
    {
        return;
    }
}

void HourGlass(int **arr, int rows, int cols, int i, int &maxSum)
{
    if (i < rows - 2)
    {
        FindSum(arr, maxSum, cols, i, 0);
        HourGlass(arr, rows, cols, i + 1, maxSum);
    }
    else
    {
        return;
    }

    // first reducing rows
    // HourGlass(arr, rows - 1, cols, maxSum);
    // FindSum(arr, maxSum, cols, i, 0);
}

void FindSum(int **arr, int &maxSum, int cols, int i, int j)
{
    if (j < cols - 2)
    {
        int sum = arr[i + 0][j + 0] + arr[i + 0][j + 1] + arr[i + 0][j + 2] + arr[i + 1][j + 1] + arr[i + 2][j + 0] + arr[i + 2][j + 1] + arr[i + 2][j + 2];
        if (sum > maxSum)
        {
            maxSum = sum;
        }
        FindSum(arr, maxSum, cols, i, j + 1);
    }
    else
    {
        return;
    }
}