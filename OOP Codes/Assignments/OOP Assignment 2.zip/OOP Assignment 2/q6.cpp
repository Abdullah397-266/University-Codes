// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

void FullLine(int fullSize, char ch);
void spacedLine(int fullSize, int size, char ch, char startColor);
void spacedCombinedLines(int fullSize, int size, char ch, char startColor, int control);
void printModule(int fullSize, int size, char ch, char &startColor);
void printSemiBoard(int fullSize, int size, char ch, char startColor, int control);
void Printboard(int fullSize, int size, char ch, char startColor);

int main()
{
    int size, fullSize;
    char ch, startColor;

    cout << "Enter the size of the chessboard (even and >= 6): ";
    cin >> size;

    cout << "Enter the character for white squares: ";
    cin >> ch;

    cout << "Enter 'w' to start from white or 'b' to start from black: ";
    cin >> startColor;

    fullSize = size * size;

    if (size % 2 != 0 || size < 6 || (startColor != 'w' && startColor != 'b'))
    {
        cout << "Invalid input" << endl;
    }
    else
    {
        // FullLine(fullSize, ch);
        // spacedLine(fullSize, size, ch , startColor);
        // spacedCombinedLines(fullSize, size, ch , startColor, size-2);
        // printModule(fullSize, size, ch, startColor);
        Printboard(fullSize, size, ch, startColor);
    }

    return 0;
}

void FullLine(int fullSize, char ch)
{
    if (fullSize == 0)
    {
        cout << endl;
        return;
    }
    cout << ch << " ";
    FullLine(fullSize - 1, ch);
}

void spacedLine(int fullSize, int size, char ch, char startColor)
{
    if (fullSize == 0)
    {
        cout << endl;
        return;
    }

    if (fullSize % size == 0)
    {
        char currentColor = startColor;
        if (currentColor == 'b')
        {
            startColor = 'w';
        }
        else
        {
            startColor = 'b';
        }
    }

    if (startColor == 'b')
    {
        cout << " " << " ";
    }
    else
    {
        cout << ch << " ";
    }

    spacedLine(fullSize - 1, size, ch, startColor);
}

void spacedCombinedLines(int fullSize, int size, char ch, char startColor, int control)
{
    if (control == 0)
    {
        return;
    }
    spacedLine(fullSize, size, ch, startColor);
    spacedCombinedLines(fullSize, size, ch, startColor, control - 1);
}

void printModule(int fullSize, int size, char ch, char &startColor)
{

    FullLine(fullSize, ch);

    char currentColor = startColor;
    if (currentColor == 'b')
    {
        startColor = 'w';
    }
    else
    {
        startColor = 'b';
    }
    spacedCombinedLines(fullSize, size, ch, startColor, size - 2);
}

void printSemiBoard(int fullSize, int size, char ch, char startColor, int control)
{
    if (control == 0)
    {
        return;
    }
    printModule(fullSize, size, ch, startColor);
    printSemiBoard(fullSize, size, ch, startColor, control - 1);
}

void Printboard(int fullSize, int size, char ch, char startColor)
{
    printSemiBoard(fullSize, size, ch, startColor, size);
    FullLine(fullSize, ch);
}
