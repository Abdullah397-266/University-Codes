// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

int AllOrderings(int, int);
int GoodOrderings(int, int);

int main()
{
    int A, B;

    cout << "Enter A-Ballots: ";
    if ((cin >> A))
    {
        if (!(A > 0))
        {
            cout << "Invalid Input!" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input!" << endl;
        return 0;
    }

    cout << "Enter B-Ballots: ";
    if ((cin >> B))
    {
        if (!(B > 0))
        {
            cout << "Invalid Input!" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input!" << endl;
        return 0;
    }

    int totalOrderings;
    totalOrderings = AllOrderings(A, B);
    cout << "Total Orderings: " << totalOrderings << endl;

    int goodOrderings;
    if (A > B)
    {
        goodOrderings = GoodOrderings(A, B);
    }
    else
    {
        goodOrderings = GoodOrderings(B, A);
    }
    cout << "Good Orderings: " << goodOrderings << endl;

    return 0;
}

int AllOrderings(int A, int B)
{
    if (A == 0 || B == 0)
    {
        return 1;
    }

    int forA = AllOrderings(A - 1, B);
    int forB = AllOrderings(A, B - 1);
    // if (forA - forB >= 0)
    //     ::count++;

    return forA + forB;
}

int GoodOrderings(int A, int B)
{
    if (B == 0)
    {
        return 1;
    }
    else if (B > A)
    {
        return 0;
    }
    int forA = GoodOrderings(A - 1, B);
    int forB = GoodOrderings(A, B - 1);

    return forA + forB;
}
