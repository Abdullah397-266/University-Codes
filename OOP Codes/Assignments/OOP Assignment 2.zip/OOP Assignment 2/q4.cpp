// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
#include <string>
using namespace std;

bool isBalanced(string);
bool helper(string &, int &, int, int, int);
bool check(string &, char, int &);

int main()
{
    cout << "Program to check the bracket error in a code" << endl;
    cout << endl;

    string str;
    cout << "Enter a line of code (with brackets) : ";
    getline(cin, str);

    if (isBalanced(str))
    {
        cout << "Line is consistent" << endl;
    }
    else
    {
        cout << "Line is NOT consistent" << endl;
    }

    return 0;
}

bool isBalanced(string str)
{
    int i = 0;
    if (helper(str, i, 0, 0, 0))
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool helper(string &str, int &i, int Bracket, int Braces, int Paranthesis)
{
    // base case
    if (str[i] == '\0')
    {
        return true;
    }

    // operations
    if (str[i] == '[')
    {
        char ch = ']';
        if (!(check(str, ch, i)))
        {
            cout << "line is not consistent" << endl;
            exit(0);
        }
    }
    else if (str[i] == '{')
    {
        char ch = '}';
        if (!(check(str, ch, i)))
        {
            cout << "line is not consistent" << endl;
            exit(0);
        }
    }
    else if (str[i] == '(')
    {
        char ch = ')';
        if (!(check(str, ch, i)))
        {
            cout << "line is not consistent" << endl;
            exit(0);
        }
    }

    i++;
    // recursive call
    helper(str, i, Bracket, Braces, Paranthesis);
}

bool check(string &str, char ch, int &i)
{
    i++;
    // base case
    if (str[i] == '\0')
    {
        return false;
    }
    if ((ch == ']' && (str[i] == ')' || str[i] == '}')) || (ch == '}' && (str[i] == ')' || str[i] == ']')) || (ch == ')' && (str[i] == ']' || str[i] == '}')))
    {
        return false;
    }

    // Operations
    if (str[i] == ch)
    {
        return true;
    }
    else if (str[i] == '{')
    {
        char ch = '}';
        check(str, ch, i);
    }
    else if (str[i] == '(')
    {
        char ch = ')';
        check(str, ch, i);
    }
    else if (str[i] == '[')
    {
        char ch = ']';
        check(str, ch, i);
    }
    else
    {
        // Recusive call
        check(str, ch, i);
    }
}