// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

void spacesAndStars(int n, char ch);
void hollowDiamondPattern(int size, int i);

int main()
{
    int size;
    cout << "Enter the size of the pattern: ";
    if (cin >> size)
    {
        if (size % 2 != 0)
        {
            if (!(size > 0))
            {
                cout << "Invaild Input" << endl;
                return 0;
            }
        }
        else
        {
            size += 1;
            cout << "Changed the size to " << size << " to make it odd" << endl;
        }
    }
    else
    {
        cout << "Invaild Input";
        return 0;
    }

    hollowDiamondPattern((size / 2 )+1, 1);

    return 0;
}

void hollowDiamondPattern(int size, int i)
{
    if (size == 0)
    {
        return;
    }

    // Upper Left
    spacesAndStars(size, '*');
    spacesAndStars(i, ' ');

    // Upper Right
    if (i == 1)
    {
        spacesAndStars(i - 1, ' ');
        spacesAndStars(size - 1, '*');
    }
    else
    {
        spacesAndStars(i - 1, ' ');
        spacesAndStars(size, '*');
    }

    cout << endl;

    hollowDiamondPattern(size - 1, i + 1);

    if (size != 1)
    {
        // Lower Left
        spacesAndStars(size, '*');
        spacesAndStars(i, ' ');

        // Lower Right
        if (i == 1)
        {
            spacesAndStars(i - 1, ' ');
            spacesAndStars(size - 1, '*');
        }
        else
        {
            spacesAndStars(i - 1, ' ');
            spacesAndStars(size, '*');
        }
        cout << endl;
    }
}

void spacesAndStars(int n, char ch)
{
    if (ch == ' ')
    {
        if (n <= 1)
        {
            return;
        }
        cout << "  ";
    }
    else
    {
        if (n <= 0)
        {
            return;
        }
        cout << ch << " ";
    }

    spacesAndStars(n - 1, ch);
}