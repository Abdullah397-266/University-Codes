// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

char convertToNum(char);
void Capitalize(string &, int);
void generateCode(string &, string &, int);

int main()
{
    string name;
    cout << "Enter Name: ";
    if (cin >> name)
    {
    }
    else
    {
        cout << "Invalid Input " << endl;
        return 0;
    }
    Capitalize(name, name.length());

    cout << "Name: " << name << endl;

    string soundex;
    generateCode(name, soundex, 0);

    if (soundex.length() < 4)
    {
        string toAdd = string(4 - soundex.length(), '0');
        soundex += toAdd;
    }

    cout << "Soundex Code: " << soundex << endl;
}

char convertToNum(char ch)
{
    if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'H' || ch == 'W' || ch == 'Y')
    {
        return '0';
    }
    else if (ch == 'B' || ch == 'F' || ch == 'P' || ch == 'V')
    {
        return '1';
    }
    else if (ch == 'C' || ch == 'G' || ch == 'J' || ch == 'K' || ch == 'Q' || ch == 'S' || ch == 'X' || ch == 'Z')
    {
        return '2';
    }
    else if (ch == 'D' || ch == 'T')
    {
        return '3';
    }
    else if (ch == 'M' || ch == 'N')
    {
        return '4';
    }
    else if (ch == 'L')
    {
        return '5';
    }
    else if (ch == 'R')
    {
        return '6';
    }
    return '9';
}

void generateCode(string &name, string &soundex, int index = 0)
{
    if (index == name.length() || soundex.length() >= 4)
    {
        return;
    }

    if (index == 0)
    {
        soundex += name[index];
    }
    else
    {
        char chToNum = convertToNum(name[index]);
        if (chToNum != soundex.back())
        {
            if (chToNum != '0')
            {
                soundex += chToNum;
            }
        }
    }

    generateCode(name, soundex, (index + 1));
}

void Capitalize(string &name, int len)
{
    if (len == -1)
    {
        return;
    }

    Capitalize(name, len-1);

    char ch;
    ch = toupper(name[len]);
    name[len] = ch;
}