// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

void spacesAndStars(int n, char ch);
void PrintPattern(int size, char symbol, int con);

int main()
{
    int size;
    char symbol;
    cout << "Enter the size of the pattern(n x n): ";
    if (cin >> size)
    {
        if (size % 2 != 0)
        {
            if (!(size > 4))
            {
                cout << "Invaild Input" << endl;
                return 0;
            }
        }
        else
        {
            size += 1;
            cout << "Changed the size to " << size << " to make it odd" << endl;
        }
    }
    else
    {
        cout << "Invaild Input";
        return 0;
    }

    cout << "Enter the symbol: ";
    if (cin >> symbol)
    {
    }
    else
    {
        cout << "Invaild Input";
        return 0;
    }

    spacesAndStars(size + 2, symbol);
    cout << endl;

    PrintPattern((size / 2), symbol, 1);

    spacesAndStars(size + 2, symbol);
    cout << endl;

    return 0;
}

void PrintPattern(int halfSize, char symbol, int con)
{
    if (halfSize == 0)
    {
        return;
    }

    // Upper Left
    cout << symbol << " ";
    spacesAndStars(con, symbol);
    spacesAndStars(halfSize, ' ');

    // Upper right
    cout << symbol << " ";
    spacesAndStars(halfSize, symbol);
    spacesAndStars(con, ' ');
    cout << symbol;
    cout << endl;

    PrintPattern(halfSize - 1, symbol, con + 1);
    if (halfSize == 1)
    {
        spacesAndStars(con + con + 3, symbol);
        cout << endl;
    }

    // Lower Left
    cout << symbol << " ";
    spacesAndStars(con, ' ');
    spacesAndStars(halfSize, symbol);
    // Lower right
    cout << symbol << " ";
    spacesAndStars(halfSize, ' ');
    spacesAndStars(con, symbol);
    cout << symbol;
    cout << endl;
}

void spacesAndStars(int n, char ch)
{
    if (ch == ' ')
    {
        if (n == 1)
        {
            return;
        }
        // if ()
        //     cout << ch << " ";
        // else
        cout << "  ";
    }
    else
    {
        if (n == 0)
        {
            return;
        }
        cout << ch << " ";
    }

    spacesAndStars(n - 1, ch);
}
