// Name: Abdullah Qadri
// Assignment # 2
// Roll-No: 23I=0089

#include <iostream>
using namespace std;

void spacesAndStar(int n, int count, char ch, char identifier)
{
    // For spaces
    if (ch == ' ')
    {
        if (n == 0)
        {
            return;
        }

        cout << " ";
        spacesAndStar(n - 1, count, ' ', 'f');
    }

    // For stars
    else if (ch == '*')
    {
        if (identifier != 'h')
        {
            if (n == 0)
            {
                return;
            }

            cout << "*";
            spacesAndStar(n - 1, count, '*', 'f');
        }
        else
        {
            if (n == 0)
            {
                return;
            }
            if (n == count || n == 1+2)
            {
                cout << "*";
            }
            else
            {
                cout << " ";
            }
            spacesAndStar(n - 1, count, '*', 'h');
        }
    }
}

void upperHalf(int count, int upper)
{
    //cout << "Value of upper is: " << upper << endl;
    if (count == 0 || upper == 0)
    {
        return;
    }

    // Printing spaces
    spacesAndStar(upper, count, ' ', 'h');
    // Printhing Stars
    spacesAndStar(count + 2, count+2, '*', 'h');

    cout << endl;
    upperHalf(count + 2, upper - 1);
}

void lowerHalf(int n, int lower)
{
    if (n == 0 || lower == 0)
    {
        return;
    }

    // For spaces
    spacesAndStar(n, lower, ' ', 'f');
    // For stars
    spacesAndStar(2 * lower - 1, lower, '*', 'f');
    cout << endl;

    lowerHalf(n+1, lower - 1);
}

int main()
{
    int count, upper, lower;
    cout << "Enter count: ";
    cin >> count;
    cout << "Enter size of upper part: ";
    cin >> upper;
    cout << "Enter size of lower part: ";
    cin >> lower;

    spacesAndStar(upper, count, ' ', ' ');
    spacesAndStar(count, count, '*', 'f');
    cout << endl;

    upperHalf(count + 2, upper - 1);
    lowerHalf(2, lower);
    return 0;
}
