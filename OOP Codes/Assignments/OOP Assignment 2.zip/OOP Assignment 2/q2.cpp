#include <iostream>
using namespace std;

void Input(int **ptr, int rows, int cols, int i, int j)
{
    if (j < cols + 1)
    {
        if (cin >> ptr[i][j])
        {
            if (!(ptr[i][j] == 0 || ptr[i][j] == 1))
            {
                cout << "Invalid Input: Number must be 0 OR 1" << endl;
                exit(0);
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            exit(0);
        }

        Input(ptr, rows, cols, i, j + 1);
    }
    else
    {
        return;
    }
}

void allocateMemory(int **ptr, int rows, int cols, int i, char ch)
{
    if (ch != 'I')
    {
        ptr[i] = new int[cols];

        if (i < rows)
        {
            allocateMemory(ptr, rows, cols, i + 1, ch);
        }
    }
    else
    {
        ptr[i] = new int[cols];
        cout << "Enter " << cols + 1 << " values for Row " << i + 1 << ": " << endl;
        Input(ptr, rows, cols, i, 0);

        if (i < rows)
        {
            allocateMemory(ptr, rows, cols, i + 1, ch);
        }
    }
}

void displayRow(int **boardPtr, int row, int cols, int index)
{
    if (index < cols)
    {
        cout << boardPtr[row][index] << " ";
        displayRow(boardPtr, row, cols, index + 1);
    }
}

void displayBoard(int **boardPtr, int rows, int cols)
{
    if (rows > 0)
    {
        displayBoard(boardPtr, rows - 1, cols);
        displayRow(boardPtr, rows - 1, cols, 0);
        cout << endl;
    }
}

int countLiveNeighborsHelper(int **board, int rows, int cols, int i, int j, int x, int y, int liveNeighbors)
{
    if (x <= min(rows - 1, i + 1))
    {
        if (y <= min(cols - 1, j + 1))
        {
            if (x != i || y != j)
            {
                liveNeighbors += board[x][y];
            }
            return countLiveNeighborsHelper(board, rows, cols, i, j, x, y + 1, liveNeighbors);
        }
        else
        {
            return countLiveNeighborsHelper(board, rows, cols, i, j, x + 1, max(0, j - 1), liveNeighbors);
        }
    }
    return liveNeighbors;
}

int countLiveNeighbors(int **board, int rows, int cols, int i, int j)
{
    if (i < rows)
    {
        if (j < cols)
        {
            return countLiveNeighborsHelper(board, rows, cols, i, j, max(0, i - 1), max(0, j - 1), 0);
        }
        else
        {
            return countLiveNeighbors(board, rows, cols, i + 1, 0);
        }
    }
    return 0;
}

void updateCell(int **board, int **newBoard, int rows, int cols, int i, int j)
{
    if (i < rows)
    {
        if (j < cols)
        {
            int liveNeighbors = countLiveNeighbors(board, rows, cols, i, j);
            newBoard[i][j] = (board[i][j] == 1) ? (liveNeighbors == 2 || liveNeighbors == 3) : (liveNeighbors == 3);
            updateCell(board, newBoard, rows, cols, i, j + 1);
        }
        else
        {
            updateCell(board, newBoard, rows, cols, i + 1, 0);
        }
    }
}

void gameOfLife(int **board, int **newBoard, int rows, int cols)
{
    updateCell(board, newBoard, rows, cols, 0, 0);
}

void deallocateMemory(int **arr, int rows)
{
    if (rows > 0)
    {
        deallocateMemory(arr, rows - 1);
        delete[] arr[rows - 1];
    }
    delete[] arr;
}

int main()
{
    int rows, cols;
    cout << "Enter the number of rows: ";
    if (cin >> rows)
    {
        if (!(rows > 0))
        {
            cout << "Invalid Input: rows must be > 0" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    cout << "Enter the number of columns: ";
    if (cin >> cols)
    {
        if (!(cols > 0))
        {
            cout << "Invalid Input: columns must be > 0" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    int **boardPtr = new int *[rows];
    allocateMemory(boardPtr, rows - 1, cols - 1, 0, 'I');
    // getUserInput(boardPtr, rows, cols);

    int **nextStatePtr = new int *[rows];
    allocateMemory(nextStatePtr, rows - 1, cols - 1, 0, 'N');
    gameOfLife(boardPtr, nextStatePtr, rows, cols);

    cout << "Next State:" << endl;
    displayBoard(nextStatePtr, rows, cols);

    // Deallocate memory
    deallocateMemory(boardPtr, rows);
    deallocateMemory(nextStatePtr, rows);

    return 0;
}