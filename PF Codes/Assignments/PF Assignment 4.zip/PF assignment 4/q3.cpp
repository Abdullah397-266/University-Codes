// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Section: AI-B

#include <iostream>
#include <iomanip>
#include <cmath>
#include <ctime>
using namespace std;

int main()
{
    srand(time(0));

    int j, size, randCount, quadLayer, halfSize, halfLayer, quad1Rand, quad2Rand, quad3Rand, quad4Rand;
    bool check = false;

    cout << "Enter the size of single layer: ";
    if (cin >> size)
    {
        if (size >= 8)
        {
            if (size % 2 == 0)
            {
            }
            else
            {
                cout << "Size cant be an Odd number" << endl;
                return 0;
            }
        }
        else
        {
            cout << "Size cant be less than 8" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Initializing the Array
    int arr[size][size][3];

    // Filling the Array
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < size; j++)
        {
            for (int k = 0; k < size; k++)
            {
                if (i == 0)
                {
                    arr[j][k][i] = 0;
                }
                if (i == 1)
                {
                    arr[j][k][i] = 1;
                }
                if (i == 2)
                {
                    arr[j][k][i] = 2;
                }
            }
        }
    }

    // Calculating how many random numbers may be generated
    randCount = ((size * size) / 8);
    halfSize = (size / 2);
    halfLayer = (size * size) / 2;
    quadLayer = halfSize * halfSize;

    // Working for Quad 1
    cout << "Quadrant 1 indices: ";
    for (int i = 0; i < (randCount / 4); i++)
    {
        quad1Rand = ((rand() % halfLayer) + 1);
        // Random number adjusting for Quadrant 1

        for (j = 1; j <= halfLayer; j++)
        {
            if (j == quad1Rand)
            {
                check = true;
                break;
            }

            if ((j % halfSize) == 0)
            {
                j = j + 4;
            }
        }

        if (check == false)
        {
            quad1Rand += 4;
        }
        cout << quad1Rand << " ";
    }
    cout << endl;

    // Working for Quad 2
    cout << "Quadrant 2 indices: ";
    for (int i = 0; i < (randCount / 4); i++)
    {
        check = false;
        // Random number adjusting for Quadrant 2
        quad2Rand = ((rand() % halfLayer) + 1);

        for (j = (1 + halfSize); j <= halfLayer; j++)
        {
            if (j == quad2Rand)
            {
                check = true;
                break;
            }

            if ((j % halfSize) == 0)
            {
                j = j + halfSize;
            }
        }
        if (check == false)
        {
            quad2Rand += halfSize;
        }
        cout << quad2Rand << " ";
    }
    cout << endl;

    // Working for Quad 3
    cout << "Quadrant 3 indices: ";
    for (int i = 0; i < (randCount / 4); i++)
    {
        check = false;
        // Random number adjusting for Quadrant 3
        quad3Rand = ((rand() % (halfLayer)) + 33);

        for (j = (halfLayer + 1); j <= (halfLayer + halfLayer); j++)
        {
            if (j == quad3Rand)
            {
                check = true;
                break;
            }

            if ((j % halfSize) == 0)
            {
                j = j + halfSize;
            }
        }
        if (check == false)
        {
            quad3Rand += halfSize;
        }
        cout << quad3Rand << " ";
    }
    cout << endl;

    // Working for Quad 4
    cout << "Quadrant 4 indices: ";
    for (int i = 0; i < (randCount / 4); i++)
    {
        check = false;
        // Random number adjusting for Quadrant 4
        quad4Rand = ((rand() % (halfLayer)) + 33);

        for (j = (halfLayer + 1 + halfSize); j <= (halfLayer + halfLayer); j++)
        {
            if (j == quad4Rand)
            {
                check = true;
                break;
            }

            if ((j % halfSize) == 0)
            {
                j = j + halfSize;
            }
        }
        if (check == false)
        {
            quad4Rand += halfSize;
        }
        cout << quad4Rand << " ";
    }
    cout << endl;

    // Printing the third Layer
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            cout << arr[i][j][2] << " ";
        }
        cout << endl;
    }

    return 0;
}
