// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Section: AI-B

#include <iostream>
#include <iomanip>
#include <cmath>
#include <ctime>
using namespace std;

int main()
{
    int row, col, rowStart, rowEnd, colStart, colEnd;

    cout << "Enter the number of rows and columns: ";
Input:
    if (cin >> row >> col)
    {
        if (row > 0 && col > 0)
        {
        }
        else
        {
            cout << "Plz Enter a positive integer: " << endl;
            goto Input;
        }
    }
    else
    {
        cout << "Plz Enter an integer: " << endl;
        goto Input;
    }

    system("cls");
    // the starting and ending values of loops
    rowStart = 0;
    rowEnd = row - 1;
    colStart = 0;
    colEnd = col - 1;
    int matrix[row][col];

    // Filling the matrix with random values
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            matrix[i][j] = rand() % 10;
            cout << matrix[i][j] << " ";
        }
        cout << endl
             << endl;
    }

    cout << "The matrix in the other way around is:" << endl;
    for (; true;)
    {

        for (int i = colStart; i <= colEnd; i++)
        {
            cout << matrix[rowStart][i] << " ";
        }
        rowStart++;

        for (int i = rowStart; i <= rowEnd; i++)
        {
            cout << matrix[i][colEnd] << " ";
        }
        colEnd--;

        // To prevent from extra iteration if the number of columns is greater than rows
        if (rowStart <= rowEnd)
        {
            for (int i = colEnd; i >= colStart; i--)
            {
                cout << matrix[rowEnd][i] << " ";
            }
            rowEnd--;
        }

        // To prevent from extra iteration if the number of rows is greater than columns
        if (colStart <= colEnd)
        {
            for (int i = rowEnd; i >= rowStart; i--)
            {
                cout << matrix[i][colStart] << " ";
            }
            colStart++;
        }
    }

    return 0;
}
