// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Section: AI-B

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    constexpr double THRESHOLD = .000001;
    double num = 1, signChanger = 1, PI, sum = 0 ;

    while ((1 / num) > THRESHOLD)
    {
        sum = sum + (signChanger * (1 / num));
        num = num + 2;
        signChanger = -signChanger;
    }

    PI = sum*4;

    cout << "PI is approximately " << setprecision(17) << PI << endl;

    return 0;
}
