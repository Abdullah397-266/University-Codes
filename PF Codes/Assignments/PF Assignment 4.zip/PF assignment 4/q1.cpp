// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Section: AI-B

#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <conio.h>
using namespace std;

int main()
{
    srand(time(0));
    int size = 25, pacManX, pacManY, ghost1X, ghost1Y, ghost2X, ghost2Y, ghost1Num, ghost2Num;
    char input, symbol = '>';
    char grid[25][25];
    bool isDotPresent;

    // Initial Position of Pac-Man
    pacManX = size / 2;
    pacManY = (size - 1) - 5;

    // 1st Ghost's initial Position
    ghost1X = (size - 1) - 7;
    ghost1Y = (size - 1) - 15;

    // 2nd Ghost's initial Position
    ghost2X = 9;
    ghost2Y = 7;

    // Preparing The layout of the game
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            if (i == 0 || i == 24 || j == 0 || j == 24 || ((i == 3 || i == 4) && ((j >= 3 && j <= 8) || (j >= 16 && j <= 21))) || ((j == 4 || j == 20) && (i >= 8 && i <= 16)) || (i == 8 && (j >= 8 && j <= 16)) || (j == 12 && (i >= 9 && i <= 13)) || (i == 12 && ((j >= 5 && j <= 9) || (j >= 15 && j <= 19))) || (i == 21 && ((j >= 8 && j <= 16) || (j >= 3 && j <= 6) || (j >= 18 && j <= 21))) || (i == 20 && ((j >= 3 && j <= 6) || (j >= 18 && j <= 21))) || ((i >= 16 && i <= 20) && (j == 8 || j == 16)) || (i == 16 && ((j == 10 || j == 9) || (j == 14 || j == 15))))
            {
                grid[i][j] = '#';
                cout << grid[i][j] << " ";
            }
            else if (i == pacManY && j == pacManX)
            {
                grid[i][j] = '.';
                cout << ">"
                     << " ";
            }
            else if (i == ghost1Y && j == ghost1X)
            {
                grid[i][j] = '.';
                cout << "8"
                     << " ";
            }
            else if (i == ghost2Y && j == ghost2X)
            {
                grid[i][j] = '.';
                cout << "8"
                     << " ";
            }
            else
            {
                grid[i][j] = '.';
                cout << grid[i][j] << " ";
            }
        }
        cout << endl;
    }

    while (true)
    {
        // check variable for any dot in grid to end the game
        isDotPresent = 0;

        // Taking the Input
    Input:
        cout << "Enter (w,a,s,d): ";
        input = getch();
        if (input == 'w' || input == 'W' || input == 'a' || input == 'A' || input == 's' || input == 'S' || input == 'd' || input == 'D')
        {
        }
        else
        {
            cout << "Invalid" << endl;
            goto Input;
        }

        // Moving the PacMan
        switch (input)
        {
        case 'W':
        case 'w':
        {
            pacManY--;
            if (pacManY <= 0)
            {
                pacManY++;
            }
            symbol = 'v';
            break;
        }
        case 's':
        case 'S':
        {
            pacManY++;
            if (pacManY >= 24)
            {
                pacManY--;
            }
            symbol = '^';
            break;
        }
        case 'a':
        case 'A':
        {
            pacManX--;
            if (pacManX < 1)
            {
                pacManX++;
            }
            symbol = '>';
            break;
        }
        case 'd':
        case 'D':
        {
            pacManX++;
            if (pacManX > 25)
            {
                pacManX--;
            }
            symbol = '<';
            break;
        }
        }

        // Moving The Ghost 1
        switch (ghost1Num = rand() % 4)
        {
        case 0:
        {
            ghost1X--;
            if (ghost1X <= 0)
            {
                ghost1X++;
            }
            break;
        }
        case 1:
        {
            ghost1X++;
            if (ghost1X >= 24)
            {
                ghost1X--;
            }
            break;
        }
        case 2:
        {
            ghost1Y--;
            if (ghost1Y <= 0)
            {
                ghost1Y++;
            }
            break;
        }
        case 3:
        {
            ghost1Y++;
            if (ghost1Y >= 24)
            {
                ghost1Y--;
            }

            break;
        }
        }

        // Moving The Ghost 2
        switch (ghost2Num = rand() % 4)
        {
        case 0:
        {
            ghost2X--;
            if (ghost2X <= 0)
            {
                ghost2X++;
            }
            break;
        }
        case 1:
        {
            ghost2X++;
            if (ghost2X >= 24)
            {
                ghost2X--;
            }
            break;
        }
        case 2:
        {
            ghost2Y--;
            if (ghost2Y <= 0)
            {
                ghost2Y++;
            }
            break;
        }
        case 3:
        {
            ghost2Y++;
            if (ghost2Y >= 24)
            {
                ghost2Y--;
            }

            break;
        }
        }

        // Preventing the Pacman from going into the walls
        if (((pacManY == 3 || pacManY == 4) && ((pacManX >= 3 && pacManX <= 8) || (pacManX >= 16 && pacManX <= 21))) || ((pacManX == 4 || pacManX == 20) && (pacManY >= 8 && pacManY <= 16)) || (pacManY == 8 && (pacManX >= 8 && pacManX <= 16)) || (pacManX == 12 && (pacManY >= 9 && pacManY <= 13)) || (pacManY == 12 && ((pacManX >= 5 && pacManX <= 9) || (pacManX >= 15 && pacManX <= 19))) || (pacManY == 21 && ((pacManX >= 8 && pacManX <= 16) || (pacManX >= 3 && pacManX <= 6) || (pacManX >= 18 && pacManX <= 21))) || (pacManY == 20 && ((pacManX >= 3 && pacManX <= 6) || (pacManX >= 18 && pacManX <= 21))) || ((pacManY >= 16 && pacManY <= 20) && (pacManX == 8 || pacManX == 16)) || (pacManY == 16 && ((pacManX == 10 || pacManX == 9) || (pacManX == 14 || pacManX == 15))))
        {
            if (input == 'w' || input == 'W')
            {
                pacManY++;
            }
            if (input == 's' || input == 'S')
            {
                pacManY--;
            }
            if (input == 'a' || input == 'A')
            {
                pacManX++;
            }
            if (input == 'd' || input == 'D')
            {
                pacManX--;
            }
        }

        // Preventing the Ghost-1 from going into the walls
        if (((ghost1Y == 3 || ghost1Y == 4) && ((ghost1X >= 3 && ghost1X <= 8) || (ghost1X >= 16 && ghost1X <= 21))) || ((ghost1X == 4 || ghost1X == 20) && (ghost1Y >= 8 && ghost1Y <= 16)) || (ghost1Y == 8 && (ghost1X >= 8 && ghost1X <= 16)) || (ghost1X == 12 && (ghost1Y >= 9 && ghost1Y <= 13)) || (ghost1Y == 12 && ((ghost1X >= 5 && ghost1X <= 9) || (ghost1X >= 15 && ghost1X <= 19))) || (ghost1Y == 21 && ((ghost1X >= 8 && ghost1X <= 16) || (ghost1X >= 3 && ghost1X <= 6) || (ghost1X >= 18 && ghost1X <= 21))) || (ghost1Y == 20 && ((ghost1X >= 3 && ghost1X <= 6) || (ghost1X >= 18 && ghost1X <= 21))) || ((ghost1Y >= 16 && ghost1Y <= 20) && (ghost1X == 8 || ghost1X == 16)) || (ghost1Y == 16 && ((ghost1X == 10 || ghost1X == 9) || (ghost1X == 14 || ghost1X == 15))))
        {
            if (ghost1Num == 0)
            {
                ghost1X++;
            }
            else if (ghost1Num == 1)
            {
                ghost1X--;
            }
            else if (ghost1Num == 2)
            {
                ghost1Y++;
            }
            else if (ghost1Num == 3)
            {
                ghost1Y--;
            }
        }

        // Preventing the Ghost-2 from going into the walls
        if (((ghost2Y == 3 || ghost2Y == 4) && ((ghost2X >= 3 && ghost2X <= 8) || (ghost2X >= 16 && ghost2X <= 21))) || ((ghost2X == 4 || ghost2X == 20) && (ghost2Y >= 8 && ghost2Y <= 16)) || (ghost2Y == 8 && (ghost2X >= 8 && ghost2X <= 16)) || (ghost2X == 12 && (ghost2Y >= 9 && ghost2Y <= 13)) || (ghost2Y == 12 && ((ghost2X >= 5 && ghost2X <= 9) || (ghost2X >= 15 && ghost2X <= 19))) || (ghost2Y == 21 && ((ghost2X >= 8 && ghost2X <= 16) || (ghost2X >= 3 && ghost2X <= 6) || (ghost2X >= 18 && ghost2X <= 21))) || (ghost2Y == 20 && ((ghost2X >= 3 && ghost2X <= 6) || (ghost2X >= 18 && ghost2X <= 21))) || ((ghost2Y >= 16 && ghost2Y <= 20) && (ghost2X == 8 || ghost2X == 16)) || (ghost2Y == 16 && ((ghost2X == 10 || ghost2X == 9) || (ghost2X == 14 || ghost2X == 15))))
        {
            if (ghost2Num == 0)
            {
                ghost2X++;
            }
            else if (ghost2Num == 1)
            {
                ghost2X--;
            }
            else if (ghost2Num == 2)
            {
                ghost2Y++;
            }
            else if (ghost2Num == 3)
            {
                ghost2Y--;
            }
        }

        system("cls");

        // Again Printing The Grid
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (i == pacManY && j == pacManX)
                {
                    grid[i][j] = ' ';
                    cout << symbol << " ";
                }
                else if (i == 0 || i == 24 || j == 0 || j == 24 || ((i == 3 || i == 4) && ((j >= 3 && j <= 8) || (j >= 16 && j <= 21))) || ((j == 4 || j == 20) && (i >= 8 && i <= 16)) || (i == 8 && (j >= 8 && j <= 16)) || (j == 12 && (i >= 9 && i <= 13)) || (i == 12 && ((j >= 5 && j <= 9) || (j >= 15 && j <= 19))) || (i == 21 && ((j >= 8 && j <= 16) || (j >= 3 && j <= 6) || (j >= 18 && j <= 21))) || (i == 20 && ((j >= 3 && j <= 6) || (j >= 18 && j <= 21))) || ((i >= 16 && i <= 20) && (j == 8 || j == 16)) || (i == 16 && ((j == 10 || j == 9) || (j == 14 || j == 15))))
                {
                    grid[i][j] = '#';
                    cout << grid[i][j] << " ";
                }
                else if ((i == ghost1Y && j == ghost1X) || (i == ghost2Y && j == ghost2X))
                {
                    cout << "8"
                         << " ";
                }
                else
                {
                    cout << grid[i][j] << " ";
                }
            }
            cout << endl;
        }

        // checking if the grid have any dots left
        for (int l = 0; l < size; l++)
        {
            for (int m = 0; m < size; m++)
            {
                if (grid[l][m] == '.')
                {
                    isDotPresent = 1;
                }
            }
        }
        if (isDotPresent == 1)
        {
        }
        else
        {
            system("cls");
            cout << endl
                 << "The pac-Man ate all the dots";
            cout << endl
                 << endl;
            cout << "<---- ========= GAME OVER ========== ---->" << endl
                 << endl
                 << endl;
            return 0;
        }

        // Checking if the Ghost and PacMan Collide
        if ((ghost1X == pacManX && ghost1Y == pacManY) || (ghost2X == pacManX && ghost2Y == pacManY))
        {
            system("cls");
            cout << endl
                 << "The Ghost Ate the Pac-Man";
            cout << endl
                 << endl;
            cout << "<---- ========= GAME OVER ========== ---->" << endl
                 << endl
                 << endl;
            return 0;
        }
    }

    return 0;
}
