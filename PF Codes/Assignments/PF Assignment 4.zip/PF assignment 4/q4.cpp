// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Section: AI-B

#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    // Random Value every time
    srand(time(0));

    int array[60], sum = 0, maxProfit = 0, startIndex = 0, endIndex = 0, i, j;
    cout << "The array is: ";
    // Filling the Array with random values and showing all of the array Values
    for (int i = 0; i < 60; i++)
    {
        array[i] = (rand() % 21) - 10;
        cout << array[i] << " ";
    }
    cout << endl;
    
    // This outer loop is checking all the possible combinations with leading indices.
    for (i = 0; i < 60; i++)
    {
        sum = 0;
        for (j = i; j < 60; j++)
        {
            sum = sum + array[j];
            if (sum > maxProfit)
            {
                maxProfit = sum;
                startIndex = i;
                endIndex = j;
            }
        }
    }

    cout << "The max profit is: " << maxProfit << endl;
    cout << "The Starting Index is: " << startIndex << endl;
    cout << "The Ending Index is: " << endIndex << endl;

    return 0;
}