// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    unsigned short int time, temp, hrs, min, sec;
    cout << "Enter a 2-Byte time value: ";
    if (cin >> time)
    {
        if (time > 0 && time <= 65535)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    temp = time;
    hrs = temp >> 12;

    temp = time;
    min = (temp & 4095) >> 6;

    temp = time;
    sec = (temp & 63);

    cout << "Time is " << hrs << " hrs " << min << " min " << sec << " sec" << endl;

    return 0;
}