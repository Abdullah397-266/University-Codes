// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    srand(time(0));
    int choice;
    cout << "'1' to Play Higher or Lower" << endl
         << "'2' for paper - scissors - rock" << endl
         << "'3' for Guess the numbers" << endl
         << "'4' to EXIT" << endl
         << "Enter the number from 1-4: ";
    if (cin >> choice)
    {
        if ((choice >= 1) && (choice <= 4))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    // 1st Choice
    if (choice == 1)
    {
        int num1 = 1 + rand() % 20;
        int num2 = 1 + rand() % 20;

        cout << "The first number is " << num1 << endl;

        cout << "The second number is higher or lower (H/L): ";
        char decision;
        if (cin >> decision)
        {
            if ((decision == 'H') || (decision == 'L'))
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }

        if (num1 > num2)
        {
            if ((decision == 'L'))
            {
                cout << "Congrats! You got it Right" << endl;
                return 0;
            }
            else
            {
                cout << "Ooops! Better Luck next time";
                return 0;
            }
        }
        else
        {
            if ((decision == 'H'))
            {
                cout << "Congrats! You got it Right" << endl;
                return 0;
            }
            else
            {
                cout << "Ooops! Better Luck next time";
                return 0;
            }
        }
    }
    // 2nd Choice
    else if (choice == 2)
    {
        int num1 = 1 + rand() % 3;
        char compInput, userInput;
        if (num1 == 1)
        {
            compInput = 'P';
        }
        else if (num1 == 2)
        {
            compInput = 'S';
        }
        else
        {
            compInput = 'R';
        }

        cout << "Enter 'P' for paper, 'S' for scissors or 'R' for rock: ";
        if (cin >> userInput)
        {
            if ((userInput == 'P') || (userInput == 'S') || (userInput == 'R'))
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }

        cout << "The compuer choosed " << compInput << endl;
        cout << "The user choosed " << userInput << endl;
        cout << "Result:" << endl;

        if (compInput == userInput)
        {
            cout << "\t Its a DRAW" << endl;
        }
        else if (((userInput == 'P') && (compInput == 'R')) || ((userInput == 'R') && (compInput == 'S')) || ((userInput == 'S') && (compInput == 'P')))
        {
            cout << "\t Congrats! The USER wins." << endl;
        }
        else
        {
            cout << "\t Ooops! The COMPUTER wins." << endl;
        }
    }
    // 3rd choice
    else if (choice == 3)
    {
        int num1, num2, num3, userNum1, userNum2, userNum3;
        num1 = rand() % 10;
        num2 = rand() % 10;
        num3 = rand() % 10;

        cout << "the computer numbers are: " << num1 << " " << num2 << " " << num3 << endl;

        cout << "Enter your 3 Guessed numbers (0-9): ";
        if (cin >> userNum1 >> userNum2 >> userNum3)
        {
            if (((userNum1 >= 0) && (userNum1 <= 9)) && ((userNum2 >= 0) && (userNum2 <= 9)) && ((userNum3 >= 0) && (userNum3 <= 9)))
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }

        // Three Exact Same
        if ((userNum1 == num1) && (userNum2 == num2) && (userNum3 == num3))
        {
            cout << "All Three number matches in EXACT order" << endl;
            return 0;
        }
        // Three NOT Exact Same
        else if (((userNum1 == num1) || (userNum1 == num2) || (userNum1 == num3)) && ((userNum2 == num1) || (userNum2 == num2) || (userNum2 == num3)) && ((userNum3 == num1) || (userNum3 == num2) || (userNum3 == num3)))
        {
            cout << "All Three number matches but NOT in EXACT order" << endl;
            return 0;
        }
        // Two Same
        else if (((userNum1 == num1) || (userNum1 == num2) || (userNum1 == num3)) && ((userNum2 == num1) || (userNum2 == num2) || (userNum2 == num3)))
        {
            cout << "Two numbers are matching" << endl;
            return 0;
        }
        else if (((userNum2 == num1) || (userNum2 == num2) || (userNum2 == num3)) && ((userNum3 == num1) || (userNum3 == num2) || (userNum3 == num3)))
        {
            cout << "Two numbers are matching" << endl;
            return 0;
        }
        else if (((userNum1 == num1) || (userNum1 == num2) || (userNum1 == num3)) && ((userNum3 == num1) || (userNum3 == num2) || (userNum3 == num3)))
        {
            cout << "Two numbers are matching" << endl;
            return 0;
        }
        // One is Matching
        else if (((userNum1 == num1) || (userNum1 == num2) || (userNum1 == num3)))
        {
            cout << "Only One number is matching" << endl;
            return 0;
        }
        else if (((userNum2 == num1) || (userNum2 == num2) || (userNum2 == num3)))
        {
            cout << "Only One number is matching" << endl;
            return 0;
        }
        else if (((userNum3 == num1) || (userNum3 == num2) || (userNum3 == num3)))
        {
            cout << "Only One number is matching" << endl;
            return 0;
        }
        // No one is matching
        else
        {
            cout << "No number is matching" << endl;
        }
    }
    else
    {
        cout << "The program is Exited" << endl;
        return 0;
    }

    return 0;
}
