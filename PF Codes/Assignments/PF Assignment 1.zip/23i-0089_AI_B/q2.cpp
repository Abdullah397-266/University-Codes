// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    float u = 1.234, p = 3.334, i, ans;

    cout << "Enter the value of i: ";
    if (cin >> i)
    {
        if (i > 0)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    ans = sqrt(u * (sqrt(i * i * i)) * ((i * i) - 1) / (sqrt((p * i) - 2) + sqrt((p * i) - 1)));
    cout << "The value of the formula is: " << setprecision(3) << ans << endl;

    return 0;
}
