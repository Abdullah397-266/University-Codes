// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
     int eggs, packs, leftovers;

     cout << "Enter the no. of eggs: ";
     if (cin >> eggs)
     {
          if (eggs >= 0)
          {
          }
          else
          {
               cout << "Invalid Input" << endl;
               return 0;
          }
     }
     else
     {
          cout << "Invalid Input" << endl;
          return 0;
     }

     // Pack of 30 eggs
     packs = 0;
     packs = eggs / 30;
     leftovers = eggs - (packs * 30);

     cout << "Number of 30 eggs Packing: " << packs << "\t \t"
          << "Number of leftover eggs: " << leftovers << endl;

     // pack of 24 eggs
     packs = 0;
     packs = eggs / 24;
     leftovers = eggs - (packs * 24);

     cout << "Number of 24 eggs Packing: " << packs << "\t \t"
          << "Number of leftover eggs: " << leftovers << endl;

     // pack of 18 eggs
     packs = 0;
     packs = eggs / 18;
     leftovers = eggs - (packs * 18);

     cout << "Number of 18 eggs Packing: " << packs << "\t \t"
          << "Number of leftover eggs: " << leftovers << endl;

     // pack of 12 eggs
     packs = 0;
     packs = eggs / 12;
     leftovers = eggs - (packs * 12);

     cout << "Number of 12 eggs Packing: " << packs << "\t \t"
          << "Number of leftover eggs: " << leftovers << endl;

     // pack of 6 eggs
     packs = 0;
     packs = eggs / 6;
     leftovers = eggs - (packs * 6);

     cout << "Number of 6 eggs Packing: " << packs << "\t \t"
          << "Number of leftover eggs: " << leftovers << endl;

     return 0;
}
