// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    int cash, count = 0;
    cout << "Enter the amount of money you want to Withdraw (Multiple of 500) : ";
    if (cin >> cash)
    {
        if (cash >= 500 && cash <= 50000)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    // Cash Check
    if ((cash % 500) == 0)
    {
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    if ((cash % 1000) == 0)
    {
        cash = cash - 500;
        if (cash >= 5000)
        {
            count = cash / 5000;
            cout << "Note of 5000: " << count << endl;
            cash = cash - (count * 5000);
        }
        count = 0;
        if (cash >= 1000)
        {
            count = cash / 1000;
            cout << "Note of 1000: " << count << endl;
            cash = cash - (count * 1000);
        }
        count = 0;
        if (cash >= 500)
        {
            count = cash / 500;
            cout << "Note of 500: " << (count + 1) << endl;
            cash = cash - (count * 500);
        }
    }
    else
    {
        if (cash >= 5000)
        {
            count = cash / 5000;
            cout << "Note of 5000: " << count << endl;
            cash = cash - (count * 5000);
        }
        count = 0;
        if (cash >= 1000)
        {
            count = cash / 1000;
            cout << "Note of 1000: " << count << endl;
            cash = cash - (count * 1000);
        }
        count = 0;
        if (cash >= 500)
        {
            count = cash / 500;
            cout << "Note of 500: " << count << endl;
            cash = cash - (count * 500);
        }
    }

    return 0;
}