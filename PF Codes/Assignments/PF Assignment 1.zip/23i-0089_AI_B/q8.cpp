// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    int date, month, year, yearPart;
    string validate;
    cout << "Enter the DATE then MONTH and then YEAR (All numbers): ";
    // Input Validation
    if (cin >> date >> month >> year)
    {
        if ((date > 0) && (date <= 31) && (month > 0) && (month <= 12) && (year > 999))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    yearPart = year % 100;
    // Using trenery operator
    ((date * month) == yearPart) ? cout << "The date is magic" : cout << "The date is NOT magic";

    return 0;
}