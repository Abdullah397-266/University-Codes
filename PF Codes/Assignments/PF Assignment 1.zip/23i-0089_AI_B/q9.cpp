// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    srand(time(0));
    char operation, decision;
    int maximumValue, randomValue1, randomValue2, answer, userAnswer, max, min;

    cout << "Which operation you would like to perform (+,-,*,/): ";
    if (cin >> operation)
    {
        if ((operation == '+') || (operation == '-') || (operation == '*') || (operation == '/'))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    cout << "What is the maximum value for the input values of the exercise: ";
    if (cin >> maximumValue)
    {
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    cout << "Are negative values allowed in the exercise (Y/N) : ";
    if (cin >> decision)
    {
        if ((decision == 'Y') || (decision == 'y') || (decision == 'N') || (decision == 'n'))
        {
            if ((decision == 'Y') || (decision == 'y'))
            {
                // Random Number Generator
                int minimumValue = -maximumValue;
                randomValue1 = minimumValue + rand() % maximumValue + 1; // For -ve Values
                randomValue2 = 1 + rand() % maximumValue;                // For +ve Values
            }
            else
            {
                // Random Number Generator Only +ve
                randomValue1 = rand() % (maximumValue + 1); // For +ve Values
                randomValue2 = rand() % (maximumValue + 1); // For +ve Values
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Now As the random valies are generated
    switch (operation)
    {

    case '+':
        cout << randomValue1 << " + " << randomValue2 << " = ";
        if (cin >> userAnswer)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
        answer = randomValue1 + randomValue2;
        if (answer == userAnswer)
        {
            cout << "Congrats! you got it right." << endl;
        }
        else
        {
            cout << "NOPE! The correct answer is: " << answer << endl;
        }
        break;

    case '-':
        if ((decision == 'n') || (decision == 'N'))
        {
            if (randomValue1 > randomValue2)
            {
                max = randomValue1;
                min = randomValue2;
            }
            else
            {
                max = randomValue2;
                min = randomValue1;
            }

            cout << max << " - " << min << " = ";
            if (cin >> userAnswer)
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
            answer = max - min;
            if (answer == userAnswer)
            {
                cout << "Congrats! you got it right." << endl;
            }
            else
            {
                cout << "NOPE! The correct answer is: " << answer << endl;
            }
        }
        else
        {
            cout << randomValue1 << " - " << randomValue2 << " = ";
            if (cin >> userAnswer)
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
            answer = randomValue1 - randomValue2;
            if (answer == userAnswer)
            {
                cout << "Congrats! you got it right." << endl;
            }
            else
            {
                cout << "NOPE! The correct answer is: " << answer << endl;
            }
        }
        break;

    case '*':
        cout << randomValue1 << " * " << randomValue2 << " = ";
        if (cin >> userAnswer)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
        answer = randomValue1 * randomValue2;
        if (answer == userAnswer)
        {
            cout << "Congrats! you got it right." << endl;
        }
        else
        {
            cout << "NOPE! The correct answer is: " << answer << endl;
        }
        break;

    case '/':
        if (randomValue2 == 0)
        {
            cout << "The second number is 0 so the division is not possible" << endl;
            return 0;
        }
        else
        {
            cout << randomValue1 << " / " << randomValue2 << " = ";
            if (cin >> userAnswer)
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
            answer = randomValue1 / randomValue2;
            if (answer == userAnswer)
            {
                cout << "Congrats! you got it right." << endl;
            }
            else
            {
                cout << "NOPE! The correct answer is: " << answer << endl;
            }
        }
        break;
    }

    return 0;
}
