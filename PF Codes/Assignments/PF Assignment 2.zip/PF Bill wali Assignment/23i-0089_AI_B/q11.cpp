// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    char newServer;
    cout << "Starting General Diagnosis Program" << endl;
    cout << "Recording Symptom Information" << endl
         << "DONE" << endl;
    cout << "Rebooting The Server To See If the Condition Still Exists" << endl
         << "DONE" << endl;

    cout << "Is there a newly Server Installed (Y/N): ";
    if (cin >> newServer)
    {
        if ((newServer == 'Y') || (newServer == 'y') || (newServer == 'N') || (newServer == 'n'))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    if ((newServer == 'Y') || (newServer == 'y'))
    {
        cout << "Please reseat any components that may have come loose during Shipping and after that, Reboot your server " << endl
             << "DONE" << endl;

        cout << "Does the condition still exists? (Y/N): ";
        char check;
        if (cin >> check)
        {
            if ((check == 'Y') || (check == 'y') || (check == 'N') || (check == 'n'))
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }

        if ((check == 'N') || (check == 'n'))
        {
            cout << "Recording The actions that were taken for future" << endl
                 << "DONE" << endl;
            return 0;
        }
        else if ((check == 'Y') || (check == 'y'))
        {
            cout << "Were options added or was the configuration changed recently (Y/N): ";
            char check;
            if (cin >> check)
            {
                if ((check == 'Y') || (check == 'y') || (check == 'N') || (check == 'n'))
                {
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }

            if ((check == 'N') || (check == 'n'))
            {
                cout << "Checking for service notifications" << endl
                     << "DONE" << endl;
                cout << "Downloading the latest software and firmware from the HP website" << endl
                     << "DONE" << endl;
                cout << "Does the condition still exists? (Y/N): ";
                char check1;
                if (cin >> check1)
                {
                    if ((check1 == 'Y') || (check1 == 'y') || (check1 == 'N') || (check1 == 'n'))
                    {
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }

                if ((check1 == 'N') || (check1 == 'n'))
                {
                    cout << "Recording The actions that were taken for future" << endl
                         << "DONE" << endl;
                    return 0;
                }
                else if ((check1 == 'Y') || (check1 == 'y'))
                {
                    cout << "Isolating and minimizing the memory configuration" << endl
                         << "DONE" << endl;
                    cout << "Does the condition still exists? (Y/N): ";
                    char check2;
                    if (cin >> check2)
                    {
                        if ((check2 == 'Y') || (check2 == 'y') || (check2 == 'N') || (check2 == 'n'))
                        {
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }

                    if ((check2 == 'N') || (check2 == 'n'))
                    {
                        cout << "Recording The actions that were taken for future" << endl
                             << "DONE" << endl;
                        return 0;
                    }
                    else if ((check2 == 'Y') || (check2 == 'y'))
                    {
                        cout << "Breaking server down to minimal configuration" << endl
                             << "DONE" << endl;
                        cout << "Does the condition still exists (Y/N): ";
                        char check3;
                        if (cin >> check3)
                        {
                            if ((check3 == 'Y') || (check3 == 'y') || (check3 == 'N') || (check3 == 'n'))
                            {
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }

                        if ((check3 == 'N') || (check3 == 'n'))
                        {
                            cout << "Adding one part at a time back to configuration to isolate faulty components" << endl
                                 << "DONE" << endl;
                            cout << "Does the condition still exists (Y/N): ";
                            char check4;
                            if (cin >> check4)
                            {
                                if ((check4 == 'Y') || (check4 == 'y') || (check4 == 'N') || (check4 == 'n'))
                                {
                                }
                                else
                                {
                                    cout << "Invalid Input" << endl;
                                    return 0;
                                }
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }

                            if ((check4 == 'N') || (check4 == 'n'))
                            {
                                cout << "Recording The actions that were taken for future" << endl
                                     << "DONE" << endl;
                                return 0;
                            }
                            else if ((check4 == 'Y') || (check4 == 'y'))
                            {
                                cout << "Ensure you have the following information available:" << endl
                                     << "--> Survey Configuration snapshots" << endl
                                     << "--> OS event log file" << endl
                                     << "--> Full crash dump";
                                cout << "Calling the HP service provider" << endl
                                     << "DONE" << endl;
                                return 0;
                            }
                        }
                        else if ((check3 == 'Y') || (check3 == 'y'))
                        {
                            cout << "Troubleshoot or replace basic server parts" << endl;
                            cout << "Does the condition still exists (Y/N): ";
                            char check5;
                            if (cin >> check5)
                            {
                                if ((check5 == 'Y') || (check5 == 'y') || (check5 == 'N') || (check5 == 'n'))
                                {
                                }
                                else
                                {
                                    cout << "Invalid Input" << endl;
                                    return 0;
                                }
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }

                            if ((check5 == 'Y') || (check5 == 'y'))
                            {
                                cout << "Ensure you have the following information available:" << endl
                                     << "--> Survey Configuration snapshots" << endl
                                     << "--> OS event log file" << endl
                                     << "--> Full crash dump";
                                cout << "Calling the HP service provider" << endl
                                     << "DONE" << endl;
                                return 0;
                            }
                            else if ((check5 == 'N') || (check5 == 'n'))
                            {
                                cout << "Recording symptom and error information repair tag if sending back a failed part" << endl;
                                return 0;
                            }
                        }
                    }
                }
            }
            else if ((check == 'Y') || (check == 'y'))
            {
                cout << "Isolating what has changed, verifying it was installed correctly, Restoring the server to last known working state or original shipped configuration" << endl
                     << "DONE" << endl;
                cout << "Does the condition still exists (Y/N): ";
                char check6;
                if (cin >> check6)
                {
                    if ((check6 == 'Y') || (check6 == 'y') || (check6 == 'N') || (check6 == 'n'))
                    {
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }
                if ((check6 == 'N') || (check6 == 'n'))
                {
                    cout << "Recording the actions taken for future" << endl
                         << "DONE" << endl;
                    return 0;
                }
                else if ((check6 == 'Y') || (check6 == 'y'))
                {
                    cout << "Isolating and minimizing the memory configuration" << endl
                         << "DONE" << endl;
                    cout << "Does the condition still exists? (Y/N): ";
                    char check2;
                    if (cin >> check2)
                    {
                        if ((check2 == 'Y') || (check2 == 'y') || (check2 == 'N') || (check2 == 'n'))
                        {
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }

                    if ((check2 == 'N') || (check2 == 'n'))
                    {
                        cout << "Recording The actions that were taken for future" << endl
                             << "DONE" << endl;
                        return 0;
                    }
                    else if ((check2 == 'Y') || (check2 == 'y'))
                    {
                        cout << "Breaking server down to minimal configuration" << endl
                             << "DONE" << endl;
                        cout << "Does the condition still exists (Y/N): ";
                        char check3;
                        if (cin >> check3)
                        {
                            if ((check3 == 'Y') || (check3 == 'y') || (check3 == 'N') || (check3 == 'n'))
                            {
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }

                        if ((check3 == 'N') || (check3 == 'n'))
                        {
                            cout << "Adding one part at a time back to configuration to isolate faulty components" << endl
                                 << "DONE" << endl;
                            cout << "Does the condition still exists (Y/N): ";
                            char check4;
                            if (cin >> check4)
                            {
                                if ((check4 == 'Y') || (check4 == 'y') || (check4 == 'N') || (check4 == 'n'))
                                {
                                }
                                else
                                {
                                    cout << "Invalid Input" << endl;
                                    return 0;
                                }
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }

                            if ((check4 == 'N') || (check4 == 'n'))
                            {
                                cout << "Recording The actions that were taken for future" << endl
                                     << "DONE" << endl;
                                return 0;
                            }
                            else if ((check4 == 'Y') || (check4 == 'y'))
                            {
                                cout << "Ensure you have the following information available:" << endl
                                     << "--> Survey Configuration snapshots" << endl
                                     << "--> OS event log file" << endl
                                     << "--> Full crash dump";
                                cout << "Calling the HP service provider" << endl
                                     << "DONE" << endl;
                                return 0;
                            }
                        }
                        else if ((check3 == 'Y') || (check3 == 'y'))
                        {
                            cout << "Troubleshoot or replace basic server parts" << endl;
                            cout << "Does the condition still exists (Y/N): ";
                            char check5;
                            if (cin >> check5)
                            {
                                if ((check5 == 'Y') || (check5 == 'y') || (check5 == 'N') || (check5 == 'n'))
                                {
                                }
                                else
                                {
                                    cout << "Invalid Input" << endl;
                                    return 0;
                                }
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }

                            if ((check5 == 'Y') || (check5 == 'y'))
                            {
                                cout << "Ensure you have the following information available:" << endl
                                     << "--> Survey Configuration snapshots" << endl
                                     << "--> OS event log file" << endl
                                     << "--> Full crash dump";
                                cout << "Calling the HP service provider" << endl
                                     << "DONE" << endl;
                                return 0;
                            }
                            else if ((check5 == 'N') || (check5 == 'n'))
                            {
                                cout << "Recording symptom and error information repair tag if sending back a failed part" << endl;
                                return 0;
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        cout << "Were options added or was the configuration changed recently (Y/N): ";
        char check;
        if (cin >> check)
        {
            if ((check == 'Y') || (check == 'y') || (check == 'N') || (check == 'n'))
            {
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }

        if ((check == 'N') || (check == 'n'))
        {
            cout << "Checking for service notifications" << endl
                 << "DONE" << endl;
            cout << "Downloading the latest software and firmware from the HP website" << endl
                 << "DONE" << endl;
            cout << "Does the condition still exists? (Y/N): ";
            char check1;
            if (cin >> check1)
            {
                if ((check1 == 'Y') || (check1 == 'y') || (check1 == 'N') || (check1 == 'n'))
                {
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }

            if ((check1 == 'N') || (check1 == 'n'))
            {
                cout << "Recording The actions that were taken for future" << endl
                     << "DONE" << endl;
                return 0;
            }
            else if ((check1 == 'Y') || (check1 == 'y'))
            {
                cout << "Isolating and minimizing the memory configuration" << endl
                     << "DONE" << endl;
                cout << "Does the condition still exists? (Y/N): ";
                char check2;
                if (cin >> check2)
                {
                    if ((check2 == 'Y') || (check2 == 'y') || (check2 == 'N') || (check2 == 'n'))
                    {
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }

                if ((check2 == 'N') || (check2 == 'n'))
                {
                    cout << "Recording The actions that were taken for future" << endl
                         << "DONE" << endl;
                    return 0;
                }
                else if ((check2 == 'Y') || (check2 == 'y'))
                {
                    cout << "Breaking server down to minimal configuration" << endl
                         << "DONE" << endl;
                    cout << "Does the condition still exists (Y/N): ";
                    char check3;
                    if (cin >> check3)
                    {
                        if ((check3 == 'Y') || (check3 == 'y') || (check3 == 'N') || (check3 == 'n'))
                        {
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }

                    if ((check3 == 'N') || (check3 == 'n'))
                    {
                        cout << "Adding one part at a time back to configuration to isolate faulty components" << endl
                             << "DONE" << endl;
                        cout << "Does the condition still exists (Y/N): ";
                        char check4;
                        if (cin >> check4)
                        {
                            if ((check4 == 'Y') || (check4 == 'y') || (check4 == 'N') || (check4 == 'n'))
                            {
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }

                        if ((check4 == 'N') || (check4 == 'n'))
                        {
                            cout << "Recording The actions that were taken for future" << endl
                                 << "DONE" << endl;
                            return 0;
                        }
                        else if ((check4 == 'Y') || (check4 == 'y'))
                        {
                            cout << "Ensure you have the following information available:" << endl
                                 << "--> Survey Configuration snapshots" << endl
                                 << "--> OS event log file" << endl
                                 << "--> Full crash dump";
                            cout << "Calling the HP service provider" << endl
                                 << "DONE" << endl;
                            return 0;
                        }
                    }
                    else if ((check3 == 'Y') || (check3 == 'y'))
                    {
                        cout << "Troubleshoot or replace basic server parts" << endl;
                        cout << "Does the condition still exists (Y/N): ";
                        char check5;
                        if (cin >> check5)
                        {
                            if ((check5 == 'Y') || (check5 == 'y') || (check5 == 'N') || (check5 == 'n'))
                            {
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }

                        if ((check5 == 'Y') || (check5 == 'y'))
                        {
                            cout << "Ensure you have the following information available:" << endl
                                 << "--> Survey Configuration snapshots" << endl
                                 << "--> OS event log file" << endl
                                 << "--> Full crash dump";
                            cout << "Calling the HP service provider" << endl
                                 << "DONE" << endl;
                            return 0;
                        }
                        else if ((check5 == 'N') || (check5 == 'n'))
                        {
                            cout << "Recording symptom and error information repair tag if sending back a failed part" << endl;
                            return 0;
                        }
                    }
                }
            }
        }
        else if ((check == 'Y') || (check == 'y'))
        {
            cout << "Isolating what has changed, verifying it was installed correctly, Restoring the server to last known working state or original shipped configuration" << endl
                 << "DONE" << endl;
            cout << "Does the condition still exists (Y/N): ";
            char check6;
            if (cin >> check6)
            {
                if ((check6 == 'Y') || (check6 == 'y') || (check6 == 'N') || (check6 == 'n'))
                {
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }
            }
            else
            {
                cout << "Invalid Input" << endl;
                return 0;
            }
            if ((check6 == 'N') || (check6 == 'n'))
            {
                cout << "Recording the actions taken for future" << endl
                     << "DONE" << endl;
                return 0;
            }
            else if ((check6 == 'Y') || (check6 == 'y'))
            {
                cout << "Isolating and minimizing the memory configuration" << endl
                     << "DONE" << endl;
                cout << "Does the condition still exists? (Y/N): ";
                char check2;
                if (cin >> check2)
                {
                    if ((check2 == 'Y') || (check2 == 'y') || (check2 == 'N') || (check2 == 'n'))
                    {
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "Invalid Input" << endl;
                    return 0;
                }

                if ((check2 == 'N') || (check2 == 'n'))
                {
                    cout << "Recording The actions that were taken for future" << endl
                         << "DONE" << endl;
                    return 0;
                }
                else if ((check2 == 'Y') || (check2 == 'y'))
                {
                    cout << "Breaking server down to minimal configuration" << endl
                         << "DONE" << endl;
                    cout << "Does the condition still exists (Y/N): ";
                    char check3;
                    if (cin >> check3)
                    {
                        if ((check3 == 'Y') || (check3 == 'y') || (check3 == 'N') || (check3 == 'n'))
                        {
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }
                    }
                    else
                    {
                        cout << "Invalid Input" << endl;
                        return 0;
                    }

                    if ((check3 == 'N') || (check3 == 'n'))
                    {
                        cout << "Adding one part at a time back to configuration to isolate faulty components" << endl
                             << "DONE" << endl;
                        cout << "Does the condition still exists (Y/N): ";
                        char check4;
                        if (cin >> check4)
                        {
                            if ((check4 == 'Y') || (check4 == 'y') || (check4 == 'N') || (check4 == 'n'))
                            {
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }

                        if ((check4 == 'N') || (check4 == 'n'))
                        {
                            cout << "Recording The actions that were taken for future" << endl
                                 << "DONE" << endl;
                            return 0;
                        }
                        else if ((check4 == 'Y') || (check4 == 'y'))
                        {
                            cout << "Ensure you have the following information available:" << endl
                                 << "--> Survey Configuration snapshots" << endl
                                 << "--> OS event log file" << endl
                                 << "--> Full crash dump";
                            cout << "Calling the HP service provider" << endl
                                 << "DONE" << endl;
                            return 0;
                        }
                    }
                    else if ((check3 == 'Y') || (check3 == 'y'))
                    {
                        cout << "Troubleshoot or replace basic server parts" << endl;
                        cout << "Does the condition still exists (Y/N): ";
                        char check5;
                        if (cin >> check5)
                        {
                            if ((check5 == 'Y') || (check5 == 'y') || (check5 == 'N') || (check5 == 'n'))
                            {
                            }
                            else
                            {
                                cout << "Invalid Input" << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "Invalid Input" << endl;
                            return 0;
                        }

                        if ((check5 == 'Y') || (check5 == 'y'))
                        {
                            cout << "Ensure you have the following information available:" << endl
                                 << "--> Survey Configuration snapshots" << endl
                                 << "--> OS event log file" << endl
                                 << "--> Full crash dump";
                            cout << "Calling the HP service provider" << endl
                                 << "DONE" << endl;
                            return 0;
                        }
                        else if ((check5 == 'N') || (check5 == 'n'))
                        {
                            cout << "Recording symptom and error information repair tag if sending back a failed part" << endl;
                            return 0;
                        }
                    }
                }
            }
        }
    }
}
