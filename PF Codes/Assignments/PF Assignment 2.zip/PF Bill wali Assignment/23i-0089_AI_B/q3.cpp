// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    short int num, multiply;

    cout << "Enter a number: ";
    if (cin >> num)
    {
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    multiply = (num << 6) - 1;
    cout << "The multiplication is " << multiply << endl;

    return 0;
}
