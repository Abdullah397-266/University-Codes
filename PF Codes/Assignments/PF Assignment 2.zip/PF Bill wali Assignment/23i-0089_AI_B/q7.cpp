// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    int num1, num2;
    cout << "Enter 2 numbers from (1-81): ";
    string rowOfNum1, rowOfNum2, colorOfNum1, colorOfNum2;
    if (cin >> num1 >> num2)
    {
        if ((num1 >= 1) && (num1 <= 81) && (num2 >= 1) && (num2 <= 81))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Checking if the row is Odd row for num1 and finding the color
    if (((num1 >= 1) && (num1 <= 9)) || ((num1 >= 19) && (num1 <= 27)) || ((num1 >= 37) && (num1 <= 45)) || ((num1 >= 55) && (num1 <= 63)) || ((num1 >= 73) && (num1 <= 81)))
    {
        // The row id odd
        if ((num1 % 3 == 0))
        {
            colorOfNum1 = "red";
        }
        else if ((num1 % 3 == 2))
        {
            colorOfNum1 = "blue";
        }
        else
        {
            colorOfNum1 = "grey";
        }
    }
    else
    {
        // The row is even
        if ((num1 % 3 == 0))
        {
            colorOfNum1 = "grey";
        }
        else if ((num1 % 3 == 2))
        {
            colorOfNum1 = "red";
        }
        else
        {
            colorOfNum1 = "blue";
        }
    }

    // Checking if the row is Odd row for num2 and finding the color
    if (((num2 >= 1) && (num2 <= 9)) || ((num2 >= 19) && (num2 <= 27)) || ((num2 >= 37) && (num2 <= 45)) || ((num2 >= 55) && (num2 <= 63)) || ((num2 >= 73) && (num2 <= 81)))
    {
        // The row is odd
        rowOfNum2 = "odd";
        if ((num2 % 3 == 0))
        {
            colorOfNum2 = "red";
        }
        else if ((num2 % 3 == 2))
        {
            colorOfNum2 = "blue";
        }
        else
        {
            colorOfNum2 = "grey";
        }
    }
    else
    {
        // The row is even
        if ((num2 % 3 == 0))
        {
            colorOfNum2 = "grey";
        }
        else if ((num2 % 3 == 2))
        {
            colorOfNum2 = "red";
        }
        else
        {
            colorOfNum2 = "blue";
        }
    }

    // Checking if the colors are same or different
    if ((colorOfNum1 == colorOfNum2))
    {
        cout << "Both have The SAME color which is " << colorOfNum1 << endl;
    }
    else
    {
        cout << "Both Have DIFFERENT color." << endl;
    }

    return 0;
}