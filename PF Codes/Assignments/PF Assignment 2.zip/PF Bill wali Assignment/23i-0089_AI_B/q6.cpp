// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    int days, salary;
    float tax, netSalary=0, tempSal, tempTax;

    cout << "Enter the no. of days of your work: ";
    if (cin >> days)
    {
        if ((days > 0) && (days <= 30))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    
    // Expected Salaries of Full-Time
    tempSal = (30 * 900 * 8);
    tempTax = tempSal * 0.05;
    cout << "Expected Highest salary Full-Time is " << (tempSal-tempTax);

    tempSal = 0; tempTax = 0;

    tempSal = (25 * 900 * 8);
    tempTax = tempSal * 0.05;
    cout << " \t\t Expected Lowest salary Full-Time is " << (tempSal-tempTax) << endl;

    // Expected Salaries of Part-Time
    tempSal = (24 * 850 * 8);
    tempTax = tempSal * 0.07;
    cout << "Expected Highest salary Part-Time is " << (tempSal-tempTax);

    tempSal = 0; tempTax = 0;

    tempSal = (15 * 850 * 8);
    tempTax = tempSal * 0.07;
    cout << " \t\t Expected Lowest salary Part-Time is " << (tempSal-tempTax) << endl;

    // Expected Salaries of Adhoc
    tempSal = (14 * 600 * 8);
    tempTax = tempSal * 0.1;
    cout << "Expected Highest salary Part-Time is " << (tempSal-tempTax);

    tempSal = 0; tempTax = 0;

    tempSal = (1 * 600 * 8);
    tempTax = tempSal * 0.1;
    cout << " \t\t Expected Lowest salary Part-Time is " << (tempSal-tempTax) << endl;



    if ((days >= 25) && (days <= 30))
    {
        salary = (days * 900 * 8);
        tax = salary * 0.05;
        netSalary = (salary - tax);
        cout << "You are a Full-Timer and your salary is " << netSalary << endl;
    }
    else if ((days >= 15) && (days <= 24))
    {
        salary = (days * 850 * 8);
        tax = salary * 0.07;
        netSalary = (salary - tax);
        cout << "You are a Part-Timer and your salary is " << netSalary << endl;
    }
    else if ((days > 0) && (days <= 14))
    {
        salary = (days * 600 * 8);
        tax = salary * 0.1;
        netSalary = (salary - tax);
        cout << "You are an Adhoc and your salary is " << netSalary << endl;
    }

    return 0;
}
