// Name: Abdullah Qadri
// Roll-no: 23i-0089
// Section: AI-B

#include <iostream>
#include <math.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    string Name, Address, Connection_Date = "28 Dec 11", Bill_Month = "Oct 21", Reading_Date = "02-Nov-21", Issue_Date = "03-Nov-21", Due_Date = "17-Nov-21", Tarrif = "A-1a(01)", Division = "Westridge", Sub_Division = "Tarnol pesh RD", Feeder_Name = "Nust Road", Reference_No = "23i-0089";

    int Total1, Total2, ED = 0, Consumer_ID = 06112003, Load = 2, Old_AC_Number = 0, Meter_No = 123456, Previous = 9742, Present = 9942, MF = 1, Units = 89, Cost, Bill, Total_FPA = 700, LP_Surcharge = 400, Bill_within_date, Bill_after_date;

    Cost = Units * 20;
    Total1 = 700 + 90 - 14;
    Total2 = 35 + 800 + 108;
    Bill = Cost + Total1 + Total2;
    Bill_within_date = Bill + Total_FPA;
    Bill_after_date = Bill_within_date + LP_Surcharge;

    cout << "Enter your Name: ";
    if (cin >> Name)
    {
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }
    cout << "Enter your Address: ";
    if (cin >> Address)
    {
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|       Connection Date       |" << "       Connected Load       |" << "  ED@  |" << "   Bill Month   |" << "   Reading Date   |" << "   Issue Date   |" << "   Due Date   |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|          28 DEC 11          |" << "                            |" << "  0%   |" << "     OCT 21     |" << "     02-NOV-21    |" << "    03-NOV-21   |" << "   17-NOV-21  |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|      CONSUMER ID      |      TARRIF      |      LOAD      |       OLD A/C NUMBER       |     DIVISION     |         WESTRIDGE        |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|        06112003       |     A-1a(01)     |        2       |              0             |   SUB-DIVISION   |     TARINOL PESH ROAD    |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|      REFERENCE NO     |     LOCK AGE     |    NO of ACs   |         UN-BILL-AGE        |   FEEDER NAME    |         NUST ROAD        |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|        23i-0089       |                  |                |                            |              WEB GENERATED BILL             |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|                                                                                        |    MONTH     UNITS     BILL       PAYMENT   |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << setfill(' ') << setw(89) << left << "| NAME & ADDRESS " <<                               "|    OCT20  |   142   |  2097   |    2097     |" << endl;
    cout << setfill(' ') << setw(89) << left << "| ABDULLAH QADRI " <<                               "|     NOV   |   124   |  1500   |    2677     |" << endl;
    cout << setfill(' ') << setw(89) << left << "| S/O AFZAAL QAYYUM " <<                            "|     DEC   |   156   |  2068   |    2646     |" << endl;
    cout << setfill(' ') << setw(89) << left << "| STREET 25 MALL RD " <<                            "|     JAN   |   204   |  1575   |    2578     |" << endl;
    cout << setfill('-') << setw(89) << "-" <<                                                       "|     FEB   |   356   |  1713   |    1245     |" << endl;
    cout << "|    METER NO    |    PREVIOUS    |    PRESENT    |   MF   |   UNITS   |     STATUS      |     MAR   |   127   |  2663   |    2663     |" << endl;
    cout << "|                     READING          READING                                           |     APR   |   160   |  3648   |    3648     |" << endl;
    cout << setfill('-') << setw(89) << "-" <<                                                       "|     MAY   |   134   |  2564   |    3568     |" << endl;
    cout << "|   SP-129634    |      9742      |      9942     |   1    |    200    |                 |     JUN   |   200   |  3589   |    3589     |" << endl;
    cout << "|                |                |               |        |           |                 |     JUL   |   190   |  2267   |    2267     |" << endl;
    cout << "|                |                |               |        |           |                 |     AUG   |   340   |  5464   |    5464     |" << endl;
    cout << "|                |                |               |        |           |                 |     SEP   |   245   |  6784   |    6784     |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|            IESCO CHARGES                    |               GOVT CHARGES               |                 TOTAL CHARGES               |" << endl;
    cout << "|                                             |                                          |                                             |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|   UNITS CONSUMED     |         200          |   ELECTRICITY DUTY     |       0         |        ARREAR/AGE        |                  |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;        
    cout << "| COST OF ELECTRICITY  |        1700          |        TV FEE          |      35         |       CURRENT BILL       |     2302         |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;        
    cout << "|     METER RENT       |                      |         GST            |      315        |      BILL ADJUSTMENT     |                  |" << endl; 
    cout << setfill('-') << setw(136) << "-" << endl;       
    cout << "|    SERVICE RENT      |                      |      INCOME TAX        |                 |       INSTALLMENT        |                  |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;        
    cout << "| FUEL PRICE AjUSTMENT |       705.36         |      EXTRA TAX         |                 |          SUBSIDY         |                  |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;        
    cout << "|    F.C SURCHARGE     |         86           |     FURTHER TAX        |                 |        TOTAL FPA         |     824.36       |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;        
    cout << "|    T.R SURCHARGE     |                      |    N.J SURSHARGE       |                 | PAYABLE WITHIN DUE DATE  |     3026         |" << endl; 
    cout << setfill('-') << setw(136) << "-" << endl;       
    cout << "|  QTR TARRIF ADJ/DMC  |        -14           |       R. STAX          |                 |       L.P SURCHARGE      |     185          |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;        
    cout << "|        TOTAL         |      2557.36         |                        |                 |  PAYABLE AFTER DUE DATE  |     3211         |" << endl; 
    cout << setfill('-') << setw(136) << "-" << endl;       
    cout << "|                      |                      |                        |                 |                          |                  |" << endl; 
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|                                        |                                |              |                                             |" << endl;      
    cout << "|          BILL CALCULATION              |          GST ON FPA            |     119      |                                             |" << endl;
    cout << "|                                        |          ED ON FPA             |              |                                             |" << endl;
    cout << "|      GOP                               |      FURTHER TAX ON FPA        |              |                                             |" << endl;
    cout << "|      TARRIF             UNITS          |          S.TAX ON FPA          |              |                                             |" << endl;
    cout << "|      07.7400     x       100           |         ET TAX ON FPA          |              |                                             |" << endl;
    cout << "|      10.0600     x       100           |         IT TAX ON FPA          |              |                                             |" << endl;
    cout << "|                                        |   -------------------------    | -----------  |                                             |" << endl;
    cout << "|                                        |      TOTAL TAXES ON FPA        |     119      |                                             |" << endl;    
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|                                        |                                |              |                                             |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|                   |                    |           TOTAL                |     469      |                                             |" << endl;
    cout << "|                   |                    |--------------------------------|--------------|                                             |" << endl;
    cout << "|                   |                    |      DIFFEREND AMOUNT          |              |                                             |" << endl;
    cout << "|                   |                    |--------------------------------|--------------|                                             |" << endl;
    cout << "|  FUEL PRICE ADJ FOR AUG21 @ 1.95/KWH   |     OUTSTANDING AMOUNT         |      0       |                                             |" << endl;
    cout << "|                   |                    |--------------------------------|--------------|                                             |" << endl;
    cout << "| PROG. IT PAID F-Y |                    |     PROG. IT PAID F-Y          |              |                                             |" << endl;
    cout << setfill('-') << setw(136) << "-" << endl;
    cout << "|   ------------------------------------------------------------------   CUT HERE   ------------------------------------------------   |" << endl;


    return 0;
}