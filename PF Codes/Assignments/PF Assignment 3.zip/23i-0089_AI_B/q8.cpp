// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assignment # 3

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>

using namespace std;

int main()
{
    int num=0, base=0, temp=0, remainder=0, convertedNum=0, multiple=0;
    string ConvertedBase, strRemainder;

    cout << "Enter the number in decimal form (base 10): ";
    if (cin >> num)
    {
        if (num > 0)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    cout << "Enter the base you want " << num << " to convert into (2-16): ";
    if (cin >> base)
    {
        if (base >= 2 && base <= 16)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    temp = num;
    convertedNum = 0;
    ConvertedBase = " ";
    multiple = 1;

    if (base == 2)
    {
        while ( temp > 0)
        {
            remainder = temp % 2;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 2;
            multiple = multiple * 10;
        }
        cout << "The Conversion to Base-2 is: " << convertedNum;
    }

    if (base == 3)
    {
        while ( temp > 0)
        {
            remainder = temp % 3;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 3;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-3 is: " << convertedNum;
    }

    if (base == 4)
    {
        while ( temp > 0)
        {
            remainder = temp % 4;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 4;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-4 is: " << convertedNum;
    }

    if (base == 5)
    {
        while ( temp > 0)
        {
            remainder = temp % 5;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 5;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-5 is: " << convertedNum;
    }

    if (base == 6)
    {
        while ( temp > 0)
        {
            remainder = temp % 6;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 6;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-6 is: " << convertedNum;
    }

    if (base == 7)
    {
        while ( temp > 0)
        {
            remainder = temp % 7;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 7;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-7 is: " << convertedNum;
    }

    if (base == 8)
    {
        while ( temp > 0)
        {
            remainder = temp % 8;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 8;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-8 is: " << convertedNum;
    }

    if (base == 9)
    {
        while ( temp > 0)
        {
            remainder = temp % 9;
            convertedNum = convertedNum + (multiple * remainder);

            temp = temp / 9;
            multiple = multiple * 10;
        }
        cout << "The OCnvrsion to Base-9 is: " << convertedNum;
    }

    if (base == 10)
    {
        cout << "The Conversion is to base 10 is: " << num;
    }

    if (base == 11)
    {
        while (temp > 0)
        {
            remainder = temp % 11;

            if (remainder < 10)
            {
                strRemainder = '0' + remainder;
            }
            else if (remainder == 10)
            {
                strRemainder = "A"; 
            }
            
            ConvertedBase = ConvertedBase + strRemainder;
            temp = temp / 11;
        }
        reverse(ConvertedBase.begin(), ConvertedBase.end());
        cout << "The Conversion to Base-11 is: " << ConvertedBase << endl;
    }

    if (base == 12)
    {
        while (temp > 0)
        {
            remainder = temp % 12;

            if (remainder < 10)
            {
                strRemainder = '0' + remainder;
            }
            else if (remainder == 10)
            {
                strRemainder = "A";
            }
            else if (remainder == 11)
            {
                strRemainder = "B"; 
            }
            
            ConvertedBase = ConvertedBase + strRemainder;
            temp = temp / 12;
        }
        reverse(ConvertedBase.begin(), ConvertedBase.end());
        cout << "The Conversion to Base-12 is: " << ConvertedBase << endl;
    }
    if (base == 13)
    {
        while (temp > 0)
        {
            remainder = temp % 13;

            if (remainder < 10)
            {
                strRemainder = '0' + remainder;
            }
            else if (remainder == 10)
            {
                strRemainder = "A"; 
            }
            else if (remainder == 11)
            {
                strRemainder = "B"; 
            }
            else if (remainder == 12)
            {
                strRemainder = "C"; 
            }
            
            ConvertedBase = ConvertedBase + strRemainder;
            temp = temp / 13;
        }
        reverse(ConvertedBase.begin(), ConvertedBase.end());
        cout << "The Conversion to Base-13 is: " << ConvertedBase << endl;
    }

    if (base == 14)
    {
        while (temp > 0)
        {
            remainder = temp % 14;

            if (remainder < 10)
            {
                strRemainder = '0' + remainder;
            }
            else if (remainder == 10)
            {
                strRemainder = "A"; 
            }
            else if (remainder == 11)
            {
                strRemainder = "B"; 
            }
            else if (remainder == 12)
            {
                strRemainder = "C"; 
            }
            else if (remainder == 13)
            {
                strRemainder = "D"; 
            }
            
            ConvertedBase = ConvertedBase + strRemainder;
            temp = temp / 14;
        }
        reverse(ConvertedBase.begin(), ConvertedBase.end());
        cout << "The Conversion to Base-14 is: " << ConvertedBase << endl;
    }
    if (base == 15)
    {
        while (temp > 0)
        {
            remainder = temp % 15;

            if (remainder < 10)
            {
                strRemainder = '0' + remainder;
            }
            else if (remainder == 10)
            {
                strRemainder = "A"; 
            }
            else if (remainder == 11)
            {
                strRemainder = "B"; 
            }
            else if (remainder == 12)
            {
                strRemainder = "C"; 
            }
            else if (remainder == 13)
            {
                strRemainder = "D"; 
            }
            else if (remainder == 14)
            {
                strRemainder = "E"; 
            }
            
            ConvertedBase = ConvertedBase + strRemainder;
            temp = temp / 15;
        }
        reverse(ConvertedBase.begin(), ConvertedBase.end());
        cout << "The Conversion to Base-15 is: " << ConvertedBase << endl;
    }

    if (base == 16)
    {
        while (temp > 0)
        {
            remainder = temp % 16;

            if (remainder < 10)
            {
                strRemainder = '0' + remainder;
            }
            else if (remainder == 10)
            {
                strRemainder = "A"; 
            }
            else if (remainder == 11)
            {
                strRemainder = "B"; 
            }
            else if (remainder == 12)
            {
                strRemainder = "C"; 
            }
            else if (remainder == 13)
            {
                strRemainder = "D"; 
            }
            else if (remainder == 14)
            {
                strRemainder = "E"; 
            }
            else if (remainder == 15)
            {
                strRemainder = "F"; 
            }
            ConvertedBase = ConvertedBase + strRemainder;
            temp = temp / 16;
        }
        reverse(ConvertedBase.begin(), ConvertedBase.end());
        cout << "The Conversion to Base-16 is: " << ConvertedBase << endl;
    }

    return 0;
}