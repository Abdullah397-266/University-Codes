// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assingment # 3

#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

int main()
{
    int player1=0, player2=0;
    char s1, s2, s3, s4, s5, s6, s7, s8, s9;

    s1 = s2 = s3 = s4 = s5 = s6 = s7 = s8 = s9 = ' ';
    // Printing the board
    cout << " " << s1 << " |"
         << " " << s2 << " |"
         << " " << s3 << endl;
    cout << setw(11) << setfill('-') << "-" << endl;
    cout << " " << s4 << " |"
         << " " << s5 << " |"
         << " " << s6 << endl;
    cout << setw(11) << setfill('-') << "-" << endl;
    cout << " " << s7 << " |"
         << " " << s8 << " |"
         << " " << s9 << endl;


    // Game running Loop
    for (int i = 1; i <= 9; i++)
    {
    
    Player1:
        // Checking for Draw
        if ((s1 != ' ') && (s2 != ' ') && (s3 != ' ') && (s4 != ' ') && (s5 != ' ') && (s6 != ' ') && (s7 != ' ') && (s8 != ' ') && (s9 != ' '))
        {
            cout << "The game ended in DRAW" << endl;
            return 0;
        }
        
        // Player 1 Input
        while (true)
        {
            cout << "Player 1's turn (1-9): ";
            if (cin >> player1)
            {
                if ((player1 > 0) && (player1 < 10))
                {
                    break;
                }
                else
                {
                    cout << "INVALID INPUT! choose from available" << endl;
                }
            }
            else
            {
                cout << "INVALID INPUT! choose from available" << endl;
            }
        }

        // Slot Vacancy checking
        if (player1 == 1)
        {
            if (s1 == ' ')
            {
                s1 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 2)
        {
            if (s2 == ' ')
            {
                s2 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 3)
        {
            if (s3 == ' ')
            {
                s3 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 4)
        {
            if (s4 == ' ')
            {
                s4 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 5)
        {
            if (s5 == ' ')
            {
                s5 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 6)
        {
            if (s6 == ' ')
            {
                s6 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 7)
        {
            if (s7 == ' ')
            {
                s7 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 8)
        {
            if (s8 == ' ')
            {
                s8 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }
        else if (player1 == 9)
        {
            if (s9 == ' ')
            {
                s9 = 'O';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player1;
            }
        }

        system("cls");
        // Again Showing the Board
        cout << " " << s1 << " |"
             << " " << s2 << " |"
             << " " << s3 << endl;
        cout << setw(11) << setfill('-') << "-" << endl;
        cout << " " << s4 << " |"
             << " " << s5 << " |"
             << " " << s6 << endl;
        cout << setw(11) << setfill('-') << "-" << endl;
        cout << " " << s7 << " |"
             << " " << s8 << " |"
             << " " << s9 << endl;

        // Checking for Win
        if (((s1 == s2) && (s2 == s3)) || ((s1 == s4) && (s4 == s7)) || ((s1 == s5) && (s5 == s9)))
        {
            if (s1 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s1 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s2 == s5) && (s5 == s8)) || ((s2 == s1) && (s1 == s3)))
        {
            if (s2 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s2 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s3 == s2) && (s2 == s1)) || ((s3 == s6) && (s6 == s9)) || ((s3 == s5) && (s5 == s7)))
        {
            if (s3 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s3 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s4 == s1) && (s1 == s7)) || ((s4 == s5) && (s5 == s6)))
        {
            if (s4 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s4 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s5 == s2) && (s2 == s8)) || ((s5 == s4) && (s4 == s6)) || ((s5 == s3) && (s3 == s7)) || ((s5 == s1) && (s1 == s9)))
        {
            if (s5 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s5 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s6 == s5) && (s5 == s4)) || ((s6 == s3) && (s3 == s9)))
        {
            if (s6 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s6 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s7 == s4) && (s4 == s1)) || ((s7 == s8) && (s8 == s9)) || ((s7 == s5) && (s5 == s3)))
        {
            if (s7 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s7 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s8 == s7) && (s7 == s9)) || ((s8 == s5) && (s5 == s2)))
        {
            if (s8 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s8 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s9 == s8) && (s8 == s7)) || ((s9 == s6) && (s6 == s3)) || ((s9 == s5) && (s5 == s1)))
        {
            if (s9 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s9 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }


    // Player 2
    Player2:

        // Checking for Draw
        if ((s1 != ' ') && (s2 != ' ') && (s3 != ' ') && (s4 != ' ') && (s5 != ' ') && (s6 != ' ') && (s7 != ' ') && (s8 != ' ') && (s9 != ' '))
        {
            cout << "The game ended in DRAW" << endl;
            return 0;
        }

        while (true)
        {
            cout << "Player 2's turn (1-9): ";
            if (cin >> player2)
            {
                if ((player2 > 0) && (player2 < 10))
                {
                    break;
                }
                else
                {
                    cout << "INVALID INPUT! choose from available" << endl;
                }
            }
            else
            {
                cout << "INVALID INPUT! choose from available" << endl;
            }
        }

        // Slot Vacancy checking
        if (player2 == 1)
        {
            if (s1 == ' ')
            {
                s1 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 2)
        {
            if (s2 == ' ')
            {
                s2 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 3)
        {
            if (s3 == ' ')
            {
                s3 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 4)
        {
            if (s4 == ' ')
            {
                s4 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 5)
        {
            if (s5 == ' ')
            {
                s5 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 6)
        {
            if (s6 == ' ')
            {
                s6 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 7)
        {
            if (s7 == ' ')
            {
                s7 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 8)
        {
            if (s8 == ' ')
            {
                s8 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }
        else if (player2 == 9)
        {
            if (s9 == ' ')
            {
                s9 = 'X';
            }
            else
            {
                cout << "This slot is already taken. Choose correct one." << endl;
                goto Player2;
            }
        }

        system("cls");
        // Again Showing the Board
        cout << " " << s1 << " |"
             << " " << s2 << " |"
             << " " << s3 << endl;
        cout << setw(11) << setfill('-') << "-" << endl;
        cout << " " << s4 << " |"
             << " " << s5 << " |"
             << " " << s6 << endl;
        cout << setw(11) << setfill('-') << "-" << endl;
        cout << " " << s7 << " |"
             << " " << s8 << " |"
             << " " << s9 << endl;

        // Checking for Win
        if (((s1 == s2) && (s2 == s3)) || ((s1 == s4) && (s4 == s7)) || ((s1 == s5) && (s5 == s9)))
        {
            if (s1 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s1 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s2 == s5) && (s5 == s8)) || ((s2 == s1) && (s1 == s3)))
        {
            if (s2 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s2 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s3 == s2) && (s2 == s1)) || ((s3 == s6) && (s6 == s9)) || ((s3 == s5) && (s5 == s7)))
        {
            if (s3 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s3 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s4 == s1) && (s1 == s7)) || ((s4 == s5) && (s5 == s6)))
        {
            if (s4 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s4 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s5 == s2) && (s2 == s8)) || ((s5 == s4) && (s4 == s6)) || ((s5 == s3) && (s3 == s7)) || ((s5 == s1) && (s1 == s9)))
        {
            if (s5 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s5 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s6 == s5) && (s5 == s4)) || ((s6 == s3) && (s3 == s9)))
        {
            if (s6 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s6 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s7 == s4) && (s4 == s1)) || ((s7 == s8) && (s8 == s9)) || ((s7 == s5) && (s5 == s3)))
        {
            if (s7 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s7 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s8 == s7) && (s7 == s9)) || ((s8 == s5) && (s5 == s2)))
        {
            if (s8 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s8 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        if (((s9 == s8) && (s8 == s7)) || ((s9 == s6) && (s6 == s3)) || ((s9 == s5) && (s5 == s1)))
        {
            if (s9 == 'O')
            {
                cout << "WooHoo! Player 1 WINS." << endl;
                return 0;
            }
            else if (s9 == 'X')
            {
                cout << "WooHoo! Player 2 WINS." << endl;
                return 0;
            }
        }
        
    }

    return 0;
}
