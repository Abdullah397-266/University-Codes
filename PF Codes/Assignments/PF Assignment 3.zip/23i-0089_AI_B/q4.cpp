// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assingment # 3

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    int people, step, lastPerson, i;

    cout << "Enter the no. of poeple and the step: ";
    if (cin >> people >> step)
    {
        if (people > 0 && step > 0)
        {
        }
        else
        {
            cout << "Invalid Input";
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input";
        return 0;
    }

    lastPerson = 0;
    i=2;

    while (i <= people)
    {
        lastPerson = ((lastPerson + step) % i);
        i++;
    }

    lastPerson = lastPerson + 1;

    cout << "The position of the last person is: " << lastPerson << endl;

    return 0;
}
