// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assignment # 3

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    int num, i = 0, j = 0, fullLength = 0, primeStart = 0;
    bool flag = 1;

    cout << "Enter the number for prime no. grid: ";
    if (cin >> num)
    {
        if (num > 0)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    fullLength = (num * num);
    primeStart = 2;

    // For grid management
    for (i = 1; i <= fullLength; i++)
    {
        // By default true
        flag = 1;

        // Printing universal prime numbers
        if (i == 1)
        {
            cout << setw((6*num)) << setfill('-') << "--" << endl;
            cout << "| P   ";
            continue;
        }

        // Checking for Prime Numbers at and after 4
        for (j = 2; j < primeStart; j++)
        {
            if ((primeStart % j) == 0)
            {
                flag = 0;
                break;
            }
        }
        primeStart++;

        if (flag == 1)
        {
            cout << "| P   ";
        }
        else if (flag == 0)
        {
            cout << "| .   ";
        }

        // Controlling Spaces
        if (i % num == 0)
        {
            cout << "|" << endl;
            cout << setw((6*num)) << setfill('-') << "--" << endl;
        }
    }

    return 0;
}