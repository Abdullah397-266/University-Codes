// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assignment # 3

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    int i, j, k, sp;

    // printing upper triangle
    for (i = 1; i <= 5; i++)
    {
        // printing tab spaces
        for (sp = 5; sp >= i; sp--)
        {
            cout << "\t";
        }

        cout << "/" << i;
        // Controlling Internal Spaces
        if (i != 1)
        {
            for (j = 0; j < ((2 * i) - 2); j++)
            {
                cout << "\t";
            }
        }

        if (i == 1)
        {
            cout << "\\";
        }
        else
        {
            cout << i << "\\";
        }
        cout << endl;
    }

    // Printing Middle Part
    for (k = 1; k <= 9; k++)
    {
        if (k == 1)
        {
            cout << "|*     " << setw(68) << setfill('^') << "^"
                 << "    *|";
        }
        if (k == 9)
        {
            cout << "|*     " << setw(68) << setfill('v') << "v"
                 << "    *|";
        }
        if (k == 2)
        {
            cout << "|*     <       " << setw(18) << setfill('.') << "." << setw(16) << setfill(' ') << " " << setw(21) << setfill('.') << "."
                 << "    >    *|";
        }
        if (k == 5)
        {
            cout << "|*     <       " << setw(18) << setfill('.') << "." << setw(8) << setfill(' ') << " " << "0" << setw(7) << setfill(' ') << " " << setw(21) << setfill('.') << "."
                 << "    >    *|";
        }
        if (k == 3 || k == 4 || k == 6 || k == 7 || k == 8)
        {
            cout << "|*     <       ." << setw(17) << setfill(' ') << "." << setw(16) << setfill(' ') << " "
                 << "." << setw(20) << setfill(' ') << "."
                 << "    >    *|";
        }
        if (k == 5)
        {

        }
        cout << endl;
    }

    // Printing the Lower Triangle
    for (i = 5; i >= 1; i--)
    {
        // printing tab spaces
        for (sp = 5; sp >= i; sp--)
        {
            cout << "\t";
        }

        cout << "\\" << i;
        // Controlling Internal Spaces
        if (i != 1)
        {
            for (j = 0; j < ((2 * i) - 2); j++)
            {
                cout << "\t";
            }
        }

        if (i == 1)
        {
            cout << "/";
        }
        else
        {
            cout << i << "/";
        }
        cout << endl;
    }

    return 0;
}