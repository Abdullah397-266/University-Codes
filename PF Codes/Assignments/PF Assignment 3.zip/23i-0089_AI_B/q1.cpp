// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assingment # 3

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    int num, temp, fib_num1, fib_num2, fib_num3, i, j, fullNum = 1, count = 0, spCounter, sp;
    cout << "Enter a fibonacci number: ";
    if (cin >> num)
    {
        if (num > 0)
        {
            fib_num1 = 0; // Default Fibonacci numbers
            fib_num2 = 1;
            i = 1;
            while (i <= num)
            {
                fib_num3 = fib_num1 + fib_num2;
                fib_num1 = fib_num2;
                fib_num2 = fib_num3;

                fullNum = fullNum * 10 + fib_num3;
                count++;

                // Checking if the entered number is Fibonacci
                if (num == fib_num3)
                {
                    cout << "The entered number is a Fibonacci number" << endl;
                    break;
                }
                i++;
            }

            // Ckecking if number entered is NOT Fibonacci
            if (num != fib_num3)
            {
                cout << "The entered number is NOT a Fibonacci number" << endl;
                return 0;
            }
        }
    }
    else
    {
        cout << "Invalid Input";
        return 0;
    }

    count = count + 2;
    temp = (count + count - 1);

    spCounter = temp / 2;

    i = 1;
    while (i <= (temp / 2) + 1)
    {
        // spaces for upper part
        sp = 1;
        while (sp <= spCounter)
        {
            cout << " ";
            sp++;
        }
        spCounter--;
        // upper triangle
        j = 1;
        while (j <= (2 * i) - 1)
        {
            if (i == j)
            {
                cout << (fullNum % 10);
            }
            int loop = 2;
            while (loop <= (temp / 2) + 1)
            {
                if ((i == loop && (j == (loop - 1) || j == (loop + 1))))
                {
                    cout << ((fullNum / 10) % 10);
                }
                loop++;
            }
            loop = 3;
            while (loop <= (temp / 2) + 2)
            {
                if ((i == loop && (j == (loop - 2) || j == (loop + 1))))
                {
                    cout << ((fullNum / 100) % 10);
                }
                loop++;
            }
            loop = 4;
            while (loop <= (temp / 2) + 3)
            {
                if ((i == loop && (j == (loop - 3) || j == (loop + 1))))
                {
                    cout << ((fullNum / 1000) % 10);
                }
                loop++;
            }
            loop = 5;
            while (loop <= (temp / 2) + 4)
            {
                if ((i == loop && (j == (loop - 4) || j == (loop + 1))))
                {
                    cout << ((fullNum / 10000) % 10);
                }
                loop++;
            }
            loop = 6;
            while (loop <= (temp / 2) + 5)
            {
                if ((i == loop && (j == (loop - 5) || j == (loop + 1))))
                {
                    cout << ((fullNum / 100000) % 10);
                }
                loop++;
            }

            if ((i == 7 && j == 1) || (i == 7 && j == temp))
            {
                cout << 0;
            }
            j++;
        }
        i++;
        cout << endl;
    }
    spCounter = 1;
    i = (temp / 2);
    while (i >= 1)
    {
        // spaces for the lower part
        sp = 1;
        while (sp <= spCounter)
        {
            cout << " ";
            sp++;
        }
        spCounter++;
        // lower triangle
        j = 1;
        while (j <= (2 * i) - 1)
        {
            int loop = 6;
            while (loop <= (temp / 2) + 5)
            {
                if ((i == loop && (j == (loop - 5) || j == (loop + 5))))
                {
                    cout << ((fullNum / 100000) % 10);
                }
                loop++;
            }
            loop = 5;
            while (loop <= (temp / 2) + 4)
            {
                if ((i == loop && (j == (loop - 4) || j == (loop + 4))))
                {
                    cout << ((fullNum / 10000) % 10);
                }
                loop++;
            }
            loop = 4;
            while (loop <= (temp / 2) + 3)
            {
                if ((i == loop && (j == (loop - 3) || j == (loop + 3))))
                {
                    cout << ((fullNum / 1000) % 10);
                }
                loop++;
            }
            loop = 3;
            while (loop <= (temp / 2) + 2)
            {
                if ((i == loop && (j == (loop - 2) || j == (loop + 2))))
                {
                    cout << ((fullNum / 100) % 10);
                }
                loop++;
            }
            loop = 2;
            while (loop <= (temp / 2) + 1)
            {
                if ((i == loop && (j == (loop - 1) || j == (loop + 1))))
                {
                    cout << ((fullNum / 10) % 10);
                }
                loop++;
            }

            if (i == j)
            {
                cout << (fullNum % 10);
            }
            j++;
        }
        i--;
        cout << endl;
    }

    return 0;
}