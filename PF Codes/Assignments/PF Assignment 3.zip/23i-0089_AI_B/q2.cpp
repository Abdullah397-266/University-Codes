// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assingment # 3

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    int num, temp, i, j, k, l, space, space2;
    Re_Enter:
    cout << "Enter a positive number: ";
    if (cin >> num)
    {
        if (num > 1)
        {}
        else
        {
            cout << "Invalid Input. Please enter a +ve number";
            goto Re_Enter;
        }
    }
    else
    {
        cout << "Invalid Input. Please enter a +ve number";
        goto Re_Enter;
    }

    temp=num;

    for (i=1; i<=(num+1); i++)
    {
        // Printing Spaces
        for (space=1; space<=temp; space++)
        {
            cout << " ";
        }
        temp--;

        if (i==1)
        {
            cout << "|" << endl;
            continue;
        }

        // printing backslashes
        for (j=1; j<=(i-1); j++)
        {
            cout << "\\";
        }
        cout << "|";

        // printing forward-slashes
        for (k=1; k<=(i-1); k++)
        {
            cout << "/";
        }

        cout << endl;
    }

    // printing the log of the tree
    for (l=1; l<=3; l++)
    {
        // For top
        if (l != 3)
        {
            for (space2 = 1; space2 < num; space2++)
            {
                cout << " ";
            }
            cout << "|||";
        }
        // for bottom
        if (l == 3)
        {
            for (space2 = 1; space2 < (num-1); space2++)
            {
                cout << " ";
            }
            cout << "_|||_";
        }
        cout << endl;
    }

    return 0;
}
