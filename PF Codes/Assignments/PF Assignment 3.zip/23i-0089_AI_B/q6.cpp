// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assignment # 3

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    long int n, i, j, fact;
    double x, approx;

    // Input x
    cout << "Enter the value of x: ";
    if (cin >> x)
    {
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Input n
    cout << "Enter the no of terms: ";
    if (cin >> n)
    {
        if (n >= 0 && n < 18)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Program starts

    // for n=0, approx=0
    approx = 0;
    for (i=0; i<n; i++)
    {
        fact = 1;
        for (j=1; j<=(2*i)+1; j++)
        {
            fact = fact * j;
        }
        approx = approx + ( pow(-1,i) * pow(x,(2*i+1)) / fact );
    }

    cout << "The Approx Value of sin(" << x << ") using " << n << " terms is: " << setprecision(3) << approx << endl;

    return 0;
}