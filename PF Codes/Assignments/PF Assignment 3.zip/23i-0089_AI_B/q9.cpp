// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assingment # 3

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    int month, year, date, monthDays, year1st, year2nd, cal, start;
    bool isLeapYear;
    string monthName;

    cout << "Enter The Month (1-12) and Year: ";
    if (cin >> month >> year)
    {
        if ((month > 0 && month < 13) && (year > 0))
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    // Storing The Name of the Month to Dispaly in the Callender
    switch (month)
    {
    case 1:
        monthName = "January";
        break;
    case 2:
        monthName = "Feburary";
        break;
    case 3:
        monthName = "March";
        break;
    case 4:
        monthName = "April";
        break;
    case 5:
        monthName = "May";
        break;
    case 6:
        monthName = "June";
        break;
    case 7:
        monthName = "July";
        break;
    case 8:
        monthName = "August";
        break;
    case 9:
        monthName = "September";
        break;
    case 10:
        monthName = "October";
        break;
    case 11:
        monthName = "November";
        break;
    case 12:
        monthName = "December";
        break;
    }

    // Checking if the entered year is a leap year
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
    {
        isLeapYear = 1;
    }
    else
    {
        isLeapYear = 0;
    }

    // Counting The days of the given month
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
    {
        monthDays = 31;
    }
    else if (month == 4 || month == 6 || month == 9 || month == 11)
    {
        monthDays = 30;
    }
    else if (month == 2)
    {
        if (isLeapYear)
        {
            monthDays = 29;
        }
        else
        {
            monthDays = 28;
        }
    }

    // Setting up Months value according to Zeller's Formula
    if (month == 1)
    {
        month = 13;
        year--;
    }
    if (month == 2)
    {
        month = 14;
        year--;
    }

    date = 1;
    year1st = year / 100;
    year2nd = year % 100;

    cal = date + 13 * (month + 1) / 5 + year2nd + year2nd / 4 + year1st / 4 + 5 * year1st;

    cal = cal % 7;
    switch (cal)
    {
    case 0:
        cout << "First day of the month is Saturday \n";
        start = 5;
        break;
    case 1:
        cout << "First day of the month is Sunday \n";
        start = 6;
        break;
    case 2:
        cout << "First day of the month is Monday \n";
        start = 0;
        break;
    case 3:
        cout << "First day of the month is Tuesday \n";
        start = 1;
        break;
    case 4:
        cout << "First day of the month is Wednesday \n";
        start = 2;
        break;
    case 5:
        cout << "First day of the month is Thursday \n";
        start = 3;
        break;
    case 6:
        cout << "First day of the month is Friday \n";
        start = 4;
        break;
    }

    // preparing the Grid
    cout << setw(42) << setfill(' ') << monthName << ", " << year << endl;
    cout << setw(12) << setfill(' ') << "Monday" << setw(12) << setfill(' ') << "Tuesday" << setw(12) << setfill(' ') << "Wednesday" << setw(12) << setfill(' ') << "Thursday" << setw(12) << setfill(' ') << "Friday" << setw(12) << setfill(' ') << "Saturday" << setw(12) << setfill(' ') << "Sunday" << endl;

    // Giving Initial Spaces IF ANY
    for (int sp = 1; sp <= start; sp++)
    {
        cout << setw(12) << setfill(' ') << " ";
    }
    // 6 Rows and 7 columns
    for (int i = start; i < (monthDays + start); i++)
    {
        cout << setw(12) << setfill(' ') << i - (start - 1);
        if ((i + 1) % 7 == 0)
        {
            cout << endl;
        }
    }

    return 0;
}
