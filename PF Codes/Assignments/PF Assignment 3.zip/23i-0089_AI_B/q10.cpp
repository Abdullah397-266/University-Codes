// Name: Abdullah Qadri
// Roll-No: 23i-0089
// Assignment # 3

#include <iostream>

using namespace std;

int main()
{
    int i, j, sp, rows, num;

    cout << "Enter the no of rows for Pascal Triangle: ";
    if (cin >> rows)
    {
        if (rows > 0)
        {
        }
        else
        {
            cout << "Invalid Input" << endl;
            return 0;
        }
    }
    else
    {
        cout << "Invalid Input" << endl;
        return 0;
    }

    for (i=0; i<rows; i++)
    {
        for (sp=0; sp<(rows-i); sp++ )
        {
            cout << " ";
        }

        num = 1;
        for (j=0; j<=i; j++)
        {
            cout << " " << num;
            num = num * (i-j) / (j+1);
        }
        cout << endl;
    }

}