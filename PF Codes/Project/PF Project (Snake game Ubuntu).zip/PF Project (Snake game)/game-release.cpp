
#ifndef TETRIS_CPP_
#define TETRIS_CPP_
#include "util.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <string>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sstream>
#include <fstream>
#include <cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

char direction = 'w';
int boardWidth = 32, boardHeight = 32;
int snakeHeadX = 16, snakeHeadY = 5;
int prevSnakeX, prevSnakeY;
int prevSnake2X, prevSnake2Y;
int snakeTailX[100], snakeTailY[100], nthTail = 2, count = 0;
int fruitX[5], fruitY[5];
int powerFoodX, powerFoodY;
int co = 0, score = 0, highScore = 0;
int toPlaceX = 0, toPlaceY = 0;
string toDisplay = "menu";

void SetCanvasSize(int width, int height)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void Hurdle(int m) // Printing the L-Shape Hurdle
{
    bool flag = true;

    // Checking if the spawn point has any collision
RemakeHurdle:
    while (flag)
    {
        flag = false;

        toPlaceX = rand() % 32;
        toPlaceY = toPlaceX; // Initial Cords for the placement of the Hurdle

        // Conditions for initial cords
        if ((toPlaceX >= 0 && toPlaceX <= 27) && (toPlaceY >= 0 && toPlaceY <= 27))
        {
        }
        else
        {
            flag = true;
            continue;
        }

        // Ckecking if the required grid is empty
        for (int Y = toPlaceY + 5; Y > toPlaceY; Y--)
        {
            for (int X = toPlaceX; X < (toPlaceX + 5); X++)
            {
                if (X == snakeHeadX && Y == snakeHeadY)
                {
                    flag = true;
                    goto RemakeHurdle;
                }
                if (X == powerFoodX && Y == powerFoodY)
                {
                    flag = true;
                    goto RemakeHurdle;
                }
                for (int i = 0; i < 5; i++)
                {
                    if (X == fruitX[i] && Y == fruitY[i])
                    {
                        flag = true;
                        goto RemakeHurdle;
                    }
                }
                for (int i = 0; i < nthTail; i++)
                {
                    if (X == snakeTailX[i] && Y == snakeTailY[i])
                    {
                        flag = true;
                        goto RemakeHurdle;
                    }
                }
            }
        }
    } // Checking ends
    glutTimerFunc(150000 / FPS, Hurdle, 0);
}

void PowerFood(int m)
{
    srand(time(0));

    bool flag = true;

    while (flag)
    {
        flag = false;
        powerFoodX = rand() % 32;
        powerFoodY = rand() % 32;

        // Check for simple fruit
        for (int i = 0; i < 5; i++)
        {
            if (powerFoodX == fruitX[i] && powerFoodY == fruitY[i])
            {
                flag = true;
                break;
            }
        }
        if (flag == true)
            continue;

        // Checking for snake tail
        for (int i = 0; i < nthTail; i++)
        {
            if (powerFoodX == snakeTailX[i] && powerFoodY == snakeTailY[i])
            {
                flag = true;
                break;
            }
        }
        if (flag == true)
            continue;

        // Checking if the fruit has hurdle cords
        for (int j = 0; j < 5; j++)
        {
            if ((powerFoodX == toPlaceX + j && powerFoodY == toPlaceX) || (powerFoodX == toPlaceY && powerFoodY == toPlaceY + j))
            {
                flag = true;
                break;
            }
        }
        if (flag == true)
            continue;
    }

    glutPostRedisplay();

    glutTimerFunc(300000.0 / FPS, PowerFood, 0); // 1min delay
}

void RemovePowerFood(int m)
{
    powerFoodX = -100;
    powerFoodY = -100;

    glutPostRedisplay();

    glutTimerFunc(75000.0 / FPS, RemovePowerFood, 0); // 15s delay
}

void Fruit(int m)
{
    srand(time(0));
    bool flag = true;

    while (flag)
    {
        flag = false;
        // Generating the Cords for the fruits
        for (int i = 0; i < 5; i++)
        {
            fruitX[i] = rand() % 32;
            fruitY[i] = rand() % 32;
        }
        // Checks for fruit
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (j == i)
                {
                    continue;
                }
                if (fruitX[i] == fruitX[j] || fruitY[i] == fruitY[j]) //* Rows and Columns Handeled
                {
                    flag = true;
                    break;
                }
            }
            if (flag == true)
                break;
        }
        if (flag == true)
            continue;

        // Ckecking if the fruit has the cords of snake tail
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < nthTail; j++)
            {
                if (fruitX[i] == snakeTailX[j] && fruitY[i] == snakeTailY[j])
                {
                    flag = true;
                    break;
                }
            }
            if (flag == true)
                break;
        }
        if (flag == true)
            continue;

        // Checking if the fruit has hurdle cords
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if ((fruitX[i] == toPlaceX + j && fruitY[i] == toPlaceX) || (fruitX[i] == toPlaceY && fruitY[i] == toPlaceY + j))
                {
                    flag = true;
                    break;
                }
            }
            if (flag == true)
                break;
        }
        if (flag == true)
            continue;

        // Condition For the Diagonals (Primary and Secondary)
        for (int i = 0; i < 5; i++)
        {
            int fX = fruitX[i];
            int fY = fruitY[i];
            for (int j = 1; j <= 46; j++)
            {
                // Checkng Top-Left side (Primary Diagonal)
                --fX;
                ++fY;
                for (int k = 0; k < 5; k++)
                {
                    if (k == i)
                    {
                        continue;
                    }
                    if (fruitX[k] == fX && fruitY[k] == fY)
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag == true)
                    break;
            }
            if (flag == true)
                break;

            fX = fruitX[i];
            fY = fruitY[i];
            for (int j = 1; j <= 46; j++)
            {
                // Checkng Bottom-Right side (Primary Diagonal)
                ++fX;
                --fY;
                for (int k = 0; k < 5; k++)
                {
                    if (k == i)
                    {
                        continue;
                    }
                    if (fruitX[k] == fX && fruitY[k] == fY)
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag == true)
                    break;
            }
            if (flag == true)
                break;

            fX = fruitX[i];
            fY = fruitY[i];
            for (int j = 1; j <= 46; j++)
            {
                // Checkng Top-Right side (Secondary Diagonal)
                ++fX;
                ++fY;
                for (int k = 0; k < 5; k++)
                {
                    if (k == i)
                    {
                        continue;
                    }
                    if (fruitX[k] == fX && fruitY[k] == fY)
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag == true)
                    break;
            }
            if (flag == true)
                break;

            fX = fruitX[i];
            fY = fruitY[i];
            for (int j = 1; j <= 46; j++)
            {
                // Checkng Bottom-Left side (Secondary Diagonal)
                --fX;
                --fY;
                for (int k = 0; k < 5; k++)
                {
                    if (k == i)
                    {
                        continue;
                    }
                    if (fruitX[k] == fX && fruitY[k] == fY)
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag == true)
                    break;
            }
            if (flag == true)
                break;
        }
    }

    glutTimerFunc(75000.0 / FPS, Fruit, 0); // 15s delay
}

void Exit()
{
    toDisplay = "Exit";

    // Writing score to file
    ofstream file1;
    file1.open("scoreHistory.txt", ios::app);
    file1 << score;
    file1.close();

    // Writing High Score to a file
    int temp;
    fstream file;
    file.open("scores.txt", ios::in);
    file >> temp;
    highScore = temp;
    file.close();

    if (score > highScore)
    {
        toDisplay = "HighScoreExit";

        fstream file;
        file.open("scores.txt", ios::out);
        file << score;
        file.close();
    }
}

/*
 * Main Canvas drawing function.
 * */

void Display()
{
    srand(time(0));
    glClearColor(0, 0.0, 0.0, 0); // Red==Green==Blue==1 --> White Colour
    glClear(GL_COLOR_BUFFER_BIT);

    if (toDisplay == "menu")
    {
        for (int Y = 32; Y >= 0; Y--)
        {
            for (int X = 0; X < 32; X++)
            {
                // Displaying the Board
                if (co == 0)
                {
                    if (Y % 2 == 0)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 1;
                }
                else
                {
                    if (Y % 2 == 1)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 0;
                }
            }
        }

        // Displaying SNAKE GAME
        DrawString(20 * 12, 20 * 21, "SNAKE GAME", colors[DARK_GREEN]);

        // Displaying Buttons (Options)
        DrawString(20 * 8, 20 * 18, "NEW GAME (PRESS ENTER)", colors[DIM_GRAY]);
        DrawString(20 * 8 + 10, 20 * 16, "RESUME GAME (PRESS R)", colors[DIM_GRAY]);
        DrawString(20 * 9, 20 * 14, "HIGH SCORE (PRESS H)", colors[DIM_GRAY]);
        DrawString(20 * 9 - 14, 20 * 12, "SCORE HISTORY (PRESS S)", colors[DIM_GRAY]);
        DrawString(20 * 14, 20 * 10, "EXIT", colors[DIM_GRAY]);
    }

    if (toDisplay == "game")
    {
        // Drawing the Snake
        for (int Y = 32; Y >= 0; Y--)
        {
            for (int X = 0; X < 32; X++)
            {
                // Displaying the Board
                if (Y <= 31)
                {
                    if (co == 0)
                    {
                        if (Y % 2 == 0)
                            DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                        else
                            DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                        co = 1;
                    }
                    else
                    {
                        if (Y % 2 == 1)
                            DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                        else
                            DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                        co = 0;
                    }
                }
                if (Y == 32 && X == 2)
                {
                    DrawString(20 * X, 20 * Y, "Score: " + to_string(score), colors[WHITE]);
                }

                if (X == powerFoodX && Y == powerFoodY)
                {

                    // Printing the star for power Food
                    DrawTriangle(20 * X + 10, 20 * Y + 22, 20 * X + 7, 20 * Y + 8, 20 * X + 13, 20 * Y + 8, colors[GOLDEN_ROD]);
                    DrawTriangle(20 * X - 2, 20 * Y + 13, 20 * X + 10, 20 * Y + 6, 20 * X + 13, 20 * Y + 13, colors[GOLDEN_ROD]);
                    DrawTriangle(20 * X + 22, 20 * Y + 13, 20 * X + 7, 20 * Y + 13, 20 * X + 10, 20 * Y + 6, colors[GOLDEN_ROD]);
                    DrawTriangle(20 * X + 2, 20 * Y - 2, 20 * X + 7, 20 * Y + 13, 20 * X + 13, 20 * Y + 8, colors[GOLDEN_ROD]);
                    DrawTriangle(20 * X + 18, 20 * Y - 2, 20 * X + 7, 20 * Y + 8, 20 * X + 13, 20 * Y + 13, colors[GOLDEN_ROD]);

                    // DrawTriangle(20*X+10,20*Y+22 , 20*X+7,20*Y+8 , 20*X+13,20*Y+8,  colors[GOLDEN_ROD]);
                    // DrawTriangle(20*X-2,20*Y+13 , 20*X+10,20*Y+6 , 20*X+13,20*Y+13,  colors[GOLDEN_ROD]);
                    // DrawTriangle(20*X+22,20*Y+13 , 20*X+7,20*Y+13 , 20*X+10,20*Y+6,  colors[GOLDEN_ROD]);
                    // DrawTriangle(20*X+2,20*Y-2 , 20*X+7,20*Y+13 , 20*X+13,20*Y+8,  colors[GOLDEN_ROD]);
                    // DrawTriangle(20*X+18,20*Y-2 , 20*X+7,20*Y+8 , 20*X+13,20*Y+13,  colors[GOLDEN_ROD]);
                }

                // Printing The Fruit
                for (int i = 0; i < 5; i++)
                {
                    if (i == 0)
                    {
                        if (X == fruitX[i] && Y == fruitY[i])
                        {
                            DrawCircle(20 * X + 10, 20 * Y + 10, 10, colors[BLACK]);
                            DrawCircle(20 * X + 10, 20 * Y + 10, 8, colors[PURPLE]);
                            DrawCircle(20 * X + 10, 20 * Y + 14, 3, colors[MEDIUM_PURPLE]);
                        }
                    }
                    else if (i == 1)
                    {
                        if (X == fruitX[i] && Y == fruitY[i])
                        {
                            DrawCircle(20 * X + 10, 20 * Y + 10, 10, colors[BLACK]);
                            DrawCircle(20 * X + 10, 20 * Y + 10, 8.5, colors[RED]);
                            DrawCircle(20 * X + 10, 20 * Y + 13, 4, colors[GREEN]);
                        }
                    }
                    else if (i == 2)
                    {
                        if (X == fruitX[i] && Y == fruitY[i])
                        {
                            DrawCircle(20 * X + 10, 20 * Y + 10, 10, colors[BLACK]);
                            DrawCircle(20 * X + 10, 20 * Y + 10, 8.5, colors[ORANGE_RED]);
                            DrawCircle(20 * X + 8, 20 * Y + 13, 2, colors[DARK_GREEN]);
                        }
                    }
                    else if (i == 3)
                    {
                        if (X == fruitX[i] && Y == fruitY[i])
                        {
                            DrawCircle(20 * X + 10, 20 * Y + 10, 10, colors[BLACK]);
                            DrawCircle(20 * X + 10, 20 * Y + 10, 8.5, colors[YELLOW_GREEN]);
                            DrawCircle(20 * X + 8, 20 * Y + 15, 2, colors[BLACK]);
                        }
                    }
                    else if (i == 4)
                    {
                        if (X == fruitX[i] && Y == fruitY[i])
                        {
                            DrawCircle(20 * X + 10, 20 * Y + 10, 10, colors[BLACK]);
                            DrawCircle(20 * X + 10, 20 * Y + 10, 8.5, colors[BROWN]);
                            DrawCircle(20 * X + 7, 20 * Y + 13, 2, colors[GRAY]);
                            DrawCircle(20 * X + 12, 20 * Y + 13, 2, colors[GRAY]);
                            DrawCircle(20 * X + 8.5, 20 * Y + 8, 2, colors[GRAY]);
                        }
                    }
                }

                // Printing Snake's Head
                if (snakeHeadX == X && snakeHeadY == Y)
                {
                    DrawCircle(20 * snakeHeadX + 10, 20 * snakeHeadY + 10, 10, colors[BLACK]);
                    DrawCircle(20 * snakeHeadX + 10, 20 * snakeHeadY + 10, 8, colors[BLUE]);
                }
                // Printing snake's Body
                for (int k = 0; k < nthTail; k++)
                {
                    if (snakeTailX[k] == X && snakeTailY[k] == Y)
                    {
                        DrawSquare(20 * X, 20 * Y, 20, colors[BLACK]);
                        DrawSquare(20 * X + 2, 20 * Y + 2, 16, colors[BLUE]);
                        DrawCircle(20 * X + 10, 20 * Y + 10, 6, colors[DARK_BLUE]);
                    }
                }

                // Printing the Hurdle
                for (int i = 0; i < 5; i++)
                {
                    if ((X == toPlaceX + i && Y == toPlaceX) || (X == toPlaceY && Y == toPlaceY + i))
                    {
                        DrawSquare(20 * X, 20 * Y, 20, colors[BLACK]);
                        DrawSquare(20 * X + 2, 20 * Y + 2, 16, colors[YELLOW]);
                    }
                }
            }
        }

        // Ckecking if the snake has eaten the fruit
        for (int i = 0; i < 5; i++)
        {
            if (snakeHeadX == fruitX[i] && snakeHeadY == fruitY[i])
            {
                nthTail++;
                score += 5;

                // Regenerating the fruit
                bool flag = true;
                while (flag)
                {
                    flag = false;
                    fruitX[i] = rand() % 32;
                    fruitY[i] = rand() % 32;

                    // Checks for fruit
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (j == i)
                            {
                                continue;
                            }
                            if (fruitX[i] == fruitX[j] || fruitY[i] == fruitY[j]) //* Rows and Columns Handeled
                            {
                                flag = true;
                            }
                        }
                    }

                    // Ckecking if the fruit has the cords of snake tail
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 0; j < nthTail; j++)
                        {
                            if (fruitX[i] == snakeTailX[j] && fruitY[i] == snakeTailY[j])
                            {
                                flag = true;
                            }
                        }
                    }
                    // Checking if the fruit has hurdle cords
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if ((fruitX[i] == toPlaceX + j && fruitY[i] == toPlaceX) || (fruitX[i] == toPlaceY && fruitY[i] == toPlaceY + j))
                            {
                                flag = true;
                                break;
                            }
                        }
                    }

                    // Condition For the Diagonals (Primary and Secondary)
                    for (int i = 0; i < 5; i++)
                    {
                        int fX = fruitX[i];
                        int fY = fruitY[i];
                        for (int j = 1; j <= 46; j++)
                        {
                            // Checkng Top-Left side (Primary Diagonal)
                            --fX;
                            ++fY;
                            for (int k = 0; k < 5; k++)
                            {
                                if (k == i)
                                {
                                    continue;
                                }
                                if (fruitX[k] == fX && fruitY[k] == fY)
                                {
                                    flag = true;
                                }
                            }
                        }
                        fX = fruitX[i];
                        fY = fruitY[i];
                        for (int j = 1; j <= 46; j++)
                        {
                            // Checkng Bottom-Right side (Primary Diagonal)
                            ++fX;
                            --fY;
                            for (int k = 0; k < 5; k++)
                            {
                                if (k == i)
                                {
                                    continue;
                                }
                                if (fruitX[k] == fX && fruitY[k] == fY)
                                {
                                    flag = true;
                                }
                            }
                        }
                        fX = fruitX[i];
                        fY = fruitY[i];
                        for (int j = 1; j <= 46; j++)
                        {
                            // Checkng Top-Right side (Secondary Diagonal)
                            ++fX;
                            ++fY;
                            for (int k = 0; k < 5; k++)
                            {
                                if (k == i)
                                {
                                    continue;
                                }
                                if (fruitX[k] == fX && fruitY[k] == fY)
                                {
                                    flag = true;
                                }
                            }
                        }
                        fX = fruitX[i];
                        fY = fruitY[i];
                        for (int j = 1; j <= 46; j++)
                        {
                            // Checkng Bottom-Left side (Secondary Diagonal)
                            --fX;
                            --fY;
                            for (int k = 0; k < 5; k++)
                            {
                                if (k == i)
                                {
                                    continue;
                                }
                                if (fruitX[k] == fX && fruitY[k] == fY)
                                {
                                    flag = true;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ckecking if the snake has eaten the Power Fruit
        if (snakeHeadX == powerFoodX && snakeHeadY == powerFoodY)
        {
            powerFoodX = -200;
            powerFoodY = -200;
            score += 20;
        }

        // Checking if the snake has touched his tail
        for (int i = 0; i < 40; i++)
        {
            if (snakeHeadX == 0 && snakeHeadY == 0)
            {
                continue;
            }
            if (snakeHeadX == snakeTailX[i] && snakeHeadY == snakeTailY[i])
            {
                Exit();
            }
        }

        // Checking if the snake has Touched the Hurdle
        for (int i = 0; i < 5; i++)
        {
            if ((snakeHeadX == toPlaceX + i && snakeHeadY == toPlaceX) || (snakeHeadX == toPlaceY && snakeHeadY == toPlaceY + i))
            {
                Exit();
            }
        }

        // Clearing the Array if it has no cords of snake's Tail
        for (int i = 0; i < 65; i++)
        {
            if (snakeTailX[i] == 0)
            {
                snakeTailX[i] = '\0';
            }
            if (snakeTailY[i] == 0)
            {
                snakeTailY[i] = '\0';
            }
        }

        // Making the snake's real movement
        prevSnakeX = snakeTailX[0];
        prevSnakeY = snakeTailY[0];
        snakeTailX[0] = snakeHeadX;
        snakeTailY[0] = snakeHeadY;

        for (int i = 1; i < nthTail; i++)
        {
            prevSnake2X = snakeTailX[i];
            prevSnake2Y = snakeTailY[i];
            snakeTailX[i] = prevSnakeX;
            snakeTailY[i] = prevSnakeY;
            prevSnakeX = prevSnake2X;
            prevSnakeY = prevSnake2Y;
        }

        // Moving the Snake in a Particullar Direction
        if (direction == 'w')
        {
            snakeHeadY += 1;
        }
        else if (direction == 's')
        {
            snakeHeadY -= 1;
        }
        else if (direction == 'a')
        {
            snakeHeadX -= 1;
        }
        else if (direction == 'd')
        {
            snakeHeadX += 1;
        }

        // Condition of free Move
        if (snakeHeadY < 0)
        {
            snakeHeadY = boardHeight - 1;
        }
        else if (snakeHeadY > boardHeight - 1)
        {
            snakeHeadY = 0;
        }
        else if (snakeHeadX < 0)
        {
            snakeHeadX = boardWidth - 1;
        }
        else if (snakeHeadX > boardWidth)
        {
            snakeHeadX = 0;
        }
    }

    if (toDisplay == "HighScores")
    {
        for (int Y = 32; Y >= 0; Y--)
        {
            for (int X = 0; X < 32; X++)
            {
                // Displaying the Board
                if (co == 0)
                {
                    if (Y % 2 == 0)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 1;
                }
                else
                {
                    if (Y % 2 == 1)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 0;
                }
            }
        }

        // Showing High Scores
        DrawString(20 * 12, 20 * 21, "SNAKE GAME", colors[DARK_GREEN]);

        // Fetching data from file
        fstream file;
        file.open("scores.txt", ios::in);
        file >> highScore;
        DrawString(20 * 10 - 10, 20 * 18, "Highest Score so far: " + to_string(highScore), colors[DIM_GRAY]);
        file.close();

        DrawString(20 * 10, 20 * 16, "GO BACK (PRESS B)", colors[DIM_GRAY]);
    }

    if (toDisplay == "History")
    {
        for (int Y = 32; Y >= 0; Y--)
        {
            for (int X = 0; X < 32; X++)
            {
                // Displaying the Board
                if (co == 0)
                {
                    if (Y % 2 == 0)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 1;
                }
                else
                {
                    if (Y % 2 == 1)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 0;
                }
            }
        }

        // Displaying SNAKE GAME
        DrawString(20 * 12, 20 * 29, "SNAKE GAME", colors[DARK_GREEN]);
        DrawString(20 * 12 + 10, 20 * 26, "Score History", colors[DARK_GREEN]);

        int arr[11];

        ifstream file;
        file.open("scoreHistory.txt");

        for (int i = 0; i < 11; i++)
        {
            file >> arr[i];
            DrawString(20 * 13 + 10, 20 * (24 - (2 * i)), "Score: " + to_string(arr[i]), colors[DIM_GRAY]);
        }
        file.close();
    }

    if (toDisplay == "HighScoreExit")
    {
        for (int Y = 32; Y >= 0; Y--)
        {
            for (int X = 0; X < 32; X++)
            {
                // Displaying the Board
                if (co == 0)
                {
                    if (Y % 2 == 0)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 1;
                }
                else
                {
                    if (Y % 2 == 1)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 0;
                }
            }
        }

        DrawString(20 * 12, 20 * 21, "GAME OVER", colors[DARK_GREEN]);
        DrawString(20 * 3, 20 * 19, "WooHoo! You have broken all the Previous Records ", colors[DARK_GREEN]);
        DrawString(20 * 8, 20 * 17, "and made a new high score", colors[DARK_GREEN]);

        // Fetching data from scores file
        fstream file;
        file.open("scores.txt", ios::in);
        file >> highScore;
        DrawString(20 * 10 - 10, 20 * 14, "NEW HIGH SCORE: " + to_string(highScore), colors[DARK_GREEN]);
        file.close();

        DrawString(20 * 10 + 10, 20 * 11, "EXIT (PRESS ESC)", colors[DIM_GRAY]);
    }

    if (toDisplay == "Exit")
    {
        for (int Y = 32; Y >= 0; Y--)
        {
            for (int X = 0; X < 32; X++)
            {
                // Displaying the Board
                if (co == 0)
                {
                    if (Y % 2 == 0)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 1;
                }
                else
                {
                    if (Y % 2 == 1)
                        DrawSquare(20 * X, 20 * Y, 21, colors[LIGHT_GREEN]);
                    else
                        DrawSquare(20 * X, 20 * Y, 21, colors[PALE_GREEN]);
                    co = 0;
                }
            }
        }

        DrawString(20 * 12, 20 * 21, "GAME OVER", colors[DARK_GREEN]);

        DrawString(20 * 13-7, 20 * 18, "Score is: " + to_string(score), colors[DARK_GREEN]);

        DrawString(20 * 10 + 10, 20 * 15, "EXIT (PRESS ESC)", colors[DIM_GRAY]);
    }

    glutSwapBuffers(); //! do not modify this line..
}
/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y)
{
    if (key == GLUT_KEY_LEFT)
    {
    }
    else if (key == GLUT_KEY_RIGHT)
    {
    }
    else if (key == GLUT_KEY_UP)
    {
    }
    else if (key == GLUT_KEY_DOWN)
    {
    }

    /* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
       this function*/
    glutPostRedisplay();
}

void PrintableKeys(unsigned char key, int x, int y)
{
    if (int(key) == 13) // Enter key
    {
        if (toDisplay == "menu")
        {
            toDisplay = "game";
            score = 0;
            nthTail = 2;
            snakeHeadX = 16, snakeHeadY = 5;
            snakeTailX[0] = snakeTailX[1] = 16;
            snakeTailY[0] = 4;
            snakeTailY[1] = 3;
            direction = 'w';
        }
    }
    if (key == KEY_ESC /* Escape key ASCII*/)
    {
        if (toDisplay == "menu")
        {
            exit(1); // exit the program when escape key is pressed.
        }
        if (toDisplay == "game")
        {
            toDisplay = "menu";
        }
        if (toDisplay == "History")
        {
            toDisplay = "menu";
        }
        if (toDisplay == "HighScoreExit" || toDisplay == "Exit")
        {
            toDisplay = "menu";
        }
    }
    if (key == 'R' || key == 'r')
    {
        if (toDisplay == "menu")
        {
            toDisplay = "game";
        }
    }
    if (key == 'H' || key == 'h')
    {
        if (toDisplay == "menu")
        {
            toDisplay = "HighScores";
        }
    }
    if (key == 'B' || key == 'b')
    {
        if (toDisplay == "HighScores")
        {
            toDisplay = "menu";
        }
    }
    if (key == 'S' || key == 's')
    {
        if (toDisplay == "menu")
        {
            toDisplay = "History";
        }
    }

    // Controlling the Direction of the snake
    if (key == 'w')
    {
        if (toDisplay == "game")
        {
            // Impossible Case
            if (direction == 's')
            {
                direction = 's';
            }
            // All Possible Cases
            if (direction == 'a')
            {
                direction = 'w';
            }
            if (direction == 'w')
            {
                direction = 'w';
            }
            if (direction == 'd')
            {
                direction = 'w';
            }
        }
    }
    else if (key == 's')
    {
        if (toDisplay == "game")
        {
            // Impossible Case
            if (direction == 'w')
            {
                direction = 'w';
            }
            // All Possible Cases
            else if (direction == 'a')
            {
                direction = 's';
            }
            else if (direction == 's')
            {
                direction = 's';
            }
            else if (direction == 'd')
            {
                direction = 's';
            }
        }
    }
    if (key == 'a')
    {
        if (toDisplay == "game")
        {
            // Impossible Case
            if (direction == 'd')
            {
                direction = 'd';
            }
            // All Possible Cases
            else if (direction == 'w')
            {
                direction = 'a';
            }
            else if (direction == 'a')
            {
                direction = 'a';
            }
            else if (direction == 's')
            {
                direction = 'a';
            }
        }
    }
    else if (key == 'd')
    {
        if (toDisplay == "game")
        {
            // Impossible Case
            if (direction == 'a')
            {
                direction = 'a';
            }
            // All Possible Cases
            else if (direction == 'w')
            {
                direction = 'd';
            }
            else if (direction == 'd')
            {
                direction = 'd';
            }
            else if (direction == 's')
            {
                direction = 'd';
            }
        }
    }

    glutPostRedisplay();
}

void Timer(int m)
{
    // implement your functionality here
    glutPostRedisplay();
    // once again we tell the library to call our Timer function after next 1000/FPS
    glutTimerFunc(500.0 / FPS, Timer, 0);
}

/*
 * our gateway main function
 * */
int main(int argc, char *argv[])
{
    // fruitX[0] = 3;
    // fruitY[0] = 6;
    // fruitX[1] = 21;
    // fruitY[1] = 16;
    // fruitX[2] = 31;
    // fruitY[2] = 12;
    // fruitX[3] = 7;
    // fruitY[3] = 23;
    // fruitX[4] = 18;
    // fruitY[4] = 26;

    snakeTailX[0] = snakeTailX[1] = 16;
    snakeTailY[0] = 4;
    snakeTailY[1] = 3;

    int width = 640, height = 660; // i have set my window size to be 640 x 660
    InitRandomizer();              // seed the random number generator...
    glutInit(&argc, argv);         // initialize the graphics library...

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
    glutInitWindowPosition(50, 50);               // set the initial position of our window
    glutInitWindowSize(width, height);            // set the size of our window
    glutCreateWindow("PF's Snake Game");          // set the title of our game window
    SetCanvasSize(width, height);                 // set the number of pixels...

    // Register your functions to the library,
    // you are telling the library names of function to call for different tasks.
    // glutDisplayFunc(display); // tell library which function to call for drawing Canvas.
    glutDisplayFunc(Display);           // tell library which function to call for drawing Canvas.
    glutSpecialFunc(NonPrintableKeys);  // tell library which function to call for non-printable ASCII characters
    glutKeyboardFunc(PrintableKeys);    // tell library which function to call for printable ASCII characters
    glutTimerFunc(5.0 / FPS, Timer, 0); // This function tells the library to call our Timer function after 1000.0/FPS milliseconds...

    glutTimerFunc(5.0 / FPS, Fruit, 0);
    glutTimerFunc(75000.0 / FPS, RemovePowerFood, 0); // remove first then print
    glutTimerFunc(5.0 / FPS, PowerFood, 0);
    glutTimerFunc(5.0 / FPS, Hurdle, 0);

    // now handle the control to library and it will call our registered functions when
    // it deems necessary...
    glutMainLoop();
    return 1;
}
#endif /* Snake Game */
