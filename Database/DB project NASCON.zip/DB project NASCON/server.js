const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();
const port = 3000;

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '714392',
    database: 'project'
});

// Connect to database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL database:', err);
        return;
    }
    console.log('Connected to MySQL project database');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));
app.use(session({
    secret: 'nascon-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 3600000 } // 1 hour
}));

// Add this middleware to check authentication status
app.use((req, res, next) => {
    // Set a global variable to indicate if user is logged in
    res.locals.isLoggedIn = !!req.session.user;
    res.locals.user = req.session.user || null;
    next();
});

// Modify the root route to redirect to login page
app.get('/', (req, res) => {
    // Check if user is already logged in
    if (req.session.user) {
        // If logged in, redirect to index
        res.sendFile(path.join(__dirname, 'index.html'));
    } else {
        // If not logged in, redirect to login page
        res.sendFile(path.join(__dirname, 'login_signup.html'));
    }
});

// Make a separate route for the home page
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Update other routes to check login status
app.get('/index.html', (req, res) => {
    if (req.session.user) {
        res.sendFile(path.join(__dirname, 'index.html'));
    } else {
        res.redirect('/');
    }
});

// Modify all page routes to redirect to login if not authenticated
const securedPages = ['events.html', 'sponsers.html', 'ambassadors.html'];

securedPages.forEach(page => {
    app.get('/' + page, (req, res) => {
        // Extract the page name without extension
        const pageName = page.replace('.html', '');

        if (req.session.user) {
            res.sendFile(path.join(__dirname, page));
        } else {
            // Store the intended destination for redirect after login
            req.session.returnTo = '/' + page;
            res.redirect('/');
        }
    });
});

// Add a route for login page direct access
app.get('/login_signup.html', (req, res) => {
    // If already logged in, redirect to home
    if (req.session.user) {
        res.redirect('/home');
    } else {
        res.sendFile(path.join(__dirname, 'login_signup.html'));
    }
});

// API routes for authentication
app.post('/api/signup', (req, res) => {
    const { name, phone, email, password } = req.body;

    if (!name || !phone || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if user already exists
    db.query('SELECT * FROM User WHERE email = ?', [email], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        if (results.length > 0) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        // Insert new user
        db.query(
            'INSERT INTO User (Name, email, Phone, Password) VALUES (?, ?, ?, ?)',
            [name, email, phone, password], // In production, hash the password
            (err, results) => {
                if (err) {
                    console.error('Error creating user:', err);
                    return res.status(500).json({ error: 'Failed to register user' });
                }

                return res.status(201).json({ message: 'User registered successfully' });
            }
        );
    });
});

app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
  
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }
  
    db.query(
        'SELECT * FROM User WHERE email = ? AND Password = ?',
        [email, password],
        (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
      
            if (results.length === 0) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }
      
            // Store user in session
            const user = results[0];
            req.session.user = {
                id: user.user_id,
                user_id: user.user_id, 
                name: user.Name,
                email: user.email
            };
            
            // Check if user is a judge
            db.query(
                'SELECT judge_id FROM Judge WHERE user_id = ?',
                [user.user_id],
                (err, judgeResults) => {
                    if (err) {
                        console.error('Error checking judge status:', err);
                        // Continue with login but without judge flag
                        return res.status(200).json({ 
                            message: 'Login successful',
                            user: {
                                id: user.user_id,
                                name: user.Name,
                                email: user.email,
                                isJudge: false
                            }
                        });
                    }
                    
                    const isJudge = judgeResults && judgeResults.length > 0;
                    
                    // Set the judge flag in session
                    req.session.user.isJudge = isJudge;
                    if (isJudge) {
                        req.session.user.judgeId = judgeResults[0].judge_id;
                    }
                    
                    // Log for debugging
                    // console.log('User logged in with judge status:', isJudge);
                    
                    // Return user details with judge status
                    return res.status(200).json({ 
                        message: 'Login successful',
                        user: {
                            id: user.user_id,
                            name: user.Name,
                            email: user.email,
                            isJudge: isJudge
                        }
                    });
                }
            );
        }
    );
});

// Admin login endpoint
app.post('/api/admin/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }

    db.query(
        'SELECT * FROM Admin WHERE email = ? AND password = ?',
        [email, password],
        (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }

            if (results.length === 0) {
                return res.status(401).json({ error: 'Invalid email or password' });
            }

            // Store admin in session
            const admin = results[0];
            req.session.user = {
                id: admin.id,
                name: admin.name,
                email: admin.email,
                isAdmin: true
            };

            return res.status(200).json({
                message: 'Login successful',
                user: {
                    name: admin.name,
                    email: admin.email,
                    isAdmin: true
                }
            });
        }
    );
});

// Add this endpoint if it doesn't exist
app.get('/api/auth-status', (req, res) => {
    if (req.session && req.session.user) {
        // Return complete user info including judge status
        return res.json({
            isLoggedIn: true,
            user: {
                id: req.session.user.id,
                name: req.session.user.name,
                email: req.session.user.email
            },
            isAdmin: req.session.user.isAdmin || false,
            isJudge: req.session.user.isJudge || false
        });
    } else {
        return res.json({ isLoggedIn: false });
    }
});

// Add logout endpoint if it doesn't exist
app.get('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ success: false, error: 'Failed to logout' });
        }
        res.clearCookie('connect.sid');
        return res.json({ success: true });
    });
});

// Enhanced API route for events with joined data
app.get('/api/events', (req, res) => {
    const query = `
    SELECT e.*, es.Start_time, es.End_time, v.Venue_name, eh.name as handler_name,
    (SELECT u.Name FROM Judge j JOIN User u ON j.user_id = u.user_id WHERE j.event_id = e.event_id LIMIT 1) as judge_name
    FROM Event e
    LEFT JOIN Event_Schedule es ON e.Schedule_id = es.Schedule_id
    LEFT JOIN Venue v ON es.Venue_Id = v.Venue_Id
    LEFT JOIN Event_Handler eh ON e.eventHandler_id = eh.eventHandler_id
  `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        return res.json(results);
    });
});

// Add endpoint to get event by ID
app.get('/api/events/:id', (req, res) => {
    const eventId = req.params.id;

    const query = `
    SELECT e.*, es.Start_time, es.End_time, v.Venue_name, eh.name as handler_name,
    (SELECT u.Name FROM Judge j JOIN User u ON j.user_id = u.user_id WHERE j.event_id = e.event_id LIMIT 1) as judge_name
    FROM Event e
    LEFT JOIN Event_Schedule es ON e.Schedule_id = es.Schedule_id
    LEFT JOIN Venue v ON es.Venue_Id = v.Venue_Id
    LEFT JOIN Event_Handler eh ON e.eventHandler_id = eh.eventHandler_id
    WHERE e.event_id = ?
  `;

    db.query(query, [eventId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }

        return res.json(results[0]);
    });
});

// Add endpoint to get events by category
app.get('/api/events/category/:category', (req, res) => {
    const category = req.params.category;

    if (!['Computing', 'Business', 'Engineering', 'Sports', 'Social'].includes(category)) {
        return res.status(400).json({ error: 'Invalid category' });
    }

    const query = `
    SELECT e.*, es.Start_time, es.End_time, v.Venue_name, eh.name as handler_name,
    (SELECT u.Name FROM Judge j JOIN User u ON j.user_id = u.user_id WHERE j.event_id = e.event_id LIMIT 1) as judge_name
    FROM Event e
    LEFT JOIN Event_Schedule es ON e.Schedule_id = es.Schedule_id
    LEFT JOIN Venue v ON es.Venue_Id = v.Venue_Id
    LEFT JOIN Event_Handler eh ON e.eventHandler_id = eh.eventHandler_id
    WHERE e.category = ?
  `;

    db.query(query, [category], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        return res.json(results);
    });
});

// API route for contact form
app.post('/api/contact', (req, res) => {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    db.query(
        'INSERT INTO Feedback (Name, email, subject, message) VALUES (?, ?, ?, ?)',
        [name, email, subject, message],
        (err, results) => {
            if (err) {
                console.error('Error submitting feedback:', err);
                return res.status(500).json({ error: 'Failed to submit message' });
            }

            return res.status(201).json({ message: 'Message sent successfully' });
        }
    );
});

// API route for sponsor inquiry
app.post('/api/sponsor-inquiry', (req, res) => {
    const { name, email, company, position, phone, sponsorship_id, details, isPaid } = req.body;

    // Basic validation
    if (!name || !email || !company || !phone || !sponsorship_id) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Insert sponsor record only if they chose to pay now
    if (isPaid) {
        db.query(
            'INSERT INTO Sponsor (email, name, phone, company, position, description, sponsorship_id, isPaid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [email, name, phone, company, position, details, sponsorship_id, isPaid ? 1 : 0],
            (err, results) => {
                if (err) {
                    console.error('Error submitting sponsor inquiry:', err);
                    return res.status(500).json({ error: 'Failed to submit inquiry' });
                }

                return res.status(201).json({
                    message: 'Sponsorship confirmed! Thank you for your support.',
                    success: true
                });
            }
        );
    } else {
        // For "Pay Later" option, store in a different table or with different status
        db.query(
            'INSERT INTO Sponsor_Inquiries (email, name, phone, company, position, description, sponsorship_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [email, name, phone, company, position, details, sponsorship_id],
            (err, results) => {
                if (err) {
                    console.error('Error submitting sponsor inquiry:', err);
                    return res.status(500).json({ error: 'Failed to submit inquiry' });
                }

                return res.status(201).json({
                    message: 'Inquiry submitted successfully! Our team will contact you about payment.',
                    success: true
                });
            }
        );
    }
});

// API route to fetch sponsors by tier
app.get('/api/sponsors/:tier', (req, res) => {
    const tier = req.params.tier.toLowerCase();

    // Map tier name to sponsorship_id
    let sponsorshipId;
    switch (tier) {
        case 'platinum':
            sponsorshipId = 1;
            break;
        case 'gold':
            sponsorshipId = 2;
            break;
        case 'silver':
            sponsorshipId = 3;
            break;
        case 'bronze':
            sponsorshipId = 4;
            break;
        default:
            return res.status(400).json({ error: 'Invalid sponsor tier' });
    }

    // Query sponsors for the specified tier
    db.query(
        'SELECT * FROM Sponsor WHERE sponsorship_id = ?',
        [sponsorshipId],
        (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }

            return res.json(results);
        }
    );
});

// API endpoint to fetch all sponsors
app.get('/api/sponsors', (req, res) => {
    db.query(
        'SELECT s.*, sp.Name AS tier_name FROM Sponsor s JOIN Sponsorship sp ON s.sponsorship_id = sp.sponsorship_id ORDER BY s.sponsorship_id ASC',
        (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }

            return res.json(results);
        }
    );
});

// API route for ambassadors
app.get('/api/ambassadors', (req, res) => {
    db.query('SELECT * FROM Ambassador', (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        return res.json(results);
    });
});

// API route for community partners
app.get('/api/community-members', (req, res) => {
    db.query('SELECT * FROM Community_Member', (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        return res.json(results);
    });
});

// Admin routes for event management
app.get('/admin-panel.html', (req, res) => {
    if (req.session.user && req.session.user.isAdmin) {
        res.sendFile(path.join(__dirname, 'admin-panel.html'));
    } else {
        res.redirect('/login_signup.html');
    }
});

// Fetch all judges for event assignment
app.get('/api/admin/judges', (req, res) => {
    db.query('SELECT * FROM User', (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        return res.json(results);
    });
});

// Fetch all event handlers
app.get('/api/admin/event-handlers', (req, res) => {
    // Query all handlers with their associated events
    const query = `
        SELECT eh.*, e.Event_name as event_name
        FROM Event_Handler eh
        LEFT JOIN Event e ON eh.eventHandler_id = e.eventHandler_id
        ORDER BY eh.isAssigned DESC
    `;
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        return res.json(results);
    });
});

// Update the add-event endpoint to include category
app.post('/api/admin/add-event', (req, res) => {
    if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: 'Unauthorized' });
    }

    const {
        eventName,
        category,   // Add category
        description,
        guidelines,
        maxParticipants,
        registrationFee,
        eventDate,
        venueId,
        eventHandlerId,
        startTime,
        endTime
    } = req.body;

    // First create schedule
    db.query(
        'INSERT INTO Event_Schedule (Start_time, End_time, Venue_Id) VALUES (?, ?, ?)',
        [startTime, endTime, venueId],
        (err, scheduleResult) => {
            if (err) {
                console.error('Error creating event schedule:', err);
                return res.status(500).json({ error: 'Failed to create event' });
            }

            const scheduleId = scheduleResult.insertId;

            // Then create the event with the schedule ID (include category)
            db.query(
                'INSERT INTO Event (Event_name, category, description, guidelines, Max_participants, Registration_Fee, Event_date, Schedule_id, eventHandler_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [eventName, category, description, guidelines, maxParticipants, registrationFee, eventDate, scheduleId, eventHandlerId],
                (err, eventResult) => {
                    if (err) {
                        console.error('Error creating event:', err);
                        return res.status(500).json({ error: 'Failed to create event' });
                    }

                    // Update event handler to be assigned
                    db.query(
                        'UPDATE Event_Handler SET isAssigned = "Yes" WHERE eventHandler_id = ?',
                        [eventHandlerId]
                    );

                    return res.status(201).json({
                        message: 'Event created successfully',
                        eventId: eventResult.insertId
                    });
                }
            );
        }
    );
});

// Add a judge to an event
app.post('/api/admin/assign-judge', (req, res) => {
    if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: 'Unauthorized' });
    }

    const { userId, eventId } = req.body;
    
    // First, check if user is already a participant in this event
    db.query(
        'SELECT * FROM Participant WHERE user_id = ? AND event_id = ?',
        [userId, eventId],
        (err, participantResults) => {
            if (err) {
                console.error('Error checking participant status:', err);
                return res.status(500).json({ error: 'Failed to validate user eligibility' });
            }
            
            // If user is a participant, prevent assignment as judge
            if (participantResults.length > 0) {
                return res.status(400).json({ 
                    error: 'This user is already a participant in this event and cannot be assigned as judge'
                });
            }
            
            // Check if event already has a judge assigned
            db.query(
                'SELECT * FROM Judge WHERE event_id = ?',
                [eventId],
                (err, judgeResults) => {
                    if (err) {
                        console.error('Error checking existing judge:', err);
                        return res.status(500).json({ error: 'Failed to validate event status' });
                    }
                    
                    // If event already has a judge, prevent assignment
                    if (judgeResults.length > 0) {
                        return res.status(400).json({ 
                            error: 'This event already has a judge assigned'
                        });
                    }
                    
                    // Proceed with judge assignment
                    db.query(
                        'INSERT INTO Judge (user_id, event_id) VALUES (?, ?)',
                        [userId, eventId],
                        (err, results) => {
                            if (err) {
                                console.error('Error assigning judge:', err);
                                return res.status(500).json({ error: 'Failed to assign judge' });
                            }

                            return res.status(201).json({
                                message: 'Judge assigned successfully',
                                judgeId: results.insertId
                            });
                        }
                    );
                }
            );
        }
    );
});

// Get venues for event creation
app.get('/api/admin/venues', (req, res) => {
    db.query('SELECT * FROM Venue', (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        return res.json(results);
    });
});

// Get all handlers for dropdown
app.get('/api/admin/handlers', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.status(403).json({ error: 'Not logged in' });
    }

    // Query all users with handler role
    db.query("SELECT user_id, Name, email FROM User WHERE role = 'handler' ORDER BY Name", (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        res.json(results);
    });
});

// API endpoint to fetch all events for admin panel
app.get('/api/admin/events', (req, res) => {
    if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: 'Unauthorized' });
    }

    const query = `
    SELECT e.*, es.Start_time, es.End_time, v.Venue_name, eh.name as handler_name,
    (SELECT u.Name FROM Judge j JOIN User u ON j.user_id = u.user_id WHERE j.event_id = e.event_id LIMIT 1) as judge_name
    FROM Event e
    LEFT JOIN Event_Schedule es ON e.Schedule_id = es.Schedule_id
    LEFT JOIN Venue v ON es.Venue_Id = v.Venue_Id
    LEFT JOIN Event_Handler eh ON e.eventHandler_id = eh.eventHandler_id
    ORDER BY e.event_id DESC
  `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        return res.json(results);
    });
});

// Check if user is registered for an event and if they are a judge for that event
app.get('/api/check-registration', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not logged in' });
    }

    const eventId = req.query.eventId;
    const userId = req.session.user.id;

    if (!eventId) {
        return res.status(400).json({ error: 'Event ID is required' });
    }

    // Check if user is registered for this event
    db.query(
        'SELECT * FROM Participant WHERE event_id = ? AND user_id = ?',
        [eventId, userId],
        (err, participantResults) => {
            if (err) {
                console.error('Error checking registration:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            // Check if user is a judge for this event
            db.query(
                'SELECT * FROM Judge WHERE event_id = ? AND user_id = ?',
                [eventId, userId],
                (err, judgeResults) => {
                    if (err) {
                        console.error('Error checking judge status:', err);
                        return res.status(500).json({ error: 'Server error' });
                    }
                    
                    return res.json({
                        isRegistered: participantResults.length > 0,
                        isJudge: judgeResults.length > 0
                    });
                }
            );
        }
    );
});

// Register for an event (individual)
app.post('/api/register-event', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'User not logged in' });
    }

    const { eventId, isSolo } = req.body;

    // Debug user session data
    console.log('User session data:', req.session.user);

    // Properly extract user ID
    // Try different properties since the exact property might vary
    const userId = req.session.user.id || req.session.user.user_id;

    console.log('Using user ID for registration:', userId);

    if (!userId) {
        return res.status(400).json({ error: 'User ID not found in session' });
    }

    if (!eventId) {
        return res.status(400).json({ error: 'Event ID is required' });
    }

    // Check if event exists and has space
    db.query(
        'SELECT Max_participants, Registration_Fee FROM Event WHERE event_id = ?',
        [eventId],
        (err, eventResults) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }

            if (eventResults.length === 0) {
                return res.status(404).json({ error: 'Event not found' });
            }

            // Check if user is already registered
            db.query(
                'SELECT * FROM Participant WHERE event_id = ? AND user_id = ?',
                [eventId, userId],
                (err, participantResults) => {
                    if (err) {
                        console.error('Database error:', err);
                        return res.status(500).json({ error: 'Server error' });
                    }

                    if (participantResults.length > 0) {
                        return res.status(400).json({ error: 'Already registered for this event' });
                    }

                    // Insert participant
                    // console.log(`Inserting participant - eventId: ${eventId}, userId: ${userId}, isSolo: ${isSolo ? 'Yes' : 'No'}`);

                    db.query(
                        'INSERT INTO Participant (event_id, user_id, isSolo) VALUES (?, ?, ?)',
                        [eventId, userId, isSolo ? 'Yes' : 'No'],
                        (err, insertResult) => {
                            if (err) {
                                console.error('Database error:', err);
                                return res.status(500).json({ error: 'Server error' });
                            }

                            // Create payment entry
                            db.query(
                                'INSERT INTO Payment (payment_of, amount, payment_status, user_id) VALUES (?, ?, ?, ?)',
                                ['Event', eventResults[0].Registration_Fee, 'Completed', userId],
                                (err, paymentResult) => {
                                    if (err) {
                                        console.error('Database error:', err);
                                        // Don't return error, just log it
                                    }
                                }
                            );

                            return res.status(201).json({
                                message: 'Registration successful',
                                participantId: insertResult.insertId
                            });
                        }
                    );
                }
            );
        }
    );
});

// Register a team for an event
app.post('/api/register-team', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not logged in' });
    }

    const { eventId, teamName, memberEmails } = req.body;
    const userId = req.session.user.id;

    if (!eventId || !teamName || !Array.isArray(memberEmails)) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
    
    // Check if event exists and has space
    db.query(
        'SELECT Max_participants, Registration_Fee FROM Event WHERE event_id = ?',
        [eventId],
        (err, eventResults) => {
            if (err) {
                console.error('Error checking event:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            if (eventResults.length === 0) {
                return res.status(404).json({ error: 'Event not found' });
            }
            
            const maxParticipants = eventResults[0].Max_participants;
            const registrationFee = eventResults[0].Registration_Fee;
            
            // Validate team size
            if (memberEmails.length + 1 > maxParticipants) { // +1 for the team leader
                return res.status(400).json({ 
                    error: `Team exceeds maximum size of ${maxParticipants} members` 
                });
            }
            
            // Create a new team
            db.query(
                'INSERT INTO Teams (Team_Name) VALUES (?)',
                [teamName],
                (err, teamResult) => {
                    if (err) {
                        console.error('Error creating team:', err);
                        return res.status(500).json({ error: 'Server error' });
                    }
                    
                    const teamId = teamResult.insertId;
                    
                    // Register team leader as participant
                    db.query(
                        'INSERT INTO Participant (event_id, user_id, Team_id, isSolo) VALUES (?, ?, ?, "No")',
                        [eventId, userId, teamId],
                        (err, leaderResult) => {
                            if (err) {
                                console.error('Error registering team leader:', err);
                                return res.status(500).json({ error: 'Server error' });
                            }
                            
                            // Record payment for team leader
                            db.query(
                                'INSERT INTO Payment (payment_of, amount, payment_status, user_id) VALUES (?, ?, ?, ?)',
                                ['Event', registrationFee, 'Completed', userId],
                                (err, paymentResult) => {
                                    if (err) {
                                        console.error('Error recording payment:', err);
                                        // Continue anyway, payment recording isn't critical
                                    }
                                    
                                    // Log the team member emails that would be notified
                                    console.log('Team members to be notified:', memberEmails);
                                    
                                    // For each member email, check if user exists, else just log the email
                                    const memberProcessingPromises = memberEmails.map(email => {
                                        return new Promise((resolve) => {
                                            // Check if user exists with this email
                                            db.query(
                                                'SELECT user_id FROM User WHERE email = ?',
                                                [email],
                                                (err, userResults) => {
                                                    if (err || userResults.length === 0) {
                                                        // Just log the email
                                                        console.log(`Notification would be sent to: ${email}`);
                                                        resolve();
                                                    } else {
                                                        // User exists, add them to the team
                                                        const memberId = userResults[0].user_id;
                                                        db.query(
                                                            'INSERT INTO Participant (event_id, user_id, Team_id, isSolo) VALUES (?, ?, ?, "No")',
                                                            [eventId, memberId, teamId],
                                                            (err) => {
                                                                if (err) {
                                                                    console.error(`Error adding team member ${email}:`, err);
                                                                } else {
                                                                    console.log(`Added existing user ${email} to team`);
                                                                }
                                                                resolve();
                                                            }
                                                        );
                                                    }
                                                }
                                            );
                                        });
                                    });
                                    
                                    // Wait for all member processing to complete
                                    Promise.all(memberProcessingPromises)
                                        .then(() => {
                                            res.json({ 
                                                success: true, 
                                                message: 'Team registered successfully',
                                                teamId: teamId 
                                            });
                                        });
                                }
                            );
                        }
                    );
                }
            );
        }
    );
});

// Get user registrations for My Registrations page
app.get('/api/user-registrations', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'User not logged in' });
    }

    const userId = req.session.user.id;

    const query = `
        SELECT p.participant_id, p.isSolo, p.Team_id,
               e.event_id, e.Event_name, e.description, e.category, e.Event_date, e.Registration_Fee,
               v.Venue_name, es.Start_time, es.End_time,
               t.Team_Name
        FROM Participant p
        JOIN Event e ON p.event_id = e.event_id
        LEFT JOIN Event_Schedule es ON e.Schedule_id = es.Schedule_id
        LEFT JOIN Venue v ON es.Venue_Id = v.Venue_Id
        LEFT JOIN Teams t ON p.Team_id = t.Team_id
        WHERE p.user_id = ?
        ORDER BY e.Event_date DESC
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        // Format results
        const registrations = results.map(reg => {
            const startTime = reg.Start_time ? new Date(reg.Start_time).toLocaleTimeString() : 'TBA';
            const endTime = reg.End_time ? new Date(reg.End_time).toLocaleTimeString() : 'TBA';

            return {
                id: reg.participant_id,
                eventId: reg.event_id,
                eventName: reg.Event_name,
                category: reg.category,
                status: 'Confirmed', // Default status, could be based on payment status
                eventDate: reg.Event_date ? new Date(reg.Event_date).toLocaleDateString() : 'TBA',
                venue: reg.Venue_name || 'TBA',
                time: `${startTime} - ${endTime}`,
                isTeam: reg.isSolo === 'No',
                teamName: reg.Team_Name || null,
                teamId: reg.Team_id || null
            };
        });

        return res.json(registrations);
    });
});

// Cancel registration
app.delete('/api/cancel-registration/:id', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'User not logged in' });
    }

    const participantId = req.params.id;
    const userId = req.session.user.id;

    // Verify that this registration belongs to the user
    db.query(
        'SELECT * FROM Participant WHERE participant_id = ? AND user_id = ?',
        [participantId, userId],
        (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }

            if (results.length === 0) {
                return res.status(403).json({ error: 'Not authorized to cancel this registration' });
            }

            const participant = results[0];

            // Delete participation record if team leader
            if (participant.Team_id) {
                // Check if user is the only team member (team leader)
                db.query(
                    'SELECT COUNT(*) as memberCount FROM Participant WHERE Team_id = ?',
                    [participant.Team_id],
                    (err, teamResults) => {
                        if (err) {
                            console.error('Database error:', err);
                            // Continue anyway
                        } else if (teamResults[0].memberCount === 1) {
                            // Delete team participation
                            db.query(
                                'DELETE FROM Participation WHERE Team_id = ? AND event_id = ?',
                                [participant.Team_id, participant.event_id],
                                (err, result) => {
                                    if (err) {
                                        console.error('Database error:', err);
                                    }
                                }
                            );
                        }
                    }
                );
            }

            // Delete participant record
            db.query(
                'DELETE FROM Participant WHERE participant_id = ?',
                [participantId],
                (err, result) => {
                    if (err) {
                        console.error('Database error:', err);
                        return res.status(500).json({ error: 'Server error' });
                    }

                    return res.json({ message: 'Registration cancelled successfully' });
                }
            );
        }
    );
});

// delete event endpoint
app.delete('/api/admin/delete-event/:id', (req, res) => {
    // Check if user is logged in and is an admin
    if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(403).json({ error: 'Unauthorized access' });
    }

    const eventId = req.params.id;
    // console.log(`Attempting to delete event ID: ${eventId}`);

    // Begin a transaction to ensure data consistency
    db.beginTransaction(err => {
        if (err) {
            console.error('Error starting transaction:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        // 1. First delete any judge associations
        db.query('DELETE FROM Judge WHERE event_id = ?', [eventId], (err) => {
            if (err) {
                console.error('Error deleting judges:', err);
                return db.rollback(() => {
                    res.status(500).json({ error: 'Error deleting judges for event' });
                });
            }

            // 2. Delete related payments
            db.query(
                `DELETE p FROM Payment p 
                JOIN Participant part ON p.user_id = part.user_id AND p.payment_of = 'Event' 
                WHERE part.event_id = ?`,
                [eventId],
                (err) => {
                    if (err) {
                        console.error('Error deleting payments:', err);
                        return db.rollback(() => {
                            res.status(500).json({ error: 'Error deleting event payments' });
                        });
                    }

                    // 3. Delete participation records
                    db.query(
                        'DELETE FROM Participation WHERE event_id = ?',
                        [eventId],
                        (err) => {
                            if (err) {
                                console.error('Error deleting participation records:', err);
                                return db.rollback(() => {
                                    res.status(500).json({ error: 'Error deleting event participation records' });
                                });
                            }

                            // 4. Get all team IDs related to this event (for cleanup)
                            db.query(
                                'SELECT DISTINCT Team_id FROM Participant WHERE event_id = ? AND Team_id IS NOT NULL',
                                [eventId],
                                (err, teamResults) => {
                                    if (err) {
                                        console.error('Error getting team IDs:', err);
                                        return db.rollback(() => {
                                            res.status(500).json({ error: 'Error processing teams' });
                                        });
                                    }

                                    // 5. Delete all participants for this event
                                    db.query(
                                        'DELETE FROM Participant WHERE event_id = ?',
                                        [eventId],
                                        (err) => {
                                            if (err) {
                                                console.error('Error deleting participants:', err);
                                                return db.rollback(() => {
                                                    res.status(500).json({ error: 'Error deleting event participants' });
                                                });
                                            }

                                            // 6. Delete orphaned team records (teams with no more participants)
                                            const teamIds = teamResults.map(t => t.Team_id);
                                            if (teamIds.length > 0) {
                                                const teamQuery = `DELETE t FROM Teams t 
                                                                  WHERE t.Team_id IN (?) 
                                                                  AND NOT EXISTS (SELECT 1 FROM Participant p WHERE p.Team_id = t.Team_id)`;

                                                db.query(
                                                    teamQuery,
                                                    [teamIds],
                                                    (err) => {
                                                        if (err) {
                                                            console.error('Error deleting orphaned teams:', err);
                                                            // Continue anyway, not critical
                                                        }

                                                        // 7. Finally, delete the event itself
                                                        deleteEventAndFinish();
                                                    }
                                                );
                                            } else {
                                                // No teams to clean up, proceed to delete the event
                                                deleteEventAndFinish();
                                            }
                                        }
                                    );
                                }
                            );
                        }
                    );
                }
            );
        });

        // Helper function to delete the event and complete the transaction
        function deleteEventAndFinish() {
            // First, get the handler_id for the event before deleting it
            db.query(
                'SELECT handler_id FROM Event WHERE event_id = ?',
                [eventId],
                (err, handlerResults) => {
                    if (err) {
                        console.error('Error getting handler ID:', err);
                        // Continue with deletion anyway
                        proceedWithEventDeletion();
                        return;
                    }

                    let handlerId = null;
                    if (handlerResults && handlerResults.length > 0 && handlerResults[0].handler_id) {
                        handlerId = handlerResults[0].handler_id;
                    }

                    proceedWithEventDeletion(handlerId);
                }
            );

            function proceedWithEventDeletion(handlerId) {
                // Delete the event
                db.query(
                    'DELETE FROM Event WHERE event_id = ?',
                    [eventId],
                    (err, result) => {
                        if (err) {
                            console.error('Error deleting event:', err);
                            return db.rollback(() => {
                                res.status(500).json({ error: 'Error deleting event: ' + err.message });
                            });
                        }

                        // If we have a handler ID, update its status to available
                        if (handlerId) {
                            db.query(
                                'UPDATE Event_Handler SET isAssigned = "No", event_name = NULL WHERE eventHandler_id = ?',
                                [handlerId],
                                (err) => {
                                    if (err) {
                                        console.error('Error resetting handler status:', err);
                                        // Continue with commit anyway, not critical
                                    }
                                    commitTransaction();
                                }
                            );
                        } else {
                            commitTransaction();
                        }
                    }
                );
            }

            function commitTransaction() {
                // Commit the transaction
                db.commit(err => {
                    if (err) {
                        console.error('Error committing transaction:', err);
                        return db.rollback(() => {
                            res.status(500).json({ error: 'Error finalizing event deletion' });
                        });
                    }

                    // Everything was successful
                    res.json({
                        success: true,
                        message: 'Event and all related records deleted successfully'
                    });
                });
            }
        }
    });
});

// Add endpoint to get eligible judges for an event (users who are not participants)
app.get('/api/admin/eligible-judges/:eventId', (req, res) => {
    if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const eventId = req.params.eventId;
    
    // Query to get all users who are not participants in this event
    const query = `
        SELECT u.* 
        FROM User u
        WHERE u.user_id NOT IN (
            SELECT p.user_id 
            FROM Participant p 
            WHERE p.event_id = ?
        )
        AND u.user_id NOT IN (
            SELECT j.user_id
            FROM Judge j
            WHERE j.event_id = ?
        )
        ORDER BY u.Name
    `;
    
    db.query(query, [eventId, eventId], (err, results) => {
        if (err) {
            console.error('Error getting eligible judges:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        return res.json(results);
    });
});

// Check if user is logged in and is a judge
app.get('/api/judge/auth-status', (req, res) => {
    if (!req.session.user) {
        return res.json({ isLoggedIn: false, isJudge: false });
    }

    // Check if this user is a judge
    const userId = req.session.user.id;
    
    db.query('SELECT judge_id FROM Judge WHERE user_id = ?', [userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        if (results.length === 0) {
            // User is not a judge
            return res.json({ isLoggedIn: true, isJudge: false });
        }
        
        // User is a judge
        return res.json({ 
            isLoggedIn: true, 
            isJudge: true,
            judgeId: results[0].judge_id,
            userId: userId,
            name: req.session.user.name,
            email: req.session.user.email
        });
    });
});

app.get('/api/judge/assigned-events/:judgeId', (req, res) => {
    // Verify user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not logged in' });
    }
    
    const judgeId = req.params.judgeId;
    
    // Query events assigned to this judge
    const query = `
        SELECT e.*, v.Venue_name 
        FROM Event e
        JOIN Judge j ON e.event_id = j.event_id
        LEFT JOIN Event_Schedule es ON e.Schedule_id = es.Schedule_id
        LEFT JOIN Venue v ON es.Venue_Id = v.Venue_Id
        WHERE j.judge_id = ?
        ORDER BY e.Event_date ASC
    `;
    
    db.query(query, [judgeId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        res.json(results);
    });
});

// Get participants for an event
app.get('/api/judge/participants/:eventId', (req, res) => {
    // Verify user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not logged in' });
    }
    
    const eventId = req.params.eventId;
    const userId = req.session.user.id;
    
    // First, verify this user is a judge for this event
    db.query(
        'SELECT judge_id FROM Judge WHERE user_id = ? AND event_id = ?',
        [userId, eventId],
        (err, judgeResults) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            if (judgeResults.length === 0) {
                return res.status(403).json({ error: 'You are not authorized to judge this event' });
            }
            
            const judgeId = judgeResults[0].judge_id;
            
            // Query all participants with their scores (if any)
            const query = `
                SELECT p.participant_id, p.user_id, p.Team_id, p.isSolo,
                       u.Name, u.email,
                       t.Team_Name,
                       s.score_value as score,
                       s.comments
                FROM Participant p
                JOIN User u ON p.user_id = u.user_id
                LEFT JOIN Teams t ON p.Team_id = t.Team_id
                LEFT JOIN Score s ON p.participant_id = s.participant_id AND s.judge_id = ?
                WHERE p.event_id = ?
                ORDER BY t.Team_Name, p.isSolo DESC, u.Name
            `;
            
            db.query(query, [judgeId, eventId], (err, results) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: 'Server error' });
                }
                
                res.json(results);
            });
        }
    );
});

// Submit a score for a participant
app.post('/api/judge/submit-score', (req, res) => {
    // Verify user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not logged in' });
    }
    
    const { participantId, judgeId, score, comments } = req.body;
    const userId = req.session.user.id;
    
    // Validate required fields
    if (!participantId || !judgeId || !score) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
    
    // Validate score range
    if (score < 0 || score > 100) {
        return res.status(400).json({ error: 'Score must be between 0 and 100' });
    }
    
    // Verify this user is the judge
    db.query(
        'SELECT * FROM Judge WHERE judge_id = ? AND user_id = ?',
        [judgeId, userId],
        (err, judgeResults) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            if (judgeResults.length === 0) {
                return res.status(403).json({ error: 'You are not authorized to submit scores for this event' });
            }
            
            // Check if a score already exists for this participant-judge combination
            db.query(
                'SELECT * FROM Score WHERE participant_id = ? AND judge_id = ?',
                [participantId, judgeId],
                (err, scoreResults) => {
                    if (err) {
                        console.error('Database error:', err);
                        return res.status(500).json({ error: 'Server error' });
                    }
                    
                    if (scoreResults.length > 0) {
                        // Update existing score
                        db.query(
                            'UPDATE Score SET score_value = ?, comments = ? WHERE participant_id = ? AND judge_id = ?',
                            [score, comments || null, participantId, judgeId],
                            (err, updateResult) => {
                                if (err) {
                                    console.error('Database error:', err);
                                    return res.status(500).json({ error: 'Server error' });
                                }
                                
                                res.json({ 
                                    success: true, 
                                    message: 'Score updated successfully',
                                    scoreId: scoreResults[0].score_id
                                });
                            }
                        );
                    } else {
                        // Insert new score
                        db.query(
                            'INSERT INTO Score (score_value, judge_id, participant_id, comments) VALUES (?, ?, ?, ?)',
                            [score, judgeId, participantId, comments || null],
                            (err, insertResult) => {
                                if (err) {
                                    console.error('Database error:', err);
                                    return res.status(500).json({ error: 'Server error' });
                                }
                                
                                res.json({ 
                                    success: true, 
                                    message: 'Score submitted successfully',
                                    scoreId: insertResult.insertId
                                });
                            }
                        );
                    }
                }
            );
        }
    );
});

// Get team members for a team
app.get('/api/team-members/:teamId', (req, res) => {
    // Verify user is logged in
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not logged in' });
    }
    
    const teamId = req.params.teamId;
    
    // Query all team members
    const query = `
        SELECT u.Name as name, u.email
        FROM Participant p
        JOIN User u ON p.user_id = u.user_id
        WHERE p.Team_id = ?
        ORDER BY p.participant_id
    `;
    
    db.query(query, [teamId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        res.json(results);
    });
});

// Add a route to access judge dashboard directly
app.get('/judge-dashboard.html', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login_signup.html');
    }
    
    // Check if user is a judge
    const userId = req.session.user.id;
    db.query('SELECT * FROM Judge WHERE user_id = ?', [userId], (err, results) => {
        if (err || results.length === 0) {
            // Not a judge, redirect to home
            return res.redirect('/');
        }
        
        // User is a judge, serve the dashboard page
        res.sendFile(path.join(__dirname, 'judge-dashboard.html'));
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});