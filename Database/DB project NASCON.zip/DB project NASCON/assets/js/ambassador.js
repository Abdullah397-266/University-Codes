// Smooth scrolling for anchor links
$(document).ready(function () {
    $('a[href^="#"]').on('click', function (e) {
        e.preventDefault();

        var target = this.hash;
        var $target = $(target);

        if ($target.length) {
            $('html, body').animate({
                'scrollTop': $target.offset().top - 76
            }, 800, 'swing');
        }
    });

    // Navbar color change on scroll
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.navbar').css('box-shadow', '0 2px 20px rgba(0, 0, 0, 0.1)');
        } else {
            $('.navbar').css('box-shadow', '0 2px 10px rgba(0, 0, 0, 0.1)');
        }
    });

    // Close navbar on click in mobile view
    $('.navbar-nav>li>a').on('click', function () {
        $('.navbar-collapse').collapse('hide');
    });

    // Fetch and display ambassadors
    function fetchAmbassadors() {
        fetch('/api/ambassadors')
            .then(response => response.json())
            .then(data => {
                // Use the specific ID to target the ambassadors table
                const ambassadorTableBody = document.querySelector('#ambassadors-table tbody');
                
                if (!ambassadorTableBody) {
                    console.error('Ambassador table not found in the DOM');
                    return;
                }
                
                ambassadorTableBody.innerHTML = ''; // Clear existing content
                
                if (data.length === 0) {
                    const noDataRow = document.createElement('tr');
                    noDataRow.innerHTML = '<td colspan="5" class="text-center">No ambassadors found</td>';
                    ambassadorTableBody.appendChild(noDataRow);
                    return;
                }
                
                data.forEach((ambassador, index) => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <th scope="row">${index + 1}</th>
                        <td>${ambassador.Name}</td>
                        <td>${ambassador.email}</td>
                        <td><span class="referral-code">${ambassador.Referral_code}</span> 
                            <button class="copy-btn" data-code="${ambassador.Referral_code}">
                                <i class="bi bi-clipboard"></i>
                            </button>
                        </td>
                        <td>${ambassador.Institute}</td>
                    `;
                    ambassadorTableBody.appendChild(row);
                });
                
                // Add copy functionality
                document.querySelectorAll('.copy-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const code = this.getAttribute('data-code');
                        navigator.clipboard.writeText(code).then(() => {
                            const originalHTML = this.innerHTML;
                            this.innerHTML = '<i class="bi bi-check2"></i>';
                            this.classList.add('text-success');
                            
                            setTimeout(() => {
                                this.innerHTML = originalHTML;
                                this.classList.remove('text-success');
                            }, 1500);
                        });
                    });
                });
            })
            .catch(error => console.error('Error fetching ambassadors:', error));
    }

    // Fetch and display community members
    function fetchCommunityMembers() {
        fetch('/api/community-members')
            .then(response => response.json())
            .then(data => {
                // Use the specific ID to target the community partners table
                const communityTableBody = document.querySelector('#community-partners-table tbody');
                
                if (!communityTableBody) {
                    console.error('Community partners table not found in the DOM');
                    return;
                }
                
                communityTableBody.innerHTML = ''; // Clear existing content
                
                if (data.length === 0) {
                    const noDataRow = document.createElement('tr');
                    noDataRow.innerHTML = '<td colspan="5" class="text-center">No community partners found</td>';
                    communityTableBody.appendChild(noDataRow);
                    return;
                }
                
                data.forEach((partner, index) => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <th scope="row">${index + 1}</th>
                        <td>${partner.Name}</td>
                        <td>${partner.email}</td>
                        <td><span class="referral-code">${partner.Referral_code}</span> 
                            <button class="copy-btn" data-code="${partner.Referral_code}">
                                <i class="bi bi-clipboard"></i>
                            </button>
                        </td>
                        <td>${partner.Institute}</td>
                    `;
                    communityTableBody.appendChild(row);
                });
                
                // Add copy functionality
                document.querySelectorAll('.copy-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const code = this.getAttribute('data-code');
                        navigator.clipboard.writeText(code).then(() => {
                            const originalHTML = this.innerHTML;
                            this.innerHTML = '<i class="bi bi-check2"></i>';
                            this.classList.add('text-success');
                            
                            setTimeout(() => {
                                this.innerHTML = originalHTML;
                                this.classList.remove('text-success');
                            }, 1500);
                        }, () => {
                            console.error('Failed to copy referral code');
                        });
                    });
                });
            })
            .catch(error => console.error('Error fetching community partners:', error));
    }

    // Call the functions to load data
    fetchAmbassadors();
    fetchCommunityMembers();
});

document.addEventListener('DOMContentLoaded', function() {
    // Initialize particles.js
    if (document.getElementById('particles-js')) {
        particlesJS('particles-js', {
            particles: {
                number: {
                    value: 80,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: "#ffffff"
                },
                shape: {
                    type: "circle",
                    stroke: {
                        width: 0,
                        color: "#000000"
                    }
                },
                opacity: {
                    value: 0.5,
                    random: false,
                    anim: {
                        enable: false
                    }
                },
                size: {
                    value: 3,
                    random: true,
                    anim: {
                        enable: false
                    }
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: "#ffffff",
                    opacity: 0.4,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 3,
                    direction: "none",
                    random: false,
                    straight: false,
                    out_mode: "out",
                    bounce: false
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: {
                        enable: true,
                        mode: "repulse"
                    },
                    onclick: {
                        enable: true,
                        mode: "push"
                    },
                    resize: true
                },
                modes: {
                    repulse: {
                        distance: 100,
                        duration: 0.4
                    },
                    push: {
                        particles_nb: 4
                    }
                }
            },
            retina_detect: true
        });
    }
    
    // Existing code below...
    // Fetch and display ambassadors
    fetchAmbassadors();
    
    // Fetch and display community members
    fetchCommunityMembers();
});