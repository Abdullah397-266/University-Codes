const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

// Input validation functions
function validateName(name) {
    if (!name || name.trim() === '') {
        return { valid: false, message: 'Name is required' };
    }
    if (name.trim().length < 3) {
        return { valid: false, message: 'Name must be at least 3 characters long' };
    }
    if (!/^[A-Za-z\s]+$/.test(name)) {
        return { valid: false, message: 'Name should contain only letters and spaces' };
    }
    return { valid: true };
}

function validatePhone(phone) {
    if (!phone || phone.trim() === '') {
        return { valid: false, message: 'Phone number is required' };
    }
    if (!/^03\d{9}$/.test(phone)) {
        return { valid: false, message: 'Enter a valid Pakistani mobile number (e.g., 03211234567)' };
    }
    return { valid: true };
}

function validateEmail(email) {
    if (!email || email.trim() === '') {
        return { valid: false, message: 'Email is required' };
    }
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailRegex.test(email)) {
        return { valid: false, message: 'Please enter a valid email address' };
    }
    return { valid: true };
}

function validatePassword(password) {
    if (!password || password === '') {
        return { valid: false, message: 'Password is required' };
    }
    if (password.length < 8) {
        return { valid: false, message: 'Password must be at least 8 characters' };
    }
    if (!/[A-Z]/.test(password)) {
        return { valid: false, message: 'Password must contain at least one uppercase letter' };
    }
    if (!/[a-z]/.test(password)) {
        return { valid: false, message: 'Password must contain at least one lowercase letter' };
    }
    if (!/[0-9]/.test(password)) {
        return { valid: false, message: 'Password must contain at least one number' };
    }
    return { valid: true };
}

// Helper functions for displaying validation errors
function showValidationError(inputElement, message) {
    // Remove any existing error message
    removeValidationError(inputElement);
    
    // Add error class to input
    inputElement.classList.add('error-input');
    
    // Create and append error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'validation-error';
    errorDiv.textContent = message;
    inputElement.parentNode.appendChild(errorDiv);
}

function removeValidationError(inputElement) {
    // Remove error class
    inputElement.classList.remove('error-input');
    
    // Remove any existing error message
    const existingError = inputElement.parentNode.querySelector('.validation-error');
    if (existingError) {
        existingError.remove();
    }
}

// Add real-time validation to input fields
document.addEventListener('DOMContentLoaded', function() {
    const signupForm = document.querySelector('.sign-up form');
    
    const nameInput = signupForm.querySelector('input[placeholder="Name"]');
    const phoneInput = signupForm.querySelector('input[placeholder="Phone-No e.g.,(03211234567)"]');
    const emailInput = signupForm.querySelector('input[placeholder="Email"]');
    const passwordInput = signupForm.querySelector('input[placeholder="Password"]');
    
    // Add event listeners for real-time validation
    nameInput.addEventListener('blur', function() {
        const result = validateName(this.value);
        if (!result.valid) {
            showValidationError(this, result.message);
        } else {
            removeValidationError(this);
        }
    });
    
    phoneInput.addEventListener('blur', function() {
        const result = validatePhone(this.value);
        if (!result.valid) {
            showValidationError(this, result.message);
        } else {
            removeValidationError(this);
        }
    });
    
    emailInput.addEventListener('blur', function() {
        const result = validateEmail(this.value);
        if (!result.valid) {
            showValidationError(this, result.message);
        } else {
            removeValidationError(this);
        }
    });
    
    passwordInput.addEventListener('blur', function() {
        const result = validatePassword(this.value);
        if (!result.valid) {
            showValidationError(this, result.message);
        } else {
            removeValidationError(this);
        }
    });
});

// Form submission for sign up with validation
document.querySelector('.sign-up form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const nameInput = this.querySelector('input[placeholder="Name"]');
    const phoneInput = this.querySelector('input[placeholder="Phone-No e.g.,(03211234567)"]');
    const emailInput = this.querySelector('input[placeholder="Email"]');
    const passwordInput = this.querySelector('input[placeholder="Password"]');
    
    // Validate all fields
    const nameResult = validateName(nameInput.value);
    const phoneResult = validatePhone(phoneInput.value);
    const emailResult = validateEmail(emailInput.value);
    const passwordResult = validatePassword(passwordInput.value);
    
    // Clear all previous errors
    removeValidationError(nameInput);
    removeValidationError(phoneInput);
    removeValidationError(emailInput);
    removeValidationError(passwordInput);
    
    // Check for validation errors
    let hasErrors = false;
    
    if (!nameResult.valid) {
        showValidationError(nameInput, nameResult.message);
        hasErrors = true;
    }
    
    if (!phoneResult.valid) {
        showValidationError(phoneInput, phoneResult.message);
        hasErrors = true;
    }
    
    if (!emailResult.valid) {
        showValidationError(emailInput, emailResult.message);
        hasErrors = true;
    }
    
    if (!passwordResult.valid) {
        showValidationError(passwordInput, passwordResult.message);
        hasErrors = true;
    }
    
    if (hasErrors) {
        return; // Don't submit if there are validation errors
    }
    
    // If validation passes, proceed with form submission
    const submitButton = this.querySelector('button');
    const originalButtonText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Signing Up...';
    
    // Get the values before submission
    const emailValue = emailInput.value;
    const passwordValue = passwordInput.value;
    
    fetch('/api/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: nameInput.value,
            phone: phoneInput.value,
            email: emailValue,
            password: passwordValue
        })
    })
    .then(response => response.json())
    .then(data => {
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
        
        if (data.error) {
            if (data.error.includes('Email already registered')) {
                showValidationError(emailInput, 'This email is already registered');
            } else {
                alert('Error: ' + data.error);
            }
        } else {
            // Registration successful
            alert('Registration successful! You can now log in with your credentials.');
            
            // Switch to login form
            container.classList.remove("active");
            
            // Fill in the login form with the registered credentials
            const loginEmailInput = document.querySelector('.sign-in form input[placeholder="Email"]');
            const loginPasswordInput = document.querySelector('.sign-in form input[placeholder="Password"]');
            
            if (loginEmailInput && loginPasswordInput) {
                loginEmailInput.value = emailValue;
                loginPasswordInput.value = passwordValue;
                
                // Optional: Add a visual indicator that fields were auto-filled
                loginEmailInput.style.backgroundColor = '#e6f7e9';
                loginPasswordInput.style.backgroundColor = '#e6f7e9';
                
                // Reset the visual indicator after a delay
                setTimeout(() => {
                    loginEmailInput.style.backgroundColor = '';
                    loginPasswordInput.style.backgroundColor = '';
                }, 2000);
            }
            
            // Reset the sign up form
            this.reset();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
    });
});

// Form submission for sign in
document.querySelector('.sign-in form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const emailInput = this.querySelector('input[placeholder="Email"]');
    const passwordInput = this.querySelector('input[placeholder="Password"]');
    
    // Simple validation for login
    if (!emailInput.value.trim()) {
        showValidationError(emailInput, 'Email is required');
        return;
    } else {
        removeValidationError(emailInput);
    }
    
    if (!passwordInput.value) {
        showValidationError(passwordInput, 'Password is required');
        return;
    } else {
        removeValidationError(passwordInput);
    }
    
    const submitButton = this.querySelector('button');
    const originalButtonText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Signing In...';

    // First try admin login
    fetch('/api/admin/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
            email: emailInput.value, 
            password: passwordInput.value 
        })
    })
    .then(response => {
        if (response.ok) {
            return response.json().then(data => {
                // Admin login successful
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
                
                // Store user data in session storage
                sessionStorage.setItem('user', JSON.stringify({
                    name: data.user.name,
                    email: data.user.email,
                    isAdmin: true
                }));
                
                alert('Admin login successful! Welcome, ' + data.user.name);
                // Redirect to admin panel
                window.location.href = '/admin-panel.html';
            });
        } else {
            // If not an admin, try regular user login
            return fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    email: emailInput.value, 
                    password: passwordInput.value 
                })
            })
            .then(userResponse => userResponse.json())
            .then(userData => {
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
                
                if (userData.error) {
                    alert('Error: ' + userData.error);
                } else {
                    // Store user data in session storage
                    sessionStorage.setItem('user', JSON.stringify({
                        id: userData.user.id,
                        name: userData.user.name,
                        email: userData.user.email,
                        isAdmin: userData.user.isAdmin || false,
                        isJudge: userData.user.isJudge || false
                    }));
                    
                    alert('Login successful! Welcome, ' + userData.user.name);
                    // Redirect to home page
                    window.location.href = '/';
                }
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
    });
});

// After successful login:
sessionStorage.setItem('user', JSON.stringify({
    name: userData.user.name,
    email: userData.user.email,
    isAdmin: false
}));