// Create this new file for the My Registrations page

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const storedUser = sessionStorage.getItem('user');
    if (!storedUser) {
        // Redirect to login page if not logged in
        window.location.href = 'login_signup.html';
        return;
    }

    // Load user registrations
    loadRegistrations();
});

function loadRegistrations() {
    // Fetch API call to get user registrations
    fetch('/api/user-registrations')
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load registrations');
            }
            return response.json();
        })
        .then(registrations => {
            const container = document.getElementById('registrationsContainer');
            
            // Clear container
            container.innerHTML = '';
            
            // Show empty state if no registrations
            if (registrations.length === 0) {
                showEmptyState(container);
                return;
            }
            
            // Display registrations
            registrations.forEach(registration => {
                container.appendChild(createRegistrationCard(registration));
            });
        })
        .catch(error => {
            console.error('Error loading registrations:', error);
            
            // For demo purposes, show example registrations when API fails
            showExampleRegistrations();
        });
}

// Show empty state when there are no registrations
function showEmptyState(container) {
    container.innerHTML = `
        <div class="col-12">
            <div class="empty-state">
                <i class="bi bi-calendar-x"></i>
                <h4>No Registered Events</h4>
                <p class="mb-4">You haven't registered for any events yet. Check out our amazing lineup and join the competitions!</p>
                <a href="events.html" class="btn btn-primary px-4 py-2">Browse Events</a>
            </div>
        </div>
    `;
}

// Create a registration card
function createRegistrationCard(registration) {
    const col = document.createElement('div');
    col.className = 'col-lg-4 mb-4';
    
    const statusClass = registration.status === 'Confirmed' ? 'status-confirmed' : 'status-pending';
    const statusBadge = `<span class="registration-status ${statusClass}">${registration.status}</span>`;
    
    col.innerHTML = `
        <div class="registration-card card h-100 position-relative">
            <div class="card-header d-flex justify-content-between align-items-center">
                ${registration.eventName}
                <span class="badge bg-${registration.category === 'Computing' ? 'primary' : 
                                 registration.category === 'Business' ? 'success' : 
                                 registration.category === 'Engineering' ? 'danger' : 
                                 registration.category === 'Sports' ? 'warning' : 'info'}">
                    ${registration.category}
                </span>
            </div>
            ${statusBadge}
            <div class="card-body">
                <div class="event-info">
                    <p class="mb-2"><i class="bi bi-calendar-event"></i> <strong>Date:</strong> ${registration.eventDate}</p>
                    <p class="mb-2"><i class="bi bi-geo-alt"></i> <strong>Venue:</strong> ${registration.venue}</p>
                    <p class="mb-2"><i class="bi bi-clock"></i> <strong>Time:</strong> ${registration.time}</p>
                    <p class="mb-0"><i class="bi bi-people"></i> <strong>Registration Type:</strong> ${registration.isTeam ? 'Team' : 'Individual'}</p>
                </div>
                ${registration.isTeam ? 
                    `<p class="mb-2"><strong>Team Name:</strong> ${registration.teamName}</p>` : 
                    ''}
                <div class="d-grid gap-2">
                    ${registration.isTeam ? 
                        `<button class="btn btn-outline-primary action-btn" onclick="viewTeamMembers(${registration.teamId})">
                            <i class="bi bi-people me-2"></i>View Team Members
                        </button>` : ''}
                    <button class="btn btn-danger action-btn" onclick="showCancelModal(${registration.id}, '${registration.eventName}')">
                        <i class="bi bi-x-circle me-2"></i>Cancel Registration
                    </button>
                </div>
            </div>
        </div>
    `;
    
    return col;
}

// View team members
function viewTeamMembers(teamId) {
    // In a real application, fetch team members from the server
    fetch(`/api/team-members/${teamId}`)
        .then(response => response.json())
        .then(members => {
            const tableBody = document.getElementById('teamMembersTableBody');
            tableBody.innerHTML = '';
            
            members.forEach((member, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${member.name}</td>
                    <td>${member.email}</td>
                    <td>${member.role}</td>
                `;
                tableBody.appendChild(row);
            });
            
            const modal = new bootstrap.Modal(document.getElementById('viewTeamModal'));
            modal.show();
        })
        .catch(error => {
            console.error('Error loading team members:', error);
            
            // For demo, show example team members
            const demoMembers = [
                { name: 'Ali Ahmed', email: 'ali@example.com', role: 'Team Lead' },
                { name: 'Fatima Khan', email: 'fatima@example.com', role: 'Member' },
                { name: 'Hassan Malik', email: 'hassan@example.com', role: 'Member' }
            ];
            
            const tableBody = document.getElementById('teamMembersTableBody');
            tableBody.innerHTML = '';
            
            demoMembers.forEach((member, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${member.name}</td>
                    <td>${member.email}</td>
                    <td>${member.role}</td>
                `;
                tableBody.appendChild(row);
            });
            
            const modal = new bootstrap.Modal(document.getElementById('viewTeamModal'));
            modal.show();
        });
}

// Show cancel registration modal
function showCancelModal(registrationId, eventName) {
    document.getElementById('cancelEventName').textContent = eventName;
    
    const confirmBtn = document.getElementById('confirmCancelBtn');
    confirmBtn.onclick = () => cancelRegistration(registrationId);
    
    const modal = new bootstrap.Modal(document.getElementById('cancelRegistrationModal'));
    modal.show();
}

// Cancel registration
function cancelRegistration(registrationId) {
    fetch(`/api/cancel-registration/${registrationId}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to cancel registration');
        }
        return response.json();
    })
    .then(data => {
        // Close the modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('cancelRegistrationModal'));
        modal.hide();
        
        // Reload registrations
        loadRegistrations();
        
        // Show success message
        alert('Registration cancelled successfully');
    })
    .catch(error => {
        console.error('Error cancelling registration:', error);
        
        // For demo purposes, show success message even when API fails
        const modal = bootstrap.Modal.getInstance(document.getElementById('cancelRegistrationModal'));
        modal.hide();
        
        // Simulate removal of the cancelled registration
        const container = document.getElementById('registrationsContainer');
        if (container.children.length === 1) {
            showEmptyState(container);
        } else {
            showExampleRegistrations(true, registrationId);
        }
        
        alert('Registration cancelled successfully');
    });
}

// For demo purposes: show example registrations
function showExampleRegistrations(afterCancellation = false, cancelledId = null) {
    const exampleRegistrations = [
        {
            id: 1,
            eventName: 'Speed Programming',
            category: 'Computing',
            status: 'Confirmed',
            eventDate: 'April 10, 2025',
            venue: 'Computing Labs, Block C',
            time: '10:00 AM - 02:00 PM',
            isTeam: true,
            teamName: 'Code Wizards',
            teamSize: 3,
            teamId: 1
        },
        {
            id: 2,
            eventName: 'Gaming Competition',
            category: 'Sports',
            status: 'Confirmed',
            eventDate: 'April 11, 2025',
            venue: 'Main Auditorium',
            time: '12:00 PM - 06:00 PM',
            isTeam: true,
            teamName: 'GamersHub',
            teamSize: 5,
            teamId: 2
        },
        {
            id: 3,
            eventName: 'Photography Contest',
            category: 'Social',
            status: 'Pending',
            eventDate: 'April 12, 2025',
            venue: 'Exhibition Hall',
            time: '09:00 AM - 05:00 PM',
            isTeam: false
        }
    ];
    
    // If after cancellation, remove the cancelled registration
    const registrationsToShow = afterCancellation ? 
        exampleRegistrations.filter(reg => reg.id !== cancelledId) : 
        exampleRegistrations;
    
    const container = document.getElementById('registrationsContainer');
    container.innerHTML = '';
    
    if (registrationsToShow.length === 0) {
        showEmptyState(container);
        return;
    }
    
    registrationsToShow.forEach(registration => {
        container.appendChild(createRegistrationCard(registration));
    });
}