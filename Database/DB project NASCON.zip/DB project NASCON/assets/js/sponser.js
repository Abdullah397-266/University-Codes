document.addEventListener('DOMContentLoaded', function() {
    // Initialize particles.js
    if (document.getElementById('particles-js')) {
        particlesJS('particles-js', {
            particles: {
                number: {
                    value: 80,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: "#ffffff"
                },
                shape: {
                    type: "circle",
                    stroke: {
                        width: 0,
                        color: "#000000"
                    }
                },
                opacity: {
                    value: 0.5,
                    random: false,
                    anim: {
                        enable: false
                    }
                },
                size: {
                    value: 3,
                    random: true,
                    anim: {
                        enable: false
                    }
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: "#ffffff",
                    opacity: 0.4,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 3,
                    direction: "none",
                    random: false,
                    straight: false,
                    out_mode: "out",
                    bounce: false
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: {
                        enable: true,
                        mode: "repulse"
                    },
                    onclick: {
                        enable: true,
                        mode: "push"
                    },
                    resize: true
                },
                modes: {
                    repulse: {
                        distance: 100,
                        duration: 0.4
                    },
                    push: {
                        particles_nb: 4
                    }
                }
            },
            retina_detect: true
        });
    }
    
    // Load sponsors from the database
    loadSponsors();
    
    // Form validation and submission
    const sponsorForm = document.getElementById('sponsorForm');
    if (sponsorForm) {
        sponsorForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Check if form is valid
            if (!sponsorForm.checkValidity()) {
                e.stopPropagation();
                sponsorForm.classList.add('was-validated');
                return;
            }
            
            // Get form data
            const formData = {
                name: document.getElementById('sponsorName').value,
                email: document.getElementById('sponsorEmail').value,
                company: document.getElementById('sponsorCompany').value,
                position: document.getElementById('sponsorPosition').value,
                phone: document.getElementById('sponsorPhone').value,
                sponsorship_id: document.getElementById('sponsorPackage').value,
                details: document.getElementById('sponsorDetails').value,
                isPaid: false
            };
            
            // Store form data in session storage for later use
            sessionStorage.setItem('sponsorData', JSON.stringify(formData));
            
            // Show payment confirmation modal
            const paymentModal = new bootstrap.Modal(document.getElementById('paymentConfirmModal'));
            paymentModal.show();
        });
    }
    
    // Pay Now button functionality
    const payNowBtn = document.getElementById('payNowBtn');
    if (payNowBtn) {
        payNowBtn.addEventListener('click', function() {
            // Show payment details form
            document.getElementById('payment-details').classList.remove('d-none');
            
            // Change button text
            this.textContent = 'Process Payment';
            
            // Change button action to process payment
            this.removeEventListener('click', arguments.callee);
            this.addEventListener('click', processPayment);
        });
    }
    
    // Process payment function
    function processPayment() {
        // Get payment details
        const cardNumber = document.getElementById('cardNumber').value;
        const expiryDate = document.getElementById('expiryDate').value;
        const cvv = document.getElementById('cvv').value;
        const cardholderName = document.getElementById('cardholderName').value;
        
        // Validate payment details
        if (!cardNumber || !expiryDate || !cvv || !cardholderName) {
            alert('Please fill in all payment details');
            return;
        }
        
        // Get sponsor data
        const sponsorData = JSON.parse(sessionStorage.getItem('sponsorData'));
        sponsorData.isPaid = true;
        
        // Submit sponsor data to server
        submitSponsorData(sponsorData, true);
        
        // Hide payment modal
        const paymentModal = bootstrap.Modal.getInstance(document.getElementById('paymentConfirmModal'));
        paymentModal.hide();
        
        // Show success modal
        setTimeout(() => {
            const successModal = new bootstrap.Modal(document.getElementById('paymentSuccessModal'));
            successModal.show();
        }, 500);
    }
    
    // Pay Later button functionality
    const payLaterBtn = document.getElementById('payLaterBtn');
    if (payLaterBtn) {
        payLaterBtn.addEventListener('click', function() {
            // Get sponsor data
            const sponsorData = JSON.parse(sessionStorage.getItem('sponsorData'));
            
            // Submit sponsor data to server
            submitSponsorData(sponsorData, false);
            
            // Hide payment modal
            const paymentModal = bootstrap.Modal.getInstance(document.getElementById('paymentConfirmModal'));
            paymentModal.hide();
            
            // Show alert
            alert('Thank you for your interest! Your sponsorship request has been saved. Our team will contact you regarding payment details.');
            
            // Reset form
            document.getElementById('sponsorForm').reset();
        });
    }
    
    // Function to submit sponsor data to the server
    function submitSponsorData(data, isPaid) {
        // Add payment status
        data.isPaid = isPaid;
        
        fetch('/api/sponsor-inquiry', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Sponsor data submitted successfully:', data);
            if (isPaid) {
                // Reset form if payment was successful
                document.getElementById('sponsorForm').reset();
            }
        })
        .catch(error => {
            console.error('Error submitting sponsor data:', error);
            alert('There was an error processing your request. Please try again later.');
        });
    }
    
    // Reset payment form when modal is closed
    const paymentConfirmModal = document.getElementById('paymentConfirmModal');
    if (paymentConfirmModal) {
        paymentConfirmModal.addEventListener('hidden.bs.modal', function() {
            document.getElementById('payment-details').classList.add('d-none');
            document.getElementById('payNowBtn').textContent = 'Pay Now';
            
            // Remove the processPayment event and add back the original event
            const payNowBtn = document.getElementById('payNowBtn');
            payNowBtn.removeEventListener('click', processPayment);
            payNowBtn.addEventListener('click', function() {
                document.getElementById('payment-details').classList.remove('d-none');
                this.textContent = 'Process Payment';
                this.removeEventListener('click', arguments.callee);
                this.addEventListener('click', processPayment);
            });
        });
    }
    
    // Function to load sponsors
    function loadSponsors() {
        // Load platinum sponsors
        fetch('/api/sponsors/platinum')
            .then(response => response.json())
            .then(sponsors => {
                displaySponsors('platinum', sponsors);
            })
            .catch(error => console.error('Error loading platinum sponsors:', error));
        
        // Load gold sponsors
        fetch('/api/sponsors/gold')
            .then(response => response.json())
            .then(sponsors => {
                displaySponsors('gold', sponsors);
            })
            .catch(error => console.error('Error loading gold sponsors:', error));
        
        // Load silver sponsors
        fetch('/api/sponsors/silver')
            .then(response => response.json())
            .then(sponsors => {
                displaySponsors('silver', sponsors);
            })
            .catch(error => console.error('Error loading silver sponsors:', error));
        
        // Load bronze sponsors
        fetch('/api/sponsors/bronze')
            .then(response => response.json())
            .then(sponsors => {
                displaySponsors('bronze', sponsors);
            })
            .catch(error => console.error('Error loading bronze sponsors:', error));
    }
    
    // Function to display sponsors in their respective sections
    function displaySponsors(tier, sponsors) {
        const sponsorContainer = document.querySelector(`.${tier}-sponsors .d-flex`);
        
        // Clear any existing content
        sponsorContainer.innerHTML = '';
        
        if (sponsors.length === 0) {
            sponsorContainer.innerHTML = '<p class="text-center w-100">No sponsors in this tier yet.</p>';
            return;
        }
        
        // Add each sponsor
        sponsors.forEach(sponsor => {
            const sponsorLogo = document.createElement('img');
            sponsorLogo.className = 'sponsor-logo';
            sponsorLogo.src = sponsor.img_path;
            sponsorLogo.alt = sponsor.company;
            sponsorLogo.title = sponsor.company;
            
            sponsorContainer.appendChild(sponsorLogo);
        });
    }
});