document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in and is a judge
    checkJudgeStatus();
    
    // Add event listeners
    setupEventListeners();
});

// Global variables
let currentJudgeId = null;
let currentEventId = null;

// Check if user is a judge
function checkJudgeStatus() {
    fetch('/api/judge/auth-status')
        .then(response => response.json())
        .then(data => {
            if (!data.isLoggedIn || !data.isJudge) {
                // Not logged in or not a judge, redirect to login
                showNotification('error', 'You must be logged in as a judge to access this page.');
                setTimeout(() => {
                    window.location.href = '/login_signup.html';
                }, 2000);
                return;
            }
            
            // User is a judge, save the judge ID
            currentJudgeId = data.judgeId;
            
            // Load assigned events
            loadAssignedEvents(currentJudgeId);
        })
        .catch(error => {
            console.error('Error checking judge status:', error);
            showNotification('error', 'Failed to verify judge status. Please try again.');
        });
}

// Load events assigned to this judge
function loadAssignedEvents(judgeId) {
    fetch(`/api/judge/assigned-events/${judgeId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load assigned events');
            }
            return response.json();
        })
        .then(events => {
            const eventsList = document.getElementById('assignedEventsList');
            
            // Clear loading indicator
            eventsList.innerHTML = '';
            
            if (events.length === 0) {
                // No events assigned
                eventsList.innerHTML = `
                    <li class="list-group-item text-center py-4">
                        <i class="bi bi-calendar-x text-muted mb-3" style="font-size: 2rem;"></i>
                        <h6>No Events Assigned</h6>
                        <p class="text-muted small mb-0">You haven't been assigned any events to judge yet.</p>
                    </li>
                `;
                return;
            }
            
            // Create list items for each assigned event
            events.forEach(event => {
                // Format event date
                const eventDate = new Date(event.Event_date);
                const formattedDate = eventDate.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Create the list item
                const listItem = document.createElement('li');
                listItem.className = 'event-list-item';
                listItem.dataset.eventId = event.event_id;
                listItem.innerHTML = `
                    <div class="event-name">${event.Event_name}</div>
                    <div class="event-date"><i class="bi bi-calendar-event me-1"></i>${formattedDate}</div>
                    <span class="badge event-badge bg-${getCategoryBadgeClass(event.category)}">${event.category}</span>
                `;
                
                // Add event listener to load event details when clicked
                listItem.addEventListener('click', function() {
                    // Set active class
                    document.querySelectorAll('.event-list-item').forEach(item => {
                        item.classList.remove('active');
                    });
                    this.classList.add('active');
                    
                    // Load event details and participants
                    loadEventDetails(event.event_id);
                });
                
                eventsList.appendChild(listItem);
            });
        })
        .catch(error => {
            console.error('Error loading assigned events:', error);
            
            const eventsList = document.getElementById('assignedEventsList');
            eventsList.innerHTML = `
                <li class="list-group-item text-center py-4">
                    <i class="bi bi-exclamation-triangle text-danger mb-3" style="font-size: 2rem;"></i>
                    <h6>Error Loading Events</h6>
                    <p class="text-muted small mb-0">Failed to load assigned events. Please refresh the page.</p>
                </li>
            `;
            
            showNotification('error', 'Failed to load assigned events.');
        });
}

// Load details for a specific event
function loadEventDetails(eventId) {
    // Save current event ID
    currentEventId = eventId;
    
    // Show loading UI
    document.getElementById('welcomeCard').classList.add('d-none');
    document.getElementById('eventDetailsSection').classList.remove('d-none');
    
    // Set initial loading state for participants table
    document.getElementById('participantsTableBody').innerHTML = `
        <tr>
            <td colspan="6" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading participants...</p>
            </td>
        </tr>
    `;
    
    // Fetch event details
    fetch(`/api/events/${eventId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load event details');
            }
            return response.json();
        })
        .then(event => {
            // Format date and time
            const eventDate = new Date(event.Event_date);
            const formattedDate = eventDate.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            
            let timeStr = 'Time not set';
            if (event.Start_time && event.End_time) {
                const startTime = new Date(event.Start_time).toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                const endTime = new Date(event.End_time).toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                timeStr = `${startTime} - ${endTime}`;
            }
            
            // Populate event details
            document.getElementById('eventTitle').textContent = event.Event_name;
            document.getElementById('eventCategory').textContent = event.category;
            document.getElementById('eventCategory').className = `badge bg-${getCategoryBadgeClass(event.category)}`;
            document.getElementById('eventDate').textContent = formattedDate;
            document.getElementById('eventVenue').textContent = event.Venue_name || 'Not assigned';
            document.getElementById('eventTime').textContent = timeStr;
            document.getElementById('eventDescription').textContent = event.description;
            
            // Format guidelines as HTML list
            let guidelinesHtml = '<ul class="guidelines-list">';
            if (event.guidelines) {
                const guidelineItems = event.guidelines.split('\n').filter(item => item.trim() !== '');
                guidelineItems.forEach(item => {
                    guidelinesHtml += `<li>${item}</li>`;
                });
            } else {
                guidelinesHtml += '<li>No specific guidelines provided.</li>';
            }
            guidelinesHtml += '</ul>';
            document.getElementById('eventGuidelines').innerHTML = guidelinesHtml;
            
            // Load participants
            loadEventParticipants(eventId);
        })
        .catch(error => {
            console.error('Error loading event details:', error);
            document.getElementById('eventDetailsSection').innerHTML = `
                <div class="alert alert-danger" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    Failed to load event details. Please try again.
                </div>
            `;
            showNotification('error', 'Failed to load event details.');
        });
}

// Load participants for a specific event
function loadEventParticipants(eventId) {
    fetch(`/api/judge/participants/${eventId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load participants');
            }
            return response.json();
        })
        .then(participants => {
            const tableBody = document.getElementById('participantsTableBody');
            
            // Update participant count
            document.getElementById('participantCount').textContent = participants.length;
            
            // Clear table
            tableBody.innerHTML = '';
            
            if (participants.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center py-4">
                            <i class="bi bi-people text-muted mb-3" style="font-size: 2rem;"></i>
                            <h6>No Participants</h6>
                            <p class="text-muted small mb-0">No participants have registered for this event yet.</p>
                        </td>
                    </tr>
                `;
                return;
            }
            
            // Create table rows for each participant
            participants.forEach((participant, index) => {
                const row = document.createElement('tr');
                
                // Create score badge
                let scoreBadge;
                if (participant.score === null) {
                    scoreBadge = '<span class="badge score-badge score-pending">Not Evaluated</span>';
                } else {
                    const scoreClass = getScoreBadgeClass(participant.score);
                    scoreBadge = `<span class="badge score-badge ${scoreClass}">${participant.score}</span>`;
                }
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${participant.Name}</td>
                    <td>${participant.isSolo === 'Yes' ? 
                        '<span class="badge bg-secondary">Individual</span>' : 
                        `<span class="badge bg-info">Team</span> 
                         <a href="#" class="ms-1 small view-team-link" data-team-id="${participant.Team_id}">
                            (${participant.Team_Name})
                         </a>`}
                    </td>
                    <td><span class="badge bg-success">Registered</span></td>
                    <td>${scoreBadge}</td>
                    <td>
                        <button class="btn btn-sm ${participant.score === null ? 'btn-primary' : 'btn-outline-primary'} evaluate-btn"
                                data-participant-id="${participant.participant_id}"
                                data-user-id="${participant.user_id}"
                                data-name="${participant.Name}"
                                data-team-id="${participant.Team_id || ''}"
                                data-team-name="${participant.Team_Name || ''}"
                                data-score="${participant.score || ''}"
                                data-comments="${participant.comments || ''}">
                            <i class="bi bi-pencil-square me-1"></i>
                            ${participant.score === null ? 'Evaluate' : 'Edit Score'}
                        </button>
                    </td>
                `;
                
                tableBody.appendChild(row);
            });
            
            // Add event listeners to evaluate buttons and team view links
            addParticipantRowListeners();
        })
        .catch(error => {
            console.error('Error loading participants:', error);
            
            const tableBody = document.getElementById('participantsTableBody');
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger py-4">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        Failed to load participants. Please try again.
                    </td>
                </tr>
            `;
            
            showNotification('error', 'Failed to load participants.');
        });
}

// Add event listeners to participant rows
function addParticipantRowListeners() {
    // Add event listeners to evaluate buttons
    document.querySelectorAll('.evaluate-btn').forEach(button => {
        button.addEventListener('click', function() {
            const participantId = this.dataset.participantId;
            const userId = this.dataset.userId;
            const name = this.dataset.name;
            const teamId = this.dataset.teamId;
            const teamName = this.dataset.teamName;
            const existingScore = this.dataset.score;
            const existingComments = this.dataset.comments;
            
            // Open evaluation modal
            openEvaluationModal(participantId, userId, name, teamId, teamName, existingScore, existingComments);
        });
    });
    
    // Add event listeners to view team links
    document.querySelectorAll('.view-team-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const teamId = this.dataset.teamId;
            viewTeamMembers(teamId);
        });
    });
}

// Open evaluation modal
function openEvaluationModal(participantId, userId, name, teamId, teamName, existingScore, existingComments) {
    // Set modal values
    document.getElementById('participantId').value = participantId;
    document.getElementById('userId').value = userId;
    document.getElementById('judgeId').value = currentJudgeId;
    document.getElementById('participantName').textContent = name;
    
    // Set team info if it's a team
    const teamInfoElement = document.getElementById('teamInfo');
    if (teamId && teamName) {
        teamInfoElement.innerHTML = `
            <strong>Team:</strong> ${teamName} 
            <button class="btn btn-sm btn-link p-0 ms-2" id="viewTeamBtn">View Members</button>
        `;
        teamInfoElement.classList.remove('d-none');
        
        // Add event listener to view team button
        document.getElementById('viewTeamBtn').addEventListener('click', function() {
            viewTeamMembers(teamId);
        });
    } else {
        teamInfoElement.classList.add('d-none');
    }
    
    // Set existing score and comments if any
    const scoreInput = document.getElementById('scoreValue');
    const scoreDisplay = document.getElementById('scoreDisplay');
    const commentsInput = document.getElementById('scoreComments');
    
    if (existingScore) {
        scoreInput.value = existingScore;
        scoreDisplay.textContent = existingScore;
    } else {
        scoreInput.value = 50;
        scoreDisplay.textContent = 50;
    }
    
    if (existingComments) {
        commentsInput.value = existingComments;
    } else {
        commentsInput.value = '';
    }
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('evaluationModal'));
    modal.show();
}

// View team members
function viewTeamMembers(teamId) {
    // Show loading state
    const tableBody = document.getElementById('teamMembersTableBody');
    tableBody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading team members...</p>
            </td>
        </tr>
    `;
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('teamMembersModal'));
    modal.show();
    
    // Fetch team members
    fetch(`/api/team-members/${teamId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load team members');
            }
            return response.json();
        })
        .then(members => {
            // Clear table
            tableBody.innerHTML = '';
            
            if (members.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center py-4">
                            <p>No team members found.</p>
                        </td>
                    </tr>
                `;
                return;
            }
            
            // Create table rows for each team member
            members.forEach((member, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${member.name}</td>
                    <td>${member.email}</td>
                    <td>${index === 0 ? '<span class="badge bg-primary">Team Lead</span>' : '<span class="badge bg-secondary">Member</span>'}</td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error loading team members:', error);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center text-danger py-4">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        Failed to load team members. Please try again.
                    </td>
                </tr>
            `;
        });
}

// Submit participant score
function submitScore() {
    // Get form values
    const participantId = document.getElementById('participantId').value;
    const userId = document.getElementById('userId').value;
    const judgeId = currentJudgeId;
    const scoreValue = document.getElementById('scoreValue').value;
    const comments = document.getElementById('scoreComments').value;
    
    // Validate score
    if (!scoreValue || scoreValue < 0 || scoreValue > 100) {
        showNotification('error', 'Please enter a valid score between 0 and 100.');
        return;
    }
    
    // Disable submit button and show loading
    const submitBtn = document.getElementById('submitScoreBtn');
    const originalBtnText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';
    
    // Prepare data for submission
    const scoreData = {
        participantId: participantId,
        userId: userId,
        judgeId: judgeId,
        score: scoreValue,
        comments: comments
    };
    
    // Send data to server
    fetch('/api/judge/submit-score', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(scoreData),
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Failed to submit score');
            });
        }
        return response.json();
    })
    .then(data => {
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('evaluationModal'));
        modal.hide();
        
        // Show success notification
        showNotification('success', 'Score submitted successfully!');
        
        // Reload participants to update scores
        loadEventParticipants(currentEventId);
    })
    .catch(error => {
        console.error('Error submitting score:', error);
        showNotification('error', error.message || 'Failed to submit score. Please try again.');
    })
    .finally(() => {
        // Restore button state
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
    });
}

// Setup event listeners
function setupEventListeners() {
    // Score range input listener
    const scoreInput = document.getElementById('scoreValue');
    const scoreDisplay = document.getElementById('scoreDisplay');
    
    scoreInput.addEventListener('input', function() {
        scoreDisplay.textContent = this.value;
    });
    
    // Submit score button
    document.getElementById('submitScoreBtn').addEventListener('click', submitScore);
}

// Helper function to get badge class based on category
function getCategoryBadgeClass(category) {
    switch(category) {
        case 'Computing':
            return 'primary';
        case 'Business':
            return 'success';
        case 'Engineering':
            return 'danger';
        case 'Sports':
            return 'warning';
        case 'Social':
            return 'info';
        default:
            return 'secondary';
    }
}

// Helper function to get badge class based on score
function getScoreBadgeClass(score) {
    if (score === null) return 'score-pending';
    
    if (score >= 80) return 'score-excellent';
    if (score >= 60) return 'score-good';
    if (score >= 40) return 'score-average';
    return 'score-poor';
}

// Show notification
function showNotification(type, message) {
    const container = document.getElementById('notificationContainer');
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="close-btn">&times;</span>
        ${type === 'success' ? '<i class="bi bi-check-circle me-2"></i>' : '<i class="bi bi-exclamation-circle me-2"></i>'}
        ${message}
    `;
    
    // Add to container
    container.appendChild(notification);
    
    // Add click event to close button
    notification.querySelector('.close-btn').addEventListener('click', function() {
        notification.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}