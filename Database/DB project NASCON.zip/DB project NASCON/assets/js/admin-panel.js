document.addEventListener('DOMContentLoaded', function() {
    // Check if user is admin
    checkAdmin();
    
    // Load events, venues, handlers and judges
    loadEvents();
    loadVenues();
    loadEventHandlers();
    loadJudges();
    
    // Event listeners for form submissions
    document.getElementById('saveEventBtn').addEventListener('click', saveEvent);
    document.getElementById('saveHandlerBtn').addEventListener('click', saveHandler);
    document.getElementById('assignJudgeBtn').addEventListener('click', assignJudge);
    
    // Logout button
    document.getElementById('logoutBtn').addEventListener('click', function() {
        fetch('/api/logout')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = '/login_signup.html';
                }
            });
    });
});

// Check if user is admin
function checkAdmin() {
    fetch('/api/auth-status')
        .then(response => response.json())
        .then(data => {
            if (!data.isLoggedIn || !data.isAdmin) {
                window.location.href = '/login_signup.html';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            window.location.href = '/login_signup.html';
        });
}

// Update the loadEvents function to add data-event-id to rows
function loadEvents() {
    fetch('/api/admin/events')
        .then(response => response.json())
        .then(events => {
            const eventsTableBody = document.getElementById('eventsTableBody');
            
            // Clear table
            eventsTableBody.innerHTML = '';
            
            if (events.length === 0) {
                eventsTableBody.innerHTML = `
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <div class="empty-state">
                                <i class="bi bi-calendar-x mb-3"></i>
                                <h5>No Events Available</h5>
                                <p class="text-muted">Add events by clicking the "Add Event" button above.</p>
                            </div>
                        </td>
                    </tr>
                `;
                return;
            }
            
            // Add events to table
            events.forEach(event => {
                const row = document.createElement('tr');
                row.setAttribute('data-event-id', event.event_id); // Add data attribute
                
                // Create category badge
                let categoryBadge;
                switch(event.category) {
                    case 'Computing':
                        categoryBadge = '<span class="badge bg-primary">Computing</span>';
                        break;
                    case 'Business':
                        categoryBadge = '<span class="badge bg-success">Business</span>';
                        break;
                    case 'Engineering':
                        categoryBadge = '<span class="badge bg-danger">Engineering</span>';
                        break;
                    case 'Sports':
                        categoryBadge = '<span class="badge bg-warning">Sports</span>';
                        break;
                    default:
                        categoryBadge = '<span class="badge bg-info">Other</span>';
                }
                
                row.innerHTML = `
                    <td>${event.event_id}</td>
                    <td>${event.Event_name}</td>
                    <td>${categoryBadge}</td>
                    <td>${event.Event_date ? new Date(event.Event_date).toLocaleDateString() : 'Not set'}</td>
                    <td>${event.venue_name || 'Not set'}</td>
                    <td>${event.handler_name || 'Not assigned'}</td>
                    <td>${event.judge_name || 'Not assigned'}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-danger me-1" onclick="deleteEvent(${event.event_id})">
                            <i class="bi bi-trash"></i>
                        </button>
                        ${event.judge_name ? '' : `<button class="btn btn-sm btn-outline-success" onclick="openAssignJudgeModal(${event.event_id})">
                            <i class="bi bi-person-plus"></i> Assign Judge
                        </button>`}
                    </td>
                `;
                
                eventsTableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error loading events:', error);
            
            const eventsTableBody = document.getElementById('eventsTableBody');
            eventsTableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger">
                        <i class="bi bi-exclamation-triangle me-2"></i>Error loading events. Please try again.
                    </td>
                </tr>
            `;
        });
}

// Load venues for dropdown
function loadVenues() {
    fetch('/api/admin/venues')
        .then(response => response.json())
        .then(venues => {
            const venueSelect = document.getElementById('venueSelect');
            venueSelect.innerHTML = '<option value="" selected disabled>Select a venue</option>';
            
            venues.forEach(venue => {
                const option = document.createElement('option');
                option.value = venue.Venue_Id;
                option.textContent = venue.Venue_name;
                venueSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading venues:', error);
        });
}

// Load event handlers for dropdown
function loadEventHandlers() {
    fetch('/api/admin/event-handlers')
        .then(response => response.json())
        .then(handlers => {
            const handlerSelect = document.getElementById('handlerSelect');
            handlerSelect.innerHTML = '<option value="" selected disabled>Select an event handler</option>';
            
            const handlersTableBody = document.getElementById('handlersTableBody');
            handlersTableBody.innerHTML = '';
            
            if (handlers.length === 0) {
                handlersTableBody.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="empty-state">
                                <i class="bi bi-person-x mb-3"></i>
                                <h5>No Event Handlers Available</h5>
                                <p class="text-muted">Add handlers by clicking the "Add New Handler" button above.</p>
                            </div>
                        </td>
                    </tr>
                `;
                return;
            }
            
            handlers.forEach(handler => {
                // Only add unassigned handlers to dropdown
                if (handler.isAssigned !== 'Yes') {
                    const option = document.createElement('option');
                    option.value = handler.eventHandler_id;
                    option.textContent = handler.name;
                    handlerSelect.appendChild(option);
                }
                
                // Add all handlers to the table
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${handler.eventHandler_id}</td>
                    <td>${handler.name}</td>
                    <td>
                        <span class="badge ${handler.isAssigned === 'Yes' ? 'bg-success' : 'bg-secondary'}">
                            ${handler.isAssigned === 'Yes' ? 'Assigned' : 'Available'}
                        </span>
                    </td>
                    <td>${handler.event_name || 'N/A'}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary me-1" onclick="editHandler(${handler.eventHandler_id})">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteHandler(${handler.eventHandler_id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                `;
                handlersTableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error loading event handlers:', error);
            
            const handlersTableBody = document.getElementById('handlersTableBody');
            handlersTableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center text-danger">
                        <i class="bi bi-exclamation-triangle me-2"></i>Error loading handlers. Please try again.
                    </td>
                </tr>
            `;
        });
}

// Load judges (users) for dropdown
function loadJudges() {
    fetch('/api/admin/judges')
        .then(response => response.json())
        .then(judges => {
            const judgeSelect = document.getElementById('judgeSelect');
            judgeSelect.innerHTML = '<option value="" selected disabled>Select a judge</option>';
            
            judges.forEach(judge => {
                const option = document.createElement('option');
                option.value = judge.user_id;
                option.textContent = judge.Name;
                judgeSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading judges:', error);
        });
}

// Save new event
function saveEvent() {
    const form = document.getElementById('addEventForm');
    
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const eventData = {
        eventName: document.getElementById('eventName').value,
        category: document.getElementById('eventCategory').value, // Add category
        description: document.getElementById('eventDescription').value,
        guidelines: document.getElementById('eventGuidelines').value,
        maxParticipants: document.getElementById('maxParticipants').value,
        registrationFee: document.getElementById('registrationFee').value,
        eventDate: document.getElementById('eventDate').value,
        venueId: document.getElementById('venueSelect').value,
        eventHandlerId: document.getElementById('handlerSelect').value,
        startTime: document.getElementById('startTime').value,
        endTime: document.getElementById('endTime').value
    };
    
    fetch('/api/admin/add-event', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(eventData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert('Event created successfully!');
            
            // Close modal and reset form
            const modal = bootstrap.Modal.getInstance(document.getElementById('addEventModal'));
            modal.hide();
            form.reset();
            
            // Reload events and handlers (as handler is now assigned)
            loadEvents();
            loadEventHandlers();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
}

// Save new event handler
function saveHandler() {
    const form = document.getElementById('addHandlerForm');
    
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const handlerData = {
        name: document.getElementById('handlerName').value
    };
    
    fetch('/api/admin/add-handler', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(handlerData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert('Event handler added successfully!');
            
            // Close modal and reset form
            const modal = bootstrap.Modal.getInstance(document.getElementById('addHandlerModal'));
            modal.hide();
            form.reset();
            
            // Reload handlers
            loadEventHandlers();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
}

// Open assign judge modal with filtered judges list
function openAssignJudgeModal(eventId) {
    document.getElementById('eventIdForJudge').value = eventId;
    
    // Show loading state in the modal body
    const modalBody = document.getElementById('assignJudgeForm').closest('.modal-body');
    const originalModalContent = modalBody.innerHTML;
    modalBody.innerHTML = `
        <div class="text-center my-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading judges...</span>
            </div>
            <p class="mt-2">Loading eligible judges...</p>
        </div>
    `;
    
    // Show the modal while loading
    const modal = new bootstrap.Modal(document.getElementById('assignJudgeModal'));
    modal.show();
    
    // Fetch eligible judges (non-participants) for this event
    fetch(`/api/admin/eligible-judges/${eventId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load judges');
            }
            return response.json();
        })
        .then(judges => {
            // Restore modal content
            modalBody.innerHTML = originalModalContent;
            
            // Get the select element
            const judgeSelect = document.getElementById('judgeSelect');
            judgeSelect.innerHTML = '<option value="" selected disabled>Select a judge</option>';
            
            // Check if there are any eligible judges
            if (judges.length === 0) {
                const option = document.createElement('option');
                option.disabled = true;
                option.textContent = 'No eligible judges available';
                judgeSelect.appendChild(option);
                
                // Disable the assign button
                document.getElementById('assignJudgeBtn').disabled = true;
            } else {
                // Add judges to dropdown
                judges.forEach(judge => {
                    const option = document.createElement('option');
                    option.value = judge.user_id;
                    option.textContent = judge.Name;
                    judgeSelect.appendChild(option);
                });
                
                // Enable the assign button
                document.getElementById('assignJudgeBtn').disabled = false;
            }
        })
        .catch(error => {
            console.error('Error loading judges:', error);
            modalBody.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    Error loading judges: ${error.message || 'Please try again'}
                </div>
                ${originalModalContent}
            `;
        });
}

// Assign judge to event
function assignJudge() {
    const form = document.getElementById('assignJudgeForm');
    
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    // Show loading state
    const assignButton = document.getElementById('assignJudgeBtn');
    const originalText = assignButton.innerHTML;
    assignButton.disabled = true;
    assignButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Assigning...';
    
    const judgeData = {
        userId: document.getElementById('judgeSelect').value,
        eventId: document.getElementById('eventIdForJudge').value
    };
    
    fetch('/api/admin/assign-judge', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(judgeData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Failed to assign judge');
            });
        }
        return response.json();
    })
    .then(data => {
        // Show success notification
        showNotification('success', 'Judge assigned successfully!');
        
        // Close modal and reset form
        const modal = bootstrap.Modal.getInstance(document.getElementById('assignJudgeModal'));
        modal.hide();
        form.reset();
        
        // Reload events
        loadEvents();
    })
    .catch(error => {
        console.error('Error:', error);
        // Show error notification
        showNotification('error', error.message || 'Failed to assign judge');
    })
    .finally(() => {
        // Restore button state
        assignButton.disabled = false;
        assignButton.innerHTML = originalText;
    });
}

// Update the existing deleteEvent function
function deleteEvent(eventId) {
    if (confirm('Are you sure you want to delete this event? This will also delete all registrations for this event.')) {
        // Show loading indicator
        const eventsTableBody = document.getElementById('eventsTableBody');
        const eventRow = document.querySelector(`tr[data-event-id="${eventId}"]`);
        
        if (eventRow) {
            const actionCell = eventRow.querySelector('td:last-child');
            if (actionCell) {
                const originalContent = actionCell.innerHTML;
                actionCell.innerHTML = '<div class="spinner-border spinner-border-sm text-danger" role="status"><span class="visually-hidden">Deleting...</span></div>';
                
                // Make API call to delete event
                fetch(`/api/admin/delete-event/${eventId}`, {
                    method: 'DELETE'
                })
                .then(response => {
                    if (!response.ok) {
                        return response.json().then(data => {
                            throw new Error(data.error || 'Failed to delete event');
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    // Show success message
                    showNotification('success', 'Event deleted successfully');
                    
                    // Animate row removal
                    eventRow.style.transition = 'opacity 0.5s, transform 0.5s';
                    eventRow.style.opacity = '0';
                    eventRow.style.transform = 'translateX(20px)';
                    
                    setTimeout(() => {
                        // Remove the row after animation
                        eventRow.remove();
                        
                        // Check if table is empty and show message if needed
                        if (eventsTableBody.children.length === 0) {
                            eventsTableBody.innerHTML = `
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="empty-state">
                                            <i class="bi bi-calendar-x mb-3"></i>
                                            <h5>No Events Available</h5>
                                            <p class="text-muted">Add events by clicking the "Add Event" button above.</p>
                                        </div>
                                    </td>
                                </tr>
                            `;
                        }
                        
                        // Also reload event handlers since their status may have changed
                        loadEventHandlers();
                    }, 500);
                })
                .catch(error => {
                    console.error('Error deleting event:', error);
                    
                    // Restore original content
                    actionCell.innerHTML = originalContent;
                    
                    // Show error message
                    showNotification('error', 'Failed to delete event. Please try again.');
                });
            }
        } else {
            // If row not found, just reload events
            loadEvents();
            loadEventHandlers();
        }
    }
}

// Add this utility function for showing notifications
function showNotification(type, message) {
    // Create notification container if it doesn't exist
    let notificationContainer = document.getElementById('notificationContainer');
    
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.id = 'notificationContainer';
        notificationContainer.style.position = 'fixed';
        notificationContainer.style.top = '20px';
        notificationContainer.style.right = '20px';
        notificationContainer.style.zIndex = '9999';
        document.body.appendChild(notificationContainer);
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
    notification.role = 'alert';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Delete handler (implement as needed)
function deleteHandler(handlerId) {
    if (confirm('Are you sure you want to delete this event handler?')) {
        fetch('/api/admin/delete-handler/' + handlerId, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error: ' + data.error);
            } else {
                alert('Handler deleted successfully!');
                loadEventHandlers();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    }
}