// Check for user auth status when page loads
document.addEventListener('DOMContentLoaded', function () {
  console.log('Auth-status.js loaded');

  // First check for user in session storage
  const storedUser = sessionStorage.getItem('user');
  if (storedUser) {
    try {
      const user = JSON.parse(storedUser);
      console.log('User found in session storage:', user);
      console.log('Is this user a judge?', user.isJudge);
      updateNavbarForUser(user);
    } catch (e) {
      console.error('Error parsing stored user data:', e);
      sessionStorage.removeItem('user');
    }
  } else {
    console.log('No user found in session storage');
  }

  // Also verify with server
  fetch('/api/auth-status')
    .then(response => response.json())
    .then(data => {
      console.log('Auth status from server:', data);
      console.log('Is this user a judge according to server?', data.isJudge);

      if (data.isLoggedIn) {
        // User is authenticated according to server
        const user = {
          name: data.user.name,
          email: data.user.email,
          isAdmin: data.isAdmin || false,
          isJudge: data.isJudge || false  // Make sure this is included
        };

        console.log('User object being stored:', user);

        // Update session storage
        sessionStorage.setItem('user', JSON.stringify(user));

        // Update UI
        updateNavbarForUser(user);
      } else {
        // User is not authenticated according to server
        sessionStorage.removeItem('user');
        updateNavbarForUser(null);
      }
    })
    .catch(error => {
      console.error('Error checking auth status:', error);
    });
});

// Function to update navbar based on login status
function updateNavbarForUser(user) {
  console.log('Updating navbar for user:', user);

  // Find the register button
  const registerBtn = document.querySelector('.navbar .btn-primary[href="login_signup.html"]');
  console.log('Register button found:', registerBtn);

  if (user) {
    // User is logged in - hide register button and show dropdown
    if (registerBtn) {
      const registerBtnParent = registerBtn.parentElement;
      if (registerBtnParent) {
        registerBtnParent.style.display = 'none';
        console.log('Register button hidden');
      }
    }

    // Check if dropdown already exists
    let userDropdown = document.getElementById('userDropdownContainer');

    if (!userDropdown) {
      // Create dropdown if it doesn't exist
      const navbarNav = document.querySelector('.navbar-nav');

      if (navbarNav) {
        // Create dropdown container
        const dropdownLi = document.createElement('li');
        dropdownLi.className = 'nav-item dropdown ms-2';
        dropdownLi.id = 'userDropdownContainer';

        // Check if user is a judge and add link to judge dashboard
        const judgeLink = user.isJudge === true ?
          `<li><a class="dropdown-item" href="judge-dashboard.html">
            <i class="bi bi-clipboard-check me-2"></i> Judge Dashboard 
              </a></li>` : '';

        console.log('Judge link:', judgeLink);

        // Create dropdown content
        dropdownLi.innerHTML = `
          <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" 
             data-bs-toggle="dropdown" aria-expanded="false">
            <div class="user-avatar me-2">
              <i class="bi bi-person-circle fs-5"></i>
            </div>
            <span>${user.name || 'User'}</span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
            <li><a class="dropdown-item" href="user-profile.html">
              <i class="bi bi-person me-2"></i> My Profile
            </a></li>
            <li><a class="dropdown-item" href="my-registrations.html">
              <i class="bi bi-calendar-check me-2"></i> My Registrations
            </a></li>
            ${judgeLink}
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#" id="logoutButton">
              <i class="bi bi-box-arrow-right me-2"></i> Logout
            </a></li>
          </ul>
        `;

        // Append dropdown to navbar
        navbarNav.appendChild(dropdownLi);
        console.log('User dropdown created');

        // Add logout functionality
        const logoutBtn = document.getElementById('logoutButton');
        if (logoutBtn) {
          logoutBtn.addEventListener('click', function (e) {
            e.preventDefault();
            logout();
          });
        }

        // Add dropdown styles
        addDropdownStyles();
      }
    } else {
      console.log('User dropdown already exists');
      userDropdown.style.display = 'block';
    }
  } else {
    // User is NOT logged in - show register button, remove dropdown
    if (registerBtn) {
      const registerBtnParent = registerBtn.parentElement;
      if (registerBtnParent) {
        registerBtnParent.style.display = '';
        console.log('Register button shown');
      }
    }

    // Remove user dropdown if it exists
    const userDropdown = document.getElementById('userDropdownContainer');
    if (userDropdown) {
      userDropdown.remove();
      console.log('User dropdown removed');
    }
  }
}

// Function to handle user logout
function logout() {
  fetch('/api/logout')
    .then(response => response.json())
    .then(data => {
      // Clear user data from session storage
      sessionStorage.removeItem('user');

      // Update navbar
      updateNavbarForUser(null);

      // Redirect to login page
      window.location.href = '/login_signup.html';
    })
    .catch(error => {
      console.error('Error logging out:', error);
    });
}

// Add dropdown styles to the page
function addDropdownStyles() {
  if (document.getElementById('user-dropdown-styles')) return;

  const style = document.createElement('style');
  style.id = 'user-dropdown-styles';
  style.textContent = `
    .user-avatar {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background-color: rgba(0, 171, 159, 0.1);
      color: var(--primary-color, #00ab9f);
    }
    
    .dropdown-menu {
      border: none;
      border-radius: 10px;
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
      padding: 0.5rem 0;
    }
    
    .dropdown-item {
      padding: 0.5rem 1.2rem;
      color: #495057;
      font-size: 0.9rem;
      transition: all 0.2s ease;
    }
    
    .dropdown-item:hover {
      background-color: rgba(0, 171, 159, 0.1);
      color: var(--primary-color, #00ab9f);
    }
    
    .dropdown-item i {
      color: var(--primary-color, #00ab9f);
      opacity: 0.8;
    }
    
    .dropdown-divider {
      border-top-color: #e9ecef;
      margin: 0.5rem 0;
    }
  `;
  document.head.appendChild(style);
}

