
document.addEventListener('DOMContentLoaded', function() {
    // Setup category tabs event handlers
    setupCategoryTabs();
    
    // Load all events with proper categorization
    loadEvents();
    
    // Setup event handlers
    setupEventHandlers();
});

// Set up category tabs functionality
function setupCategoryTabs() {
    const tabs = document.querySelectorAll('.category-tabs .tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Get target category
            const targetCategory = this.dataset.target;
            
            // Hide all event sections
            document.querySelectorAll('.event-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Show target section with animation
            const targetSection = document.getElementById(targetCategory);
            if (targetSection) {
                targetSection.classList.add('active');
                
                // Scroll to section with smooth animation
                targetSection.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Load all events with categories
function loadEvents() {
    fetch('/api/events')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.statusText);
            }
            return response.json();
        })
        .then(events => {
            // Group events by category
            const eventsByCategory = {
                "Computing": [],
                "Business": [],
                "Engineering": [],
                "Sports": [],
                "Social": []
            };
            
            // Store events for later use
            window.eventsData = events;
            
            // Sort events into their categories
            events.forEach(event => {
                if (eventsByCategory[event.category]) {
                    eventsByCategory[event.category].push(event);
                }
            });
            
            // Populate each category section
            for (const [category, categoryEvents] of Object.entries(eventsByCategory)) {
                const categorySection = document.getElementById(category.toLowerCase());
                if (!categorySection) continue;
                
                const eventsRow = categorySection.querySelector('.row');
                
                if (categoryEvents.length === 0) {
                    eventsRow.innerHTML = `
                        <div class="col-12 text-center py-5">
                            <p class="text-muted">No ${category} events available</p>
                        </div>
                    `;
                    continue;
                }
                
                let eventsHTML = '';
                categoryEvents.forEach(event => {
                    // Format event date if available
                    const eventDate = event.Event_date ? new Date(event.Event_date).toLocaleDateString() : 'TBA';
                    
                    // Get accent color for category
                    const accentColor = getCategoryAccentColor(event.category);
                    
                    eventsHTML += `
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card event-card h-100" data-category="${event.category.toLowerCase()}">
                                <div class="card-accent" style="background-color: ${accentColor};"></div>
                                <div class="card-body">
                                    <div class="category-tag">${event.category}</div>
                                    <h5 class="card-title">${event.Event_name}</h5>
                                    <p class="card-text text-truncate-3">${event.description}</p>
                                    <div class="event-details">
                                        <div class="event-detail">
                                            <i class="bi bi-calendar-event"></i>
                                            <span>${eventDate}</span>
                                        </div>
                                        <div class="event-detail">
                                            <i class="bi bi-geo-alt"></i>
                                            <span>${event.Venue_name || 'Venue TBA'}</span>
                                        </div>
                                        <div class="event-detail">
                                            <i class="bi bi-people"></i>
                                            <span>Max Participants: ${event.Max_participants}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-primary view-details" data-event-id="${event.event_id}">
                                        View Details
                                    </button>
                                    <div class="event-participants">
                                        <i class="bi bi-currency-dollar"></i>
                                        <span>Fee: Rs. ${event.Registration_Fee}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
                
                eventsRow.innerHTML = eventsHTML;
            }
            
            // Add event listeners for view details buttons
            document.querySelectorAll('.view-details').forEach(button => {
                button.addEventListener('click', function() {
                    const eventId = this.dataset.eventId;
                    showEventDetails(eventId);
                });
            });
        })
        .catch(error => {
            console.error('Error loading events:', error);
            
            // Show error message in each category
            document.querySelectorAll('.event-section').forEach(section => {
                const row = section.querySelector('.row');
                if (row) {
                    row.innerHTML = `
                        <div class="col-12 text-center py-5">
                            <div class="alert alert-danger">
                                <i class="bi bi-exclamation-triangle me-2"></i>
                                Error loading events. Please refresh the page.
                            </div>
                        </div>
                    `;
                }
            });
        });
}

// Get accent color based on category
function getCategoryAccentColor(category) {
    switch(category) {
        case 'Computing':
            return '#3498db';  // Blue
        case 'Business':
            return '#2ecc71';  // Green
        case 'Engineering':
            return '#e74c3c';  // Red
        case 'Sports':
            return '#f39c12';  // Orange
        case 'Social':
            return '#9b59b6';  // Purple
        default:
            return '#00ab9f';  // Default teal
    }
}

// helper function to get badge class based on category
function getCategoryBadgeClass(category) {
    switch(category) {
        case 'Computing':
            return 'primary';
        case 'Business':
            return 'success';
        case 'Engineering':
            return 'danger';
        case 'Sports':
            return 'warning';
        case 'Social':
            return 'info';
        default:
            return 'secondary';
    }
}

// Setup event handlers for modals and forms
function setupEventHandlers() {
    // Add team member button
    document.getElementById('addMemberBtn').addEventListener('click', function() {
        const teamMembersContainer = document.getElementById('teamMembersContainer');
        const memberCount = teamMembersContainer.querySelectorAll('.team-member').length + 1; // +1 because leader is not in .team-member
        
        if (memberCount >= 5) {
            alert('Maximum 5 team members allowed (including team leader)');
            return;
        }
        
        const newMember = document.createElement('div');
        newMember.className = 'team-member mb-3';
        newMember.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <label class="form-label">Member ${memberCount + 1}</label>
                    <input type="email" class="form-control" placeholder="Email address" required>
                </div>
                <div class="ms-2 mt-4">
                    <button type="button" class="btn btn-sm btn-outline-danger remove-member">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>
            </div>
        `;
        
        teamMembersContainer.appendChild(newMember);
        
        // Add remove button handler
        newMember.querySelector('.remove-member').addEventListener('click', function() {
            newMember.remove();
            // Renumber members
            const members = teamMembersContainer.querySelectorAll('.team-member');
            members.forEach((member, index) => {
                const label = member.querySelector('.form-label');
                if (label) {
                    label.textContent = `Member ${index + 2}`; // +2 because index starts at 0 and leader is 1
                }
            });
        });
    });
    
    // Team registration submit button
    document.getElementById('submitTeamRegistration').addEventListener('click', function() {
        const form = document.getElementById('teamRegistrationForm');
        
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        const eventId = document.getElementById('teamEventId').value;
        const teamName = document.getElementById('teamName').value;
        
        // Get team members emails
        const memberEmails = [];
        document.querySelectorAll('.team-member input[type="email"]').forEach(input => {
            if (input.value && input.value.trim() !== '') {
                memberEmails.push(input.value.trim());
            }
        });
        
        // Register team
        registerTeam(eventId, teamName, memberEmails);
    });
}

// Function to show event details
function showEventDetails(eventId) {
    fetch(`/api/events/${eventId}`)
        .then(response => response.json())
        .then(event => {
            // Store current event for registration
            window.currentEvent = event;
            
            const modal = new bootstrap.Modal(document.getElementById('eventDetailModal'));
            
            // Populate modal with event details (existing code)
            document.getElementById('eventModalTitle').textContent = event.Event_name;
            document.getElementById('eventModalDescription').textContent = event.description || 'No description available.';
            document.getElementById('eventModalDate').textContent = event.Event_date ? new Date(event.Event_date).toLocaleDateString() : 'TBA';
            document.getElementById('eventModalVenue').textContent = event.Venue_name || 'FAST-NU, Lahore Campus';
            document.getElementById('eventModalFee').textContent = `Rs. ${event.Registration_Fee}`;
            document.getElementById('eventModalMaxParticipants').textContent = event.Max_participants;
            
            // Add event rules from guidelines (existing code)
            const rulesList = document.getElementById('eventModalRules');
            rulesList.innerHTML = '';
            
            if (event.guidelines) {
                const guidelines = event.guidelines.split('\n').filter(line => line.trim() !== '');
                guidelines.forEach(guideline => {
                    const li = document.createElement('li');
                    li.textContent = guideline;
                    rulesList.appendChild(li);
                });
            } else {
                const li = document.createElement('li');
                li.textContent = 'No guidelines available.';
                rulesList.appendChild(li);
            }
            
            // Check if user is logged in
            const userLoggedIn = !!sessionStorage.getItem('user');
            
            // Show appropriate registration options
            const registrationOptions = document.getElementById('registrationOptions');
            const loginPrompt = document.getElementById('loginPrompt');
            const alreadyRegisteredMsg = document.getElementById('alreadyRegisteredMsg');
            
            // Hide all by default
            registrationOptions.classList.add('d-none');
            loginPrompt.classList.add('d-none');
            alreadyRegisteredMsg.classList.add('d-none');
            
            if (!userLoggedIn) {
                loginPrompt.classList.remove('d-none');
            } else {
                // Check if user is already registered
                checkEventRegistration(eventId)
                    .then(isRegistered => {
                        if (isRegistered) {
                            alreadyRegisteredMsg.classList.remove('d-none');
                        } else {
                            registrationOptions.classList.remove('d-none');
                            
                            // Determine if this is a solo or team event based on Max_participants
                            const isSoloEvent = event.Max_participants === 1;
                            
                            // Create registration options HTML
                            let registrationHTML = '';
                            
                            if (isSoloEvent) {
                                // Solo event - only show individual registration button
                                registrationHTML = `
                                    <h5>Registration Option</h5>
                                    <div class="d-grid gap-2 mt-3">
                                        <button id="registerIndividualBtn" class="btn btn-primary">
                                            <i class="bi bi-person me-2"></i>Register for this Event
                                        </button>
                                    </div>
                                `;
                            } else {
                                // Team event - show team registration button
                                registrationHTML = `
                                    <h5>Registration Option</h5>
                                    <div class="d-grid gap-2 mt-3">
                                        <button id="registerTeamBtn" class="btn btn-primary">
                                            <i class="bi bi-people me-2"></i>Register as Team
                                        </button>
                                    </div>
                                    <p class="text-muted small mt-2">
                                        <i class="bi bi-info-circle me-1"></i> 
                                        You'll register as team leader and can add up to ${event.Max_participants - 1} team members.
                                    </p>
                                `;
                            }
                            
                            // Set the HTML
                            registrationOptions.innerHTML = registrationHTML;
                            
                            // Add event listeners to the newly created buttons
                            if (isSoloEvent) {
                                document.getElementById('registerIndividualBtn').onclick = () => registerIndividual(eventId);
                            } else {
                                document.getElementById('registerTeamBtn').onclick = () => setupTeamRegistration(eventId, event.Max_participants);
                            }
                        }
                    });
            }
            
            modal.show();
        })
        .catch(error => {
            console.error('Error loading event details:', error);
            alert('Error loading event details. Please try again.');
        });
}

// Check if user is already registered for an event
function checkEventRegistration(eventId) {
    return new Promise((resolve, reject) => {
        const user = JSON.parse(sessionStorage.getItem('user'));
        if (!user) {
            resolve(false);
            return;
        }
        
        fetch(`/api/check-registration?eventId=${eventId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error checking registration status');
                }
                return response.json();
            })
            .then(data => {
                resolve(data.isRegistered);
            })
            .catch(error => {
                console.error('Error checking registration:', error);
                reject(error);
            });
    });
}

// Set up team registration modal
function setupTeamRegistration(eventId, maxMembers) {
    console.log("Setting up team registration for event ID:", eventId, "with max members:", maxMembers);
    
    // Create team registration form if it doesn't exist
    if (!document.getElementById('teamRegistrationForm')) {
        console.error("Team registration form not found");
        return;
    }
    
    // Reset form
    document.getElementById('teamRegistrationForm').reset();
    
    // Set event ID
    document.getElementById('teamEventId').value = eventId;
    
    // Clear existing team members except the first one
    const teamMembersContainer = document.getElementById('teamMembersContainer');
    teamMembersContainer.innerHTML = '';
    
    // Set team leader info (current user)
    const user = JSON.parse(sessionStorage.getItem('user'));
    if (!user) {
        console.error("User not found in session storage");
        return;
    }
    
    // Create team name input
    const teamNameDiv = document.createElement('div');
    teamNameDiv.className = 'mb-3';
    teamNameDiv.innerHTML = `
        <label for="teamName" class="form-label">Team Name</label>
        <input type="text" class="form-control" id="teamName" required>
    `;
    teamMembersContainer.appendChild(teamNameDiv);
    
    // Create team leader section
    const leaderDiv = document.createElement('div');
    leaderDiv.className = 'mb-4';
    leaderDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="flex-grow-1">
                <label class="form-label">Team Leader (You)</label>
                <div class="leader-info border rounded p-3 bg-light">
                    <div><strong>${user.name}</strong> (${user.email})</div>
                    <div class="mt-1 text-success">
                        <i class="bi bi-cash-coin me-1"></i>
                        <small>Team leader will pay the registration fee</small>
                    </div>
                </div>
            </div>
        </div>
    `;
    teamMembersContainer.appendChild(leaderDiv);
    
    // Create "Add Team Member" section
    const addMemberHeader = document.createElement('div');
    addMemberHeader.className = 'mb-3';
    addMemberHeader.innerHTML = `
        <label class="form-label d-flex justify-content-between align-items-center">
            <span>Team Members (${maxMembers > 2 ? 'up to ' + (maxMembers - 1) : '1'} required)</span>
            <small class="text-muted">Email addresses only</small>
        </label>
    `;
    teamMembersContainer.appendChild(addMemberHeader);
    
    // Add first member field by default
    const newMember = document.createElement('div');
    newMember.className = 'team-member mb-3';
    newMember.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="flex-grow-1">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" class="form-control" placeholder="Team member email" required>
                </div>
                <small class="text-muted">Member will receive a notification email</small>
            </div>
            <div class="ms-2 mt-1">
                <button type="button" class="btn btn-sm btn-outline-danger remove-member">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>
    `;
    teamMembersContainer.appendChild(newMember);
    
    // Add "Add Member" button
    const addBtnContainer = document.createElement('div');
    addBtnContainer.className = 'mb-3 d-flex justify-content-center';
    addBtnContainer.innerHTML = `
        <button type="button" id="addMemberBtn" class="btn btn-sm btn-outline-primary">
            <i class="bi bi-plus-circle me-1"></i> Add Another Member
        </button>
    `;
    teamMembersContainer.appendChild(addBtnContainer);
    
    // Add remove button handler for first member
    newMember.querySelector('.remove-member').addEventListener('click', function() {
        this.closest('.team-member').remove();
    });
    
    // Add event listener for the add member button
    const addMemberBtn = document.getElementById('addMemberBtn');
    if (addMemberBtn) {
        addMemberBtn.addEventListener('click', function() {
            addTeamMember(teamMembersContainer, addBtnContainer, maxMembers);
        });
    }
    
    // Add event listener for the registration submit button
    const submitBtn = document.getElementById('submitTeamRegistration');
    if (submitBtn) {
        submitBtn.addEventListener('click', function() {
            submitTeamRegistration(eventId);
        });
    }
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('teamRegistrationModal'));
    modal.show();
}

// Helper function to add a new team member
function addTeamMember(container, addBtnContainer, maxMembers) {
    const memberCount = document.querySelectorAll('.team-member').length;
    
    // Check if we've reached the max team size
    if (memberCount >= maxMembers - 1) {
        alert(`Maximum team size is ${maxMembers} members (including you as leader)`);
        return;
    }
    
    const newMember = document.createElement('div');
    newMember.className = 'team-member mb-3';
    newMember.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="flex-grow-1">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" class="form-control" placeholder="Team member email" required>
                </div>
                <small class="text-muted">Member will receive a notification email</small>
            </div>
            <div class="ms-2 mt-1">
                <button type="button" class="btn btn-sm btn-outline-danger remove-member">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        </div>
    `;
    
    // Insert before the add button container
    container.insertBefore(newMember, addBtnContainer);
    
    // Add remove button handler
    newMember.querySelector('.remove-member').addEventListener('click', function() {
        this.closest('.team-member').remove();
    });
}

// Function to handle team registration submission
function submitTeamRegistration(eventId) {
    const form = document.getElementById('teamRegistrationForm');
    
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const teamName = document.getElementById('teamName').value;
    
    // Get team members emails
    const memberEmails = [];
    document.querySelectorAll('.team-member input[type="email"]').forEach(input => {
        if (input.value && input.value.trim() !== '') {
            memberEmails.push(input.value.trim());
        }
    });
    
    // Register team
    registerTeam(eventId, teamName, memberEmails);
}

// Register team for an event
function registerTeam(eventId, teamName, memberEmails) {
    const user = JSON.parse(sessionStorage.getItem('user'));
    if (!user) {
        alert('You need to be logged in to register a team.');
        return;
    }
    
    // Validate team name
    if (!teamName || teamName.trim() === '') {
        alert('Please enter a team name.');
        return;
    }
    
    // Validate team members
    if (memberEmails.length === 0) {
        alert('Please add at least one team member.');
        return;
    }
    
    // Show loading state
    const submitBtn = document.getElementById('submitTeamRegistration');
    const originalBtnText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Registering...';
    
    // Send registration request
    fetch('/api/register-team', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            eventId: eventId,
            teamName: teamName,
            memberEmails: memberEmails
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Failed to register team');
            });
        }
        return response.json();
    })
    .then(data => {
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('teamRegistrationModal')).hide();
        
        // Show success message with info about team members
        alert(`Your team "${teamName}" has been successfully registered! Team members will be notified via email.`);
        
        // Redirect to my registrations
        window.location.href = 'my-registrations.html';
    })
    .catch(error => {
        console.error('Error registering team:', error);
        alert(error.message || 'Failed to register team. Please try again later.');
    })
    .finally(() => {
        // Reset button state
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
    });
}

// Register individual for an event
function registerIndividual(eventId) {
    const userJson = sessionStorage.getItem('user');
    if (!userJson) {
        alert('You need to be logged in to register.');
        window.location.href = 'login_signup.html';
        return;
    }
    
    // Confirm registration
    if (!confirm('Confirm registration for this event?')) {
        return;
    }
    
    // Send registration request
    fetch('/api/register-event', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            eventId: eventId,
            isSolo: true
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Registration failed');
            });
        }
        return response.json();
    })
    .then(data => {
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('eventDetailModal')).hide();
        
        // Show success message
        alert('You have successfully registered for this event!');
        
        // Redirect to my registrations
        window.location.href = 'my-registrations.html';
    })
    .catch(error => {
        console.error('Error registering:', error);
        alert(error.message || 'Failed to register. Please try again later.');
    });
}