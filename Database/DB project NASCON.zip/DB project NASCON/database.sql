drop database if exists project;

create database project;
use project;

-- Venue Table
CREATE TABLE Venue (
  Venue_Id INT PRIMARY KEY AUTO_INCREMENT,
  Venue_name VARCHAR(50) NOT NULL,
  Capacity INT NOT NULL,
  Location VARCHAR(100) NOT NULL
);

-- Event Schedule Table
CREATE TABLE Event_Schedule (
  Schedule_id INT PRIMARY KEY AUTO_INCREMENT,
  Start_time DATETIME NOT NULL,
  End_time DATETIME NOT NULL,
  Venue_Id INT NOT NULL,
  FOREIGN KEY (Venue_Id) REFERENCES Venue(Venue_Id)
);

-- Teams Table
CREATE TABLE Teams (
  Team_id INT PRIMARY KEY AUTO_INCREMENT,
  Team_Name VARCHAR(50) NOT NULL UNIQUE
);

-- Sponsorship Table
CREATE TABLE Sponsorship (
  sponsorship_id INT PRIMARY KEY AUTO_INCREMENT,
  Name VARCHAR(50) NOT NULL,
  amount DECIMAL(10, 2) NOT NULL
);

-- Sponsor Table
CREATE TABLE Sponsor (
  email VARCHAR(80) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  company VARCHAR(50) NOT NULL,
  position VARCHAR(50) NOT NULL,
  description VARCHAR(200),
  sponsorship_id INT NOT NULL,
  img_path varchar(255) NOT NULL,
  FOREIGN KEY (sponsorship_id) REFERENCES Sponsorship(sponsorship_id)
);

-- Create Sponsor_Inquiries table for "Pay Later" submissions
CREATE TABLE Sponsor_Inquiries (
  inquiry_id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(80) NOT NULL,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  company VARCHAR(100) NOT NULL,
  position VARCHAR(100),
  description TEXT,
  sponsorship_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sponsorship_id) REFERENCES Sponsorship(sponsorship_id)
);

-- Ambassador Table
CREATE TABLE Ambassador (
  id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(80) UNIQUE NOT NULL,
  Referral_code VARCHAR(10) UNIQUE NOT NULL,
  Institute VARCHAR(50) NOT NULL,
  Name VARCHAR(50) NOT NULL
);

-- Community Member Table
CREATE TABLE Community_Member (
  Name VARCHAR(50) NOT NULL,
  email VARCHAR(80) UNIQUE NOT NULL,
  id INT PRIMARY KEY AUTO_INCREMENT,
  Referral_code VARCHAR(10) UNIQUE NOT NULL,
  Institute VARCHAR(50) NOT NULL
);

-- Event Handler Table
CREATE TABLE Event_Handler (
  eventHandler_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  isAssigned ENUM('Yes', 'No') DEFAULT 'No' NOT NULL
);

-- Admin Table
CREATE TABLE Admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  email VARCHAR(80),
  password VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(15) NOT NULL
);

-- Event Table
CREATE TABLE Event (
  event_id INT PRIMARY KEY AUTO_INCREMENT,
  Event_name VARCHAR(100) NOT NULL,
  description VARCHAR(1000) NOT NULL,
  guidelines TEXT NOT NULL,
  Max_participants INT NOT NULL,
  Registration_Fee DECIMAL(10, 2) NOT NULL,
  Event_date DATE NOT NULL,
  Schedule_id INT NOT NULL,
  eventHandler_id INT NOT NULL,
  category ENUM('Computing', 'Business', 'Engineering', 'Sports', 'Social') NOT NULL,
  FOREIGN KEY (Schedule_id) REFERENCES Event_Schedule(Schedule_id),
  FOREIGN KEY (eventHandler_id) REFERENCES Event_Handler(eventHandler_id)
);

-- User Table
CREATE TABLE User (
  user_id INT PRIMARY KEY AUTO_INCREMENT,
  Name VARCHAR(50) NOT NULL,
  email VARCHAR(80) UNIQUE NOT NULL,
  Phone VARCHAR(15) UNIQUE NOT NULL,
  Password VARCHAR(255) UNIQUE NOT NULL
);

-- Participant Table
CREATE TABLE Participant (
  participant_id INT PRIMARY KEY AUTO_INCREMENT,
  event_id INT NOT NULL,
  user_id INT NOT NULL,
  Team_id INT,
  isSolo ENUM('Yes', 'No') DEFAULT 'No',
  UNIQUE (event_id, user_id),
  FOREIGN KEY (event_id) REFERENCES Event(event_id),
  FOREIGN KEY (user_id) REFERENCES User(user_id),
  FOREIGN KEY (Team_id) REFERENCES Teams(Team_id)
);

-- Participation Table
CREATE TABLE Participation (
  event_id INT NOT NULL,
  Team_id INT NOT NULL,
  PRIMARY KEY (event_id, Team_id),
  FOREIGN KEY (event_id) REFERENCES Event(event_id),
  FOREIGN KEY (Team_id) REFERENCES Teams(Team_id)
);

-- Payment Table
CREATE TABLE Payment (
  payment_id INT PRIMARY KEY AUTO_INCREMENT,
  payment_of ENUM('Event', 'Sponsorship') NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_status ENUM('Pending', 'Completed', 'Failed') NOT NULL,
  user_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES User(user_id)
);

-- Judge Table
CREATE TABLE Judge (
  judge_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  event_id INT,
  FOREIGN KEY (user_id) REFERENCES User(user_id),
  FOREIGN KEY (event_id) REFERENCES Event(event_id)
);

-- Score Table
CREATE TABLE Score (
  score_id INT PRIMARY KEY AUTO_INCREMENT,
  score_value INT NOT NULL,
  judge_id INT NOT NULL,
  participant_id INT NOT NULL,
  comments TEXT,
  FOREIGN KEY (judge_id) REFERENCES Judge(judge_id),
  FOREIGN KEY (participant_id) REFERENCES Participant(participant_id)
);

-- Feedback Table
CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(50) NOT NULL,
    email VARCHAR(80) NOT NULL,
    subject VARCHAR(30) NOT NULL,
    message TEXT NOT NULL
);

DELIMITER //
CREATE TRIGGER check_event_capacity BEFORE INSERT ON Participant
FOR EACH ROW
BEGIN
    DECLARE current_participants INT;
    DECLARE max_participants INT;
    
    SELECT Max_participants INTO max_participants 
    FROM Event 
    WHERE event_id = NEW.event_id;
    
    SELECT COUNT(*) INTO current_participants 
    FROM Participant 
    WHERE event_id = NEW.event_id;
    
    IF current_participants >= max_participants THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Cannot register: Event has reached maximum capacity';
    END IF;
END//
DELIMITER ;

DELIMITER //
CREATE EVENT daily_participant_counter
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_DATE + INTERVAL 23 HOUR -- will rn at 11:00 PM
DO
BEGIN
	-- insert todayss statistics
    INSERT INTO Daily_Stats (stat_date, total_participants, solo_participants, team_participants)
    SELECT 
        CURRENT_DATE,
        COUNT(*),
        SUM(CASE WHEN isSolo = 'Yes' THEN 1 ELSE 0 END),
        SUM(CASE WHEN isSolo = 'No' THEN 1 ELSE 0 END)
    FROM 
        Participant;
END//
DELIMITER ;

INSERT INTO Admin (name, email, password, phone) VALUES
('admin1', 'admin1@gmail.com', 'admin1', '03001234561'),
('admin2', 'admin2@gmail.com', 'admin2', '03001234562'),
('admin3', 'admin3@gmail.com', 'admin3', '03001234563'),
('admin4', 'admin4@gmail.com', 'admin4', '03001234564'),
('admin5', 'admin5@gmail.com', 'admin5', '03001234565');

INSERT INTO User (Name, email, Phone, Password) VALUES ('User 1', 'user1@gmail.com', '03000000001', 'user1');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 2', 'user2@gmail.com', '03000000002', 'user2');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 3', 'user3@gmail.com', '03000000003', 'user3');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 4', 'user4@gmail.com', '03000000004', 'user4');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 5', 'user5@gmail.com', '03000000005', 'user5');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 6', 'user6@gmail.com', '03000000006', 'user6');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 7', 'user7@gmail.com', '03000000007', 'user7');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 8', 'user8@gmail.com', '03000000008', 'user8');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 9', 'user9@gmail.com', '03000000009', 'user9');
INSERT INTO User (Name, email, Phone, Password) VALUES ('User 10', 'user10@gmail.com', '03000000010', 'user10');


INSERT INTO Event_Handler (name, isAssigned) VALUES
('eventHandler1', 'No'),
('eventHandler2', 'No'),
('eventHandler3', 'No'),
('eventHandler4', 'No'),
('eventHandler5', 'No'),
('eventHandler6', 'No'),
('eventHandler7', 'No'),
('eventHandler8', 'No'),
('eventHandler9', 'No'),
('eventHandler10', 'No');

insert into sponsorship(Name, amount)
VALUES
('Platinum', 1000000),
('Gold', 500000),
('Silver', 250000),
('Bronze', 100000);

INSERT INTO Ambassador (email, Referral_code, Institute, Name) VALUES
('sara.khan@gmail.com', 'REFSK7890', 'FAST Lahore', 'Sara Khan'),
('ahmed.raza@yahoo.com', 'REFAR5621', 'NUST Islamabad', 'Ahmed Raza'),
('amna.malik@gmail.com', 'REFAM9823', 'LUMS', 'Amna Malik'),
('bilal.ahmad@hotmail.com', 'REFBA6612', 'UET Lahore', 'Bilal Ahmad'),
('hina.shah@gmail.com', 'REFHS3408', 'COMSATS Islamabad', 'Hina Shah'),
('zainab.farooq@outlook.com', 'REFZF1345', 'PU Lahore', 'Zainab Farooq'),
('hamza.abbasi@gmail.com', 'REFHA9087', 'GIKI', 'Hamza Abbasi'),
('maheen.iqbal@gmail.com', 'REFMI5620', 'IBA Karachi', 'Maheen Iqbal'),
('faisal.mughal@yahoo.com', 'REFFM7289', 'SZABIST Karachi', 'Faisal Mughal'),
('sadia.noor@hotmail.com', 'REFSN4421', 'FAST Karachi', 'Sadia Noor');

INSERT INTO Community_Member (Name, email, Referral_code, Institute) VALUES
  ('Tech Innovators', 'contact@techinnovators.pk', 'TECHIN25', 'Lahore'),
  ('CodeCrafters', 'info@codecrafters.org', 'CODE25', 'Karachi'),
  ('Hackathon Hub', 'team@hackathonhub.pk', 'HACK25', 'Islamabad'),
  ('AI Pakistan', 'connect@aipakistan.org', 'AIPK25', 'Multiple Cities'),
  ('Women in Tech PK', 'hello@womenintech.pk', 'WIT25', 'Nationwide');

INSERT INTO Venue (Venue_name, Capacity, Location) VALUES
('MEHRAN LAB 1', 40, 'Block A, First Floor, University Campus'),
('MEHRAN LAB 2', 40, 'Block A, First Floor, University Campus'),
('MEHRAN LAB 3', 40, 'Block A, Second Floor, University Campus'),
('MEHRAN LAB 4', 40, 'Block A, Second Floor, University Campus'),
('KARAKORAM LAB 1', 35, 'Block B, Ground Floor, University Campus'),
('KARAKORAM LAB 2', 35, 'Block B, Third Floor, University Campus'),
('KARAKORAM LAB 3', 35, 'Block B, Fourth Floor, University Campus'),
('KARAKORAM LAB 4', 35, 'Block B, Ground Floor, University Campus'),
('RAWAL LAB 1', 30, 'Block C, Room 101, University Campus'),
('RAWAL LAB 2', 30, 'Block C, Room 102, University Campus');

-- Platinum
INSERT INTO Sponsor (email, name, phone, company, position, description, sponsorship_id, img_path) VALUES 
('q@example.com', 'Q Sponsor', '0000000000', 'Q', 'Manager', 'Platinum level sponsor', 1, 'assets/Images/Platinum/Q.png'),
('zindagi@example.com', 'Zindagi Sponsor', '0000000001', 'zindagi', 'Manager', 'Platinum level sponsor', 1, 'assets/Images/Platinum/zindagi.png');

-- Gold
INSERT INTO Sponsor (email, name, phone, company, position, description, sponsorship_id, img_path) VALUES 
('bentley@example.com', 'Bentley Sponsor', '0000000002', 'Bentley', 'Manager', 'Gold level sponsor', 2, 'assets/Images/Gold/Bentley.png'),
('mrs@example.com', 'MRS Sponsor', '0000000003', 'MRS', 'Manager', 'Gold level sponsor', 2, 'assets/Images/Gold/MRS.png'),
('nescafe@example.com', 'Nescafe Sponsor', '0000000004', 'Nescafe', 'Manager', 'Gold level sponsor', 2, 'assets/Images/Gold/Nescafe.png'),
('nestle@example.com', 'Nestle Sponsor', '0000000005', 'Nestle', 'Manager', 'Gold level sponsor', 2, 'assets/Images/Gold/Nestle.png');

-- Silver
INSERT INTO Sponsor (email, name, phone, company, position, description, sponsorship_id, img_path) VALUES 
('folio3@example.com', 'Folio3 Sponsor', '0000000006', 'folio3', 'Manager', 'Silver level sponsor', 3, 'assets/Images/Silver/folio3.png'),
('foodpanda@example.com', 'Foodpanda Sponsor', '0000000007', 'Foodpanda', 'Manager', 'Silver level sponsor', 3, 'assets/Images/Silver/Foodpanda.png'),
('i3a@example.com', 'i3a Sponsor', '0000000008', 'i3a', 'Manager', 'Silver level sponsor', 3, 'assets/Images/Silver/i3a.png'),
('planetbeyond@example.com', 'PlanetBeyond Sponsor', '0000000009', 'planetBeyond', 'Manager', 'Silver level sponsor', 3, 'assets/Images/Silver/planetBeyond.png'),
('synergy@example.com', 'Synergy Sponsor', '0000000010', 'Synergy', 'Manager', 'Silver level sponsor', 3, 'assets/Images/Silver/Synergy.png');

-- Bronze
INSERT INTO Sponsor (email, name, phone, company, position, description, sponsorship_id, img_path) VALUES 
('boostbalm@example.com', 'BoostBalm Sponsor', '0000000011', 'boostBalm', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/boostBalm.png'),
('cleaning@example.com', 'Cleaning Sponsor', '0000000012', 'cleaning', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/cleaning.png'),
('darimooch@example.com', 'DariMooch Sponsor', '0000000013', 'dariMooch', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/dariMooch.png'),
('datayard@example.com', 'DataYard Sponsor', '0000000014', 'dataYard', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/dataYard.png'),
('fes@example.com', 'FES Sponsor', '0000000015', 'FES', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/FES.png'),
('gamelife@example.com', 'GameLife Sponsor', '0000000016', 'gamelife', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/gamelife.png'),
('glitch@example.com', 'Glitch Sponsor', '0000000017', 'glitch', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/glitch.png'),
('merik@example.com', 'Merik Sponsor', '0000000018', 'merik', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/merik.png'),
('msmsons@example.com', 'MSMSons Sponsor', '0000000019', 'MSMSons', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/MSMSons.png'),
('smartwrite@example.com', 'SmartWrite Sponsor', '0000000020', 'smartWrite', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/smartWrite.png'),
('tayto@example.com', 'Tayto Sponsor', '0000000021', 'tayto', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/tayto.png'),
('xenia@example.com', 'Xenia Sponsor', '0000000022', 'Xenia', 'Manager', 'Bronze level sponsor', 4, 'assets/Images/Bronze/Xenia.png');