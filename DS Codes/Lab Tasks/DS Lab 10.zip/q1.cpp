#include <iostream>
using namespace std;

class AVLTree
{
public:
    struct Node
    {
        int ID;
        Node *left;
        Node *right;
        int height;
        Node(int val) : ID(val), left(nullptr), right(nullptr), height(1) {}
    };

    Node *root;

    AVLTree() : root(nullptr) {}

    int getHeight(Node *node)
    {
        return (node ? node->height : 0);
    }

    int getBalance(Node *node)
    {
        return node ? getHeight(node->left) - getHeight(node->right) : 0;
    }

    void updateHeight(Node *node)
    {
        if (node)
        {
            node->height = 1 + max(getHeight(node->left), getHeight(node->right));
        }
    }

    Node *rotateRight(Node *k1)
    {
        Node *k2 = k1->left;
        Node *T2 = k2->right;

        k2->right = k1;
        k1->left = T2;

        updateHeight(k1);
        updateHeight(k2);

        return k2;
    }

    Node *rotateLeft(Node *k1)
    {
        Node *k2 = k1->right;
        Node *T2 = k2->left;

        k2->left = k1;
        k1->right = T2;

        updateHeight(k1);
        updateHeight(k2);

        return k2;
    }

    Node *insert(Node *node, int ID)
    {
        if (!node)
            return new Node(ID);

        if (ID < node->ID)
        {
            node->left = insert(node->left, ID);
        }
        else if (ID > node->ID)
        {
            node->right = insert(node->right, ID);
        }
        else
        {
            return node; // Duplicate
        }

        updateHeight(node);
        int balance = getBalance(node);

        if (balance > 1 && ID < node->left->ID)
        {
            return rotateRight(node);
        }

        if (balance < -1 && ID > node->right->ID)
        {
            return rotateLeft(node);
        }

        if (balance > 1 && ID > node->left->ID)
        {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }

        if (balance < -1 && ID < node->right->ID)
        {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }

        return node;
    }

    Node *getMinValueNode(Node *node)
    {
        Node *current = node;
        while (current->left)
            current = current->left;
        return current;
    }

    Node *deleteNode(Node *root, int ID)
    {
        if (!root)
            return root;

        if (ID < root->ID)
        {
            root->left = deleteNode(root->left, ID);
        }
        else if (ID > root->ID)
        {
            root->right = deleteNode(root->right, ID);
        }
        else
        {
            if (!root->left || !root->right)
            {
                Node *temp = root->left ? root->left : root->right;
                if (!temp)
                {
                    temp = root;
                    root = nullptr;
                }
                else
                {
                    *root = *temp;
                }
                delete temp;
            }
            else
            {
                Node *temp = getMinValueNode(root->right);
                root->ID = temp->ID;
                root->right = deleteNode(root->right, temp->ID);
            }
        }

        if (!root)
            return root;

        updateHeight(root);
        int balance = getBalance(root);

        if (balance > 1 && getBalance(root->left) >= 0)
        {
            return rotateRight(root);
        }

        if (balance > 1 && getBalance(root->left) < 0)
        {
            root->left = rotateLeft(root->left);
            return rotateRight(root);
        }

        if (balance < -1 && getBalance(root->right) <= 0)
        {
            return rotateLeft(root);
        }

        if (balance < -1 && getBalance(root->right) > 0)
        {
            root->right = rotateRight(root->right);
            return rotateLeft(root);
        }

        return root;
    }

    void preorder(Node *root)
    {
        if (root)
        {
            cout << root->ID << " ";
            preorder(root->left);
            preorder(root->right);
        }
    }

    void insert(int ID)
    {
        root = insert(root, ID);
    }

    void remove(int ID)
    {
        root = deleteNode(root, ID);
    }
};

int main()
{
    AVLTree avl;

    avl.insert(10);
    avl.insert(20);
    avl.insert(30);
    avl.insert(40);
    avl.insert(50);
    avl.insert(25);

    cout << "Preorder traversal: ";
    avl.preorder(avl.root);
    cout << endl;

    avl.remove(10);
    cout << "Preorder traversal after deleting 10: ";
    avl.preorder(avl.root);

    return 0;
}