#include <iostream>
#include <cstring>

using namespace std;

const int MAX_NODES = 12;        // A-L
const int MAX_SIZE = 100;        // Maximum size for stack/queue
int graph[MAX_NODES][MAX_NODES]; // adjacency matrix
char nodes[MAX_NODES] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'};
bool visited[MAX_NODES];

class Queue
{
private:
    int data[MAX_SIZE];
    int front, rear, size;

public:
    Queue() : front(0), rear(-1), size(0) {}

    void enqueue(int value)
    {
        if (size == MAX_SIZE)
        {
            cout << "Queue Overflow\n";
            return;
        }
        rear = (rear + 1) % MAX_SIZE;
        data[rear] = value;
        size++;
    }

    int dequeue()
    {
        if (size == 0)
        {
            cout << "Queue Underflow\n";
            return -1;
        }
        int value = data[front];
        front = (front + 1) % MAX_SIZE;
        size--;
        return value;
    }

    bool isEmpty()
    {
        return size == 0;
    }
};

class Stack
{
private:
    int data[MAX_SIZE];
    int top;

public:
    Stack() : top(-1) {}

    void push(int value)
    {
        if (top == MAX_SIZE - 1)
        {
            cout << "Stack Overflow\n";
            return;
        }
        data[++top] = value;
    }

    int pop()
    {
        if (top == -1)
        {
            cout << "Stack Underflow\n";
            return -1;
        }
        return data[top--];
    }

    bool isEmpty()
    {
        return top == -1;
    }
};

// Find the index of a node by its label
int findIndex(char node)
{
    for (int i = 0; i < MAX_NODES; i++)
    {
        if (nodes[i] == node)
            return i;
    }
    return -1; // Not found
}

void BFS(char start, char target)
{
    memset(visited, false, sizeof(visited)); // Initialize visited array to false
    int parent[MAX_NODES];
    memset(parent, -1, sizeof(parent));

    Queue q;
    int startIndex = findIndex(start);
    int targetIndex = findIndex(target);

    visited[startIndex] = true;
    q.enqueue(startIndex);

    while (!q.isEmpty())
    {
        int current = q.dequeue();

        if (current == targetIndex)
        {
            // Path found, print it
            int path[MAX_NODES], pathIndex = 0;
            while (current != -1)
            {
                path[pathIndex++] = current;
                current = parent[current];
            }

            cout << "BFS Path: ";
            for (int i = pathIndex - 1; i >= 0; i--)
                cout << nodes[path[i]] << " ";
            cout << endl;
            return;
        }

        for (int i = 0; i < MAX_NODES; i++)
        {
            if (graph[current][i] && !visited[i])
            {
                visited[i] = true;
                parent[i] = current;
                q.enqueue(i);
            }
        }
    }

    cout << "Path not found using BFS." << endl;
}

void DFS(char start, char target)
{
    memset(visited, false, sizeof(visited)); // Initialize visited array to false
    int parent[MAX_NODES];
    memset(parent, -1, sizeof(parent));

    Stack s;
    int startIndex = findIndex(start);
    int targetIndex = findIndex(target);

    visited[startIndex] = true;
    s.push(startIndex);

    while (!s.isEmpty())
    {
        int current = s.pop();

        if (current == targetIndex)
        {
            // Path found, print it
            int path[MAX_NODES], pathIndex = 0;
            while (current != -1)
            {
                path[pathIndex++] = current;
                current = parent[current];
            }

            cout << "DFS Path: ";
            for (int i = pathIndex - 1; i >= 0; i--)
                cout << nodes[path[i]] << " ";
            cout << endl;
            return;
        }

        for (int i = 0; i < MAX_NODES; i++)
        {
            if (graph[current][i] && !visited[i])
            {
                visited[i] = true;
                parent[i] = current;
                s.push(i);
            }
        }
    }

    cout << "Path not found using DFS." << endl;
}

int main()
{
    // Initialize adjacency matrix to 0
    memset(graph, 0, sizeof(graph));

    // Add edges
    graph[findIndex('A')][findIndex('B')] = 1;
    graph[findIndex('A')][findIndex('C')] = 1;
    graph[findIndex('B')][findIndex('D')] = 1;
    graph[findIndex('B')][findIndex('E')] = 1;
    graph[findIndex('C')][findIndex('F')] = 1;
    graph[findIndex('D')][findIndex('G')] = 1;
    graph[findIndex('E')][findIndex('H')] = 1;
    graph[findIndex('E')][findIndex('I')] = 1;
    graph[findIndex('F')][findIndex('J')] = 1;
    graph[findIndex('G')][findIndex('K')] = 1;
    graph[findIndex('G')][findIndex('L')] = 1;

    for (int i = 0; i < MAX_NODES; i++)
    {
        for (int j = 0; j < MAX_NODES; j++)
        {
            if (graph[i][j])
                graph[j][i] = 1;
        }
    }

    BFS('A', 'G');
    DFS('A', 'G');

    return 0;
}