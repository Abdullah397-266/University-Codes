#include <iostream>
using namespace std;

int main()
{
    int vertices = 8, edges = 7;
    int arr[7][2] = {{1, 2}, {2, 3}, {4, 5}, {1, 5}, {6, 1}, {7, 4}, {3, 8}};

    // initializing the graph
    int **graph = new int *[vertices];
    for (int i = 0; i < vertices; i++)
    {
        graph[i] = new int[vertices];

        for (int j = 0; j < vertices; j++)
        {
            graph[i][j] = 0;
        }
    }

    // adding the edges
    for (int i = 0; i < edges; i++)
    {
        int x = arr[i][0] - 1;
        int y = arr[i][1] - 1;

        graph[x][y] = 1;
        graph[y][x] = 1;
    }

    // printing the graph
    system("CLS");
    cout << "The graph is: " << endl;
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            cout << graph[i][j] << "   ";
        }
        cout << endl << endl;
    }

    // delete the graph
    for (int i = 0; i < vertices; i++)
    {
        delete[] graph[i];
    }
    delete[] graph;

    return 0;
}