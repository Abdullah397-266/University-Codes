#include <iostream>
using namespace std;

int main() 
{
    int vertices = 10, edges = 15;
    int arr[15][2] = {{0,1}, {0,6}, {0,8}, {1,4}, {1,6}, {1,9}, {2,4}, {2,6}, {3,4}, {3,5}, {3,8}, {4,5}, {4,9}, {7,8}, {7,9}}; // edges = 15

    // creating the adjacency matrix
    char **graph = new char *[vertices];
    for (int i = 0; i < vertices; i++)
    {
        graph[i] = new char[vertices];

        for (int j = 0; j < vertices; j++)
        {
            graph[i][j] = 'F';
        }
    }

    // adding the edges
    for (int i = 0; i < edges; i++)
    {
        int x = arr[i][0];
        int y = arr[i][1];

        graph[x][y] = 'T';
        graph[y][x] = 'T';
    }

    // printing the graph
    system("CLS");
    cout << "Assuming the graph is undirected, the graph is: " << endl;
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            cout << graph[i][j] << "   ";
        }
        cout << endl << endl;
    }

    int numOfEdges[10] = {0}; // vertices = 10
    for (int i = 0; i < edges; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            numOfEdges[arr[i][j]]++;
        }
    }

    cout << "The number of edges for each vertex (assuming the graph is undirected) is: " << endl;
    for (int i = 0; i < vertices; i++)
    {
        cout << "V" << i << ": " << numOfEdges[i] << endl;
    }

    // delete the graph
    for (int i = 0; i < vertices; i++)
    {
        delete[] graph[i];
    }
    delete[] graph;

    return 0;
}