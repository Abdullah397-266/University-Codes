#include <iostream>
using namespace std;

// create a list
class Node
{
public:
    int vertex;
    Node *next;

    Node(int vertex)
    {
        this->vertex = vertex;
        this->next = NULL;
    }
};

// create a adjacency list
class List
{
public:
    Node *head;
    Node *tail;
    int size;

    List()
    {
        head = NULL;
        tail = NULL;
        size = 0;
    }

    void addVertex(int vertex)
    {
        Node *newNode = new Node(vertex);

        if (head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    void printList()
    {
        Node *temp = head;

        while (temp != NULL)
        {
            cout << temp->vertex << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

int main()
{
    const int vertices = 5;

    List adjList[vertices];

    adjList[0].addVertex(1);
    adjList[0].addVertex(5);
    adjList[1].addVertex(0);
    adjList[3].addVertex(1);
    adjList[3].addVertex(2);
    adjList[3].addVertex(5);

    system("CLS");
    cout << "The adjacency list of 5 vertices (0-4) is: " << endl;
    cout << endl;
    for (int i = 0; i < vertices; i++)
    {
        cout << "V" << i << ": ";
        adjList[i].printList();
    }
    cout << endl;

    return 0;
}