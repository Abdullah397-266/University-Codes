#include <iostream>
#include <stack>

using namespace std;

class treeNode
{
public:
    char data;
    treeNode *left;
    treeNode *right;

    treeNode(char dta) : data(dta), left(nullptr), right(nullptr) {}
};

treeNode *makeTree(string exp);
void preOrder(treeNode *root);
void inOrder(treeNode *root);
void postOrder(treeNode *root);
int evaluate(string exp);

class Node
{
public:
    int data;
    Node *next;

    Node(int value) : data(value), next(nullptr) {}
};

class Stack
{
public:
    Node *topNode;

    Stack() : topNode(nullptr) {}

    ~Stack()
    {
        while (!isEmpty())
        {
            pop();
        }
    }

    void push(int value)
    {
        Node *newNode = new Node(value);
        newNode->next = topNode;
        topNode = newNode;
    }

    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack underflow. No elements to pop." << endl;
        }
        Node *tempNode = topNode;
        topNode = topNode->next;
        delete tempNode;
    }

    int top()
    {
        if (isEmpty())
        {
            cout << "Stack is empty. No topNode element." << endl;
            return -1;
        }
        return topNode->data;
    }

    bool isEmpty()
    {
        return topNode == nullptr;
    }

    void display()
    {
        Node *currentNode = topNode;
        cout << "Stack: ";
        while (currentNode != nullptr)
        {
            cout << currentNode->data << " ";
            currentNode = currentNode->next;
        }
        cout << endl;
    }
};

class TreeNodeStack
{
public:
    treeNode *topNode;

    TreeNodeStack() : topNode(nullptr) {}

    ~TreeNodeStack()
    {
        while (!isEmpty())
        {
            pop();
        }
    }

    void push(treeNode *newNode)
    {
        newNode->right = topNode;
        topNode = newNode;
    }

    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack underflow. No elements to pop." << endl;
        }
        treeNode *tempNode = topNode;
        topNode = topNode->right;
        delete tempNode;
    }

    treeNode *top()
    {
        if (isEmpty())
        {
            cout << "Stack is empty. No top element." << endl;
            return nullptr;
        }
        return topNode;
    }

    bool isEmpty()
    {
        return topNode == nullptr;
    }

    void display()
    {
        treeNode *currentNode = topNode;
        cout << "Stack: ";
        while (currentNode != nullptr)
        {
            cout << currentNode->data << " ";
            currentNode = currentNode->right;
        }
        cout << endl;
    }
};

int main()
{
    string exp = "ABC*+D/";
    treeNode *root = makeTree(exp);

    cout << "Pre-Order: ";
    preOrder(root);
    cout << endl;

    cout << "In-Order: ";
    inOrder(root);
    cout << endl;

    cout << "Post-Order: ";
    postOrder(root);
    cout << endl;

    int result = evaluate(exp);
    cout << "Evaluated exp is: " << result << endl;

    return 0;
}

int evaluate(string exp)
{
    Stack s;

    for (char ch : exp)
    {
        if (isalpha(ch))
        {
            int value;
            if (ch == 'A' || ch == 'B')
                value = 2;
            else if (ch == 'C')
                value = 3;
            else if (ch == 'D')
                value = 4;

            s.push(value);
        }
        else
        {
            int right = s.top();
            s.pop();
            int left = s.top();
            s.pop();

            int result;
            switch (ch)
            {
            case '*':
                result = left * right;
                break;
            case '+':
                result = left + right;
                break;
            case '/':
                result = left / right;
                break;
            }

            s.push(result);
        }
    }

    return s.top();
}

treeNode *makeTree(string exp)
{
    stack<treeNode*> s;

    for (char ch : exp)
    {
        if (isalpha(ch)) // if alphabet/operand, push to stack
        {
            treeNode *node = new treeNode(ch); // A,B,C,D
            s.push(node);
        }
        else
        {
            treeNode *node = new treeNode(ch); // +,/,*
            node->right = s.top();
            s.pop();
            node->left = s.top();
            s.pop();

            s.push(node);
        }
    }

    return s.top(); // root node
}

void preOrder(treeNode *root)
{
    if (root == nullptr)
    {
        return;
    }

    cout << root->data << " ";
    preOrder(root->left);
    preOrder(root->right);
}

void inOrder(treeNode *root)
{
    if (root == nullptr)
    {
        return;
    }

    inOrder(root->left);
    cout << root->data << " ";
    inOrder(root->right);
}

void postOrder(treeNode *root)
{
    if (root == nullptr)
    {
        return;
    }

    postOrder(root->left);
    postOrder(root->right);
    cout << root->data << " ";
}