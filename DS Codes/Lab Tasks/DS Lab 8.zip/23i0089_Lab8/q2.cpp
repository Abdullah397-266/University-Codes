#include <iostream>

using namespace std;

void preorder(int tree[], int index, int size);
void inorder(int tree[], int index, int size);
void postorder(int tree[], int index, int size);

int main()
{
    //      1
    //    /   \
    //   2     3
    //    \   
    //     5
    int tree[] = {1, 2, 3, -1, 5, -1, -1};
    int size = sizeof(tree) / sizeof(tree[0]);

    cout << "Preorder Traversal: ";
    preorder(tree, 0, size);
    cout << endl;

    cout << "Inorder Traversal: ";
    inorder(tree, 0, size);
    cout << endl;

    cout << "Postorder Traversal: ";
    postorder(tree, 0, size);
    cout << endl;

    return 0;
}

void preorder(int tree[], int index, int size)
{
    if (index >= size || tree[index] == -1)
        return;

    cout << tree[index] << " ";
    preorder(tree, 2 * index + 1, size);
    preorder(tree, 2 * index + 2, size);
}

void inorder(int tree[], int index, int size)
{
    if (index >= size || tree[index] == -1)
        return;

    inorder(tree, 2 * index + 1, size); 
    cout << tree[index] << " ";         
    inorder(tree, 2 * index + 2, size);
}

void postorder(int tree[], int index, int size)
{
    if (index >= size || tree[index] == -1)
        return; 

    postorder(tree, 2 * index + 1, size); 
    postorder(tree, 2 * index + 2, size);
    cout << tree[index] << " ";
}