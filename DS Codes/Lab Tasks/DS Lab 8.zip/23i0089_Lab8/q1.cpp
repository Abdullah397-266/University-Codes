#include <iostream>
#include <queue>
using namespace std;

int main()
{
    int N;
    cout << "Enter no of nodes: ";
    cin >> N;

    queue<int> q;
    int arr[N];

    int val, left, right;
    for (int i = 0; i < N; i++)
    {
        cout << "Enter (value/left/right): ";
        cin >> val >> left >> right;
        if (i == 0)
            q.push(val);
        q.push(left);
        q.push(right);
    }

    for (int i=0; !q.empty(); i++)
    {
        int data = q.front();
        q.pop();

        if (data != -1)
        {
            arr[i] = data;
        }
        else
        {
            i--;
        }
    }

    for (int i=0; i<N; i++)
    {
        cout << arr[i] << " ";
    }

    return 0;
}