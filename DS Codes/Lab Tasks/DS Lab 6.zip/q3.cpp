#include <iostream>
using namespace std;

class LLNode
{
public:
    int data;
    LLNode *next = nullptr;

    LLNode(int dta) : data(dta) {}
};

class LL
{
public:
    LLNode *head = nullptr;
    LLNode *tail = nullptr;
    int size = 0;

    void addList(int *arr, int len)
    {
        for (int i = 0; i < len; i++)
        {
            LLNode *newNode = new LLNode(arr[i]);
            if (size == 0)
            {
                head = newNode;
                tail = newNode;
            }
            else
            {
                tail->next = newNode;
                tail = tail->next;
            }
            size++;
        }
    }

    int pop()
    {
        LLNode *backup = head;
        int data = head->data;
        head = head->next;
        delete backup;
        return data;
    }

    void print()
    {
        LLNode *current = head;
        while (current != nullptr)
        {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "\b nullptr" << endl;
    }
};

class DLLNode
{
public:
    int data;
    DLLNode *next = nullptr;
    DLLNode *prev = nullptr;

    DLLNode(int dta) : data(dta) {}
};

class DLL
{
public:
    DLLNode *head = nullptr;
    DLLNode *tail = nullptr;
    int size = 0;

    void add(int data)
    {
        DLLNode *newNode = new DLLNode(data);
        if (isEmpty())
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            newNode->prev = tail;
            tail->next = newNode;
            tail = tail->next;
        }
        size++;
    }

    bool isEmpty()
    {
        return size == 0;
    }

    void printList()
    {
        DLLNode *current = head;
        while (current != nullptr)
        {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "\b nullptr" << endl;
    }
};

int main()
{

    LL list;
    DLL even, odd;
    int size = 10;
    int arr[10] = {1,2,3,4,5,6,7,8,9,10};
    list.addList(arr,size);
    // list.print();

    for(int i=0; i<size; i++)
    {
        int num = list.pop();
        if(num%2==0)
        {
            even.add(num);
        }
        else
        {
            odd.add(num);
        }
    }

    cout << "Even DLL:" << endl;
    even.printList();
    cout << endl;

    cout << "Odd DLL:" << endl;
    odd.printList();
    cout << endl;
    return 0;
}