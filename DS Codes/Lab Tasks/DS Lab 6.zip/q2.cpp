#include <iostream>
#include <windows.h>
using namespace std;

class Node
{
public:
    int id;
    int time;
    Node *next = nullptr;

    Node(int ID, int timee) : id(ID), time(timee) {}
};

class Queue
{
    public:
    Node *head = nullptr;
    Node *tail = nullptr;
    int size = 0;

    void Enqueue(int id, int time)
    {
        Node *newNode = new Node(id,time);
        if(size == 0)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = tail->next;
        }
        size++;
    }

    void Dequeue()
    {
        if(!isEmpty())
        {
            Node* backup = head;
            head = head->next;
            delete backup;
            size--;
        }
    }

    bool isEmpty()
    {
        return (size==0);
    }

    void startProcess()
    {
        while(!isEmpty())
        {
            // cout << head->time << endl;
            Sleep(head->time*1000);
            cout << head->id << " completed " << head->time << " seconds" << endl;
            Dequeue();
        }
    }
};

int main()
{
    Queue process;
    int id, time;
    while (true) 
    {
        cout << "Enter ID and time: ";
        cin >> id >> time;
        if(id == -1)
            break;
        process.Enqueue(id,time);
    }
    process.startProcess();

    return 0;
}