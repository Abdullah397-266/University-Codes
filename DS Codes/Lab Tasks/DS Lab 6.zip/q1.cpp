#include <iostream>
#include <windows.h>
using namespace std;

// stack Node
class Node
{
public:
    int data;
    Node *next;

    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }
};

class Stack
{
public:
    Node *top;
    int size = 0;

    Stack() : top(nullptr) {}

    void push(int data)
    {
        Node *newNode = new Node(data);
        newNode->next = top;
        top = newNode;
        size++;
    }

    int pop()
    {
        if (!isEmpty())
        {
            Node *backup = top;
            auto backupData = top->data;
            top = top->next;
            size--;
            delete backup;

            return backupData;
        }
        cout << "Stack is Already Empty!" << endl;
    }

    int peek()
    {
        return top->data;
    }

    void print()
    {
        Node *temp = top;

        while (temp)
        {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "\b nullptr" << endl;
    }

    bool isEmpty()
    {
        return (top == nullptr);
    }

    void wipe()
    {
        Node *backup;
        while (top)
        {
            backup = top;
            top = top->next;
            delete backup;
        }
        top = nullptr;
    }

    void transferTo(Stack &to)
    {
        if (!this->isEmpty())
        {
            while (!this->isEmpty())
            {
                to.push(this->pop());
            }
        }
    }
};

class Queue
{
public:
    Stack main, temp;
    int size = 0;
    int capacity = 5;

    void Enqueue(int data)
    {
        if (size < capacity)
        {
            main.push(data);
            size++;
        }
    }

    int Dequeue()
    {
        // dequeue form temp
        if (main.isEmpty() && temp.isEmpty())
        {
            cout << "Queue is Already empty!" << endl;
        }
        else
        {
            if (temp.isEmpty())
                main.transferTo(temp);

            int data = temp.pop();
            size--;
            temp.transferTo(main);
            return data;
        }
    }

    bool isEmpty()
    {
        return (main.isEmpty() && temp.isEmpty());
    }

    bool isFull()
    {
        return (size == capacity);
    }

    void print()
    {
        main.transferTo(temp);
        Node *tempHead = temp.top;

        while(tempHead)
        {
            cout << tempHead->data << " -> ";
            tempHead = tempHead->next;
        }
        cout << "\b nullptr" << endl;

        temp.transferTo(main);
    }
};

int main()
{
    Queue q;
    q.Enqueue(1);
    q.Enqueue(2);
    q.Enqueue(3);
    q.Enqueue(4);
    q.Enqueue(5);

    q.print();

    q.Dequeue();
    q.Dequeue();

    q.print();

    return 0;
}