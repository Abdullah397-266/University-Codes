#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

class DLLNode
{
public:
    string songName;
    int duration;
    DLLNode *next = nullptr;
    DLLNode *prev = nullptr;

    DLLNode(string name, int dur) : songName(name), duration(dur) {}
};

class DLL
{
public:
    DLLNode *head = nullptr;
    DLLNode *tail = nullptr;
    DLLNode *playerPtr = nullptr;
    int size = 0;

    void addSong(string songName, int dur)
    {
        DLLNode *newNode = new DLLNode(songName, dur);
        if (size == 0)
        {
            head = tail = playerPtr = newNode;
        }
        else
        {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    void removeSong(string name)
    {
        if (head == nullptr)
            return;

        DLLNode *temp = head;

        while (temp != nullptr && temp->songName != name)
        {
            temp = temp->next;
        }

        if (temp == nullptr)
        {
            cout << "No such song found" << endl;
            return;
        }

        if (size == 1)
        {
            delete temp;
            head = tail = nullptr;
        }
        else if (temp == head)
        {
            head = temp->next;
            head->prev = nullptr;
            delete temp;
        }
        else if (temp == tail)
        {
            tail = temp->prev;
            tail->next = nullptr;
            delete temp;
        }
        else if (temp == playerPtr)
        {
            playerPtr = (playerPtr->next) ? playerPtr->next : head;
        }
        else
        {
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            delete temp;
        }

        size--;
    }

    void playNext() 
    {
        if (size == 0) 
            return;

        if (playerPtr->next != nullptr) 
        {
            playerPtr = playerPtr->next;
        } 
        else 
        {
            playerPtr = head;
        }

        displayCurrentSong();
    }

    void playPrevious()
    {
        if (size == 0) 
            return;

        if (playerPtr->prev != nullptr) 
        {
            playerPtr = playerPtr->prev;
        } 
        else 
        {
            playerPtr = tail;
        }

        displayCurrentSong();
    }

    void displayCurrentSong() 
    {
        if (size == 0) 
        {
            cout << "No song is currently playing." << endl;
        }
        else 
        {
            cout << "Currently playing: " << playerPtr->songName << endl;
        }
    }

    void replayCurrent() 
    {
        displayCurrentSong();
    }

    void loopPlaylist() 
    {
        playNext();
    }

    void printList()
    {
        DLLNode *current = head;
        while (current != nullptr)
        {
            cout << current->songName << " & " << current->duration << " -> ";
            current = current->next;
        }
        cout << "\b nullptr" << endl;
    }

    DLLNode *getNodeAt(int index)
    {
        DLLNode *current = head;
        int count = 0;

        while (current != nullptr && count < index)
        {
            current = current->next;
            count++;
        }
        return current;
    }

    void shuffle()
    {
        srand(time(0));

        if (size <= 1)
            return;

        for (int i = size - 1; i > 0; --i)
        {
            int j = rand() % (i + 1);

            DLLNode *node1 = getNodeAt(i);
            DLLNode *node2 = getNodeAt(j);

            swap(node1->songName, node2->songName);
            swap(node1->duration, node2->duration);
        }
    }
};

int main()
{
    DLL list;
    list.addSong("Song1", 2);
    list.addSong("Song2", 4);
    list.addSong("Song3", 6);
    list.addSong("Song4", 8);
    list.addSong("Song5", 10);
    list.addSong("Song6", 8);
    list.addSong("Song7", 6);

    list.printList();

    list.shuffle();
    list.printList();

    list.playNext();
    list.playNext();
    list.displayCurrentSong();

    list.playPrevious();
    list.displayCurrentSong();

    list.replayCurrent();

    for (int i = 0; i < 12; i++) 
    {
        list.loopPlaylist();
    }

    cout << "\nremoved song 3: " << endl;
    list.removeSong("Song3");
    list.printList();

    return 0;
}