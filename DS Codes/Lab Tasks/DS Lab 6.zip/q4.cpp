#include <iostream>

using namespace std;

void addCustomer(string name, string *arr, int size, int &remain);
void AttendCustomer(string *arr, int size, int &remain);
void viewQueue(string *arr, int size, int remain);

int main()
{
    int size = 5;
    int remain = size;
    string queue[5];

    addCustomer("CS-1", queue, size, remain);
    addCustomer("CS-2", queue, size, remain);
    addCustomer("CS-3", queue, size, remain);
    addCustomer("CS-4", queue, size, remain);
    addCustomer("CS-5", queue, size, remain);

    viewQueue(queue, size, remain);

    AttendCustomer(queue, size, remain);
    AttendCustomer(queue, size, remain);

    viewQueue(queue, size, remain);

    return 0;
}

void addCustomer(string name, string *arr, int size, int &remain)
{
    if (remain > 0)
    {
        arr[size - remain] = name;
        remain--;
    }
}

void AttendCustomer(string *arr, int size, int &remain)
{
    if (remain == size)
    {
        cout << "All customer are attented, No mere left" << endl;
    }
    else
    {
        for (int i = 0; i < size - 1; i++)
        {
            arr[i] = arr[i + 1];
        }
        remain++;
    }
}

void viewQueue(string *arr, int size, int remain)
{
    for (int i = 0; i < (size - remain); i++)
    {
        cout << arr[i] << " -> ";
    }
    cout << "\b nullptr" << endl;
}