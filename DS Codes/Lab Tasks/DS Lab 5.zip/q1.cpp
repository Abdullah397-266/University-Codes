#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

bool precedence(char op1, char op2);
bool isOpreator(char ch);
string convertToPostfix(string exp);

class Node
{
public:
	char ch;
	Node* next;

	Node(char c)
	{
		ch = c;
		next = NULL;
	}
};

class Stack
{
public:
	Node* top;

	char pop()
	{
		if (top == NULL)
        {
            cout << "Stack is empty" << endl;

        }
        else
        {
            char ch = top->ch;
            Node *temp = top;
            top = top->next;
            temp->next = NULL;
            delete temp;
            
            return ch;
        }
	}

	void push(char chr)
	{
		Node* temp = new Node(chr);
        temp->next = top;
        top = temp;
	}

	bool isEmpty()
	{
		return top == NULL;
	}

    char stackTop()
    {
        return top->ch;
    }

    void printStack()
    {
        Node* temp = top;
        while(temp != NULL)
        {
            cout << temp->ch << ", ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    string exp = "(6+2)*5-8/4";
    cout << "The Postfix String is: " << convertToPostfix(exp) << endl;
    return 0;
}

bool precedence(char op1, char op2)
{
    if(isOpreator(op1) == false || isOpreator(op2) == false)
    {
        cout << "Not an operator" << endl;
        return false;
    }

    char powerSymb = '^';

    if (op1 == powerSymb)
    {
        return true;
    }
    else if (op2 == powerSymb)
    {
        return false;
    }
    else if(op1 == '(')
    {
        return false;
    }
    else if(op2 == '(')
    {
        return false;
    }
    // else if(op1 == ')')
    // {
    //     return true;
    // }
    else if(op2 == ')')
    {
        return true;
    }
    else if (op1 == '*' || op1 == '/')
    {
        return true;
    }
    else if (op2 == '*' || op2 == '/')
    {
        return false;
    }
    else if (op1 == '+' || op1 == '-')
    {
        return true;
    }
    else
    {
        return false;
    }
}
  
bool isOpreator(char ch)
{
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' || ch == '(' || ch == ')');
}

string convertToPostfix(string exp)
{
    Stack s;
    string converted = "";
    char ch;

    int len = exp.length();
    for(int i=0; i<len; i++)
    {
        ch = exp[i];
        if(isdigit(ch))
        {
            converted += ch;
        }
        else
        {
            while(!s.isEmpty() && precedence(s.top->ch, ch))
            {
                converted += s.pop();
            }

            if(s.isEmpty() || ch != ')')
            {
                s.push(ch);
            }
            else
            {
                s.pop();
            }
        }
    }

    while(!s.isEmpty())
    {
        converted += s.pop();
    }

    cout << "Conveted String: " << converted << endl;
    return converted;
}