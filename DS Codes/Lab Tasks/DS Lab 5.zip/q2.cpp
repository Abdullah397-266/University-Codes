#include <iostream>
#include <cstdlib>
using namespace std;

bool precedence(char op1, char op2);
bool isOpreator(char ch);
string convertToPostfix(string exp);
string handleBraces(string exp);
string reverseString(string str);
string convertToPrefix(string exp);

class Node
{
public:
    char ch;
    Node *next;

    Node(char c)
    {
        ch = c;
        next = NULL;
    }
};

class Stack
{
public:
    Node *top;

    char pop()
    {
        if (top == NULL)
        {
            cout << "Stack is empty" << endl;
            return '\0';
        }
        else
        {
            char ch = top->ch;
            Node *temp = top;
            top = top->next;
            temp->next = NULL;
            delete temp;

            return ch;
        }
        return '\0';
    }

    void push(char chr)
    {
        Node *temp = new Node(chr);
        temp->next = top;
        top = temp;
    }

    bool isEmpty()
    {
        return top == NULL;
    }

    char stackTop()
    {
        return top->ch;
    }

    void printStack()
    {
        Node *temp = top;
        while (temp != NULL)
        {
            cout << temp->ch << ", ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    string exp = "(6+2)*5-8/4";
    string prefix = convertToPrefix(exp);
    cout << "Prefix: " << prefix << endl;
    return 0;
}

bool precedence(char op1, char op2)
{
    if (isOpreator(op1) == false || isOpreator(op2) == false)
    {
        cout << "Not an operator" << endl;
        return false;
    }

    if (op1 == '^')
    {
        return true;
    }
    else if (op2 == '^')
    {
        return false;
    }
    else if (op1 == '(')
    {
        return false;
    }
    else if (op2 == '(')
    {
        return false;
    }
    // else if(op1 == ')')
    // {
    //     return true;
    // }
    else if (op2 == ')')
    {
        return true;
    }
    else if (op1 == '*' || op1 == '/')
    {
        return true;
    }
    else if (op2 == '*' || op2 == '/')
    {
        return false;
    }
    else if (op1 == '+' || op1 == '-')
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool isOpreator(char ch)
{
    return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' || ch == '(' || ch == ')';
}

string convertToPostfix(string exp)
{
    Stack s;
    string converted = "";
    char ch;

    int len = exp.length();
    for (int i = 0; i < len; i++)
    {
        ch = exp[i];
        if(ch == ' ')
        {
            continue;
        }

        if (isdigit(ch))
        {
            converted += ch;
        }
        else
        {
            while (!s.isEmpty() && precedence(s.top->ch, ch))
            {
                converted += s.pop();
            }

            if (s.isEmpty() || ch != ')')
            {
                s.push(ch);
            }
            else
            {
                s.pop();
            }
        }
    }

    while (!s.isEmpty())
    {
        converted += s.pop();
    }

    cout << "Conveted String: " << converted << endl;
    return converted;
}

string handleBraces(string exp)
{
    int len = exp.length();
    for (int i = 0; i < len; i++)
    {
        if (exp[i] == '(')
        {
            exp[i] = ')';
        }
        else if (exp[i] == ')')
        {
            exp[i] = '(';
        }
    }
    return exp;
}

string reverseString(string str)
{
    string reversed = "";
    int len = str.length();
    for (int i = len - 1; i >= 0; i--)
    {
        reversed += str[i];
    }

    cout << "Reversed String: " << reversed << endl;
    return reversed;
}

string convertToPrefix(string exp)
{
    string reversed = reverseString(exp);

    reversed = handleBraces(reversed);
    cout << "Handled Braces: " << reversed << endl;

    string postfix = convertToPostfix(reversed);

    string prefix = reverseString(postfix);

    return prefix;
}