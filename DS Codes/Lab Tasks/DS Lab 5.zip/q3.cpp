#include <iostream>
#include <string>
#include <cstdlib>
#include <cmath>
using namespace std;

bool precedence(char op1, char op2);
bool isOpreator(char ch);
string convertToPostfix(string exp);
int evaluatePostfix(string exp);

class NodeChr
{
public:
	char ch;
	NodeChr* next;

	NodeChr(char c)
	{
		ch = c;
		next = NULL;
	}
};

class StackChr
{
public:
	NodeChr* top;

	char pop()
	{
		if (top == NULL)
        {
            cout << "Stack is empty" << endl;

        }
        else
        {
            char ch = top->ch;
            NodeChr *temp = top;
            top = top->next;
            temp->next = NULL;
            delete temp;
            
            return ch;
        }
	}

	void push(char chr)
	{
		NodeChr* temp = new NodeChr(chr);
        temp->next = top;
        top = temp;
	}

	bool isEmpty()
	{
		return top == NULL;
	}

    char stackTop()
    {
        return top->ch;
    }

    void printStack()
    {
        NodeChr* temp = top;
        while(temp != NULL)
        {
            cout << temp->ch << ", ";
            temp = temp->next;
        }
        cout << endl;
    }
};

class NodeInt
{
public:
	int num;
	NodeInt* next;

	NodeInt(int c)
	{
		num = c;
		next = NULL;
	}
};

class StackInt
{
public:
	NodeInt* top;

	int pop()
	{
		if (top == NULL)
        {
            cout << "Stack is empty" << endl;

        }
        else
        {
            int ch = top->num;
            NodeInt *temp = top;
            top = top->next;
            temp->next = NULL;
            delete temp;
            
            return ch;
        }
	}

	void push(int chr)
	{
		NodeInt* temp = new NodeInt(chr);
        temp->next = top;
        top = temp;
	}

	bool isEmpty()
	{
		return top == NULL;
	}

    char stackTop()
    {
        return top->num;
    }

    void printStack()
    {
        NodeInt* temp = top;
        while(temp != NULL)
        {
            cout << temp->num << ", ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    string exp = "(6+2)*5-8/4";
    cout << "The Postfix String is: " << convertToPostfix(exp) << endl;

    cout << "The result is: " << evaluatePostfix(exp) << endl;
    return 0;
}

bool precedence(char op1, char op2)
{
    // if(isOpreator(op1) == false || isOpreator(op2) == false)
    // {
    //     cout << "Not an operator" << endl;
    //     return false;
    // }

    if (op1 == '^')
    {
        return true;
    }
    else if (op2 == '^')
    {
        return false;
    }
    else if(op1 == '(')
    {
        return false;
    }
    else if(op2 == '(')
    {
        return false;
    }
    // else if(op1 == ')')
    // {
    //     return true;
    // }
    else if(op2 == ')')
    {
        return true;
    }
    else if (op1 == '*' || op1 == '/')
    {
        return true;
    }
    else if (op2 == '*' || op2 == '/')
    {
        return false;
    }
    else if (op1 == '+' || op1 == '-')
    {
        return true;
    }
    else
    {
        return false;
    }
}
  
// bool isOpreator(char ch)
// {
//     return (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' || ch == '(' || ch == ')');
// }

string convertToPostfix(string exp)
{
    StackChr s;
    string converted = "";
    char ch;

    int len = exp.length();
    for(int i=0; i<len; i++)
    {
        ch = exp[i];
        if(isdigit(ch))
        {
            converted += ch;
        }
        else
        {
            while(!s.isEmpty() && precedence(s.top->ch, ch))
            {
                converted += s.pop();
            }

            if(s.isEmpty() || ch != ')')
            {
                s.push(ch);
            }
            else
            {
                s.pop();
            }
        }
    }

    while(!s.isEmpty())
    {
        converted += s.pop();
    }

    cout << "Conveted String: " << converted << endl;
    return converted;
}

int evaluatePostfix(string exp)
{
    string postfixStr = convertToPostfix(exp);

    StackInt s;
    int len = postfixStr.length();
    char ch;

    for (int i=0; i< len; i++)
    {
        ch = postfixStr[i];
        if(isdigit(ch))
        {
            s.push(ch - '0');
        }
        else
        {
            int op2 = s.pop();
            int op1 = s.pop();

            switch(ch)
            {
                case '+':
                    s.push(op1 + op2);
                    break;
                case '-':
                    s.push(op1 - op2);
                    break;
                case '*':
                    s.push(op1 * op2);
                    break;
                case '/':
                    s.push(op1 / op2);
                    break;
                case '^':
                    s.push(pow(op1, op2));
                    break;
            }
        }
    }

    return s.pop();
}