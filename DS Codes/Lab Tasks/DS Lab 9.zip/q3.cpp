#include <iostream>

using namespace std;

class node
{
public:
    int data;
    node *left, *right;

    node(int dta) : data(dta), left(NULL), right(NULL) {}
};

class BT
{
public:
    node *root;
    BT() : root(NULL) {}

    void insert(int data)
    {
        node *newNode = new node(data);
        if (root == nullptr)
        {
            root = newNode;
            return;
        }

        node *temp = root;
        while (temp)
        {
            if (data < temp->data)
            {
                if (temp->left == nullptr)
                {
                    temp->left = newNode;
                    break;
                }
                temp = temp->left;
            }
            else if (data > temp->data)
            {
                if (temp->right == nullptr)
                {
                    temp->right = newNode;
                    break;
                }
                temp = temp->right;
            }
            else
            {
                // Avoid duplicate data
                delete newNode;
                break;
            }
        }
    }

    node *search(int key)
    {
        node *temp = root;
        while (temp)
        {
            if (key == temp->data)
            {
                return temp;
            }
            else if (key < temp->data)
            {
                temp = temp->left;
            }
            else
            {
                temp = temp->right;
            }
        }
        return nullptr;
    }

    node *getRoot()
    {
        return root;
    }

    void inorder_traversal(node *p)
    {
        if (p)
        {
            inorder_traversal(p->left);
            cout << p->data << " ";
            inorder_traversal(p->right);
        }
    }

    void preorder_traversal(node *p)
    {
        if (p)
        {
            cout << p->data << " ";
            preorder_traversal(p->left);
            preorder_traversal(p->right);
        }
    }

    void postorder_traversal(node *p)
    {
        if (p)
        {
            postorder_traversal(p->left);
            postorder_traversal(p->right);
            cout << p->data << " ";
        }
    }

    int Height(node *p)
    {
        if (p == nullptr)
            return 0;

        int leftHeight = Height(p->left);
        int rightHeight = Height(p->right);
        return max(leftHeight, rightHeight) + 1;
    }

    int countNodes(node *p)
    {
        if (p == nullptr)
            return 0;
        return 1 + countNodes(p->left) + countNodes(p->right);
    }

    int total_number_of_nodes()
    {
        return countNodes(root);
    }

    int countLeafNodes(node *p)
    {
        if (p == nullptr)
            return 0;

        if (p->left == nullptr && p->right == nullptr)
            return 1;

        return countLeafNodes(p->left) + countLeafNodes(p->right);
    }

    int total_number_of_leaf_nodes()
    {
        return countLeafNodes(root);
    }

    void deleteTree(node *p)
    {
        if (p == NULL)
            return;

        deleteTree(p->left);
        deleteTree(p->right);

        cout << "Deleting node with data: " << p->data << endl;
        delete p;
    }

    ~BT()
    {
        deleteTree(root);
    }
};

int main()
{
    BT tree;
    tree.insert(10);
    tree.insert(5);
    tree.insert(15);
    tree.insert(3);
    tree.insert(7);

    cout << "Inorder Traversal: ";
    tree.inorder_traversal(tree.getRoot());
    cout << endl;

    cout << "Preorder Traversal: ";
    tree.preorder_traversal(tree.getRoot());
    cout << endl;

    cout << "Postorder Traversal: ";
    tree.postorder_traversal(tree.getRoot());
    cout << endl;

    cout << "Height of Tree: " << tree.Height(tree.getRoot()) << endl;
    cout << "Total Number of Nodes: " << tree.total_number_of_nodes() << endl;
    cout << "Total Number of Leaf Nodes: " << tree.total_number_of_leaf_nodes() << endl;

    return 0;
}