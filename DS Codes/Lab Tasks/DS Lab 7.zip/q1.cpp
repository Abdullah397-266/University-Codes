#include <iostream>

using namespace std;

class Node
{
public:
    int songID;
    string songName;
    Node *next;

    Node(int id, string name)
    {
        songID = id;
        songName = name;
        next = nullptr;
    }
};

class CircularPlayList
{
public:
    Node *head;
    Node *tail;
    int size = 0;

    CircularPlayList() : head(nullptr), tail(nullptr) {}

    void addSong(int songID, string songName)
    {
        Node *newNode = new Node(songID, songName);
        if (size == 0)
        {
            head = tail = newNode;
        }
        else
        {
            // Node *temp = head;
            // while (temp->next != nullptr)
            // {
            //     temp = temp->next;
            // }
            // temp->next = newNode;
            tail->next = newNode;
            tail = newNode;
            tail->next = head;
        }
        size++;
    }

    void removeSong(int songID)
    {
        if (size == 0)
        {
            cout << "Already Empty!" << endl;
            return;
        }
        if(size == 1)
        {
            delete head;
            delete tail;
            head = tail = nullptr;
            size--;
            return;
        }

        Node *temp = head;
        while (temp->next->songID != songID)
        {
            temp = temp->next;
        }

        if(temp->next == tail)
        {
            Node *backup = tail;
            tail = temp;
            tail->next = head;
            delete backup;
        }
        else
        {
            Node *backup = temp->next;
            temp->next = temp->next->next;
            delete backup;
        }
        size--;
    }

    void displayPlaylist()
    {
        Node *temp = head;
        tail->next = nullptr;
        while(temp != nullptr)
        {
            cout << temp->songID << " : " << temp->songName << " -> ";
            temp = temp->next;
        }
        cout << "head" << endl;

        tail->next = head;
    }

    void playNextSong(int length)
    {
        if (size < length)
        {
            cout << "Not enough songs to play!" << endl;
            return;
        }

        Node *curr = head;
        int count = 0;
        cout << "Playing next " << length << " songs:" << endl;
        while(count < length)
        {
            cout << "Now playing: " << curr->songName << endl;
            curr = curr->next;
            count++;
        }
    }
};

int main()
{
    CircularPlayList playlist;
    playlist.addSong(101, "Song A");
    playlist.addSong(102, "Song B");
    playlist.addSong(103, "Song C");
    playlist.addSong(104, "Song D");
    playlist.addSong(105, "Song E");

    playlist.displayPlaylist();
    cout << endl;

    playlist.removeSong(103);

    cout << "After removing song C: ";
    playlist.displayPlaylist();
    cout << endl;

    playlist.playNextSong(3);

    return 0;
}