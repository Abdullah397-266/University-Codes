#include <iostream>

using namespace std;

class Node
{
public:
    string url;
    Node *prev = nullptr;
    Node *next = nullptr;

    Node(string urll)
    {
        url = urll;
    }
};

class BrowserHistory
{
public:
    Node *head = nullptr;
    Node *tail = nullptr;
    Node *current = nullptr;
    int size = 0;

    void visitNewSite(string url)
    {
        Node *newNode = new Node(url);

        if(size == 0)
        {
            head = tail = current = newNode;
        }
        else if(size == 1)
        {
            tail = newNode;
            tail->prev = head;
            head->next = tail;

            tail->next = head;
            head->prev = tail;
            current = tail;
        }
        else
        {
            tail->next = newNode;
            newNode->prev = tail;
            tail = tail->next;

            tail->next = head;
            head->prev = tail;
            current = tail;
        }
        size++;
    }

    void displayHistory()
    {
        Node *temp = head;
        tail->next = nullptr;
        while(temp != nullptr)
        {
            cout << temp->url << " <-> ";
            temp = temp->next;
        }
        cout << "head" << endl;
        tail->next = head;
        cout << endl;
    }

    void goBack()
    {
        if(size == 0)
        {
            cout << "Already Empty!" << endl;
            return;
        }
        if(size == 1)
        {
            cout << "Cant go back! Only one node" << endl;
        }

        current = current->prev;
        // cout << "Now At: " << current->url << endl;
    }

    void goForward()
    {
        if(size == 0)
        {
            cout << "Already Empty!" << endl;
            return;
        }
        if(size == 1)
        {
            cout << "Cant go forward! Only one node" << endl;
        }

        current = current->next;
        // cout << "Now At: " << current->url << endl;
    }
};

int main()
{
    BrowserHistory history;
    history.visitNewSite("google.com");
    history.visitNewSite("youtube.com");
    history.visitNewSite("facebook.com");
    history.visitNewSite("instagram.com");
    history.visitNewSite("twitter.com");

    cout << "visited sites: " << endl;
    history.displayHistory();

    cout << "After going back twice: " << endl;
    history.goBack();
    history.goBack();
    cout << "Now At: " << history.current->url << endl;
    cout << endl;

    cout << "After visiting: news.com" << endl;
    history.visitNewSite("news.com");
    cout << "Now At: " << history.current->url << endl;
    cout << endl;

    cout << "After going forward once: " << endl;
    history.goForward();
    cout << "Now At: " << history.current->url << endl;
    cout << endl;

    cout << "Browser History: " << endl;
    history.displayHistory();

    return 0;
}