#include <iostream>
using namespace std;

void MaxHeapifyArr(int arr[], int size);
void heapSort(int arr[], int n);
void top_M_mostFrequentElements(int arr[], int size, int M);

class MaxHeap
{
public:
    int *arr;
    int size;
    int capacity;

    MaxHeap(int cap)
    {
        capacity = abs(cap);
        size = 0;
        arr = new int[capacity];
    }

    int parent(int i) { return (i - 1) / 2; }
    int left(int i) { return 2 * i + 1; }
    int right(int i) { return 2 * i + 2; }

    void insert(int key)
    {
        if (size == capacity)
        {
            cout << "Heap is full" << endl;
            return;
        }

        size++;
        int i = size - 1;
        arr[i] = key;

        while (i != 0 && arr[parent(i)] < arr[i])
        {
            swap(arr[i], arr[parent(i)]);
            i = parent(i);
        }
    }

    void heapify(int i)
    {
        int l = left(i);
        int r = right(i);
        int largest = i;

        if (l < size && arr[l] > arr[largest])
            largest = l;
        if (r < size && arr[r] > arr[largest])
            largest = r;

        if (largest != i)
        {
            swap(arr[i], arr[largest]);
            heapify(largest);
        }
    }

    int extractMax()
    {
        if (size <= 0)
            return NULL;
        if (size == 1)
        {
            size--;
            return arr[0];
        }

        int root = arr[0];
        arr[0] = arr[size - 1];
        size--;
        heapify(0);

        return root;
    }

    void increaseKey(int i, int new_val)
    {
        arr[i] = new_val;
        while (i != 0 && arr[parent(i)] < arr[i])
        {
            swap(arr[i], arr[parent(i)]);
            i = parent(i);
        }
    }

    void deletebyIndex(int i)
    {
        increaseKey(i, INT_MAX);
        extractMax();
    }

    void deleteKey(int key)
    {
        int i;
        for (i = 0; i < size; i++)
        {
            if (arr[i] == key)
                break;
        }

        increaseKey(i, INT_MAX);
        extractMax();
    }

    void printHeap()
    {
        for (int i = 0; i < size; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    void extractWithinRange(int k1, int k2)
    {
        for (int i = 0; i < size; i++)
        {
            if (arr[i] >= k1 && arr[i] <= k2)
                cout << arr[i] << " ";
        }
        cout << endl;
    }

    void pathToRoot(int num)
    {
        for (int i = 0; i < size; i++)
        {
            if (arr[i] == num)
            {
                while (i != 0)
                {
                    cout << arr[i] << " ";
                    i = parent(i);
                }
                cout << arr[0] << endl;
                return;
            }
        }
        cout << "Element not found" << endl;
    }

    MaxHeap convertToMaxHeap(int arr[], int size)
    {
        MaxHeap maxHeap(size);
        for (int i = 0; i < size; i++)
            maxHeap.insert(arr[i]);
        return maxHeap;
    }
};

class MinHeap
{
public:
    int *arr;
    int size;
    int capacity;

    MinHeap(int capacity)
    {
        this->capacity = capacity;
        this->size = 0;
        this->arr = new int[capacity];
    }

    int parent(int i) { return (i - 1) / 2; }
    int left(int i) { return 2 * i + 1; }
    int right(int i) { return 2 * i + 2; }

    void insert(int key)
    {
        if (size == capacity)
        {
            cout << "Heap is full" << endl;
            return;
        }

        size++;
        int i = size - 1;
        arr[i] = key;

        while (i != 0 && arr[parent(i)] > arr[i])
        {
            swap(arr[i], arr[parent(i)]);
            i = parent(i);
        }
    }

    void heapify(int i)
    {
        int l = left(i);
        int r = right(i);
        int smallest = i;

        if (l < size && arr[l] < arr[smallest])
            smallest = l;
        if (r < size && arr[r] < arr[smallest])
            smallest = r;

        if (smallest != i)
        {
            swap(arr[i], arr[smallest]);
            heapify(smallest);
        }
    }

    int extractMin()
    {
        if (size <= 0)
            return NULL;
        if (size == 1)
        {
            size--;
            return arr[0];
        }

        int root = arr[0];
        arr[0] = arr[size - 1];
        size--;
        heapify(0);

        return root;
    }

    void decreaseKey(int i, int new_val)
    {
        arr[i] = new_val;
        while (i != 0 && arr[parent(i)] > arr[i])
        {
            swap(arr[i], arr[parent(i)]);
            i = parent(i);
        }
    }

    void deletebyIndex(int i)
    {
        decreaseKey(i, INT_MIN);
        extractMin();
    }

    void printHeap()
    {
        for (int i = 0; i < size; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    void deleteKey(int key)
    {
        int i;
        for (i = 0; i < size; i++)
        {
            if (arr[i] == key)
                break;
        }

        decreaseKey(i, INT_MIN);
        extractMin();
    }
};

int main()
{
    system("CLS");

    // problem 1
    MaxHeap maxHeap(5);
    maxHeap.insert(3);
    maxHeap.insert(2);
    maxHeap.insert(15);
    maxHeap.insert(5);
    maxHeap.insert(4);
    cout << "Max Heap: ";
    maxHeap.printHeap();

    // problem 2
    MinHeap minHeap(5);
    minHeap.insert(3);
    minHeap.insert(2);
    minHeap.insert(15);
    minHeap.insert(5);
    minHeap.insert(4);

    cout << "Min Heap: ";
    minHeap.printHeap();

    minHeap.deleteKey(3);
    cout << "After deleting 3: ";
    minHeap.printHeap();

    // problem 3
    int arr[10] = {3, 2, 4, 5, 1, 6, 7, 8, 9, 10};
    int size = 10;
    MaxHeapifyArr(arr, size);
    for(int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;

    // problem 4
    int k = 3;
    int kthLargest;
    for (int i = 0; i < k; i++)
    {
        kthLargest = maxHeap.extractMax();
    }
    cout << "3rd largest element: " << kthLargest << endl;

    // problem 5
    MaxHeap maxHeap1(5);
    maxHeap1.insert(30);
    maxHeap1.insert(20);
    maxHeap1.insert(150);
    maxHeap1.insert(50);
    maxHeap1.insert(40);

    MaxHeap maxHeap2(5);
    maxHeap2.insert(3);
    maxHeap2.insert(2);
    maxHeap2.insert(15);
    maxHeap2.insert(5);
    maxHeap2.insert(4);

    cout << "Max Heap 1: ";
    maxHeap1.printHeap();
    cout << "Max Heap 2: ";
    maxHeap2.printHeap();

    int size1 = maxHeap1.size;
    int size2 = maxHeap2.size;
    int sizeO = size1 + size2;
    int *arrO = new int[sizeO];
    for (int i = 0; i < size1; i++)
        arrO[i] = maxHeap1.arr[i];
    for (int i = 0; i < size2; i++)
        arrO[size1 + i] = maxHeap2.arr[i];

    MaxHeapifyArr(arrO, sizeO);
    cout << "Merged Max Heap: ";
    for (int i = 0; i < sizeO; i++)
        cout << arrO[i] << " ";
    cout << endl;

    // problem 6
    heapSort(arr, size);
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";

    // problem 7
    minHeap.deleteKey(3);
    cout << "After deleting 3: ";
    minHeap.printHeap();

    // problem 8
    int k1 = 3, k2 = 10;
    cout << "Elements within range " << k1 << " and " << k2 << ": ";
    maxHeap.extractWithinRange(k1, k2);


    // problem 9
    cout << "Path to root of 2: ";
    maxHeap.pathToRoot(2);


    // problem 10
    int M = 3;
    top_M_mostFrequentElements(arr, size, M);

    return 0;
}

void MaxHeapifyArr(int arr[], int size)
{
    for (int i = size / 2 - 1; i >= 0; i--)
    {
        int l = 2 * i + 1;
        int r = 2 * i + 2;
        int largest = i;

        if (l < size && arr[l] > arr[largest])
            largest = l;
        if (r < size && arr[r] > arr[largest])
            largest = r;

        if (largest != i)
        {
            swap(arr[i], arr[largest]);
            MaxHeapifyArr(arr, size);
        }
    }
}

void heapSort(int arr[], int size)
{
    MaxHeapifyArr(arr, size);
    for (int i = size - 1; i > 0; i--)
    {
        swap(arr[0], arr[i]);
        MaxHeapifyArr(arr, i);
    }
}

void top_M_mostFrequentElements(int arr[], int size, int M)
{
    MaxHeap maxHeap(size);
    for (int i = 0; i < size; i++)
    {
        maxHeap.insert(arr[i]);
    }

    for (int i = 0; i < M; i++)
        cout << maxHeap.extractMax() << " ";
    cout << endl;
}