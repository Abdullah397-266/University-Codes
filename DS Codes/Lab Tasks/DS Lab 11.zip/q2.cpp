#include <iostream>
using namespace std;

class Player
{
    public:
    int id;
    int score;
    bool isRecent;

    Player(int id = 0, int score = 0, bool isRecent = false)
        : id(id), score(score), isRecent(isRecent) {}
};

class MaxHeap
{
public:
    Player heap[100];
    int size;

    MaxHeap() : size(0) {}

    void swap(Player &a, Player &b)
    {
        Player temp = a;
        a = b;
        b = temp;
    }

    void heapifyUp(int index)
    {
        while (index > 0)
        {
            int parent = (index - 1) / 2;
            if (heap[index].score > heap[parent].score)
            {
                swap(heap[index], heap[parent]);
                index = parent;
            }
            else
            {
                break;
            }
        }
    }

    void heapifyDown(int index)
    {
        while (index * 2 + 1 < size)
        {
            int left = index * 2 + 1;
            int right = index * 2 + 2;
            int largest = index;

            if (left < size && heap[left].score > heap[largest].score)
            {
                largest = left;
            }
            if (right < size && heap[right].score > heap[largest].score)
            {
                largest = right;
            }

            if (largest != index)
            {
                swap(heap[index], heap[largest]);
                index = largest;
            }
            else
            {
                break;
            }
        }
    }


    void insert(Player player)
    {
        heap[size] = player;
        heapifyUp(size);
        size++;
    }

    Player extractMax()
    {
        if (size == 0)
            return Player();
        Player maxPlayer = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);
        return maxPlayer;
    }

    Player getMax()
    {
        if (size == 0)
            return Player();
        return heap[0];
    }

    bool isEmpty()
    {
        return size == 0;
    }

    int getSize()
    {
        return size;
    }
};

MaxHeap overallPointsHeap;
MaxHeap recentPointsHeap;

void AddPlayer(int id, int initialOverallScore, int initialRecentScore)
{
    overallPointsHeap.insert(Player(id, initialOverallScore, false));
    recentPointsHeap.insert(Player(id, initialRecentScore, true));
}

void UpdateScore(int id, int newOverallScore, int newRecentScore)
{
    overallPointsHeap.insert(Player(id, newOverallScore, false));
    recentPointsHeap.insert(Player(id, newRecentScore, true));

    if (!recentPointsHeap.isEmpty() && recentPointsHeap.getMax().id == id)
    {
        cout << "Promo: Player " << id << " is now at top in recent.\n";
    }
}

void GetTopOverall()
{
    cout << "Top 5 Players by Overall Points:\n";
    Player temp[5];
    int count = 0;

    while (!overallPointsHeap.isEmpty() && count < 5)
    {
        Player top = overallPointsHeap.extractMax();
        cout << "Player " << top.id << " with Overall Points: " << top.score << endl;
        temp[count++] = top;
    }

    for (int i = 0; i < count; i++)
    {
        overallPointsHeap.insert(temp[i]);
    }
}

void GetTopRecent()
{
    cout << "Top 5 Players by Recent Performance:\n";
    Player temp[5];
    int count = 0;

    while (!recentPointsHeap.isEmpty() && count < 5)
    {
        Player top = recentPointsHeap.extractMax();
        cout << "Player " << top.id << " with Recent Points: " << top.score << endl;
        temp[count++] = top;
    }

    for (int i = 0; i < count; i++)
    {
        recentPointsHeap.insert(temp[i]);
    }
}

int main()
{
    AddPlayer(1, 250, 50);
    AddPlayer(2, 300, 80);
    AddPlayer(3, 280, 60);
    AddPlayer(4, 150, 30);
    AddPlayer(5, 350, 90);

    // P3 scores more and promoted
    UpdateScore(3, 380, 100);

    GetTopOverall();
    GetTopRecent();

    return 0;
}
