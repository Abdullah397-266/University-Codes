#include <iostream>
using namespace std;

template <typename T>
void swapValues(T &a, T &b)
{
    a = a+b;
    b = a-b;
    a = a-b;
}

template <typename T>
void swapStrings(T &str1, T &str2)
{
    T temp = str1;
    str1 = str2;
    str2 = temp;
}

int main() 
{
    int a = 10, b = 20;
    cout << "Before swap: a = " << a << " : b = " << b << endl;
    swapValues(a, b);
    cout << "After swap: a = " << a << " : b = " << b << endl;
    
    string str1 = "Hello", str2 = "World";
    cout << "Before swap: str1 = " << str1 << " : str2 = " << str2 << endl;
    swapStrings(str1, str2);
    cout << "After swap : str1 = " << str1 << " : str2 = " << str2 << endl;
    return 0;
}