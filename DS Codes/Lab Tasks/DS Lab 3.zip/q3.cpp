#include <iostream>

using namespace std;

class CustomerList
{
    int *customersID;
    int size;
    int index;

    public:
    CustomerList()
    {
        size = 0;
        customersID = NULL;
        index = 0;
    }
    CustomerList(int size)
    {
        this->size = size;
        customersID = new int[size];
        index = 0;
    }

    void AddCustomer(int id)
    {
        if(index<0)
        {
            cout << "Invalid index" << endl;
            return;
        }

        if(index == size)
        {
            int *newArr = new int[size * 2];
            for(int i = 0; i < size; i++)
            {
                newArr[i] = customersID[i];
            }
            delete[] customersID;
            customersID = newArr;
            size = size * 2;
        }
        customersID[index] = id;
        index++;
    }

    int FindCustomer(int id) const
    {
        for(int i = 0; i < index; i++)
        {
            if(customersID[i] == id)
            {
                return i;
            }
        }
        return -1;
    }

    bool RemoveCustomer(int id)
    {
        int i = FindCustomer(id);
        if(i == -1)
        {
            return false;
        }
        for(int j = i; j < index - 1; j++)
        {
            customersID[j] = customersID[j+1];
        }
        index--;
        return true;
    }

    void PrintList() const
    {
        for(int i = 0; i < index; i++)
        {
            cout << customersID[i] << " ";
        }
        cout << endl;
    }

    ~CustomerList()
    {
        delete[] customersID;
    }
};

int main() 
{
    CustomerList list(5);

    list.AddCustomer(1);
    list.AddCustomer(2);
    list.AddCustomer(3);
    list.AddCustomer(4);
    list.AddCustomer(5);

    list.PrintList();
    cout << endl;

    cout << "Removing customer with ID 3" << endl;
    if(list.RemoveCustomer(3))
    {
        cout << "Customer removed successfully" << endl;
    }
    else
    {
        cout << "Customer not found" << endl;
    }
    list.PrintList();
    cout << endl;

    cout << "Finding customer with ID 2" << endl;
    int index = list.FindCustomer(2);
    if(index != -1)
    {
        cout << "Customer found at index: " << index << endl;
    }
    else
    {
        cout << "Customer not found" << endl;
    }

    return 0;
}