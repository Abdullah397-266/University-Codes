#include <iostream>

using namespace std;

class ResizeableArray
{
    int *arr;
    int size;
    int remainingCapacity;

public:
    ResizeableArray()
    {
        size = 1;
        arr = new int[size];
        remainingCapacity = 1;
    }
    ResizeableArray(int size)
    {
        this->size = size;
        arr = new int[size];
        remainingCapacity = size;
    }

    void resize()
    {
        int *newArr = new int[size * 2];
        for (int i = 0; i < size; i++)
        {
            newArr[i] = arr[i];
        }
        delete[] arr;
        arr = newArr;
        remainingCapacity += size;
        size = size * 2;
    }

    void Add(int value)
    {
        if (remainingCapacity == 0)
        {
            resize();
        }
        arr[size - remainingCapacity] = value;
        remainingCapacity--;
    }

    bool Insert(int index, int value)
    {
        if (index < 0 || index >= size || index != size - remainingCapacity)
        {
            return false;
        }

        Add(value);
        remainingCapacity--;
        return true;
    }

    bool Remove(int index)
    {
        if (index < 0 || index >= size)
        {
            return false;
        }

        for(int i = index; i < size - 1; i++)
        {
            arr[i] = arr[i+1];
        }
        remainingCapacity++;
        return true;
    }

    bool Update(int index, int value)
    {
        if (index < 0 || index >= size)
        {
            return false;
        }

        arr[index] = value;
        if(!(index < size - remainingCapacity))
        {
            remainingCapacity--;
        }
        return true;
    }

    int get(int index) const
    {
        if (index < 0 || index >= size || index > size - remainingCapacity)
        {
            return -1;
        }

        return arr[index];
    }

    int getRemainingCapacity() const
    {
        return remainingCapacity;
    }

    int getSize() const
    {
        return size;
    }

    void clear()
    {
        delete[] arr;
        size = 0;
        remainingCapacity = 0;
    }

    void Reverse()
    {
        for(int i = 0; i < (size-remainingCapacity)/2; i++)
        {
            int temp = arr[i];
            arr[i] = arr[(size-remainingCapacity) - i - 1];
            arr[(size-remainingCapacity) - i - 1] = temp;
        }
    }

    int find(int value) const
    {
        for(int i = 0; i < size - remainingCapacity; i++)
        {
            if(arr[i] == value)
            {
                return i;
            }
        }
        return -1;
    }

    ~ResizeableArray()
    {
        delete[] arr;
    }
};

int main()
{
    ResizeableArray arr(10);
    arr.Add(10);
    arr.Add(20);
    arr.Add(30);
    arr.Add(40);

    cout << "Inserting 50 at index 4" << endl;
    if(arr.Insert(4, 50))
    {
        cout << "Inserted successfully" << endl;
    }
    else
    {
        cout << "Insertion failed" << endl;
    }
    cout << endl;

    cout << "Removing value at index 2" << endl;
    if(arr.Remove(2))
    {
        cout << "Removed successfully" << endl;
    }
    else
    {
        cout << "Removal failed" << endl;
    }
    cout << endl;

    cout << "Updating value at index 2 to 60" << endl;
    if(arr.Update(2, 60))
    {
        cout << "Updated successfully" << endl;
    }
    else
    {
        cout << "Update failed" << endl;
    }
    cout << "Value at index 2: " << arr.get(2) << endl;
    cout << endl;

    cout << "Remaining capacity: " << arr.getRemainingCapacity() << endl;
    cout << "Size: " << arr.getSize() << endl;
    cout << endl;

    cout << "Array: ";
    for(int i = 0; i < arr.getSize() - arr.getRemainingCapacity(); i++)
    {
        cout << arr.get(i) << " ";
    }
    arr.Reverse();
    cout << endl;
    cout << "Reversed array: ";
    for(int i = 0; i < arr.getSize() - arr.getRemainingCapacity(); i++)
    {
        cout << arr.get(i) << " ";
    }
    cout << endl;

    cout << "Finding value 60: ";
    if(arr.find(60) != -1)
    {
        cout << "Value found at index: " << arr.find(60) << endl;
    }
    else
    {
        cout << "Value not found" << endl;
    }
    cout << endl;

    arr.clear();
    cout << "Array cleared" << endl;

    return 0;
}