#include <iostream>
#include <string>
using namespace std;

class Patient
{
public:
    string name;
    Patient *next;

    Patient(string n) : name(n), next(nullptr) {}
};

class PatientArr
{
private:
    Patient *head;

public:
    PatientArr() : head(nullptr) {}

    void addPatient(string name, string priority)
    {
        if (priority == "high")
        {
            addAtBeginning(name);
        }
        else if (priority == "low")
        {
            addAtEnd(name);
        }
        else
        {
            cout << "At which position you want to add the patient: ";
            int position;
            cin >> position;
            addAtPosition(name, position);
        }
    }

    void addAtBeginning(string name)
    {
        Patient *newPatient = new Patient(name);
        newPatient->next = head;
        head = newPatient;
        cout << name << " added at the beginning" << endl;
    }

    void addAtEnd(string name)
    {
        Patient *newPatient = new Patient(name);
        if (head == nullptr)
        {
            head = newPatient;
        }
        else
        {
            Patient *temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            temp->next = newPatient;
        }
        cout << name << " added at the end" << endl;
    }

    void addAtPosition(string name, int position)
    {
        if (position == 1)
        {
            addAtBeginning(name);
            return;
        }

        Patient *newPatient = new Patient(name);
        Patient *temp = head;

        for (int i = 1; (i < position - 1 && temp != nullptr); i++)
        {
            temp = temp->next;
        }

        if (temp == nullptr)
        {
            cout << "Position out of bounds, adding at the end instead" << endl;
            addAtEnd(name);
        }
        else
        {
            newPatient->next = temp->next;
            temp->next = newPatient;
            cout << name << " added at position " << position << endl;
        }
    }

    void removeFromBeginning()
    {
        if (head == nullptr)
        {
            cout << "No patients to remove.\n";
            return;
        }

        Patient *temp = head;
        head = head->next;
        cout << temp->name << " removed from the list" << endl;
        delete temp;
    }

    void removeFromEnd()
    {
        if (head == nullptr)
        {
            cout << "No patients to remove" << endl;
            return;
        }

        if (head->next == nullptr)
        {
            delete head;
            head = nullptr;
            cout << "Last patient removed from the list" << endl;
            return;
        }

        Patient *temp = head;
        while (temp->next->next != nullptr)
        {
            temp = temp->next;
        }
        delete temp->next;
        temp->next = nullptr;
        cout << "Last patient removed from the list.\n";
    }

    void removeFromPosition(int position)
    {
        if (head == nullptr)
        {
            cout << "No patients to remove" << endl;
            return;
        }

        if (position == 1)
        {
            removeFromBeginning();
            return;
        }

        Patient *temp = head;
        for (int i = 1; (i < position - 1 && temp->next != nullptr); i++)
        {
            temp = temp->next;
        }

        if (temp->next == nullptr)
        {
            cout << "Position out of bounds.\n";
        }
        else
        {
            Patient *toRemove = temp->next;
            temp->next = toRemove->next;
            cout << toRemove->name << " removed from position " << position << endl;
            delete toRemove;
        }
    }

    void displayAllPatients()
    {
        if (head == nullptr)
        {
            cout << "No patients in the list" << endl;
            return;
        }

        Patient *temp = head;
        int position = 1;
        while (temp != nullptr)
        {
            cout << position << ". " << temp->name << endl;
            temp = temp->next;
            position++;
        }
    }
};

int main()
{
    PatientArr patients;

    patients.addPatient("P1", "high");
    patients.addPatient("P2", "low");
    patients.addPatient("P3", "low");
    patients.addPatient("P4", "high");
    patients.addPatient("P5", "low");

    patients.displayAllPatients();

    return 0;
}


// time complexity is O(n)
