#include <iostream>
using namespace std;

class Patient
{
public:
    string name;
    string priority;

    Patient() {}
    Patient(string name, string priority)
    {
        this->name = name;
        this->priority = priority;
    }
};

class PatientList
{
    Patient *patient_arr;
    int size;
    int remainingCapacity;

public:
    PatientList(int capacity = 10)
    {
        size = capacity;
        patient_arr = new Patient[size];
        remainingCapacity = size;
    }

    void Add_to_last(string name, string priority)
    {
        if (remainingCapacity == 0)
        {
            cout << "No more space to add patients." << endl;
            return;
        }
        patient_arr[size - remainingCapacity] = Patient(name, priority);
        remainingCapacity--;
    }

    bool Insert(string name, string priority)
    {
        if (remainingCapacity == 0)
        {
            cout << "No more space to add patients." << endl;
            return false;
        }

        if (priority == "low")
        {
            Add_to_last(name, priority);
        }
        else if (priority == "medium")
        {
            // Insert in the middle
            int mid = (size - remainingCapacity) / 2;
            for (int i = size - remainingCapacity; i > mid; i--)
            {
                patient_arr[i] = patient_arr[i - 1];
            }
            patient_arr[mid] = Patient(name, priority);
        }
        else if (priority == "high")
        {
            // Insert in front
            for (int i = size - remainingCapacity-1; i > 0; i--)
            {
                patient_arr[i] = patient_arr[i - 1];
            }
            Patient temp = Patient(name, priority);
            patient_arr[0] = temp;
        }
        else
        {
            cout << "Invalid priority." << endl;
            return false;
        }
        remainingCapacity--;
        return true;
    }

    bool Remove(int index)
    {
        if(index < 0 || index >= size - remainingCapacity)
        {
            cout << "Invalid index." << endl;
            return false;
        }

        for (int i = index; i < size - remainingCapacity - 1; i++)
        {
            patient_arr[i] = patient_arr[i + 1];
        }
        remainingCapacity++;
        return true;
    }

    void display_all_patients()
    {
        if (remainingCapacity == size)
        {
            cout << "No patients to display." << endl;
            return;
        }

        for (int i = 0; i < size - remainingCapacity-1; i++)
        {
            cout << "Patient Name: " << patient_arr[i].name << ", Priority: " << patient_arr[i].priority << endl;
        }
        cout << endl;
    }

    ~PatientList()
    {
        delete[] patient_arr;
    }
};

int main()
{
    PatientList patientList(10);
    patientList.Insert("P1", "high");
    patientList.Insert("P2", "medium");
    patientList.Insert("P3", "low");
    patientList.Insert("P4", "medium");
    patientList.Insert("P5", "high");

    patientList.Remove(2);

    patientList.display_all_patients();

    return 0;
}


// time complexity of the code is O(n)

