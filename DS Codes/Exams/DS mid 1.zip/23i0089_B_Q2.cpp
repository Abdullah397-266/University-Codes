#include <iostream>

using namespace std;

class Node
{
public:
	int personNo;
	Node* next = nullptr;

	Node(int perNo) : personNo(perNo) {}
};

class Queue
{
public:
	Node* front = nullptr;
	Node* rear = nullptr;
	int size = 0;

	void enqueue(int perNo)
	{
		Node* newNode = new Node(perNo);
		if (front == nullptr)
		{
			front = rear = newNode;
		}
		else
		{
			rear->next = newNode;
			rear = newNode;
		}
		size++;
	}

	void enqueue7Persons()
	{
		for (int i = 0; i < 7; i++)
		{
			enqueue(i);
		}
	}

	int dequeue()
	{
		if (front == nullptr)
		{
			cout << "Queue is already empty" << endl;
		}
		else if(size == 1)
		{
			int data = front->personNo;

			delete front;
			front = nullptr;
			rear = nullptr;
			size--;
			return data;
		}
		else
		{
			Node* backup = front;
			int data = backup->personNo;
			front = front->next;
			delete backup;
			size--;
			return data;
		}
	}

	int reverseDequeue()
	{
		if (front == nullptr)
		{
			cout << "Queue is already empty" << endl;
		}
		else if (size == 1)
		{
			int data = front->personNo;

			delete front;
			front = nullptr;
			rear = nullptr;
			size--;
			return data;
		}
		else
		{
			Node* temp = front;
			while (temp->next != rear)
			{
				delete temp->next;
				rear = temp;
			}
			size--;
		}
	}


	Node* peekFront()
	{
		return front;
	}

	Node* peekRear()
	{
		return rear;
	}

	bool isEmpty()
	{
		return size == 0;
	}

	~Queue()
	{
		while (!isEmpty())
		{
			dequeue();
		}
	}
};

class QNode
{
public:
	Queue q;
	QNode* next = nullptr;

	QNode(Queue que) : q(que) {}
};

class QStack
{
public:

	QNode* top;
	int size = 0;

	void push(Queue q)
	{
		if (top == nullptr)
		{
			QNode* newNode = new QNode(q);
			top = newNode;
			size++;
			return;
		}

		QNode* newNode = new QNode(q);
		newNode->next = top;
		top = newNode;
		size++;
	}

	bool isEmpty()
	{
		return size == 0;
	}

	Queue pop()
	{
		if (!isEmpty())
		{
			QNode* backup = top;
			Queue data = backup->q;
			top = top->next;
			delete backup;
			size--;
			return data;
		}
		else
		{
			cout << "Stack enpty!" << endl;
		}
	}

	Queue peek()
	{
		return top->q;
	}

	/*void printStack()
	{
		QNode* temp = top;

		while (temp != nullptr)
		{
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
	}

	~Stack()
	{
		while (!isEmpty())
		{
			pop();
		}
	}*/
};

int main()
{
	int n;
	cout << "Enter no of queues: ";
	cin >> n;

	// pushing q's to stack
	QStack s;
	for (int i = 0; i < n; i++)
	{
		Queue q;
		q.enqueue7Persons();
		s.push(q);
	}

	// processing line
	for (int i = 0; i < n; i++)
	{
		Queue q = s.pop();

		if(i%2==0)
		{
			for (int i = 0; i < 7; i++)
			{
				q.dequeue();
			}
		}
		else
		{
			for (int i = 0; i < 7; i++)
			{
				q.reverseDequeue();
			}
		}
	}

	cout << endl;
}