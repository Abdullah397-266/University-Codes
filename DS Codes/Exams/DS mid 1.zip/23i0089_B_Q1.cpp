#include <iostream>

using namespace std;

string refine(string str);

class Stack
{
public:
	struct Node
	{
		string data;

		Node* next = nullptr;

		Node(string dta) : data(dta) {}
	};

	Node* top;
	int size = 0;

	void push(string dta)
	{
		if (top == nullptr)
		{
			Node* newNode = new Node(dta);
			top = newNode;
			size++;
			return;
		}

		Node* newNode = new Node(dta);
		newNode->next = top;
		top = newNode;
		size++;
	}

	bool isEmpty()
	{
		return size == 0;
	}

	string pop()
	{
		if (!isEmpty())
		{
			Node* backup = top;
			string data = backup->data;
			top = top->next;
			delete backup;
			size--;
			return data;
		}
		else
		{
			cout << "Stack enpty!" << endl;
		}
	}

	string peek()
	{
		return top->data;
	}

	void printStack()
	{
		Node* temp = top;

		while (temp!=nullptr)
		{
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
	}

	~Stack()
	{
		while (!isEmpty())
		{
			pop();
		}
	}
};

int main()
{
	string msg = "Kindness is what defines humanity!!!";

	msg = refine(msg);

	cout << "Refined: " << msg << endl;

	Stack s;

	// pushing to stack
	string word = "";
	int i = 0;
	while (true)
	{
		if (msg[i] == ' ' || msg[i] == '\0')
		{
			if (word == "")
			{
				i++;
				continue;
			}

			s.push(word);
			word = "";

			if (msg[i] == '\0')
			{
				break;
			}
		}
		else
		{
			word += msg[i];
		}
		i++;
	}

	//cout << "stack size: " << s.size << endl;

	cout << "Result = ";
	s.printStack();
}

string refine(string str)
{
	string refined = "";
	for (char ch : str)
	{
		if (ch == '!' || ch == ',' || ch == '@' || ch == '(' || ch == ')' || ch == '?' || ch == '.' || ch==':' || ch == ';' || ch == '\'' || ch == '\"')
		{
			continue;
		}
		else
		{
			refined += ch;
		}
	}

	return refined;
}