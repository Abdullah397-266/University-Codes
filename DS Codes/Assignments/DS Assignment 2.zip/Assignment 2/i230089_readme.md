# Blind Maze Adventure Game

Welcome to the **Blind Maze Adventure Game**! This is a unique 2D maze game where players navigate through a maze without sight, relying solely on hints about their proximity to the key and the exit door. The player can collect coins, avoid bombs, and unlock doors to progress through multiple levels of increasing difficulty.

## Table of Contents
- [Introduction](#introduction)
- [Key Features](#key-features)
- [Game Mechanics](#game-mechanics)
- [How to Run the Game](#how-to-run-the-game)
- [Sample Outputs](#sample-outputs)

## Introduction

The Blind Maze Adventure Game challenges players to find a hidden key to unlock the exit door while collecting coins along the way. With a unique sensing mechanic, players receive hints to guide their movements. This game is built using C++ and demonstrates principles of game design, including state management, grid navigation, and user interaction.

## Key Features

- **Unique Gameplay**: Navigate through the maze without seeing the layout. Players rely on hints about their distance to the key and exit door.
- **Multiple Levels**: Three difficulty levels with varying maze sizes and challenges.
- **Collectibles**: Gather coins to increase your score while avoiding bombs that end your game.
- **Undo Functionality**: Players can undo their last move by pressing `U`, providing a second chance to strategize.
- **Dynamic Coin Respawn**: Coins are relocated every 30 seconds, increasing gameplay engagement.

## Game Mechanics

- **Player Movement**: Use the `W`, `A`, `S`, and `D` keys to move up, left, down, and right, respectively. The player has a limited number of moves.
- **Hints**: Players receive hints indicating whether they are getting closer to the key or farther away.
- **Winning and Losing**: Collect the key to unlock the door and win the game. Hitting a bomb results in game over.
- **Scoring**: Collecting coins increases your score, while using undo moves decreases it.

## How to Run the Game

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/Abdullah397-266/DS-Assignment-2.git

2. **Navigate to the Project Directory**:
   ```bash
   cd DS-Assignment-2

3. **Compile the Code**:
   ```bash
   g++ -o BlindMazeAdventure game.cpp

4. **Run the game**:
   ```bash
   ./BlindMazeAdventure

## Sample Outputs
Here are some screenshots demonstrating the game in action:

![Menu](https://raw.githubusercontent.com/Abdullah397-266/DS-Assignment-2/master/screenshots/menu.PNG)
*Menu of the game.*

![Game](https://raw.githubusercontent.com/Abdullah397-266/DS-Assignment-2/master/screenshots/game.PNG)
*Interface of the game.*

![Game Over](https://raw.githubusercontent.com/Abdullah397-266/DS-Assignment-2/master/screenshots/game-over.PNG)
*The player is out of moves and the game ends.*
