#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Node
{
public:
    int x, y;
    char value;
    Node *left;
    Node *right;
    Node *up;
    Node *down;
    Node *next; // for stack

    Node(int xPos, int yPos, char val = '.') : x(xPos), y(yPos), value(val), left(nullptr), right(nullptr), up(nullptr), down(nullptr), next(nullptr) {}
    Node(Node *nd)
    {
        x = nd->x;
        y = nd->y;
        value = nd->value;
        left = nd->left;
        right = nd->right;
        up = nd->up;
        down = nd->down;
        next = nd->next;
    }
};

int manhattanDistance(Node *a, Node *b);

class Q_Node
{
public:
    int x;
    int y;
    Q_Node *next = nullptr;

    Q_Node(int xcor, int ycor) : x(xcor), y(ycor) {}
};

class Queue
{
public:
    Q_Node *front;
    Q_Node *rear;
    int size = 0;

    Queue() : front(nullptr), rear(nullptr) {}

    void enqueue(int x, int y)
    {
        Q_Node *newNode = new Q_Node(x, y);
        if (isEmpty())
        {
            front = rear = newNode;
        }
        else
        {
            rear->next = newNode;
            rear = newNode;
        }
        size++;
    }

    void dequeue()
    {
        if (isEmpty())
        {
            cout << "Queue is empty, cannot dequeue." << endl;
            return;
        }
        Q_Node *temp = front;
        front = front->next;

        if (front == nullptr)
        {
            rear = nullptr;
        }
        size--;
        delete temp;
    }

    Q_Node *getFront()
    {
        if (isEmpty())
        {
            cout << "Queue is empty." << endl;
            return nullptr;
        }
        return front;
    }

    Q_Node *getRear()
    {
        if (isEmpty())
        {
            cout << "Queue is empty." << endl;
            return nullptr;
        }
        return rear;
    }

    bool isEmpty()
    {
        return front == nullptr;
    }

    friend ostream &operator<<(ostream &os, Queue &q)
    {
        if (q.isEmpty())
        {
            os << "NULL, No coins collected";
            return os;
        }

        Q_Node *current = q.front;
        while (current != nullptr)
        {
            os << "(" << current->x << ", " << current->y << ") ";
            current = current->next;
        }
        return os;
    }

    ~Queue()
    {
        while (!isEmpty())
        {
            dequeue();
        }
        size = 0;
    }
};

class MazeGrid
{
public:
    Node *head;
    int rows, cols;

    MazeGrid(int r, int c) : rows(r), cols(c)
    {
        head = createGrid();
    }

    Node *createGrid()
    {
        Node *grid[rows][cols];

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                grid[i][j] = new Node(i, j);
            }
        }

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (i > 0)
                {
                    grid[i][j]->up = grid[i - 1][j];
                    grid[i - 1][j]->down = grid[i][j];
                }
                if (j > 0)
                {
                    grid[i][j]->left = grid[i][j - 1];
                    grid[i][j - 1]->right = grid[i][j];
                }
            }
        }

        // returning head
        return grid[0][0];
    }

    void displayGrid()
    {
        Node *rowPtr = head;
        for (int i = -1; i < rows + 1; i++)
        {
            Node *colPtr = rowPtr;
            for (int j = -1; j < cols + 1; j++)
            {
                if (i == -1 || j == -1 || i == rows || j == cols)
                {
                    cout << "#" << " ";
                    continue;
                }
                // commenting this for testing
                if (colPtr->value == 'K' || colPtr->value == 'D' || colPtr->value == 'B') // key, door and bomb
                {
                    cout << "." << " ";
                }
                else
                {
                    cout << colPtr->value << " ";
                }
                colPtr = colPtr->right;
            }

            if (i != -1 && i != rows)
                rowPtr = rowPtr->down;
            cout << endl;
        }
    }

    Node *getNodeAt(int x, int y)
    {
        Node *current = head;
        for (int i = 0; i < x; i++)
            current = current->down;
        for (int j = 0; j < y; j++)
            current = current->right;
        return current;
    }
};

class Player
{
public:
    Node *currentNode;
    Node *prevNode = nullptr;
    int remainingMoves;
    int coinsCollected = 0;
    Queue coinQ;
    bool hasKey = false;
    bool gettingCloser = true;
    bool coinFlag = false;
    char symbol;

    Player(Node *start, int moves) : currentNode(start), remainingMoves(moves)
    {
        currentNode->value = 'P';
    }

    bool move(char dir, bool &win)
    {
        Node *nextNodee = nullptr;

        if (dir == 'w' && currentNode->up)
            nextNodee = currentNode->up;
        else if (dir == 's' && currentNode->down)
            nextNodee = currentNode->down;
        else if (dir == 'a' && currentNode->left)
            nextNodee = currentNode->left;
        else if (dir == 'd' && currentNode->right)
            nextNodee = currentNode->right;

        if (nextNodee != nullptr)
        {
            if (nextNodee->value == 'B')
            {
                system("CLS");
                cout << "\nGame over! You hit the bomb!" << endl;
                win = true;
                return false;
            }

            if (nextNodee->value == 'K')
            {
                hasKey = true;
                cout << "You collected the key!" << endl;
            }

            if (nextNodee->value == 'D' && hasKey == true)
            {
                system("CLS");
                cout << "\nCongrats! You unlocked the door and won the game :)" << endl;
                win = true;
                return false;
            }
            else if (nextNodee->value == 'D')
            {
                cout << "You need the key to unlock the door!" << endl;
                return true;
            }

            symbol = nextNodee->value;
            currentNode->value = '.';
            prevNode = currentNode;
            currentNode = nextNodee;
            if (checkForCoin(nextNodee))
            {
                coinFlag = true;
            }
            currentNode->value = 'P';
            remainingMoves--;
        }
        else
        {
            cout << "Invalid move!" << endl;
        }

        return true;
    }

    bool checkForCoin(Node *node)
    {
        if (symbol == 'C')
        {
            int coinX, coinY;
            coinX = node->x;
            coinY = node->y;
            coinQ.enqueue(coinX, coinY);

            coinsCollected++;
            currentNode->value = 'P';
            // cout << "Coin collected!" << endl;
            return true;
        }
        return false;
    }

    void senseDistance(Node *keyORdoor)
    {
        int prevDist = manhattanDistance(prevNode, keyORdoor);
        int currDist = manhattanDistance(currentNode, keyORdoor);
        if (prevDist < currDist)
        {
            cout << "Hint: Getting Farther" << endl;
        }
        else
        {
            cout << "Hint: Getting Closer" << endl;
        }
    }
};

class NodeStack
{
public:
    Node *top = nullptr;
    int size = 0;

    void push(Node *nd)
    {
        Node *newNode = new Node(nd);
        newNode->next = top;
        top = newNode;
        size++;
    }

    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack is alreaady empty\n";
        }
        else
        {
            Node *temp = top;
            top = top->next;
            delete temp;
            size--;
        }
    }

    Node *peek()
    {
        if (isEmpty())
        {
            cout << "Stack is Empty\n";
            return nullptr;
        }
        return top;
    }

    bool isEmpty()
    {
        return size == 0;
    }

    void wipeStack()
    {
        while (!isEmpty())
        {
            pop();
        }
        size = 0;
    }

    ~NodeStack()
    {
        while (!isEmpty())
        {
            pop();
        }
        size = 0;
    }
};

class Game
{
public:
    int level;
    int rows, cols;
    int extraMoves;
    int undos;
    int score;
    NodeStack undoStack;
    time_t coinStartTime;
    bool win = false;
    char **initialBoard;

    Game(int lvl) : level(lvl) { initializeLevel(); }

    void initializeLevel()
    {
        if (level == 1)
        {
            rows = cols = 10;
            extraMoves = 6;
            undos = 6;
            score = 0;
            undoStack.wipeStack();
            startLevel1();
        }
        else if (level == 2)
        {
            rows = cols = 15;
            extraMoves = 2;
            undos = 4;
            score = 0;
            undoStack.wipeStack();
            startLevel2();
        }
        else
        {
            rows = cols = 20;
            extraMoves = 0;
            undos = 1;
            score = 0;
            undoStack.wipeStack();
            startLevel3();
        }
    }

    void startLevel1()
    {
        srand(time(0));

        MazeGrid maze(rows, cols);

        int startX = rand() % rows;
        int startY = rand() % cols;
        Node *startNode = maze.getNodeAt(startX, startY);

        int keyX = rand() % rows;
        int keyY = rand() % cols;
        maze.getNodeAt(keyX, keyY)->value = 'K';
        Node *keyNode = maze.getNodeAt(keyX, keyY);

        int doorX = rand() % rows;
        int doorY = rand() % cols;
        maze.getNodeAt(doorX, doorY)->value = 'D';
        Node *doorNode = maze.getNodeAt(doorX, doorY);

        int bombX = rand() % rows;
        int bombY = rand() % cols;
        maze.getNodeAt(bombX, bombY)->value = 'B';

        const int coinCount = 2;
        int coinX[coinCount];
        int coinY[coinCount];
        for (int i = 0; i < coinCount; i++)
        {
            do
            {
                coinX[i] = rand() % rows;
                coinY[i] = rand() % cols;
            } while ((coinX[i] == startX && coinY[i] == startY) || (coinX[i] == keyX && coinY[i] == keyY) || (coinX[i] == doorX && coinY[i] == doorY) || (coinX[i] == bombX && coinY[i] == bombY));
            maze.getNodeAt(coinX[i], coinY[i])->value = 'C';
        }
        coinStartTime = time(nullptr);

        int initialMoves = manhattanDistance(startNode, maze.getNodeAt(keyX, keyY)) + manhattanDistance(maze.getNodeAt(keyX, keyY), maze.getNodeAt(doorX, doorY)) + extraMoves;

        Player player(startNode, initialMoves);

        system("CLS");
        maze.displayGrid();
        saveBoard(maze);

        while (player.remainingMoves > 0)
        {
            if (time(nullptr) - coinStartTime >= 30) // 30 sec
            {
                for (int i = 0; i < coinCount; i++)
                {
                    maze.getNodeAt(coinX[i], coinY[i])->value = '.';
                    do
                    {
                        coinX[i] = rand() % rows;
                        coinY[i] = rand() % cols;
                    } while ((coinX[i] == startX && coinY[i] == startY) || (coinX[i] == keyX && coinY[i] == keyY) || (coinX[i] == doorX && coinY[i] == doorY) || (coinX[i] == bombX && coinY[i] == bombY));

                    maze.getNodeAt(coinX[i], coinY[i])->value = 'C';
                }
                coinStartTime = time(nullptr); // reset timer
                cout << "coin respawned at a new location" << endl;
            }

            char direction;
            cout << "Enter direction [w|a|s|d|u(undo)]: ";
            cin >> direction;

            if (direction != 'u')
            {
                if (!player.move(direction, win))
                {
                    showStats(player);

                    break; // game over
                }
                undoStack.push(player.prevNode);
            }
            else // undo move
            {
                undoMove(player);
            }

            system("CLS");
            maze.displayGrid();
            cout << "Remaining moves: " << player.remainingMoves << endl;
            cout << "Coins collected: " << player.coinsCollected << endl;
            if (player.coinFlag == true)
            {
                // cout << "Coin collected!" << endl;
                undos++;
                score += 2;
                player.coinFlag = false;
            }
            cout << "Remaining Undo's: " << undos << endl;
            cout << "Score: " << score << endl;

            if (player.hasKey)
            {
                player.senseDistance(doorNode);
                cout << "Has-Key: YES" << endl;
            }
            else
            {
                player.senseDistance(keyNode);
                cout << "Has-Key: NO" << endl;
            }

            if (player.remainingMoves <= 0)
            {
                system("CLS");
                cout << "Game over! Not enough moves left." << endl;
                showStats(player);
                break;
            }
        }
    }

    void startLevel2()
    {
        srand(time(0));

        MazeGrid maze(rows, cols);

        int startX = rand() % rows;
        int startY = rand() % cols;
        Node *startNode = maze.getNodeAt(startX, startY);

        int keyX = rand() % rows;
        int keyY = rand() % cols;
        maze.getNodeAt(keyX, keyY)->value = 'K';
        Node *keyNode = maze.getNodeAt(keyX, keyY);

        int doorX = rand() % rows;
        int doorY = rand() % cols;
        maze.getNodeAt(doorX, doorY)->value = 'D';
        Node *doorNode = maze.getNodeAt(doorX, doorY);

        int bombX = rand() % rows;
        int bombY = rand() % cols;
        maze.getNodeAt(bombX, bombY)->value = 'B';

        const int coinCount = 4;
        int coinX[coinCount];
        int coinY[coinCount];
        for (int i = 0; i < coinCount; i++)
        {
            do
            {
                coinX[i] = rand() % rows;
                coinY[i] = rand() % cols;
            } while ((coinX[i] == startX && coinY[i] == startY) || (coinX[i] == keyX && coinY[i] == keyY) || (coinX[i] == doorX && coinY[i] == doorY) || (coinX[i] == bombX && coinY[i] == bombY));
            maze.getNodeAt(coinX[i], coinY[i])->value = 'C';
        }
        coinStartTime = time(nullptr);

        int initialMoves = manhattanDistance(startNode, maze.getNodeAt(keyX, keyY)) + manhattanDistance(maze.getNodeAt(keyX, keyY), maze.getNodeAt(doorX, doorY)) + extraMoves;

        Player player(startNode, initialMoves);

        system("CLS");
        maze.displayGrid();
        saveBoard(maze);

        while (player.remainingMoves > 0)
        {
            if (time(nullptr) - coinStartTime >= 30) // 30 seconds
            {
                for (int i = 0; i < coinCount; i++)
                {
                    maze.getNodeAt(coinX[i], coinY[i])->value = '.';
                    do
                    {
                        coinX[i] = rand() % rows;
                        coinY[i] = rand() % cols;
                    } while ((coinX[i] == startX && coinY[i] == startY) || (coinX[i] == keyX && coinY[i] == keyY) || (coinX[i] == doorX && coinY[i] == doorY) || (coinX[i] == bombX && coinY[i] == bombY));

                    maze.getNodeAt(coinX[i], coinY[i])->value = 'C';
                }
                coinStartTime = time(nullptr); // reset timer
                cout << "coin respawned at a new location" << endl;
            }

            char direction;
            cout << "Enter direction [w|a|s|d|u(undo)]: ";
            cin >> direction;

            if (direction != 'u')
            {
                if (!player.move(direction, win))
                {
                    showStats(player);

                    break; // game win
                }
                undoStack.push(player.prevNode);
            }
            else // undo move
            {
                undoMove(player);
            }

            system("CLS");
            maze.displayGrid();
            cout << "Remaining moves: " << player.remainingMoves << endl;
            cout << "Coins collected: " << player.coinsCollected << endl;
            if (player.coinFlag == true)
            {
                // cout << "Coin collected!" << endl;
                undos++;
                score += 2;
                player.coinFlag = false;
            }
            cout << "Remaining Undo's: " << undos << endl;
            cout << "Score: " << score << endl;

            if (player.hasKey)
            {
                player.senseDistance(doorNode);
                cout << "Has-Key: YES" << endl;
            }
            else
            {
                player.senseDistance(keyNode);
                cout << "Has-Key: NO" << endl;
            }

            if (player.remainingMoves <= 0)
            {
                system("CLS");
                cout << "Game over! Not enough moves left." << endl;
                showStats(player);
                break;
            }
        }
    }

    void startLevel3()
    {
        srand(time(0));

        MazeGrid maze(rows, cols);

        int startX = rand() % rows;
        int startY = rand() % cols;
        Node *startNode = maze.getNodeAt(startX, startY);

        int keyX = rand() % rows;
        int keyY = rand() % cols;
        maze.getNodeAt(keyX, keyY)->value = 'K';
        Node *keyNode = maze.getNodeAt(keyX, keyY);

        int doorX = rand() % rows;
        int doorY = rand() % cols;
        maze.getNodeAt(doorX, doorY)->value = 'D';
        Node *doorNode = maze.getNodeAt(doorX, doorY);

        int bombX = rand() % rows;
        int bombY = rand() % cols;
        maze.getNodeAt(bombX, bombY)->value = 'B';

        const int coinCount = 6;
        int coinX[coinCount];
        int coinY[coinCount];
        for (int i = 0; i < coinCount; i++)
        {
            do
            {
                coinX[i] = rand() % rows;
                coinY[i] = rand() % cols;
            } while ((coinX[i] == startX && coinY[i] == startY) || (coinX[i] == keyX && coinY[i] == keyY) || (coinX[i] == doorX && coinY[i] == doorY) || (coinX[i] == bombX && coinY[i] == bombY));
            maze.getNodeAt(coinX[i], coinY[i])->value = 'C';
        }
        coinStartTime = time(nullptr);

        int initialMoves = manhattanDistance(startNode, maze.getNodeAt(keyX, keyY)) + manhattanDistance(maze.getNodeAt(keyX, keyY), maze.getNodeAt(doorX, doorY)) + extraMoves;

        Player player(startNode, initialMoves);

        system("CLS");
        maze.displayGrid();
        saveBoard(maze);

        while (player.remainingMoves > 0)
        {
            if (time(nullptr) - coinStartTime >= 30) // 30 seconds
            {
                for (int i = 0; i < coinCount; i++)
                {
                    maze.getNodeAt(coinX[i], coinY[i])->value = '.';
                    do
                    {
                        coinX[i] = rand() % rows;
                        coinY[i] = rand() % cols;
                    } while ((coinX[i] == startX && coinY[i] == startY) || (coinX[i] == keyX && coinY[i] == keyY) || (coinX[i] == doorX && coinY[i] == doorY) || (coinX[i] == bombX && coinY[i] == bombY));

                    maze.getNodeAt(coinX[i], coinY[i])->value = 'C';
                }
                coinStartTime = time(nullptr); // reset timer
                cout << "coin respawned at a new location" << endl;
            }

            char direction;
            cout << "Enter direction [w/a/s/d/u(undo)]: ";
            cin >> direction;

            if (direction != 'u')
            {
                if (!player.move(direction, win))
                {
                    showStats(player);

                    break; // game over
                }
                undoStack.push(player.prevNode);
            }
            else // undo move
            {
                undoMove(player);
            }

            system("CLS");
            maze.displayGrid();
            cout << "Remaining moves: " << player.remainingMoves << endl;
            cout << "Coins collected: " << player.coinsCollected << endl;
            if (player.coinFlag == true)
            {
                // cout << "Coin collected!" << endl;
                undos++;
                score += 2;
                player.coinFlag = false;
            }
            cout << "Remaining Undo's: " << undos << endl;
            cout << "Score: " << score << endl;

            if (player.hasKey)
            {
                player.senseDistance(doorNode);
                cout << "Has-Key: YES" << endl;
            }
            else
            {
                player.senseDistance(keyNode);
                cout << "Has-Key: NO" << endl;
            }

            if (player.remainingMoves <= 0)
            {
                system("CLS");
                cout << "Game over! Not enough moves left." << endl;
                showStats(player);
                break;
            }
        }
    }

    void undoMove(Player &player)
    {
        if (undoStack.size > 0 && undos > 0)
        {
            Node *prevNode = undoStack.peek();
            undoStack.pop();

            // settong the current node to its prev value
            char symbol = player.symbol;
            player.currentNode->value = symbol;

            prevNode->value = 'P';
            player.currentNode = prevNode; // going back
            player.currentNode->value = 'P';

            if (symbol == 'K')
            {
                player.hasKey = false;
            }
            else if (symbol == 'C')
            {
                undos--;
                score--;
                player.coinsCollected--;
                player.coinFlag = false;
            }
            player.remainingMoves++;
            undos--;
        }
        else
        {
            cout << "Cannot UNDO!" << endl;
        }
    }

    void saveBoard(MazeGrid &maze)
    {
        initialBoard = new char *[rows];
        for (int i = 0; i < rows; i++)
        {
            initialBoard[i] = new char[cols];
            for (int j = 0; j < cols; j++)
            {
                initialBoard[i][j] = maze.getNodeAt(i, j)->value;
            }
        }
    }

    void printInitialBoard()
    {
        cout << "\nInitial Board State:\n";
        for (int i = -1; i < rows + 1; i++)
        {
            for (int j = -1; j < cols + 1; j++)
            {
                if (i == -1 || j == -1 || i == rows || j == cols)
                    cout << '#' << " ";
                else
                    cout << initialBoard[i][j] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }

    void showStats(Player &player)
    {
        if (win)
        {
            score += player.remainingMoves;
            player.remainingMoves = 0;
        }
        cout << "\nYour stats are: \n";
        // cout << "  Remaining moves: " << player.remainingMoves << endl;
        cout << "  Coins collected: " << player.coinsCollected << endl;
        cout << "  Coins Order: " << player.coinQ << endl;
        cout << "  Remaining Undo's: " << undos << endl;
        cout << "  Score: " << score << endl;
        cout << endl;

        printInitialBoard();
    }

    ~Game()
    {
        for (int i = 0; i < rows; i++)
        {
            delete[] initialBoard[i];
        }
        delete[] initialBoard;
    }
};

int main()
{
    system("CLS");
    cout << endl << endl;
    int lvl = 0;
    cout << "----------------- WELCOME TO THE GAME -----------------" << endl;
    cout << "\nChoose your Difficulty:\n  1: Easy\n  2: Medium\n  3: Hard\n\nEnter: ";
    cin >> lvl;
    while (lvl < 1 || lvl > 3)
    {
        cout << "Invalid Choice!" << endl;
        cout << "Enter (1-3): ";
        cin >> lvl;
    }
    Game game(lvl);
}

int manhattanDistance(Node *a, Node *b)
{
    int dist = abs(a->x - b->x) + abs(a->y - b->y);
    return dist;
}