#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <random>

using namespace std;

template <typename T>
class queue
{
public:
    struct Node
    {
        T data;
        Node *next;

        Node(T value) : data(value), next(nullptr) {}
    };

    Node *frontNode;
    Node *rearNode;
    int size;

    // Constructor to initialize the queue
    queue() : frontNode(nullptr), rearNode(nullptr), size(0) {}

    // Destructor to free up the memory
    ~queue()
    {
        clear();
    }

    // Function to check if the queue is empty
    bool empty() const
    {
        return size == 0;
    }

    // Function to get the size of the queue
    int getSize() const
    {
        return size;
    }

    // Function to get the front element of the queue
    T &front() const
    {
        if (empty())
        {
            throw runtime_error("Queue is empty.");
        }
        return frontNode->data;
    }

    // Function to get the rear element of the queue
    T &rear() const
    {
        if (empty())
        {
            throw runtime_error("Queue is empty.");
        }
        return rearNode->data;
    }

    // Function to add an element to the queue
    void push(T value)
    {
        Node *newNode = new Node(value);
        if (empty())
        {
            frontNode = rearNode = newNode;
        }
        else
        {
            rearNode->next = newNode;
            rearNode = newNode;
        }
        size++;
    }

    // Function to remove an element from the queue
    void pop()
    {
        if (empty())
        {
            cout << "Queue is empty." << endl;
            return;
        }
        Node *temp = frontNode;
        frontNode = frontNode->next;
        delete temp;
        size--;

        if (size == 0)
        {
            rearNode = nullptr;
        }
    }

    // Function to display the elements of the queue
    void display() const
    {
        if (empty())
        {
            cout << "Queue is empty." << endl;
            return;
        }
        Node *temp = frontNode;
        while (temp)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    // Function to clear the queue
    void clear()
    {
        while (!empty())
        {
            pop();
        }
    }
};

class LLNode
{
public:
    int noOfGames;
    string PlayerID;
    LLNode *next;

    LLNode(int games, string id) : noOfGames(games), PlayerID(id), next(nullptr) {}
};
class LL
{
public:
    LLNode *head;

    LL() : head(nullptr) {}

    void insert(int games, string id)
    {
        LLNode *newNode = new LLNode(games, id);

        if (head == nullptr || head->noOfGames < games)
        {
            newNode->next = head;
            head = newNode;
        }
        else
        {
            LLNode *current = head;
            while (current->next != nullptr && current->next->noOfGames >= games)
            {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }
    }

    void display(int N)
    {
        LLNode *current = head;
        while (current != nullptr && (N-- > 0))
        {
            cout << "Player ID: " << current->PlayerID << ", Games: " << current->noOfGames << endl;
            current = current->next;
        }
    }

    ~LL()
    {
        LLNode *current = head;
        while (current != nullptr)
        {
            LLNode *temp = current;
            current = current->next;
            delete temp;
        }
    }
};

class GameNode
{
public:
    string game_id;
    string name;
    string developer;
    string publisher;
    float file_size_GB;
    int downloads;
    GameNode *left;
    GameNode *right;

    GameNode(const string &id, const string &n, const string &dev, const string &pub, float size, int dl)
        : game_id(id), name(n), developer(dev), publisher(pub), file_size_GB(size), downloads(dl), left(nullptr), right(nullptr) {}
};
class GameTree
{
public:
    GameNode *root;

    GameTree() : root(nullptr) {}

    GameNode *insertGame(GameNode *node, GameNode *game)
    {
        if (!node)
            return game;

        if (game->game_id < node->game_id)
            node->left = insertGame(node->left, game);
        else if (game->game_id > node->game_id)
            node->right = insertGame(node->right, game);
        else
            cout << "Error: Game ID already exists." << endl;

        return node;
    }

    void insert(const string &id, const string &name, const string &dev, const string &pub, float size, int downloads)
    {
        root = insertGame(root, new GameNode(id, name, dev, pub, size, downloads));
    }

    GameNode *searchGame(const string &game_id, GameNode *node)
    {
        if (!node || node->game_id == game_id)
            return node;
        if (game_id < node->game_id)
            return searchGame(game_id, node->left);
        return searchGame(game_id, node->right);
    }

    string gameName(string &game_id)
    {
        GameNode *game = searchGame(game_id, root);
        if (game)
            return game->name;
        return "Error: Game ID not found.";
    }

    GameNode *deleteGame(GameNode *node, const string &game_id)
    {
        if (!node)
            return nullptr;

        if (game_id < node->game_id)
            node->left = deleteGame(node->left, game_id);
        else if (game_id > node->game_id)
            node->right = deleteGame(node->right, game_id);
        else
        {
            if (!node->left)
            {
                GameNode *temp = node->right;
                delete node;
                return temp;
            }
            else if (!node->right)
            {
                GameNode *temp = node->left;
                delete node;
                return temp;
            }

            GameNode *temp = node->right;
            while (temp && temp->left)
                temp = temp->left;

            node->game_id = temp->game_id;
            node->name = temp->name;
            node->developer = temp->developer;
            node->publisher = temp->publisher;
            node->file_size_GB = temp->file_size_GB;
            node->downloads = temp->downloads;
            node->right = deleteGame(node->right, temp->game_id);
        }
        return node;
    }

    void wipeTree(GameNode *node)
    {
        if (node)
        {
            wipeTree(node->left);
            wipeTree(node->right);
            delete node;
        }
    }

    void levelOrderTraversal(GameNode *node)
    {
        if (!node)
            return;

        queue<GameNode *> q;
        q.push(node);

        while (!q.empty())
        {
            GameNode *current = q.front();
            q.pop();

            cout << "Game ID: " << current->game_id << ", Name: " << current->name << endl;

            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
    }
};

class GamesPlayedNode
{
public:
    string game_id;
    float hours_played;
    int achievements_unlocked;
    GamesPlayedNode *left;
    GamesPlayedNode *right;

    GamesPlayedNode(const string &id, float hours, int achievements)
        : game_id(id), hours_played(hours), achievements_unlocked(achievements), left(nullptr), right(nullptr) {}
};
class GamesPlayedTree
{
public:
    GamesPlayedNode *root;

    GamesPlayedTree() : root(nullptr) {}

    GamesPlayedNode *insert(GamesPlayedNode *node, const string &id, float hours, int achievements)
    {
        if (!node)
            return new GamesPlayedNode(id, hours, achievements);

        if (id < node->game_id)
            node->left = insert(node->left, id, hours, achievements);
        else if (id > node->game_id)
            node->right = insert(node->right, id, hours, achievements);
        else
            cout << "Error: Game ID already exists." << endl;

        return node;
    }

    void insertPlayedGame(const string &id, float hours, int achievements)
    {
        root = insert(root, id, hours, achievements);
    }

    GamesPlayedNode *searchPlayedGame(const string &id, GamesPlayedNode *node)
    {
        if (!node || node->game_id == id)
            return node;
        if (id < node->game_id)
            return searchPlayedGame(id, node->left);
        return searchPlayedGame(id, node->right);
    }

    GamesPlayedNode *deletePlayedGame(GamesPlayedNode *node, const string &id)
    {
        if (!node)
            return nullptr;

        if (id < node->game_id)
            node->left = deletePlayedGame(node->left, id);
        else if (id > node->game_id)
            node->right = deletePlayedGame(node->right, id);
        else
        {
            if (!node->left)
            {
                GamesPlayedNode *temp = node->right;
                delete node;
                return temp;
            }
            else if (!node->right)
            {
                GamesPlayedNode *temp = node->left;
                delete node;
                return temp;
            }

            GamesPlayedNode *temp = node->right;
            while (temp && temp->left)
                temp = temp->left;

            node->game_id = temp->game_id;
            node->hours_played = temp->hours_played;
            node->achievements_unlocked = temp->achievements_unlocked;
            node->right = deletePlayedGame(node->right, temp->game_id);
        }
        return node;
    }

    void wipeTree(GamesPlayedNode *node)
    {
        if (node)
        {
            wipeTree(node->left);
            wipeTree(node->right);
            delete node;
        }
    }

    void levelOrderTraversalGP(GamesPlayedNode *node)
    {
        if (!node)
            return;

        queue<GamesPlayedNode *> q;
        q.push(node);

        while (!q.empty())
        {
            GamesPlayedNode *current = q.front();
            q.pop();

            cout << "Game ID: " << current->game_id << ", Hours Played: " << current->hours_played << ", Achievements Unlocked: " << current->achievements_unlocked << endl;

            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
    }

    void printAllPlayedGames(GamesPlayedNode *node, GameTree *gameroot) // in-order
    {
        if (!node)
            return;

        printAllPlayedGames(node->left, gameroot);

        string gameName = gameroot->gameName(node->game_id);
        cout << "Game: " << gameName << ", Hours Played: " << node->hours_played << ", Achievements Unlocked: " << node->achievements_unlocked << endl;

        printAllPlayedGames(node->right, gameroot);
    }

    ~GamesPlayedTree()
    {
        wipeTree(root);
    }

    int countNodes(GamesPlayedNode *node)
    {
        if (!node)
            return 0;

        return 1 + countNodes(node->left) + countNodes(node->right);
    }

    GamesPlayedTree &operator=(const GamesPlayedTree &other)
    {
        if (this == &other)
            return *this;

        wipeTree(root);
        root = copyTree(other.root);

        return *this;
    }
    GamesPlayedNode *copyTree(GamesPlayedNode *node)
    {
        if (!node)
            return nullptr;

        GamesPlayedNode *newNode = new GamesPlayedNode(node->game_id, node->hours_played, node->achievements_unlocked);
        newNode->left = copyTree(node->left);
        newNode->right = copyTree(node->right);

        return newNode;
    }
};

class PlayerNode
{
public:
    string id;
    string name;
    string phoneNo;
    string email;
    string password;
    GamesPlayedTree *GamesPlayedRoot;
    PlayerNode *left;
    PlayerNode *right;

    PlayerNode(const string &pID, const string &n, const string &phone, const string &mail, const string &pass)
        : id(pID), name(n), phoneNo(phone), email(mail), password(pass), GamesPlayedRoot(new GamesPlayedTree()), left(nullptr), right(nullptr) {}

    ~PlayerNode()
    {
        delete GamesPlayedRoot;
    }

    PlayerNode &operator=(PlayerNode &other)
    {
        if (this == &other)
            return *this;

        id = other.id;
        name = other.name;
        phoneNo = other.phoneNo;
        email = other.email;
        password = other.password;
        GamesPlayedRoot = other.GamesPlayedRoot;
        left = other.left;
        right = other.right;

        return *this;
    }
};
class PlayerTree
{
public:
    PlayerNode *root;
    int height;

    PlayerTree() : root(nullptr), height(0) {}

    PlayerNode *insertPlayer(PlayerNode *node, PlayerNode *player)
    {
        if (!node)
            return player;

        if (player->id < node->id)
            node->left = insertPlayer(node->left, player);
        else if (player->id > node->id)
            node->right = insertPlayer(node->right, player);
        else
            cout << "Error: Player ID already exists." << endl;

        updateHeight(root);
        return node;
    }

    PlayerNode *searchPlayer(const string &player_id, PlayerNode *node)
    {
        if (!node || node->id == player_id)
            return node;
        if (player_id < node->id)
            return searchPlayer(player_id, node->left);
        return searchPlayer(player_id, node->right);
    }

    PlayerNode *deletePlayer(PlayerNode *node, const string &player_id)
    {
        if (!node)
            return nullptr;

        if (player_id < node->id)
            node->left = deletePlayer(node->left, player_id);
        else if (player_id > node->id)
            node->right = deletePlayer(node->right, player_id);
        else
        {
            if (!node->left)
            {
                PlayerNode *temp = node->right;
                delete node;
                return temp;
            }
            else if (!node->right)
            {
                PlayerNode *temp = node->left;
                delete node;
                return temp;
            }

            PlayerNode *temp = node->right;
            while (temp && temp->left)
                temp = temp->left;

            node->id = temp->id;
            node->name = temp->name;
            node->phoneNo = temp->phoneNo;
            node->email = temp->email;
            node->password = temp->password;
            node->GamesPlayedRoot = temp->GamesPlayedRoot;
            node->right = deletePlayer(node->right, temp->id);
        }
        updateHeight(root);
        return node;
    }

    void wipeTree(PlayerNode *node)
    {
        if (node)
        {
            wipeTree(node->left);
            wipeTree(node->right);
            delete node;
        }
        height = 0;
    }

    void updateHeight(PlayerNode *root)
    {
        height = calculateHeight(root);
    }

    int calculateHeight(PlayerNode *node)
    {
        if (!node)
            return 0;

        return 1 + max(calculateHeight(node->left), calculateHeight(node->right));
    }

    void levelOrderTraversalPT(PlayerNode *node)
    {
        if (!node)
            return;

        queue<PlayerNode *> q;
        q.push(node);

        while (!q.empty())
        {
            PlayerNode *current = q.front();
            q.pop();

            cout << "Player ID: " << current->id
                 << ", Name: " << current->name
                 << ", Phone: " << current->phoneNo
                 << ", Email: " << current->email
                 << ", Password: " << current->password << endl;

            cout << "Games played by the player:" << endl;
            current->GamesPlayedRoot->levelOrderTraversalGP(current->GamesPlayedRoot->root);

            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
    }

    ~PlayerTree()
    {
        wipeTree(root);
    }
};

class Database
{
public:
    GameTree *game_root;
    PlayerTree *player_tree;

    Database() : game_root(new GameTree()), player_tree(new PlayerTree()) {}
    ~Database()
    {
        delete game_root;
        delete player_tree;
    }

    void loadGames(const string &filename)
    {
        ifstream file(filename);
        if (!file.is_open())
        {
            cout << "Error: Could not open the file." << endl;
            return;
        }
        cout << "File Opened Successfully" << endl;

        string line;
        while (getline(file, line))
        {
            stringstream ss(line);
            string game_id, name, developer, publisher;
            float file_size;
            int downloads;

            getline(ss, game_id, ',');
            getline(ss, name, ',');
            getline(ss, developer, ',');
            getline(ss, publisher, ',');
            ss >> file_size;
            ss.ignore();
            ss >> downloads;

            GameNode *new_game = new GameNode(game_id, name, developer, publisher, file_size, downloads);

            game_root->root = game_root->insertGame(game_root->root, new_game);
        }
    }

    void loadPlayers(const string &filename)
    {
        ifstream file(filename);
        if (!file.is_open())
        {
            cout << "Error: Could not open the file." << endl;
            return;
        }
        cout << "File Opened Successfully" << endl;

        int seed = 230089;
        int skip_threshold = 89 * 10 + 100;

        default_random_engine generator(seed);
        uniform_int_distribution<int> distribution(0, 1000);

        string line;
        while (getline(file, line))
        {
            int random_value = distribution(generator);

            if (random_value < skip_threshold)
            {
                continue;
            }

            // Process the line
            istringstream iss(line);
            string id, name, phone, email, password;

            getline(iss, id, ',');
            getline(iss, name, ',');
            getline(iss, phone, ',');
            getline(iss, email, ',');
            getline(iss, password, ',');

            PlayerNode *new_player = new PlayerNode(id, name, phone, email, password);

            string game_id, hours_played, achievements_unlocked;
            while (getline(iss, game_id, ',') && getline(iss, hours_played, ',') && getline(iss, achievements_unlocked, ','))
            {
                new_player->GamesPlayedRoot->insertPlayedGame(game_id, stof(hours_played), stoi(achievements_unlocked));
            }

            player_tree->root = player_tree->insertPlayer(player_tree->root, new_player);
        }

        file.close();
    }

    PlayerNode *findNode(string playerID)
    {
        PlayerNode *player = player_tree->searchPlayer(playerID, player_tree->root);
        if (player)
        {
            cout << "Player ID: " << player->id << endl
                 << "Name: " << player->name << endl
                 << "Phone: " << player->phoneNo << endl
                 << "Email: " << player->email << endl
                 << "Password: " << player->password << endl;

            return player;
        }
        else
        {
            cout << "Error: Player ID not found." << endl;
            return nullptr;
        }
    }

    void deleteNode(string playerID)
    {
        player_tree->root = player_tree->deletePlayer(player_tree->root, playerID);
    }

    void saveToCSV()
    {
        ofstream file("saved.csv");
        if (!file.is_open())
        {
            cout << "Error: Could not open the file." << endl;
            return;
        }
        cout << "File Opened Successfully" << endl;

        savePlayers(file, player_tree->root);

        file.close();
    }
    void savePlayers(ofstream &file, PlayerNode *node)
    {
        if (!node)
            return;

        file << node->id << "," << node->name << "," << node->phoneNo << "," << node->email << "," << node->password;

        if (node->GamesPlayedRoot->root)
        {
            file << ",";
            saveGamesPlayed(file, node->GamesPlayedRoot->root);
        }

        file << endl;

        savePlayers(file, node->left);
        savePlayers(file, node->right);
    }
    void saveGamesPlayed(ofstream &file, GamesPlayedNode *node)
    {
        if (!node)
            return;

        file << node->game_id << "," << node->hours_played << "," << node->achievements_unlocked;

        saveGamesPlayed(file, node->left);
        saveGamesPlayed(file, node->right);
    }

    void show_N_Layers(int N)
    {
        queue<PlayerNode *> q;
        q.push(player_tree->root);

        int level = 1;
        while (!q.empty() && level <= N)
        {
            int size = q.size;
            cout << "Level " << level << ": \n";
            for (int i = 0; i < size; i++)
            {
                PlayerNode *current = q.front();
                q.pop();

                cout << i << ") " << current->id << ", " << current->name << ", " << current->phoneNo << ", " << current->email << ", " << current->password << endl;

                if (current->left)
                    q.push(current->left);
                if (current->right)
                    q.push(current->right);
            }
            cout << endl
                 << endl;

            level++;
            if (level > player_tree->height)
            {
                cout << "Limit reached, can't go further! " << endl;
                return;
            }
        }
    }

    void showLayerNumber(string playerID)
    {
        queue<PlayerNode *> q;
        q.push(player_tree->root);

        int level = 1;
        while (!q.empty())
        {
            int size = q.size;
            for (int i = 0; i < size; i++)
            {
                PlayerNode *current = q.front();
                q.pop();

                if (current->id == playerID)
                {
                    cout << "Layer Number: " << level << endl;
                    return;
                }

                if (current->left)
                    q.push(current->left);
                if (current->right)
                    q.push(current->right);
            }
            level++;
        }
    }

    void showPath(string playerID) // preorder traversal
    {
        cout << "Path: ";
        preOrderPath(playerID, player_tree->root);
    }
    void preOrderPath(string playerID, PlayerNode *node)
    {
        static bool found = false;
        if (!node)
            return;

        if (!found)
        {
            if (node->id == playerID)
            {
                cout << node->id << "-> END";
                found = true;
            }
            else
                cout << node->id << " -> ";

            preOrderPath(playerID, node->left);
            preOrderPath(playerID, node->right);
        }
    }

    void editEntry(string playerID)
    {
        PlayerNode *player = player_tree->searchPlayer(playerID, player_tree->root);

        cout << "Things to edit: " << endl;
        cout << "1. Player ID" << endl;
        cout << "2. Player Name" << endl;
        cout << "3. Phone Number" << endl;
        cout << "4. Email" << endl;
        cout << "5. Password" << endl;
        cout << "6. Game(s)" << endl;
        cout << "7. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;
        while (!(choice >= 1 && choice <= 7))
        {
            cout << "Invalid choice. Enter (1-7): ";
            cin >> choice;
        }

        if (choice == 1)
        {
            string newID = "";
            cout << "Enter new Player ID: ";
            cin >> newID;

            PlayerNode *newNode = player;
            newNode->id = newID;

            player_tree->deletePlayer(player_tree->root, playerID);
            player_tree->root = player_tree->insertPlayer(player_tree->root, newNode);
            cout << "Player ID changed successfully." << endl;
        }
        else if (choice == 2)
        {
            string newName = "";
            cout << "Enter new Player Name: ";
            getline(cin, newName);
            cin.ignore();

            player->name = newName;
        }
        else if (choice == 3)
        {
            string newPhone = "";
            cout << "Enter new Phone Number: ";
            cin >> newPhone;

            player->phoneNo = newPhone;
        }
        else if (choice == 4)
        {
            string newEmail = "";
            cout << "Enter new Email: ";
            cin >> newEmail;

            player->email = newEmail;
        }
        else if (choice == 5)
        {
            string newPassword = "";
            cout << "Enter new Password: ";
            cin >> newPassword;

            player->password = newPassword;
        }
        else if (choice == 6)
        {
            editGame(player);
        }
        else if (choice == 7)
            return;
    }
    void editGame(PlayerNode *player)
    {
        cout << "Things to edit: " << endl;
        cout << "1. Add Game" << endl;
        cout << "2. Remove Game" << endl;
        cout << "3. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;
        while (!(choice >= 1 && choice <= 3))
        {
            cout << "Invalid choice. Enter (1-3): ";
            cin >> choice;
        }

        if (choice == 1)
        {
            string gameID = "";
            cout << "Enter Game ID: ";
            cin >> gameID;

            float hours = 0;
            cout << "Enter Hours Played: ";
            cin >> hours;

            int achievements = 0;
            cout << "Enter Achievements Unlocked: ";
            cin >> achievements;

            player->GamesPlayedRoot->insertPlayedGame(gameID, hours, achievements);
        }
        else if (choice == 2)
        {
            string gameID = "";
            cout << "Enter Game ID to remove: ";
            cin >> gameID;

            player->GamesPlayedRoot->deletePlayedGame(player->GamesPlayedRoot->root, gameID);
        }
        else if (choice == 3)
            return;
    }

    void printNode(string playerID)
    {
        PlayerNode *player = player_tree->searchPlayer(playerID, player_tree->root);
        if (player)
        {
            cout << "Player ID: " << player->id << endl
                 << "Name: " << player->name << endl
                 << "Phone: " << player->phoneNo << endl
                 << "Email: " << player->email << endl
                 << "Password: " << player->password << endl;

            cout << "\nGames played by " << player->name << ": " << endl;
            player->GamesPlayedRoot->printAllPlayedGames(player->GamesPlayedRoot->root, game_root);
        }
        else
            cout << "Error: Player ID not found." << endl;
    }

    void hasPlayed(string playerID, string gameID)
    {
        PlayerNode *player = player_tree->searchPlayer(playerID, player_tree->root);
        if (player)
        {
            GamesPlayedNode *game = player->GamesPlayedRoot->searchPlayedGame(gameID, player->GamesPlayedRoot->root);
            if (game)
                cout << "Player has played the game." << endl;
        }
        cout << "Player has not played the game." << endl;
    }

    void top_N_Players(int N)
    {
        LL list;
        fillList(player_tree->root, list, N);
        list.display(N);
    }
    void fillList(PlayerNode *pNode, LL &list, int N)
    {
        if (!pNode)
            return;

        fillList(pNode->left, list, N);

        list.insert(pNode->GamesPlayedRoot->countNodes(pNode->GamesPlayedRoot->root), pNode->id);

        fillList(pNode->right, list, N);
    }
};

int main()
{
    Database db;
    db.loadGames("games.txt");
    db.loadPlayers("players.txt");
    system("CLS");

    // db.game_root->levelOrderTraversal(db.game_root->root);
    // db.player_tree->levelOrderTraversalPT(db.player_tree->root);

    db.saveToCSV();
    db.show_N_Layers(3);

    string pID = "";
    cout << "Enter Player ID to find in layer n: ";
    cin >> pID;
    db.showLayerNumber(pID);

    cout << "Enter Player ID to find: ";
    cin >> pID;
    db.findNode(pID);

    cout << "Showig path of player: ";
    db.showPath(pID);

    cout << "Enter Player ID to edit: ";
    db.editEntry(pID);

    cout << "printing node with ID " << pID << ": " << endl;
    db.printNode(pID);

    cout << "Enter Player ID and game ID to check for played: ";
    string gID;
    cin >> pID >> gID;
    db.hasPlayed(pID, gID);

    cout << "Enter N to get top N players: ";
    int N;
    cin >> N;
    db.top_N_Players(N);

    return 0;
}