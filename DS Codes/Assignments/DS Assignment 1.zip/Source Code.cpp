#include <iostream>
#include <cstdlib>

using namespace std;

void openHtmlFile(const string &filePath)
{
#ifdef _WIN32
    string command = "start " + filePath;
#elif __linux__
    string command = "xdg-open " + filePath;
#elif __APPLE__
    string command = "open " + filePath;
#else
    cerr << "Unsupported operating system" << endl;
    return;
#endif
    system(command.c_str());
}

int main()
{
    string filePath = "Html Code"; // Replace with your HTML file path
    openHtmlFile(filePath);
    return 0;
}
