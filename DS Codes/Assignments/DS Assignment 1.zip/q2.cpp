#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

void openHtmlFile(const string &filePath);

const int MAX_HISTORY = 100;  // Maximum history size

class BrowserHistory 
{
private:
    string history[MAX_HISTORY];
    int visitCount[MAX_HISTORY];
    int currentIndex;
    int historySize;

    // Function to find the index of a URL in history
    int findUrl(const string& url) {
        for (int i = 0; i < historySize; ++i) {
            if (history[i] == url) {
                return i;
            }
        }
        return -1;
    }

    // Function to open the URL (HTML file)
    void openURL(const string& url) {
        cout << "Opening URL: " << url << endl;
        // Placeholder for opening URL - Replace with the real function from your source code
        openHtmlFile(url);
    }

public:
    // Constructor
    BrowserHistory() : currentIndex(-1), historySize(0) {
        for (int i = 0; i < MAX_HISTORY; ++i) {
            visitCount[i] = 0;
        }
    }

    // Visit a new URL, clear forward history
    void visit(const string& url) {
        // Clear forward history if currentIndex is not at the end
        if (currentIndex < historySize - 1) {
            historySize = currentIndex + 1;
        }

        // Add the new URL to history
        if (historySize < MAX_HISTORY) {
            history[historySize] = url;
            currentIndex = historySize;
            historySize++;
        } 
        else 
        {
            // If the history is full, we shift everything to the left and add the new URL at the end
            for (int i = 1; i < MAX_HISTORY; ++i) {
                history[i - 1] = history[i];
                visitCount[i - 1] = visitCount[i];
            }
            history[MAX_HISTORY - 1] = url;
            currentIndex = MAX_HISTORY - 1;
        }

        // Update visit count
        int urlIndex = findUrl(url);
        if (urlIndex != -1) 
        {
            visitCount[urlIndex]++;
        }

        // Open the corresponding URL
        openURL(url);
    }

    // Move backward in history by up to 'steps'
    string back(int steps) {
        if (currentIndex == -1) {
            cout << "No history available." << endl;
            return "";
        }

        // Move backward, ensuring we don't go beyond the first entry
        currentIndex = (currentIndex - steps >= 0) ? currentIndex - steps : 0;

        // Open the corresponding URL
        openURL(history[currentIndex]);
        return history[currentIndex];
    }

    // Move forward in history by up to 'steps'
    string forward(int steps) {
        if (currentIndex == -1) {
            cout << "No history available." << endl;
            return "";
        }

        // Move forward, ensuring we don't go beyond the last entry
        currentIndex = (currentIndex + steps < historySize) ? currentIndex + steps : historySize - 1;

        // Open the corresponding URL
        openURL(history[currentIndex]);
        return history[currentIndex];
    }

    // Open the top k most frequently visited URLs
    void openTopK(int k) {
        // Find top K most frequently visited URLs
        for (int i = 0; i < k && i < historySize; ++i) {
            int maxIndex = i;
            for (int j = i + 1; j < historySize; ++j) {
                if (visitCount[j] > visitCount[maxIndex]) {
                    maxIndex = j;
                }
            }

            // Swap the most visited URL to the top
            swap(history[i], history[maxIndex]);
            swap(visitCount[i], visitCount[maxIndex]);

            // Open the top K URL
            openURL(history[i]);
        }
    }
};

void openHtmlFile(const string &filePath)
{
#ifdef _WIN32
    string command = "start " + filePath;
#elif __linux__
    string command = "xdg-open " + filePath;
#elif __APPLE__
    string command = "open " + filePath;
#else
    cerr << "Unsupported operating system" << endl;
    return;
#endif
    system(command.c_str());
}

int main() {
    BrowserHistory browser;

    browser.visit("https://www.google.com/");
    browser.visit("https://leetcode.com/");
    browser.visit("https://www.google.com/");

    // browser.back(1);
    // browser.forward(1); 
    
    browser.visit("https://www.wondar.site/");

    // Open top 2 most frequently visited URLs
    browser.openTopK(1);

    return 0;
}
