#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// Cache node structure for a singly linked list
class CacheNode
{
public:
    int address;
    int data;   // cache stores data in decimal
    bool dirty; // dirty bit for write-back policy
    CacheNode *next;

    CacheNode(int Address, int Data) : address(Address), data(Data), dirty(false), next(nullptr) {}
};

// Cache as a singly linked list
class Cache
{
private:
    CacheNode *head;
    int capacity;
    int size;

public:
    Cache(int cap) : head(nullptr), capacity(cap), size(0) {}

    bool isFull()
    {
        return size >= capacity;
    }

    // Add a new node to the cache (if the cache is full, we need to evict)
    void add(int address, int data)
    {
        CacheNode *newNode = new CacheNode(address, data);
        if (isFull())
        {
            evict();
        }
        newNode->next = head;
        head = newNode;
        size++;
    }

    // Evict or release the last node from the cache to make space (FIFO)
    void evict()
    {
        if (!head)
            return;

        CacheNode *current = head;
        CacheNode *prev = nullptr;

        while (current->next)
        {
            prev = current;
            current = current->next;
        }

        if (prev)
        {
            prev->next = nullptr;
        }
        else
        {
            head = nullptr;
        }

        delete current;
        size--;
    }

    // Check if an address is in the cache
    CacheNode *find(int address)
    {
        CacheNode *current = head;
        while (current)
        {
            if (current->address == address)
            {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

    // Print the entire cache linked list
    void printCache()
    {
        CacheNode *current = head;
        cout << "Cache contents (from most recent to least recent):\n";
        while (current)
        {
            cout << "Address: " << current->address 
                 << ", Data: " << current->data 
                 << ", Dirty: " << (current->dirty ? "Yes" : "No") << "\n";
            current = current->next;
        }
        cout << "---- End of Cache ----\n";
    }
};

// Load memory data from a CSV file into an array
void loadMemory(const string &filepath, int memory[], const int memorySize)
{
    ifstream file(filepath);
    if(!file.is_open())
    {
        cout << "Error opening file: " << filepath << endl;
        return;
    }
    string line;
    int address = 0;

    while (getline(file, line) && address < memorySize)
    {
        size_t commaPos = line.find(',');
        if (commaPos != string::npos) // end of line
        {
            string addrStr = line.substr(0, commaPos);
            string dataStr = line.substr(commaPos + 1);

            // Memory in the CSV file is in dec, convert to dec
            memory[address] = stoi(dataStr, nullptr, 16); // Convert hex to dec
        }
        address++;
    }

    file.close();
}

// Update memory data to the CSV file
void updateMemory(const string &filepath, int memory[], const int memorySize)
{
    ofstream file(filepath);
    if(!file.is_open())
    {
        cout << "Error opening file: " << filepath << endl;
        return;
    }
    for (int i = 0; i < memorySize; ++i)
    {
        file << i << "," << hex << memory[i] << "\n"; // Write as hex
    }
    file.close();
}

// Function to convert hexadecimal string to decimal integer manually
int hexToDec(const string &hexStr)
{
    int decimalValue = 0;
    int len = hexStr.length();
    for (int i = 0; i < len; i++)
    {
        char hexDigit = hexStr[i];
        decimalValue *= 16;
        if (hexDigit >= '0' && hexDigit <= '9')
        {
            decimalValue += hexDigit - '0';
        }
        else if (hexDigit >= 'A' && hexDigit <= 'F')
        {
            decimalValue += hexDigit - 'A' + 10;
        }
        else if (hexDigit >= 'a' && hexDigit <= 'f')
        {
            decimalValue += hexDigit - 'a' + 10;
        }
    }
    return decimalValue;
}

// Function to convert decimal integer to hexadecimal string manually
string decToHex(int decimalValue)
{
    if (decimalValue == 0)
        return "0";

    string hexStr = "";
    while (decimalValue > 0)
    {
        int remainder = decimalValue % 16;
        if (remainder < 10)
        {
            hexStr = char('0' + remainder) + hexStr;
        }
        else
        {
            hexStr = char('A' + (remainder - 10)) + hexStr;
        }
        decimalValue /= 16;
    }
    return hexStr;
}

// Main cache simulation logic
int main()
{
    // Constants
    const int memorySize = 256;   // Example size of memory (can be changed)
    int memory[memorySize] = {0}; // Memory array to store data in decimal

    // Load memory from CSV file
    string memoryFile = "Memory.csv";
    loadMemory(memoryFile, memory, memorySize);

    // Cache policies input
    int cacheHitPolicy, cacheMissPolicy;
    cout << "Enter Cache Hit Policy (1. write-through or 2. write-back): ";
    cin >> cacheHitPolicy;
    cout << "Enter Cache Miss Policy (1. write-allocate or 2. write-around): ";
    cin >> cacheMissPolicy;

    // Cache initialization (capacity can be set to any desired size)
    Cache cache(4);

    while (true)
    {
        string operation;
        cout << "Enter operation (load/store/print) or 'exit' to quit: ";
        cin >> operation;

        if (operation == "exit")
            break;

        if (operation == "print")
        {
            cache.printCache();
            continue;
        }

        int address;
        string data;

        cout << "Enter address (decimal): ";
        cin >> address;

        if (operation == "load")
        {
            // Load operation: Check for cache hit or miss
            CacheNode *node = cache.find(address);
            if (node)
            {
                cout << "Cache Hit! Data: " << node->data << "\n";
            }
            else
            {
                cout << "Cache Miss!\n";
                // Load from memory and add to cache
                cache.add(address, memory[address]);
                cout << "Loaded data into cache: " << memory[address] << "\n";
            }
        }
        else if (operation == "store")
        {
            // Store operation: handle cache hit or miss based on policies
            cout << "Enter data (hexadecimal): ";
            cin >> data;

            int data_dec = hexToDec(data); // Convert hex to decimal
            CacheNode *node = cache.find(address);

            if (node)
            {
                cout << "Cache Hit!\n";
                if (cacheHitPolicy == 1) // write-through
                {
                    node->data = data_dec;
                    memory[address] = data_dec;
                    updateMemory(memoryFile, memory, memorySize);
                    cout << "Write-through: Updated cache and memory.\n";
                }
                else if (cacheHitPolicy == 2) // write-back
                {
                    node->data = data_dec;
                    node->dirty = true;
                    cout << "Write-back: Updated cache, marked as dirty.\n";
                }
            }
            else
            {
                cout << "Cache Miss!\n";
                if (cacheMissPolicy == 1) // write-allocate
                {
                    cache.add(address, data_dec);
                    memory[address] = data_dec;
                    updateMemory(memoryFile, memory, memorySize);
                    cout << "Write-allocate: Loaded data into cache and updated memory.\n";
                }
                else if (cacheMissPolicy == 2) // write-around
                {
                    memory[address] = data_dec;
                    updateMemory(memoryFile, memory, memorySize);
                    cout << "Write-around: Updated memory directly.\n";
                }
            }
        }
    }

    return 0;
}

















































































































































































































































// if (current->dirty)
        // {
        //     cout << "Evicting dirty cache entry. Writing back to memory.\n";
        //     // Code to write the dirty block back to memory
        //     memory[current->address] = current->data; // Update memory with evicted cache data
        //     updateMemory(memoryFile, memory, memorySize); // Write the updated memory array back to CSV
        // }