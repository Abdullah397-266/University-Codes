#include <iostream>
#include <list>
#include <stack>
#include <queue>
#include <conio.h>
#include <fstream>
using namespace std;

#include <iostream>

class LLNode
{
public:
    char data;
    LLNode *next;

    LLNode(char c) : data(c), next(nullptr) {}
};
class LL
{
public:
    LLNode *head;
    LLNode *rear;
    int size = 0;

    LL() : head(nullptr), rear(nullptr) {}

    void push(char c)
    {
        LLNode *newNode = new LLNode(c);
        if (!head)
        {
            head = rear = newNode;
        }
        else
        {
            rear->next = newNode;
            rear = newNode;
        }
        size++;
    }

    void pushString(string str)
    {
        for (char c : str)
        {
            push(c);
        }
    }

    string giveString()
    {
        string str;
        LLNode *temp = head;
        while (temp)
        {
            str += temp->data;
            temp = temp->next;
        }
        return str;
    }

    void pop()
    {
        if (!head)
            return;

        if (head == rear)
        {
            delete head;
            head = rear = nullptr;
        }
        else
        {
            LLNode *temp = head;

            while (temp->next != rear)
            {
                temp = temp->next;
            }
            delete rear;
            rear = temp;
            rear->next = nullptr;
        }
        size--;
    }

    void display()
    {
        LLNode *temp = head;
        while (temp)
        {
            cout << temp->data;
            temp = temp->next;
        }
    }

    void clear()
    {
        LLNode *temp;
        while (head)
        {
            temp = head;
            head = head->next;
            delete temp;
        }
        rear = nullptr;
    }

    bool empty()
    {
        return size == 0;
    }

    ~LL()
    {
        clear();
    }
};

class avlNode
{
public:
    string word;
    avlNode *left;
    avlNode *right;
    int height;

    avlNode(string str)
    {
        word = str;
        left = right = nullptr;
        height = 1;
    }
};

class AVL
{
public:
    avlNode *root;

    AVL() : root(nullptr) {}

    void insert(string str)
    {
        root = insertWord(root, str);
    }
    avlNode *insertWord(avlNode *root, string str)
    {
        if (!root)
            return new avlNode(str);

        if (str < root->word)
            root->left = insertWord(root->left, str);
        else if (str > root->word)
            root->right = insertWord(root->right, str);
        else
            return root;

        root->height = 1 + max(height(root->left), height(root->right));

        int balance = getBalance(root);

        if (balance > 1)
        {
            if (getBalance(root->left) >= 0)
                return rightRotate(root);
            else
                return leftRightRotate(root);
        }
        if (balance < -1)
        {
            if (getBalance(root->right) <= 0)
                return leftRotate(root);
            else
                return rightLeftRotate(root);
        }

        return root;
    }

    bool find(string str)
    {
        bool check = false;
        findWord(root, str, check);
        return check;
    }
    void findWord(avlNode *root, string str, bool &flag)
    {
        if (!root)
        {
            // cout << "Not found" << endl;
            flag = false;
            return;
        }

        //! check string comparison
        if (str < root->word)
            findWord(root->left, str, flag);
        else if (str > root->word)
            findWord(root->right, str, flag);
        else if (str == root->word)
        {
            // cout << "Found" << endl;
            flag = true;
            return;
        }
    }

    void loadDict()
    {
        string str;
        ifstream file("dictionary.txt");
        if (!file.is_open())
        {
            cout << "File not found" << endl;
            return;
        }

        while (file >> str)
        {
            insert(str);
        }
        file.close();
    }

    int height(avlNode *root)
    {
        if (!root)
            return 0;
        return root->height;
    }

    int getBalance(avlNode *root)
    {
        if (!root)
            return 0;
        return height(root->left) - height(root->right);
    }

    avlNode *rightRotate(avlNode *k1)
    {
        avlNode *k2 = k1->left;
        k1->left = k2->right;
        k2->right = k1;

        k1->height = 1 + max(height(k1->left), height(k1->right));
        k2->height = 1 + max(height(k2->left), height(k2->right));

        return k2;
    }

    avlNode *leftRotate(avlNode *k1)
    {
        avlNode *k2 = k1->right;
        k1->right = k2->left;
        k2->left = k1;

        k1->height = 1 + max(height(k1->left), height(k1->right));
        k2->height = 1 + max(height(k2->left), height(k2->right));

        return k2;
    }

    avlNode *leftRightRotate(avlNode *k1)
    {
        k1->left = leftRotate(k1->left);
        return rightRotate(k1);
    }

    avlNode *rightLeftRotate(avlNode *k1)
    {
        k1->right = rightRotate(k1->right);
        return leftRotate(k1);
    }

    void inorder()
    {
        inorderT(root);
    }
    void inorderT(avlNode *root)
    {
        if (!root)
            return;
        inorderT(root->left);
        cout << root->word << endl;
        inorderT(root->right);
    }

    void spellCheck(string str)

    {
        cout << "\n\nSubstitution suggestions: ";
        letterSubstitution(str);

        cout << "\nOmission suggestions: ";
        letterOmission(str);

        cout << "\nInsertion suggestions: ";
        letterInsertion(str);

        cout << "\nReversal suggestions: ";
        letterReversal(str);
    }

    void letterSubstitution(string str)
    {
        int len = str.length();
        string temp = "";

        for (int i = 0; i < len; i++)
        {
            temp = str;
            for (int j = 0; j < 26; j++)
            {
                temp[i] = 'a' + j;
                if (find(temp) && str != temp)
                    cout << temp << " ";
            }
        }
    }

    void letterOmission(string str)
    {
        int len = str.length();
        string temp = "";

        for (int i = 0; i < len; i++)
        {
            temp = "";
            for (int j = 0; j < len; j++)
            {
                if (i == j)
                    continue;
                else
                    temp += str[i];
            }
            if (find(temp) && str != temp)
                cout << temp << " ";
        }
    }

    void letterInsertion(string str)
    {
        int len = str.length();
        string temp = "";

        for (int i = 0; i < len + 1; i++)
        {
            temp = str;
            for (int j = 0; j < 26; j++)
            {
                temp.insert(i, 1, 'a' + j);
                if (find(temp) && str != temp)
                    cout << temp << " ";
            }
        }
    }

    void letterReversal(string str)
    {
        int len = str.length();
        string temp = "";

        for (int i = 0; i < len - 1; i++)
        {
            temp = str;
            swap(temp[i], temp[i + 1]);
            if (find(temp) && str != temp)
                cout << temp << " ";
        }
    }

    void wipeTree()
    {
        wipeTreeT(root);
    }
    void wipeTreeT(avlNode *root)
    {
        if (!root)
            return;
        wipeTreeT(root->left);
        wipeTreeT(root->right);
        delete root;
    }

    ~AVL()
    {
        wipeTree();
    }
};

int main()
{
    AVL tree;
    tree.loadDict();
    // tree.inorder();

    LL list;
    LL currentWord;
    system("CLS");
    while (true)
    {
        cout << "Text: ";
        list.display();

        char c = _getche();

        if (c == 27) // ESC
            break;
        else if (c == 13) // Enter
        {
            list.push('\n');
            cout << endl;
        }
        else if (c == 8) // Backspace
        {
            list.pop();
            cout << " \b";
        }
        else if (c == 32) // Space
        {
            list.push(c);
            string word = currentWord.giveString();
            currentWord.clear();

            tree.spellCheck(word);
            _getch();
        }
        else if (c == 19) // Ctrl + S (save data)
        {
            ofstream file("save.txt", ios::trunc);
            if (!file.is_open())
            {
                cout << "File not found" << endl;
                return 0;
            }

            file << list.giveString();
            file.close();
        }
        else if (c == 12) // CTRL + L (load data)
        {
            ifstream file("save.txt");
            if (!file.is_open())
            {
                cout << "File not found" << endl;
                return 0;
            }

            list.clear();
            char ch;
            while (file.get(ch))
            {
                list.push(ch);
            }
            file.close();
        }
        else
        {
            list.push(c);
            currentWord.push(c);
        }
        system("CLS");
    }
    return 0;
}