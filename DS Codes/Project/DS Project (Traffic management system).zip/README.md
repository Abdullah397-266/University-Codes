# Advanced Traffic Management System

## Overview

This is a comprehensive C++ implementation of an intelligent traffic management system that handles road networks, vehicle routing, emergency vehicle prioritization, and traffic signal management.

## Features

- **Road Network Modeling**
  - Represents intersections and roads as a graph
  - Supports dynamic road and intersection blocking
  - Handles multiple vehicle types (emergency and regular)

- **Routing Optimization**
  - Calculates optimal paths considering:
    - Travel time
    - Traffic congestion
    - Road blockages
    - Emergency vehicle priorities

- **Traffic Signal Management**
  - Intelligent signal timing
  - Priority-based road management
  - Emergency mode activation

- **Data-Driven Approach**
  - Loads road network, vehicle, and signal timing data from CSV files
  - Supports dynamic traffic updates

## System Components

### Key Classes

1. **Graph**: 
   - Manages the entire road network
   - Handles vehicle routing and traffic management
   - Processes emergency and regular vehicles

2. **TrafficSignal**:
   - Manages traffic signals for each intersection
   - Implements priority-based signal timing

3. **PriorityQueue**:
   - Manages road priorities based on vehicle count and wait time

4. **Heap**:
   - Assists in finding optimal routes with minimal travel time

### Data Structures

- **EmergencyVehicle**: Stores emergency vehicle details
- **Vehicle**: Stores regular vehicle information
- **SignalTiming**: Manages traffic signal timings
- **Node**: Represents road segments with travel time and vehicle count

## Input Files

The system requires the following CSV files:

- `road_network.csv`: Road connections between intersections
- `emergency_vehicles.csv`: Emergency vehicle routes
- `vehicles.csv`: Regular vehicle routes
- `traffic_signal_timings.csv`: Signal timing configurations

## Key Functionalities

- Optimal path finding
- Emergency vehicle routing
- Traffic congestion management
- Dynamic road and intersection blocking
- Intelligent traffic signal control

## Usage Example

```cpp
Graph RoadNetworks(5); // Create a road network with 5 intersections

// Process emergency vehicles
RoadNetworks.processEmergencyVehicles();

// Process regular vehicles
RoadNetworks.processVehicles();

// Manage traffic signals
RoadNetworks.manageTrafficSignals();

// Block an intersection or road
RoadNetworks.blockIntersection('B');
RoadNetworks.blockRoad('B', 'D');
```

## Compilation

Compile with a C++ compiler that supports C++11 or later:

```bash
g++ -std=c++11 main.cpp -o traffic_system
```

## Potential Improvements

- Real-time traffic data integration
- Machine learning-based signal timing optimization
- Enhanced emergency vehicle priority algorithms
- Visualization of road network and traffic flow

## Dependencies

- Standard C++ libraries
- CSV parsing capabilities

## Contributors

- Abdullah Qadri
- Adam Afridi
- Hafeez Mughal
