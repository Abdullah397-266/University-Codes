#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <windows.h>
#include <conio.h>
using namespace std;

// to store emergency vehicle data
struct EmergencyVehicle
{
    string vehicleId;
    char startIntersection;
    char endIntersection;
    string priorityLevel;
};

// to store regular vehicle data
struct Vehicle
{
    string vehicleId;
    char startIntersection;
    char endIntersection;
};

// to store traffic signal timing data
struct SignalTiming
{
    char intersection;
    int greenTime;
};

// Node class containing Road data
// """
//      Vertex:       Intersection ID,
//      travelTime:   time to travel to next intersection,
//      vehicleCount: number of vehicles on road
// """
class Node
{
public:
    char Vertex;
    int travelTime;
    int vehicleCount;
    Node *next;

    Node(char n = '\0', int t = INT_MAX, int Vehicles = 0)
    {
        Vertex = n;
        travelTime = t;
        vehicleCount = Vehicles;
        next = nullptr;
    }

    void setNext(Node *n) { next = n; }
    Node *getNext() { return next; }
    void setVertex(char n) { Vertex = n; }
    char getVertex() { return Vertex; }
    void setTravelTime(int t) { travelTime = t; }
    int getTravelTime() { return travelTime; }
    void setVehicleCount(int count) { vehicleCount = count; }
    int getVehicleCount() { return vehicleCount; }
    void incrementVehicleCount() { vehicleCount++; }
};

// Linked List class for storing multiple roads
class List
{
public:
    Node *head;

    List() { head = nullptr; }

    Node *getHead() { return head; }

    ~List()
    {
        Node *current = head;
        while (current != nullptr)
        {
            Node *temp = current;
            current = current->getNext();
            delete temp;
        }
    }

    void insert(char N, int t)
    {
        Node *newNode = new Node(N, t);
        newNode->setTravelTime(t);
        newNode->setNext(head);
        head = newNode;
    }

    void deleteNode(char N)
    {
        if (head == nullptr)
        {
            cout << "List is empty. Cannot delete." << endl;
            return;
        }

        if (head->getVertex() == N)
        {
            Node *temp = head;
            head = head->getNext();
            delete temp;
            return;
        }

        Node *current = head;
        Node *prev = nullptr;
        while (current != nullptr && current->getVertex() != N)
        {
            prev = current;
            current = current->getNext();
        }

        if (current == nullptr)
            return;

        prev->setNext(current->getNext());
        delete current;
    }

    void displayList()
    {
        Node *current = head;
        while (current != nullptr)
        {
            cout << "(" << current->getVertex() << ", " << current->getTravelTime()
                 << ", Vehicles: " << current->getVehicleCount() << ") -> ";
            current = current->getNext();
        }
        cout << "NULL" << endl;
    }
};

// Priority Queue for Traffic Signal Management
// storing road data
//? road with higher vehicle count and wait time has higher priority
// """
//      id:           Road ID,
//      vehicleCount: number of vehicles on road,
//      waitTime:     time vehicles have been waiting
// """
class PriorityQueue
{
    struct Road
    {
        char id;
        int vehicleCount;
        int waitTime;

        Road(char i = '\0', int v = 0, int w = 0) : id(i), vehicleCount(v), waitTime(w) {}
    };

public:
    Road *heap;
    int capacity;
    int size;

    void heapifyUp(int index)
    {
        while (index > 0)
        {
            int parent = (index - 1) / 2;
            if (heap[parent].vehicleCount * heap[parent].waitTime >=
                heap[index].vehicleCount * heap[index].waitTime)
                break;

            Road temp = heap[parent];
            heap[parent] = heap[index];
            heap[index] = temp;
            index = parent;
        }
    }

    void heapifyDown(int index)
    {
        while (true)
        {
            int maxIndex = index;
            int left = 2 * index + 1;
            int right = 2 * index + 2;

            if (left < size &&
                heap[left].vehicleCount * heap[left].waitTime >
                    heap[maxIndex].vehicleCount * heap[maxIndex].waitTime)
            {
                maxIndex = left;
            }

            if (right < size &&
                heap[right].vehicleCount * heap[right].waitTime >
                    heap[maxIndex].vehicleCount * heap[maxIndex].waitTime)
            {
                maxIndex = right;
            }

            if (maxIndex == index)
                break;

            Road temp = heap[index];
            heap[index] = heap[maxIndex];
            heap[maxIndex] = temp;
            index = maxIndex;
        }
    }

    PriorityQueue(int maxSize = 100) : capacity(maxSize), size(0)
    {
        heap = new Road[capacity];
    }

    ~PriorityQueue()
    {
        delete[] heap;
    }

    void push(char id, int vehicles, int wait)
    {
        if (size >= capacity)
            return;

        heap[size] = Road(id, vehicles, wait);
        heapifyUp(size);
        size++;
    }

    Road pop()
    {
        if (size == 0)
            return Road();

        Road top = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);

        return top;
    }

    bool empty() { return size == 0; }
};

// Heap for Traffic Signal Management
// storing road data
//? road with lower travel time has higher priority
class Heap
{
    Node *heapArray;
    int capacity;
    int size;

public:
    Heap(int n)
    {
        capacity = n;
        heapArray = new Node[capacity];
        size = 0;
    }

    void heapifyUp()
    {
        int child = size;
        int parent = child / 2;

        while (parent > 0 && heapArray[parent].getTravelTime() > heapArray[child].getTravelTime())
        {
            Node temp = heapArray[parent];
            heapArray[parent] = heapArray[child];
            heapArray[child] = temp;

            child = parent;
            parent = child / 2;
        }
    }

    void push(char N, int t)
    {
        size++;

        if (size == capacity)
            return;

        Node newNode(N, t);
        heapArray[size] = newNode;
        heapifyUp();
    }

    void heapifyDown()
    {
        if (empty())
            return;

        int parent = 1;

        while (true)
        {
            int child[2];
            child[0] = parent * 2;
            child[1] = parent * 2 + 1;

            bool br = false;
            for (int i = 0; i < 2; i++)
            {
                if (child[i] <= size && (heapArray[parent].getTravelTime() > heapArray[child[i]].getTravelTime()))
                {
                    Node temp = heapArray[parent];
                    heapArray[parent] = heapArray[child[i]];
                    heapArray[child[i]] = temp;

                    parent = child[i];

                    br = false;
                    break;
                }
                else
                    br = true;
            }
            if (br)
                break;
        }
    }

    Node pop()
    {
        Node r = heapArray[1];

        if (empty())
            return r;

        heapArray[1] = heapArray[size];

        size--;
        heapifyDown();

        return r;
    }

    bool empty() { return size == 0; }
};

// Traffic Signal Management Class
// managing traffic signals for each intersection
// with priority queue for road management
// """
//      signalQueue:          priority queue for road management,
//      emergencyMode:        flag for emergency mode,
//      currentGreenDuration: duration of green signal
// """
class TrafficSignal
{
    PriorityQueue signalQueue;
    bool emergencyMode;
    int currentGreenDuration;

public:
    TrafficSignal() : emergencyMode(false), currentGreenDuration(30) {}

    void addRoad(char roadId, int vehicles, int wait)
    {
        signalQueue.push(roadId, vehicles, wait);
    }

    void setEmergencyMode(bool mode)
    {
        emergencyMode = mode;
    }

    char getNextGreenSignal()
    {
        if (signalQueue.empty())
            return '\0';
        auto current = signalQueue.pop();
        return current.id;
    }

    int getGreenDuration() const { return currentGreenDuration; }

    void setGreenDuration(int duration)
    {
        currentGreenDuration = duration;
    }
};

struct tupleNode
{
    char v1, v2;
    tupleNode *next;

    tupleNode(char v1, char v2) : v1(v1), v2(v2), next(nullptr) {}
};

struct tupleList
{
public:
    tupleNode *head;

    tupleList() { head = nullptr; }

    tupleNode *getHead() { return head; }

    ~tupleList()
    {
        tupleNode *current = head;
        while (current != nullptr)
        {
            tupleNode *temp = current;
            current = current->next;
            delete temp;
        }
    }

    void insert(char N1, char N2)
    {
        tupleNode *newNode = new tupleNode(N1, N2);
        newNode->next = head;
        head = newNode;
    }

    void deleteNode(char N1, char N2)
    {
        if (head == nullptr)
        {
            cout << "List is empty. Cannot delete." << endl;
            return;
        }

        if (head->v1 == N1 && head->v2 == N2)
        {
            tupleNode *temp = head;
            head = head->next;
            delete temp;
            return;
        }

        tupleNode *current = head;
        tupleNode *prev = nullptr;
        while (current && current->v1 == N1 && current->v2 == N2)
        {
            prev = current;
            current = current->next;
        }

        if (current == nullptr)
            return;

        prev->next = current->next;
        delete current;
    }

    void displayList()
    {
        tupleNode *current = head;
        while (current != nullptr)
        {
            cout << current->v1 << " to " << current->v2 << " -> blocked\n";
            current = current->next;
        }
    }

    bool find(char N1, char N2)
    {
        tupleNode *current = head;
        while (current != nullptr)
        {
            if (current->v1 == N1 && current->v2 == N2)
                return true;

            current = current->next;
        }
        return false;
    }
};

// Graph class for Road Network
// managing road network data
// """
//      AdjacencyList:        list of roads,
//      numVertices:          number of intersections,
//      emergencyVehicles:    list of emergency vehicles,
//      numEmergencyVehicles: number of emergency vehicles,
//      vehicles:             list of regular vehicles,
//      numVehicles:          number of regular vehicles,
//      signalTimings:        list of traffic signal timings,
//      numSignalTimings:     number of traffic signal timings,
//      intersections:        list of traffic signals
//      blockedRoads:         list of blocked roads
//      intersections:        list of traffic signals
// """
class Graph
{
public:
    List *AdjacencyList;
    int numVertices;

    EmergencyVehicle *emergencyVehicles;
    int numEmergencyVehicles;

    Vehicle *vehicles;
    int numVehicles;

    SignalTiming *signalTimings;
    int numSignalTimings;

    tupleList blockedRoads;
    TrafficSignal *intersections;

    // Macros
    int CONGESTION_THRESHOLD = 100;
    int MAX_VEHICLES = 100;
    int MAX_EMERGENCY = 50;
    int MAX_SIGNALS = 10;

    Graph(int n)
    {
        numVertices = n;
        AdjacencyList = new List[n];
        intersections = new TrafficSignal[n];

        // Initialize arrays with maximum sizes
        emergencyVehicles = new EmergencyVehicle[MAX_EMERGENCY];
        vehicles = new Vehicle[MAX_VEHICLES];
        signalTimings = new SignalTiming[MAX_SIGNALS];

        numEmergencyVehicles = 0;
        numVehicles = 0;
        numSignalTimings = 0;

        loadData();
    }

    ~Graph()
    {
        delete[] AdjacencyList;
        delete[] intersections;
        delete[] emergencyVehicles;
        delete[] vehicles;
        delete[] signalTimings;
    }

    void loadData()
    {
        loadRoadNetwork();
        loadEmergencyVehicles();
        loadVehicles();
        loadSignalTimings();
        loadClosures();
    }

    void loadRoadNetwork()
    {
        ifstream file("road_network.csv");
        if (!file.is_open())
        {
            cout << "Error opening file: road_network.csv" << endl;
            return;
        }

        string line;
        bool first = true;
        while (getline(file, line))
        {
            if (first)
            {
                first = false;
                continue;
            }

            stringstream ss(line);
            string col;

            getline(ss, col, ',');
            char S = col[0];

            getline(ss, col, ',');
            char D = col[0];

            getline(ss, col, ',');
            int time = stoi(col);

            insert(S, D, time);
        }
        file.close();
    }

    void loadEmergencyVehicles()
    {
        ifstream file("emergency_vehicles.csv");
        if (!file.is_open())
        {
            cout << "Error opening file: emergency_vehicles.csv" << endl;
            return;
        }

        string line;
        bool first = true;
        while (getline(file, line) && numEmergencyVehicles < MAX_EMERGENCY)
        {
            if (first)
            {
                first = false;
                continue;
            }

            stringstream ss(line);
            string col;

            getline(ss, col, ',');
            emergencyVehicles[numEmergencyVehicles].vehicleId = col;

            getline(ss, col, ',');
            emergencyVehicles[numEmergencyVehicles].startIntersection = col[0];

            // increment vehicle count on road
            int index = col[0] - 'A';
            if (index >= 0 && index < numVertices)
            {
                AdjacencyList[index].getHead()->vehicleCount++;
            }

            getline(ss, col, ',');
            emergencyVehicles[numEmergencyVehicles].endIntersection = col[0];

            getline(ss, col, ',');
            emergencyVehicles[numEmergencyVehicles].priorityLevel = col;

            numEmergencyVehicles++;
        }
        file.close();
    }

    void loadVehicles()
    {
        ifstream file("vehicles.csv");
        if (!file.is_open())
        {
            cout << "Error opening file: vehicles.csv" << endl;
            return;
        }

        string line;
        bool first = true;
        while (getline(file, line) && numVehicles < MAX_VEHICLES)
        {
            if (first)
            {
                first = false;
                continue;
            }

            stringstream ss(line);
            string col;

            getline(ss, col, ',');
            vehicles[numVehicles].vehicleId = col;

            getline(ss, col, ',');
            vehicles[numVehicles].startIntersection = col[0];

            // increment vehicle count on road
            int index = col[0] - 'A';
            if (index >= 0 && index < numVertices)
            {
                AdjacencyList[index].getHead()->vehicleCount++;
            }

            getline(ss, col, ',');
            vehicles[numVehicles].endIntersection = col[0];

            numVehicles++;
        }
        file.close();
    }

    void loadSignalTimings()
    {
        ifstream file("traffic_signals.csv");
        if (!file.is_open())
        {
            cout << "Error opening file: traffic_signals.csv" << endl;
            return;
        }

        string line;
        bool first = true;
        while (getline(file, line) && numSignalTimings < MAX_SIGNALS)
        {
            if (first)
            {
                first = false;
                continue;
            }

            stringstream ss(line);
            string col;

            getline(ss, col, ',');
            signalTimings[numSignalTimings].intersection = col[0];

            getline(ss, col, ',');
            signalTimings[numSignalTimings].greenTime = stoi(col);

            // Update intersection timing
            int index = signalTimings[numSignalTimings].intersection - 'A';
            if (index >= 0 && index < numVertices)
            {
                intersections[index].setGreenDuration(signalTimings[numSignalTimings].greenTime);
            }

            numSignalTimings++;
        }
        file.close();
    }

    void loadClosures()
    {
        ifstream file("road_closures.csv");
        if (!file.is_open())
        {
            cout << "Error opening file: road_closures.csv" << endl;
            return;
        }

        string line;
        bool first = true;
        while (getline(file, line))
        {
            if (first)
            {
                first = false;
                continue;
            }

            stringstream ss(line);
            string col;

            getline(ss, col, ',');
            char c1 = col[0];

            getline(ss, col, ',');
            char c2 = col[0];

            getline(ss, col, ',');
            string status = col;

            if (col == "Blocked")
                blockedRoads.insert(c1, c2);
        }

        file.close();
    }

    void processEmergencyVehicles()
    {
        if (numEmergencyVehicles == 0)
        {
            cout << "No emergency vehicles to process.\n";
            return;
        }

        for (int i = 0; i < numEmergencyVehicles; i++)
        {
            cout << "\nProcessing emergency vehicle " << emergencyVehicles[i].vehicleId << "\n";

            cout << "Emergency route from " << emergencyVehicles[i].startIntersection
                 << " to " << emergencyVehicles[i].endIntersection << ":\n";
            optimalPath(emergencyVehicles[i].startIntersection, emergencyVehicles[i].endIntersection);

            // remove vehice count on road
            int index = emergencyVehicles[i].startIntersection - 'A';
            if (index >= 0 && index < numVertices)
            {
                AdjacencyList[index].getHead()->vehicleCount--;
            }
        }
        numEmergencyVehicles = 0;
    }

    void processVehicles()
    {
        if (numVehicles == 0)
        {
            cout << "No vehicles to process.\n";
            return;
        }

        for (int i = 0; i < numVehicles; i++)
        {
            cout << "\nProcessing vehicle " << vehicles[i].vehicleId << ":\n";
            cout << "Route from " << vehicles[i].startIntersection
                 << " to " << vehicles[i].endIntersection << ":\n";
            optimalPath(vehicles[i].startIntersection, vehicles[i].endIntersection);

            // remove vehice count on road
            int index = vehicles[i].startIntersection - 'A';
            if (index >= 0 && index < numVertices)
            {
                AdjacencyList[index].getHead()->vehicleCount--;
            }
        }
        numVehicles = 0;
    }

    void insert(char V, char n, int time)
    {
        AdjacencyList[V - 65].insert(n, time);
    }

    void displayTrafficSignals()
    {
        for (int i = 0; i < numVertices; i++)
        {
            char intersection = char('A' + i);
            Node *current = AdjacencyList[i].getHead();

            while (current)
            {
                intersections[i].addRoad(
                    current->getVertex(),
                    current->getVehicleCount(),
                    current->getTravelTime());
                current = current->getNext();
            }

            char nextGreen = intersections[i].getNextGreenSignal();
            if (nextGreen != '\0')
            {
                cout << "Intersection " << intersection << " Green time: "
                     << intersections[i].getGreenDuration() << "s\n";
            }
        }
    }

    void displayCongestionStatus()
    {
        for (int i = 0; i < numVertices; i++)
        {
            char intersection = char('A' + i);
            Node *current = AdjacencyList[i].getHead();

            while (current)
            {
                if (current->getVehicleCount() > 0)
                {
                    cout << intersection << " to " << current->getVertex()
                         << " -> Vehicles: " << current->getVehicleCount() << endl;
                }
                current = current->getNext();
            }
        }
    }

    void optimalPath(char source, char destination)
    {
        if (blockedRoads.find(source, destination))
        {
            cout << "Road Blocked.";
            return;
        }

        Heap h(numVertices);

        int *distance = new int[numVertices];
        char *predesessor = new char[numVertices];
        char *path = new char[numVertices];

        for (int i = 0; i < numVertices; i++)
        {
            predesessor[i] = path[i] = '\0';
            distance[i] = INT_MAX;
        }

        distance[source - 65] = 0;
        h.push(source, 0);

        while (!h.empty())
        {
            Node curr = h.pop();

            Node *temp = AdjacencyList[curr.getVertex() - 65].getHead();
            while (temp)
            {
                if (blockedRoads.find(curr.getVertex(), temp->getVertex()))
                {
                    temp = temp->getNext();
                    continue;
                }

                // travel time
                int totalTime = curr.getTravelTime() + (temp->getTravelTime());

                if (totalTime < distance[temp->getVertex() - 65])
                {
                    distance[temp->getVertex() - 65] = totalTime;
                    predesessor[temp->getVertex() - 65] = curr.getVertex();
                    h.push(temp->getVertex(), distance[temp->getVertex() - 65]);
                }
                temp = temp->getNext();
            }
        }

        // cout << "\nShortest distances considering congestion:\n";
        // for (int i = 0; i < numVertices; i++)
        // {
        //     cout << "Distance from " << source << " to " << char(i + 65) << " is " << distance[i] << endl;
        // }

        cout << "\nOptimal path from " << source << " to " << destination << " is: ";
        for (char dest = destination, i = '0' - 48; dest != '\0'; dest = predesessor[dest - 65], i++)
        {
            path[int(i)] = dest;
        }

        if (path[1] == '\0')
        {
            cout << "\nRoad Blocked";
            path[0] = '\0';
        }

        for (int i = numVertices - 1; i >= 0; i--)
        {
            if (path[i] != '\0')
            {
                cout << path[i];
                if (i > 0)
                    cout << " -> ";
                Sleep(500); // 0.5 sec, for visualization
            }
        }
        cout << endl;

        delete[] distance;
        delete[] predesessor;
        delete[] path;
    }

    void display()
    {
        for (int i = 0; i < numVertices; i++)
        {
            cout << "[" << char(i + 65) << "] -> ";
            AdjacencyList[i].displayList();
        }
    }

    void blockRoad(char source, char destination)
    {
        blockedRoads.insert(source, destination);
    }

    void unblockRoad(char v1, char v2)
    {
        blockedRoads.deleteNode(v1, v2);
    }
};

int main()
{
    system("CLS");
    Graph RoadNetworks(26); // 26 intersections (A through Z)
    char choice;

    do
    {
        cout << "\n\n---------- Traffic Simulator ----------\n";
        cout << "1. Display Road Network\n";
        cout << "2. Display Traffic Signals\n";
        cout << "3. Display Congestion Status\n";
        cout << "4. Display Blocked Roads\n";
        cout << "5. Simulate Emergency Vehicle Routing\n";
        cout << "6. Block Road due to Accident\n";
        cout << "7. Simulate Vehicle Routing\n";
        cout << "8. Route custom vehicle\n";
        cout << "9. Exit Simulation\n";

        cout << "\nEnter your choice: ";
        choice = getch();

        switch (choice)
        {
        case '1':
            system("CLS");
            cout << "\nRoad Network State:\n";
            RoadNetworks.display();
            break;

        case '2':
            system("CLS");
            cout << "\nTraffic Signals:\n";
            RoadNetworks.displayTrafficSignals();
            break;

        case '3':
            system("CLS");
            cout << "\nCongestion Status:\n";
            RoadNetworks.displayCongestionStatus();
            break;

        case '4':
            system("CLS");
            cout << "\nBlocked Roads:\n";
            RoadNetworks.blockedRoads.displayList();
            break;

        case '5':
            system("CLS");
            cout << "\nProcessing Emergency Vehicles:\n";
            RoadNetworks.processEmergencyVehicles();
            break;

        case '6':
            system("CLS");
            char v1, v2;
            cout << "\nEnter road to block (e.g. B D): ";
            cin >> v1 >> v2;
            RoadNetworks.blockRoad(v1, v2);
            break;

        case '7':
            system("CLS");
            cout << "\nProcessing Regular Vehicles:\n";
            RoadNetworks.processVehicles();
            break;

        case '8':
            system("CLS");
            char start, end;
            cout << "\nEnter start and end intersection (e.g. A E): ";
            cin >> start >> end;
            RoadNetworks.optimalPath(start, end);
            break;

        case '9':
            cout << "\nExiting Simulation...\n";
            break;

        default:
            cout << "Invalid choice. Please try again.\n";
            break;
        }

    } while (choice != 9);

    cout << "\nSimulation Ended.\n";
    return 0;
}