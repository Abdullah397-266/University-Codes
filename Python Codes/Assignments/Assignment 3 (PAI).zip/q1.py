import pandas as pd

# % Functions
def DecideDay(key):
    day = ""
    if key == 1:
        day = "Monday"
    elif key == 2:
        day = "Tuesday"
    elif key == 3:
        day = "Wednesday"
    elif key == 4:
        day = "Thursday"
    elif key == 5:
        day = "Friday"
    elif key == 6:
        day = "Saturday"
    return day


# ? Loaded the data
timetable = pd.read_excel("TimeTable, FSC, Fall-2024.xlsx", [1, 2, 3, 4, 5, 6], header=4)  # 0 is Welcome sheet (dont need that)

# ? Cleaned the data
for key in timetable:
    timetable[key] = timetable[key].loc[:, ~timetable[key].columns.str.contains("^Unnamed")]

# print(timetable)

# sheet1LabDF = pd.read_excel("TimeTable, FSC, Fall-2024.xlsx", 1, header=41)
# print(sheet1LabDF)


# ? Query by subject
def find_classes(subject, sheet):
    rows = []
    for idx, row in sheet.iterrows():
        for col in sheet.columns[1:]:  # Skip the 'Room' column
            # Check if the cell starts with the subject name
            if isinstance(row[col], str) and row[col].startswith(subject):
                rows.append({"Room": row["Room"], "Time": col, "Class": row[col]})
    return pd.DataFrame(rows)

def Query_by_subject():
    subject = input("Enter subject name: ")

    dictionary = {}

    for key in timetable:
        day = DecideDay(key)
        df = find_classes(subject, timetable[key])
        dictionary[day] = df

    for key in dictionary:
        print(key, "\n", dictionary[key], "\n")


# ? Query by subject and day
def Query_by_subject_day():
    subject = input("Enter the subject name: ")
    day = input("Enter the day: ")

    if day.lower() == "monday":
        print("\n", find_classes(subject, timetable[1]))
    elif day.lower() == "tuesday":
        print("\n", find_classes(subject, timetable[2]))
    elif day.lower() == "wednesday":
        print("\n", find_classes(subject, timetable[3]))
    elif day.lower() == "thursday":
        print("\n", find_classes(subject, timetable[4]))
    elif day.lower() == "friday":
        print("\n", find_classes(subject, timetable[5]))
    elif day.lower() == "saturday":
        print("\n", find_classes(subject, timetable[6]))
    else:
        print("No classes Available OR Invalid input!")
        

#? Query Classes by Subject, Section, and Week
def Query_classes_by_subject_section_week():
    Query_by_subject()

#? Generate a Custom Timetable for a Batch
def Generate_custom_timetable_for_batch():
    batch_name = input("Enter batch name: ")


#?  Create a Teacher’s Timetable
def teachers_timetalbe():
    CA = pd.read_excel("Courses Allocation, FSC, FAST-NUCES, Islamabad, Fall-2024.xlsx", header=2)
    CA = CA.iloc[:, :6]
    CA = CA.fillna(-1)
    CA = CA.drop(columns=["CHs", "Code"])
    print(CA)

    instructorName = input("Enter the instructor name: ")
    sections = []
    courses = []

    CA = CA(CA['Course Instructor'] == instructorName)
    print(CA)


# ? Main
Query_by_subject()
Query_by_subject_day()
Query_classes_by_subject_section_week()
Generate_custom_timetable_for_batch()
teachers_timetalbe()
