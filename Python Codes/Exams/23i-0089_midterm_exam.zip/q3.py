import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import turtle as t
import math


mass = 1
initial_displacement = 1
initial_velocity = 0
spring_constant= 1
damping_coefficient = 0.1

time = 20 #sec
step = 0.01

def compute(mass, initial_displacement, initial_velocity, spring_constant, damping_coefficient, time, step):
    x = initial_displacement
    v = initial_velocity
    a = 0
    x_list = []
    v_list = []
    t_list = []
    for i in np.arange(0, time, step):
        a = (-spring_constant*x - damping_coefficient*v)/mass
        v = v + a*step
        x = x + v*step
        x_list.append(x)
        v_list.append(v)
        t_list.append(i)
    return x_list, v_list, t_list

x, v, t = compute(mass, initial_displacement, initial_velocity, spring_constant, damping_coefficient, time, step)


plt.plot(x,v)
plt.xlabel("Displacement")
plt.ylabel("Velocity")
plt.show()