import cv2
import numpy as np

input_video = cv2.VideoCapture("sunrise.mp4")
if not input_video.isOpened():
    print("Error: Could not open video.")

frame_width = int(input_video.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(input_video.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = int(input_video.get(cv2.CAP_PROP_FPS))

fourcc = cv2.VideoWriter_fourcc(*'mp4v')
output_video = cv2.VideoWriter("sunrise_output.mp4", fourcc, fps, (frame_width, frame_height))
output_video_gray = cv2.VideoWriter("sunrise_output.mp4", fourcc, fps, (frame_width, frame_height))

while True:
    ret, frame = input_video.read()
    if not ret:
        break  

    
    modified_frame = frame.copy()
    modified_frame[:frame_height//2] = cv2.flip(modified_frame[:frame_height//2], 1)
    output_video.write(modified_frame)

    GRAY = 0.2989*modified_frame[:,:,0] + 0.5870*modified_frame[:,:,1] + 0.1140*modified_frame[:,:,2]
    modified_frame[:,:,0] = GRAY
    modified_frame[:,:,1] = GRAY
    modified_frame[:,:,2] = GRAY
    output_video_gray.write(modified_frame)


input_video.release()
output_video.release()
cv2.destroyAllWindows()