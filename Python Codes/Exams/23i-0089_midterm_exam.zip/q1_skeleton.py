import turtle
import numpy as np
import time

screen = turtle.Screen()
screen.bgcolor("lightblue")
screen.title("Tower Defense Game")
screen.setup(width=800, height=600)

line_turtle = turtle.Turtle()
line_turtle.color("white")
line_turtle.speed(0)
line_turtle.pensize(20)

def draw_line(start_x, start_y, end_x, end_y):
    line_turtle.penup()
    line_turtle.goto(start_x, start_y)
    line_turtle.pendown()
    line_turtle.goto(end_x, end_y)

draw_line(-400, 70, 400, 70)
draw_line(-400, -120, 400, -120)
line_turtle.hideturtle()

global score, misses, total_shots
score = 0
misses = 0
total_shots = 0

score_display = turtle.Turtle()
score_display.hideturtle()
score_display.penup()
score_display.goto(0, 260)
score_display.write(f"Score: {score}  Misses: {misses}", align="center", font=("Arial", 16, "normal"))

class Tower(turtle.Turtle):
    def __init__(self):
        super().__init__()
        self.shape("square")
        self.color("black")
        self.penup()
        self.goto(0, 0)
        self.range = 200
        self.projectiles = []
        self.last_shot_time_dict = {}
        

class Enemy(turtle.Turtle):
    def __init__(self, x, y, speed):
        super().__init__()
        self.shape("circle")
        self.color("red")
        self.penup()
        self.goto(x, y)
        self.speed = speed
        self.radius = 10

    def move(self):
        self.forward(self.speed)

class Projectile(turtle.Turtle):
    def __init__(self, x, y, angle):
        super().__init__()
        self.shape("triangle")
        self.color("yellow")
        self.penup()
        self.goto(x, y)
        self.speed(0)
        self.setheading(np.degrees(angle))
        self.projectile_speed = 10

    def move(self):
        self.forward(self.projectile_speed)

    def check_collision(self, enemy):
        return self.distance(enemy) < (enemy.radius + 10)

def update_scoreboard():
    score_display.clear()
    score_display.write(f"Score: {score}  Misses: {misses}", align="center", font=("Arial", 16, "normal"))


tower = Tower()
enemies = [
    Enemy(-350, 70, 2),
    Enemy(-300, 70, 2),
    Enemy(-300, -120, 2)
]

game_running = True
while game_running:
    all_enemies_off_screen = True
    for enemy in enemies:
        enemy.move()
        if enemy.xcor() > 350:
            enemy.hideturtle()
        else:
            all_enemies_off_screen = False


        for projectile in tower.projectiles[:]:
            projectile.move()
            if projectile.check_collision(enemy):
                score
                score += 1
                projectile.hideturtle()
                tower.projectiles.remove(projectile)
                update_scoreboard()
            elif abs(projectile.xcor()) > 400 or abs(projectile.ycor()) > 300:
                misses
                misses += 1
                projectile.hideturtle()
                tower.projectiles.remove(projectile)
                update_scoreboard()

    if all_enemies_off_screen:
        game_running = False

        line_turtle.clear()
        score_display.clear()
        for enemy in enemies:
            enemy.hideturtle()
        tower.hideturtle()

        # accuracy
        accuracy = (score / total_shots) * 100 if total_shots > 0 else 0
        score_display.goto(0, 0)
        score_display.write(
            f"Game Over!!\nScore: {score}\nMisses: {misses}\nAccuracy: {accuracy:.2f}%",
            align="center",
            font=("Arial", 16, "normal")
        )

    time.sleep(0.05)

turtle.mainloop()
