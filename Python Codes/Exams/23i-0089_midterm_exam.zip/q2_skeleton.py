import turtle
import random

def draw_rectangle(t, x, y, width, height):
    t.penup()
    t.goto(x, y)
    t.pendown()
    for _ in range(2):
        t.forward(width)
        t.right(90)
        t.forward(height)
        t.right(90)

def is_collision(player, walls):
    for wall in walls:
        x, y, width, height = wall
        if (player.xcor() > x and player.xcor()  < x + width and
            player.ycor() > y - height and player.ycor() < y):
            return True
    return False

def is_at_goal(player, goal):
    gx, gy = goal 
    if abs(player.xcor() - gx) < 15 and abs(player.ycor() - gy) < 15:
        return True
    return False


wn = turtle.Screen()
wn.title("Mariam's Turtle Trainer")
wn.bgcolor("pink")

maze_turtle = turtle.Turtle()
maze_turtle.speed(0)  
maze_turtle.hideturtle()
# with open("maze_state.txt", "r") as file:
#     x, y, heading = file.read().split(",")
#     maze_turtle.goto(float(x), float(y))
#     maze_turtle.setheading(float(heading))

walls = [
    (-200, 200, 400, 20),  
    (-200, -200, 400, 20), 
    (-200, 200, 20, 400),  
    (180, 200, 20, 400),   

    (-160, 160, 320, 20), 
    (-160, 120, 20, 80),   
    (140, 120, 20, 80),   
    (-80, 40, 160, 20),   

    (-120, -40, 20, 100),  
    (100, -40, 20, 100),  
    (-60, -80, 120, 20),  

    (-40, -140, 80, 20), 
    (-40, -120, 20, 40),  
    (20, -120, 20, 40),  
]

for wall in walls:
    draw_rectangle(maze_turtle, wall[0], wall[1], wall[2], wall[3])

goal = turtle.Turtle()
goal.shape("circle")
goal.color("green")
goal.penup()
goal.goto(160, -180)

player = turtle.Turtle()
player.shape("turtle")
player.color("blue")
player.penup()
player.goto(-170, 170)

try:
    with open("maze_state.txt", "r") as file:
        x, y, heading = file.read().split(",")
        player.goto(float(x), float(y))
        player.setheading(float(heading))
except:
    with open("maze_state.txt", "w") as file:
        file.write(f"{player.xcor()},{player.ycor()},{player.heading()}")


def display_win_message():
    message_turtle = turtle.Turtle()
    message_turtle.hideturtle()
    message_turtle.penup()
    message_turtle.goto(0, 0)
    message_turtle.write("YOU WON!", align="center", font=("Arial", 24, "bold"))


def move_up():
    player.setheading(90)
    player.forward(20)
    if is_collision(player, walls):
        player.backward(20)
    if is_at_goal(player, goal.position()):
        display_win_message()

    with open("maze_state.txt", "w") as file:
        file.write(f"{player.xcor()},{player.ycor()},{player.heading()}")

def move_down():
    player.setheading(270)
    player.forward(20)
    if is_collision(player, walls):
        player.backward(20)
    if is_at_goal(player, goal.position()):
        display_win_message()

    with open("maze_state.txt", "w") as file:
        file.write(f"{player.xcor()},{player.ycor()},{player.heading()}")

def move_left():
    player.setheading(180)
    player.forward(20)
    if is_collision(player, walls):
        player.backward(20)
    if is_at_goal(player, goal.position()):
        display_win_message()
    
    with open("maze_state.txt", "w") as file:
        file.write(f"{player.xcor()},{player.ycor()},{player.heading()}")

def move_right():
    player.setheading(0)
    player.forward(20)
    if is_collision(player, walls):
        player.backward(20)
    if is_at_goal(player, goal.position()):
        display_win_message()

    with open("maze_state.txt", "w") as file:
        file.write(f"{player.xcor()},{player.ycor()},{player.heading()}")


wn.listen()
wn.onkey(move_up, "Up")
wn.onkey(move_down, "Down")
wn.onkey(move_left, "Left")
wn.onkey(move_right, "Right")

turtle.done()