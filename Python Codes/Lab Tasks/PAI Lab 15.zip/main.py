from flask import Flask, render_template, request, redirect, url_for, flash
import firebase_admin
from firebase_admin import credentials, firestore

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "abcdefghi"  # Replace with a strong secret key

# Initialize Firebase Admin SDK
cred = credentials.Certificate("key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Routes
@app.route("/")
def home():
    return redirect(url_for("login"))

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        # Check if user already exists
        user_ref = db.collection("users").document(email).get()
        if user_ref.exists:
            flash("User already exists! Please login.")
            return redirect(url_for("login"))

        # Save user data to Firebase
        db.collection("users").document(email).set({"email": email, "password": password})
        flash("Signup successful! Please login.")
        return redirect(url_for("login"))

    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        # Check user credentials
        user_ref = db.collection("users").document(email).get()
        if user_ref.exists:
            user_data = user_ref.to_dict()
            if user_data["password"] == password:  # Plaintext password comparison (not secure)
                flash("Login successful!")
                return redirect(url_for("dashboard"))
            else:
                flash("Incorrect password!")
        else:
            flash("User does not exist! Please sign up.")
            return redirect(url_for("signup"))

    return render_template("login.html")


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form["email"]

        # Check if user exists
        user_ref = db.collection("users").document(email).get()
        if user_ref.exists:
            flash(f"Password for {email}: {user_ref.to_dict()['password']}")
            return redirect(url_for("login"))
        else:
            flash("User does not exist! Please sign up.")
            return redirect(url_for("signup"))

    return render_template("forgot_password.html")


@app.route("/dashboard")
def dashboard():
    return "Welcome to your dashboard! (Protected Route)"

# Run the application
if __name__ == "__main__":
    app.run(debug=True)