import turtle
import random
import file_handling 


screen = turtle.Screen()
screen.title("Mariam's Collision Box")
screen.bgcolor("lightblue")
screen.setup(width=600, height=600)

player = turtle.Turtle()
player.shape("turtle")
player.color("green")
player.penup()
player.speed(0)
player.setposition(0, -250)

score = 0
score_display = turtle.Turtle()
score_display.hideturtle()
score_display.penup()
score_display.goto(0, 250)
score_display.write(f"Score: {score}", align="center", font=("Arial", 20, "normal"))

def move_left():
    x = player.xcor()
    x -= 20
    if x < -280:
        x = -280
    player.setx(x)

def move_right():
    x = player.xcor()
    x += 20
    if x > 280:
        x = 280
    player.setx(x)

screen.listen()
screen.onkey(move_left, "Left")
screen.onkey(move_right, "Right")


def create_obstacle():
    obs = turtle.Turtle()
    obs.shape("circle")
    obs.color("red")
    obs.penup()
    obs.speed(0)
    obs.setposition(random.randint(-290, 290), random.randint(100, 290))
    obs.dy = -3 
    return obs

obstacles = [create_obstacle()]

game_over = False
while not game_over:
    for obstacle in obstacles:
        obstacle.sety(obstacle.ycor() + obstacle.dy)

        if obstacle.ycor() < -300: 
            obstacle.setposition(random.randint(-290, 290), random.randint(100, 290))

            new_obstacle = create_obstacle()
            obstacles.append(new_obstacle)

            score += 1
            score_display.clear()
            score_display.write(f"Score: {score}", align="center", font=("Arial", 20, "normal"))

        if player.distance(obstacle) < 20:
            print("Collision detected!")
            game_over = True
            break

# Save score to file
file_handling.save_score(score)


player.hideturtle()
for obstacle in obstacles:
    obstacle.hideturtle()

score_display.goto(0, 0)
score_display.write(f"Game Over", align="center", font=("Arial", 24, "normal"))

# Display previous scores
score_display.goto(0, -50)
previous_scores = file_handling.read_scores()
score_display.write("Previous Scores:", align="center", font=("Arial", 16, "normal"))

y = -80
for prev_score in previous_scores:
    score_display.goto(0, y)
    score_display.write(f"Score: {prev_score}", align="center", font=("Arial", 14, "normal"))
    y -= 20

screen.exitonclick()
