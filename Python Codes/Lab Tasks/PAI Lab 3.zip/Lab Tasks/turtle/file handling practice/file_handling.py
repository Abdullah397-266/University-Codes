
def save_score(score, filename="scores.txt"):
    with open(filename, "a") as file:
        file.write(f"{score}\n")

def read_scores(filename="scores.txt"):
    try:
        with open(filename, "r") as file:
            scores = file.readlines()
    except FileNotFoundError:
        scores = []
    return [int(score.strip()) for score in scores]
