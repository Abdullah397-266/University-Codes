import turtle

# Draw a triangle using what we have learned in file2
def draw_rectangle(t, x, y, width, height):
    t.penup()
    t.goto(x, y)
    t.pendown()
    for _ in range(2):
        t.forward(width)
        t.right(90)
        t.forward(height)
        t.right(90)


#def is_collision(player, walls):
    

#def is_goal(player, goal):



wn = turtle.Screen()
wn.title("Mariam's Turtle Trainer")
wn.bgcolor("pink")

# Create "turtle" (pen) for drawing the maze
maze_turtle = turtle.Turtle()
maze_turtle.speed(0)  # Fastest drawing speed
maze_turtle.hideturtle()

# Draw the maze walls
walls = [
    # Outer walls: format is x, y, height, width
    (-200, 200, 400, 20),   #top wall
    (-200, -200, 400, 20),  #bottom wall
    (-200, 200, 20, 400),   #left wall
    (180, 200, 20, 400),    #right wall

    (-160, 160, 320, 20),   #inner top wall
    (-160, 120, 20, 80),    #left vertical wall
    (140, 120, 20, 80),     #right vertical wall
    (-80, 40, 160, 20),     #middle horizontal wall

    (-120, -40, 20, 100),   #left vertical wall
    (100, -40, 20, 100),    #right vertical wall
    (-60, -80, 120, 20),    #bottom horizontal wall

    (-40, -140, 80, 20),    #bottom middle horizontal wall-snippet
    (-40, -120, 20, 40),    #bottom left vertical wall-snippet
    (20, -120, 20, 40),     #bottom right vertical wall-snippet
]

for wall in walls:
    draw_rectangle(maze_turtle, wall[0], wall[1], wall[2], wall[3])

#goal
goal = turtle.Turtle()
goal.shape("circle")
goal.color("green")
goal.penup()
goal.goto(160, -180)

#turtle
player = turtle.Turtle()
player.shape("turtle")
player.color("blue")
player.penup()
player.goto(-170, 170)


def display_win_message():
    message_turtle = turtle.Turtle()
    message_turtle.hideturtle()
    message_turtle.penup()
    message_turtle.goto(0, 0)
    message_turtle.write("YOU WON!", align="center", font=("Arial", 24, "bold"))


def move_up():
    player.setheading(90)
    player.forward(20)

def move_down():
    player.setheading(270)
    player.forward(20)

def move_left():
    player.setheading(180)
    player.forward(20)

def move_right():
    player.setheading(0)
    player.forward(20)


wn.listen()
wn.onkey(move_up, "Up")
wn.onkey(move_down, "Down")
wn.onkey(move_left, "Left")
wn.onkey(move_right, "Right")


turtle.done()


#TASK 1: Implement collision handling
#TASK 2: Implement winning the game when the goal is reached
#TASK 3: Make the turtle take random actions until it reaches the goal (for the sake of demonstration, you can make the maze smaller)
#TASK 4: Mark the path the turtle takes to the goal
#TASK 5: Implement a score system using file handling where each new player is assigned a unique serial number and their score is saved against that number in a file. 
# When the game is over, read all the previous scores and display them