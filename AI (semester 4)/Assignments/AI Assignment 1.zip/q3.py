from os import system
from time import sleep

class Wumpus_agent:
    def __init__(self):
        self.grid = [
            ["Pacman", "┊", "Cherry", "┊", "Pellet", "|", "Cherry"],
            ["------", "|", "━━━━━━", "|", "━━━━━━", "|", "------"],
            ["Pellet", "|", "Ghost", "|", "Pellet", "|", "Cherry"],
            ["------", "|", "━━━━━━", "|", "━━━━━━", "|", "━━━━━━"],
            ["Cherry", "|", "Pellet", "┊", "Cherry", "|", "Ghost"],
            ["━━━━━━", "|", "━━━━━━", "|", "━━━━━━", "|", "------"],
            ["Cherry", "┊", "Pellet", "|", "Ghost", "|", "Pellet"],
        ]
        self.start_position = self.current_position = [0, 0] # top-left
        self.task_completed = False
        self.left = self.right = self.up = self.down = ""
        self.can_move_left = self.can_move_right = self.can_move_up = self.can_move_down = False
        self.pellets = 6
        self.eaten_by_ghost = False
        self.eaten_cherry = False

    def move_left(self):
        if self.current_position[1] > 0:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[1] -= 2
            self.grid[self.current_position[0]][self.current_position[1]] = "Pacman"
            return
        
    def move_right(self):
        if self.current_position[1] < 6:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[1] += 2
            self.grid[self.current_position[0]][self.current_position[1]] = "Pacman"
            return
        
    def move_up(self):
        if self.current_position[0] > 0:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[0] -= 2
            self.grid[self.current_position[0]][self.current_position[1]] = "Pacman"
            return
        
    def move_down(self):
        if self.current_position[0] < 6:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[0] += 2
            self.grid[self.current_position[0]][self.current_position[1]] = "Pacman"
            return

    def obtain_surronding_info(self):
        # right
        if self.current_position[1] < 6:
            if self.grid[self.current_position[0]][self.current_position[1]+1] != '|':
                self.right = self.grid[self.current_position[0]][self.current_position[1] + 2]
                self.can_move_right = True
            else:
                self.can_move_right = False
                self.right = "Unknown"

        # left
        if self.current_position[1] > 0:
            if self.grid[self.current_position[0]][self.current_position[1]-1] != '|':
                self.left = self.grid[self.current_position[0]][self.current_position[1] - 2]
                self.can_move_left = True
            else:
                self.can_move_left = False
                self.left = "Unknown"

        # up
        if self.current_position[0] > 0:
            if self.grid[self.current_position[0]-1][self.current_position[1]] != '━━━━━━':
                self.up = self.grid[self.current_position[0] - 2][self.current_position[1]]
                self.can_move_up = True
            else:
                self.can_move_up = False
                self.up = "Unknown"

        # down
        if self.current_position[0] < 6:
            if self.grid[self.current_position[0]+1][self.current_position[1]] != '━━━━━━':
                self.down = self.grid[self.current_position[0] + 2][self.current_position[1]]
                self.can_move_down = True
            else:
                self.can_move_down = False
                self.down = "Unknown"

    def print_grid(self):
        system("cls")
        print(f"Current Position: [{self.current_position[0]//2}, {self.current_position[1]//2}]")
        print("Pellets left: ", self.pellets)
        for row in self.grid:
            print(row)
        sleep(2)

    def activate_agent(self):
        while True:
            if not self.task_completed:
                self.print_grid()

            if self.eaten_by_ghost:
                print("FAILURE, Eaten by ghost")
                return
            
            if self.pellets == 0:
                self.task_completed = True
                print("SUCCESS, All pellets eaten")
                return
            
            self.obtain_surronding_info()
            # priority: pellet > cherry > ghost > empty
            if self.down == "Pellet":
                if self.can_move_down:
                    self.move_down()
                    self.pellets -= 1
            elif self.right == "Pellet":
                if self.can_move_right:
                    self.move_right()
                    self.pellets -= 1
            elif self.up == "Pellet":
                if self.can_move_up:
                    self.move_up()
                    self.pellets -= 1
            elif self.left == "Pellet":
                if self.can_move_left:
                    self.move_left()
                    self.pellets -= 1

            elif self.down == "Cherry":
                if self.can_move_down:
                    self.move_down()
                    self.eaten_cherry = True
            elif self.right == "Cherry":
                if self.can_move_right:
                    self.move_right()
                    self.eaten_cherry = True
            elif self.up == "Cherry":
                if self.can_move_up:
                    self.move_up()
                    self.eaten_cherry = True
            elif self.left == "Cherry":
                if self.can_move_left:
                    self.move_left()
                    self.eaten_cherry = True

            elif self.down == "Ghost" and self.eaten_cherry:
                if self.can_move_down:
                    self.move_down()
                    self.eaten_cherry = False
            elif self.right == "Ghost" and self.eaten_cherry:
                if self.can_move_right:
                    self.move_right()
                    self.eaten_cherry = False
            elif self.up == "Ghost" and self.eaten_cherry:
                if self.can_move_up:
                    self.move_up()
                    self.eaten_cherry = False
            elif self.left == "Ghost" and self.eaten_cherry:
                if self.can_move_left:
                    self.move_left()
                    self.eaten_cherry = False

            elif self.down == "Empty":
                if self.can_move_down:
                    self.move_down()
            elif self.right == "Empty":
                if self.can_move_right:
                    self.move_right()
            elif self.up == "Empty":
                if self.can_move_up:
                    self.move_up()
            elif self.left == "Empty":
                if self.can_move_left:
                    self.move_left()

def main():
    agent = Wumpus_agent()
    agent.activate_agent()

main()