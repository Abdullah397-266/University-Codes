diseases = {
    "Acute Appendicitis": {
        "symptoms": ["fever", "pain in abdomen", "vomiting"],
        "tests": {"tlc": "high", "dlc neutrophils": "high", "esr": "high"},
        "treatment": "Surgery",
    },
    "Pneumonia": {
        "symptoms": ["fever", "cough", "chestpain"],
        "tests": {
            "tlc": "high",
            "dlc neutrophils": "high",
            "esr": "high",
            "x-ray chest": "pneumonic patch",
        },
        "treatment": "Antibiotics",
    },
    "Acute Tonsillitis": {
        "symptoms": ["fever", "cough"],
        "tests": {"red enlarged tonsils": "present", "pus in tonsils": "present"},
        "treatment": "Anti-allergic + Paracetamol. If not cured: Add antibiotics orally. If still not cured: Add IV antibiotics.",
    }
}

def diagnose_disease(symptoms, tests):
    for disease in diseases:
        if diseases[disease]["symptoms"] == symptoms and diseases[disease]["tests"] == tests:
            treatment = diseases[disease]["treatment"]
            return disease, treatment
    return "Disease not found", None

def take_input():
    symptoms = input("Enter symptoms (comma seprated): ").lower().replace(" ","").split(",")
    tests = input("Enter tests (comma seprated): ").lower().split(", ")

    # formatting the data
    testsDict = {}
    for test in tests:
        if "dlc" in test:
            if 'high' in test:
                testsDict["dlc neutrophils"] = "high"
            else:
                testsDict["dlc neutrophils"] = "low"
        elif "tlc" in test:
            if 'high' in test:
                testsDict["tlc"] = "high"
            else:
                testsDict["tlc"] = "low"
        elif "esr" in test:
            if 'high' in test:
                testsDict["esr"] = "high"
            else:
                testsDict["esr"] = "low"
        elif "x-ray" in test:
            if 'pneumonic patch' in test:
                testsDict["x-ray chest"] = "pneumonic patch"
        elif "red enlarged tonsils" in test:
            if 'present' in test:
                testsDict["red enlarged tonsils"] = "present"
        elif "pus in tonsils" in test:
            if 'present' in test:
                testsDict["pus in tonsils"] = "present"

    # print(symptoms, testsDict)
    return symptoms, testsDict

def main():
    symptoms, tests = take_input()
    disease, treatment = diagnose_disease(symptoms, tests)
    print(f"\nDiagonesed Disease: {disease}")
    print(f"Recommended Treatment: {treatment}")

main()