from queue import PriorityQueue as PQ

def uniform_cost_search(crossing_times):
    bank_A = PQ()
    total_people = len(crossing_times)
    for time in crossing_times:
        bank_A.put(time)
    bank_B = PQ()
    total_time = 0

    while True:
        fastest_1 = bank_A.get()
        fastest_2 = bank_A.get()
        bank_B.put(fastest_1)
        bank_B.put(fastest_2)
        total_time += fastest_2
        print(f"({fastest_1}, {fastest_2}) cross -> Time: {total_time}")
        if bank_B.qsize() == total_people:
            break
        else:
            bank_A.put(bank_B.get())
            total_time += fastest_1
            print(f"({fastest_1}) return -> Time: {total_time}")

    return total_time


# Example usage
crossing_times = list(map(int, input("Enter the crossing times of the four tourists: ").split()))
# print("crossing_times:", crossing_times)
total_time = uniform_cost_search(crossing_times)
print("Total time taken:", total_time)
