from os import system
from time import sleep

class Wumpus_agent:
    def __init__(self):
        self.grid = [
            ["Agent", "Empty", "Empty", "Pit",],
            ["Empty", "Gold", "Empty", "Empty"],
            ["Empty", "Empty", "Wumpus", "Pit"],
            ["Empty", "Empty", "Pit", "Empty"],
        ]
        self.start_position = self.current_position = [0, 0] # top-left
        self.has_gold = False
        self.reached_start = False
        self.eaten_by_wumpus = False
        self.fell_in_pit = False
        self.task_completed = False
        self.moves = 50
        self.movement_stack = []
        self.left = self.right = self.up = self.down = ""

    def move_left(self):
        if self.current_position[1] > 0:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[1] -= 1
            self.grid[self.current_position[0]][self.current_position[1]] = "Agent"
            if not self.has_gold:
                self.movement_stack.append("left")
            return
        
    def move_right(self):
        if self.current_position[1] < 3:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[1] += 1
            self.grid[self.current_position[0]][self.current_position[1]] = "Agent"
            if not self.has_gold:
                self.movement_stack.append("right")
            return
        
    def move_up(self):
        if self.current_position[0] > 0:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[0] -= 1
            self.grid[self.current_position[0]][self.current_position[1]] = "Agent"
            if not self.has_gold:
                self.movement_stack.append("up")
            return
        
    def move_down(self):
        if self.current_position[0] < 3:
            self.grid[self.current_position[0]][self.current_position[1]] = "Empty"
            self.current_position[0] += 1
            self.grid[self.current_position[0]][self.current_position[1]] = "Agent"
            if not self.has_gold:
                self.movement_stack.append("down")
            return

    def obtain_surronding_info(self):
        if self.current_position[1] > 0:
            self.left = self.grid[self.current_position[0]][self.current_position[1] - 1]
        else:
            self.left = "Wall"
        
        if self.current_position[1] < 3:
            self.right = self.grid[self.current_position[0]][self.current_position[1] + 1]
        else:
            self.right = "Wall"
        
        if self.current_position[0] > 0:
            self.up = self.grid[self.current_position[0] - 1][self.current_position[1]]
        else:
            self.up = "Wall"

        if self.current_position[0] < 3:
            self.down = self.grid[self.current_position[0] + 1][self.current_position[1]]
        else:
            self.down = "Wall"

    def print_grid(self):
        system("cls")
        print("Current Position: ", self.current_position)
        print("Moves left: ", self.moves)
        for row in self.grid:
            print(row)
        sleep(2)

    def backtrack(self):
        while self.movement_stack:
            movement = self.movement_stack.pop()
            if movement == "left":
                self.move_right()
            elif movement == "right":
                self.move_left()
            elif movement == "up":
                self.move_down()
            elif movement == "down":
                self.move_up()
            self.moves -= 1
            self.print_grid()

    def activate_agent(self):
        while True:
            if not self.task_completed:
                self.print_grid()

            if self.moves == 0:
                print("FAILURE, Out of moves")
                return

            if self.eaten_by_wumpus:
                print("FAILURE, Eaten by Wumpus")
                return

            if self.fell_in_pit:
                print("FAILURE, Fell in pit")
                return

            if self.task_completed:
                print("SUCCESS, Task completed")
                return
            
            self.obtain_surronding_info()
            if not self.has_gold:
                if self.left == "Gold":
                    self.move_left()
                    self.has_gold = True
                elif self.right == "Gold":
                    self.move_right()
                    self.has_gold = True
                elif self.up == "Gold":
                    self.move_up()
                    self.has_gold = True
                elif self.down == "Gold":
                    self.move_down()
                    self.has_gold = True
                elif self.down == "Empty":
                    self.move_down()
                elif self.right == "Empty":
                    self.move_right()
                elif self.up == "Empty":
                    self.move_up()
                elif self.left == "Empty":
                    self.move_left()
            self.moves -= 1

            if self.has_gold:
                self.print_grid()
                self.backtrack()
                self.task_completed = True

            if self.grid[self.current_position[0]][self.current_position[1]] == "Wumpus":
                self.eaten_by_wumpus = True

            if self.grid[self.current_position[0]][self.current_position[1]] == "Pit":
                self.fell_in_pit = True

def main():
    agent = Wumpus_agent()
    agent.activate_agent()

main()