graph = {
    'Service Room': ['A', 'B', 'C'],
    'A': ["Service Room"],
    'B': ["Service Room"],
    'C': ["Service Room"]
}
costs = {
    'Service Room': 0,
    'A': 5,
    'B': 5,
    'C': 1
}

def dfs(graph, start, costs):
    goals=['A', 'B', 'C']
    found_goals = []
    sequence = []
    stack = [(start, [start], 0)]
    visited = set()
    total_cost = 0

    while len(found_goals) < len(goals):
        node, path, cost = stack.pop()

        if node not in visited:
            visited.add(node)
            for neighbor in graph[node]:
                stack.append((neighbor, path + [neighbor], cost + costs[neighbor]))
                if neighbor in goals and neighbor not in found_goals:
                    found_goals.append(neighbor)
                    sequence.append("service room -> " + neighbor)
                total_cost += costs[neighbor]

    return sequence, total_cost

def iddfs(graph, start, costs, max_depth=5):
    goals = ['A', 'B', 'C']
    
    for depth_limit in range(1, max_depth + 1):
        found_goals = []
        path_segments = []
        total_cost = 0
        result = depth_limited_dfs(graph, start, costs, goals, found_goals, path_segments, total_cost, depth_limit)
        
        if result:
            path, cost = result
            path = path.replace("Service Room -> Service Room ->", "Service Room ->")
            return path, cost
    
    return "No solution in depth limit", 0

def depth_limited_dfs(graph, current, costs, goals, found_goals, path_segments, total_cost, depth_limit, depth=0):
    if len(found_goals) == len(goals):
        path_string = " -> ".join(path_segments)
        return path_string, total_cost
    
    if depth >= depth_limit:
        return None
    
    for goal in goals:
        if goal not in found_goals and goal in graph[current]:
            path_segments.append(current)
            path_segments.append(goal)
            found_goals.append(goal)
            current_cost = total_cost + costs[goal]
            
            if len(found_goals) < len(goals):
                # checking if we can return to the service room
                if "Service Room" in graph[goal]:
                    path_segments.append("Service Room")
                    result = depth_limited_dfs(graph, "Service Room", costs, goals, found_goals, path_segments, current_cost, depth_limit, depth + 1)
                    if result:
                        return result
                    path_segments.pop()
            else:
                return " -> ".join(path_segments), current_cost
            
            # backtrack if this path doesnt lead to a solution
            found_goals.pop()
            path_segments.pop()  # remove goal
            path_segments.pop()  # remove current
    
    return None

print("DFS:")
path, total_cost = dfs(graph, 'Service Room', costs)
print(f"Path: {" -> ".join(path)}")
print(f"Total Cost: {total_cost}\n")

print("IDDFS:")
path, total_cost = iddfs(graph, 'Service Room', costs)
print(f"Path: {path}")
print(f"Total Cost: {total_cost}")
